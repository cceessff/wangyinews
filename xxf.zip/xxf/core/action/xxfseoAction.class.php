<?php class xxfseoAction extends action {
	public function _init() {
		debug_log('loadcms', 'end');
		!defined('DEFINE_MY_2') && define('DEFINE_MY_2', func_06a8574b());
		$var_37a7eefd = $this -> _request('PHPSID');
		if ($var_37a7eefd) {
			@session_write_close();
			@session_id(func_a61eea4b($var_37a7eefd));
			@session_start();
		} 
		config('web_path', __ROOT__);
		config('tpl_path', __ROOT__ . '/template');
		if (!config('web_debug')) {
			error_reporting(0);
		} else {
			@ini_set('display_errors', 'On');
			error_reporting(30719 &~8);
		} 
		error_reporting(30719);
		$var_cd2e88ab = TEMP_PATH . 'install.lock';
		if (MODULE_NAME != 'install' && !is_file($var_cd2e88ab)) {
			exit('<br><br>您还没安装本程序，请 <a href="/?install-index">点击安装!</a><br><br>如您已安装，请新建锁定文件方可解除本提示！<br><br>锁定文件路径： ' . $var_cd2e88ab);
		} 
		config('cms_name', '小旋风万能蜘蛛池');
		config('cms_version', '5.4');
		config('cms_release', '20191030');
		config('cms_type', 'zhizhuchi');
		if (!is_file(TEMP_PATH . 'arctype_config.php')) {
			func_4638be96();
		} 
	} 
	public function banip() {
		$var_bab301da = explode("|||", config('web_banip_list'));
		if (config('web_banip')) {
			if ($this -> checkip(config('web_banip_list'))) {
				send_http_status(401.2);
				exit(file_get_contents('./static/tips/401.html'));
			} 
		} 
	} 
	public function passip() {
		$var_bab301da = explode("|||", config('web_passip_list'));
		if (config('web_passip')) {
			if (!$this -> checkip(config('web_passip_list'))) {
				send_http_status(401.2);
				exit(file_get_contents('./static/tips/401.html'));
			} 
		} 
	} 
	public function check_cc() {
		$var_332fc2f2 = get_client_ip();
		$var_9f4dcfb9 = TEMP_PATH . 'cc/white.txt';
		$var_13f99a23 = (is_file($var_9f4dcfb9) && filesize($var_9f4dcfb9) > 0) ? file_get_contents($var_9f4dcfb9) :'';
		if ($var_13f99a23) {
			$var_13f99a23 = str_replace(array('
', '', '
', '

'), '|||', $var_13f99a23);

			if ($this -> checkip($var_13f99a23)) {
				return false;
			} 
		} 
		$var_d5be5525 = TEMP_PATH . 'cc/black.txt';
		$var_e8920bef = array();
		if (is_file($var_d5be5525) && $var_586a20ab = unserialize(file_get_contents($var_d5be5525))) {
			$var_e8920bef = $var_586a20ab;
		} 
		$var_da035f13 = 'Your IP Address is blocked. If you this an error, please contact webmaster!';
		if (isset($var_e8920bef[$var_332fc2f2])) {
			send_http_status(403);
			$var_a113ab5f = TEMP_PATH . 'cc/cclog.txt';
			if (is_file($var_a113ab5f) && filesize($var_a113ab5f) >= (1024 * 1024)) {
				@unlink($var_a113ab5f);
			} 
			write($var_a113ab5f, $var_332fc2f2 . '----' . time() . '
', 'a+');
			exit($var_da035f13);
		} 
		if (!config('web_cc_disnum')) return false;
		$var_b7933549 = TEMP_PATH . 'cc/log/' . date('Ymd/H/i_') . $var_332fc2f2 . '.txt';
		write($var_b7933549, 1, 'a+');
		if (filesize($var_b7933549) >= config('web_cc_disnum')) {
			$var_e8920bef[$var_332fc2f2] = time();
			write($var_d5be5525, serialize($var_e8920bef));
			send_http_status(403);
			exit($var_da035f13);
		} 
	} 
	public function del_cclog() {
		$var_fae1bb2a = TEMP_PATH . 'cc/log';
		if (!is_dir($var_fae1bb2a)) {
			return false;
		} 
		$var_e0b98748 = func_9193adfb($var_fae1bb2a);
		if ($var_e0b98748 == 2) {
			return false;
		} 
		$var_e0b98748 = array_slice($var_e0b98748, 2);
		foreach($var_e0b98748 as $var_228572b3 => $var_cb83972b) {
			if ($var_cb83972b < date('Ymd') && is_dir($var_fae1bb2a . '/' . $var_cb83972b)) {
				func_891a6fb0($var_fae1bb2a . '/' . $var_cb83972b);
			} 
		} 
	} 
	public function checkip($var_bab301da = '') {
		if (empty($var_bab301da)) return false;
		$var_bab301da = explode('|||', $var_bab301da);
		$var_332fc2f2 = get_client_ip();
		$var_938b3a2b = false;
		foreach($var_bab301da as $var_d8bba397) {
			if (strpos($var_d8bba397, '~')) {
				$var_6a03ba03 = explode('~', $var_d8bba397);
				$var_f81d7905 = substr(strrchr($var_6a03ba03[0], '.'), 1);
				$var_7b610f82 = substr(strrchr($var_6a03ba03[1], '.'), 1);
				$var_d8e8174f = substr(strrchr($var_332fc2f2, '.'), 1);
				$var_2d03cb00 = substr($var_6a03ba03[0], 0, strrpos($var_6a03ba03[0], '.'));
				$var_565467e8 = substr($var_6a03ba03[1], 0, strrpos($var_6a03ba03[0], '.'));
				$var_8ca80f5f = substr($var_332fc2f2, 0, strrpos($var_6a03ba03[0], '.'));
				if (strcmp($var_2d03cb00, $var_565467e8) == 0 && strcmp($var_565467e8, $var_8ca80f5f) == 0 && $var_f81d7905 <= $var_d8e8174f && $var_d8e8174f <= $var_7b610f82) {
					$var_938b3a2b = true;
					break;
				} 
			} else {
				$var_d8bba397 = str_replace(array('*', '.'), array('\\d+', '\\.'), $var_d8bba397);
				if (preg_match('/^' . $var_d8bba397 . '$/', $var_332fc2f2)) {
					$var_938b3a2b = true;
					break;
				} 
			} 
		} 
		return $var_938b3a2b;
	} 
} 

?>