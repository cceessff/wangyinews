<?php class plusAction extends xxfseoAction {
	public function _init() {
		parent :: _init();
	} 
} 

?>