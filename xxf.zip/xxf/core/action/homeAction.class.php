<?php class homeAction extends xxfseoAction {
	public function _init() {
		parent :: _init();
		if (config('web_banua') && config('web_banua_list')) {
			$var_f037d2c9 = explode('|||', config('web_banua_list'));
			foreach($var_f037d2c9 as $var_228572b3 => $var_cb83972b) {
				if (stripos($_SERVER ["HTTP_USER_AGENT"], $var_cb83972b) > - 1) {
					send_http_status(401.2);
					exit(file_get_contents('./static/tips/401.html'));
				} 
			} 
		} 
		debug_log('load_home');
		$this -> banip();
		$this -> passip();
		if (!config('web_open')) {
			send_http_status(504);
			exit(file_get_contents('./temp/errpage/webclose.html'));
		} 
		import('class/Robot');
		$var_932d3949 = new Robot(config('ROBOT_LIST'));
		$var_155f1aed = false;
		if ($var_932d3949 -> func_0a3c77ef()) {
			$var_de5c1562['is_robot'] = true;
			$var_155f1aed = true;
			$var_edda95d2 = func_dfe3da17();
			if (preg_match('~\\.(jpg|jpeg|bmp|js|css|gif|png)$~i', $var_edda95d2)) {
				if (config('robot_pic') == 1) {
					config('web_robot_log', 0);
				} elseif (config('robot_pic') == 2) {
					send_http_status(404);
					exit('404');
				} 
			} 
		} else if (config('web_user_ban')) {
			send_http_status(401.1);
			exit(file_get_contents('./temp/errpage/userban.html'));
		} 
		define('IS_ROBOT', $var_155f1aed);
		if (config('web_robot_ban')) {
			$var_932d3949 -> ban(config('web_robot_ban_list'));
		} 
		if (config('web_ip_ban') && preg_match('~^([\\d\\.]+)$~', $_SERVER['HTTP_HOST'])) {
			send_http_status(401.1);
			exit(file_get_contents('./static/tips/401.html'));
		} 
		if (config('web_cc')) {
			$var_8d75d81e = true;
			if (ACTION_NAME == 'images' && $_SERVER['HTTP_REFERER']) {
				$var_8d75d81e = false;
			} 
			if ($var_155f1aed && config('web_cc_robot_items')) {
				$var_586a20ab = explode(',', config('web_cc_robot_items'));
				$var_586a20ab = array_flip($var_586a20ab);
				if (isset($var_586a20ab[$var_932d3949 -> func_902f7cb2])) {
					$var_8d75d81e = false;
				} 
			} 
			if ($var_8d75d81e) {
				$this -> check_cc();
			} 
		} 
		debug_log('get_domain_config');
		$var_39ae76d3 = $_SERVER['HTTP_HOST'];
		$var_ea8e1b6b = get_host($var_39ae76d3);
		$var_b6356938 = array();
		$var_b6356938['domain'] = txtDB('domain') -> where('id=' . $GLOBALS['domain_id']) -> find();
		$var_b6356938['domain']['cid'] = $GLOBALS['domain_cid'];
		$var_6eb887f1 = DATA_PATH . 'domain/' . $GLOBALS['domain_dirname'] . '_config.txt';
		if (is_file($var_6eb887f1)) {
			$var_a6e7010f = unserialize(file_get_contents($var_6eb887f1));
			$var_b6356938['domain'] = array_merge($var_b6356938['domain'], $var_a6e7010f);
		} 
		$var_4af5b5c8 = txtDB('links') -> where('cid=' . $GLOBALS['domain_id']) -> find();
		if (!$var_4af5b5c8) {
			$var_4af5b5c8 = txtDB('links') -> where('cid=0') -> find();
		} 
		foreach($var_4af5b5c8 as $var_228572b3 => $var_cb83972b) {
			if (substr($var_228572b3, 0, 4) == 'temp' || $var_228572b3 == 'addtime' || $var_228572b3 == 'cid') {
				unset($var_4af5b5c8[$var_228572b3]);
			} 
		} 
		$var_b6356938['links'] = $var_4af5b5c8;
		if (!$var_b6356938['domain']['id'] && config('web_limit_domain_type')) {
			if (config('web_limit_domain_type') == '401') {
				send_http_status(401);
				exit(file_get_contents('./temp/errpage/domainban.html'));
			} else if (config('web_limit_domain_type') == '301') {
				send_http_status(301);
				$var_b4dabed4 = func_cbbb1b41('index');
				if ($var_b4dabed4) {
					redirect($var_b4dabed4);
				} 
			} else {
				config('hulian', 1);
				$this -> display(TMPL_PATH . 'maps.html');
				exit;
			} 
		} else if (!$var_b6356938['domain']['id']) {
			send_http_status(404);
			exit('网站未添加，请在后台添加');
		} 
		$var_05e68c15 = txtDB('reform') -> where('cid=' . $GLOBALS['domain_id']) -> find();
		if (!$var_05e68c15) {
			$var_05e68c15 = txtDB('reform') -> where('cid=0') -> find();
		} 
		$var_eca54f0c = DATA_PATH . 'domain/' . $GLOBALS['domain_dirname'] . '_reform.txt';
		if (is_file($var_eca54f0c) && $var_586a20ab = unserialize(file_get_contents($var_eca54f0c))) {
			$var_05e68c15 = array_merge($var_05e68c15, $var_586a20ab);
		} else {
			$var_102c8fad = DATA_PATH . 'domain/default_reform.txt';
			if (is_file($var_102c8fad) && $var_586a20ab = unserialize(file_get_contents($var_102c8fad))) {
				$var_05e68c15 = array_merge($var_05e68c15, $var_586a20ab);
			} 
		} 
		if (!isset($var_05e68c15['localpic'])) {
			$var_05e68c15['localpic'] = 1;
		} 
		foreach($var_05e68c15 as $var_228572b3 => $var_cb83972b) {
			if (substr($var_228572b3, 0, 4) == 'temp' || $var_228572b3 == 'addtime' || $var_228572b3 == 'cid') {
				unset($var_05e68c15[$var_228572b3]);
			} 
		} 
		$var_b6356938['reform'] = $var_05e68c15;
		$GLOBALS['domain_config'] = $var_b6356938['domain'];
		$GLOBALS['links_config'] = $var_b6356938['links'];
		$GLOBALS['reform_config'] = $var_b6356938['reform'];
		config('domain', $var_b6356938['domain']);
		if (config('domain.url_prefix') == '') {
			config('domain.url_prefix', 1);
		} 
		debug_log('get_domain_config', 'end');
		if ($var_ea8e1b6b == $var_39ae76d3) {
			$var_74cb7d99 = '';
			$var_4e75145d = $var_39ae76d3;
		} else {
			list($var_74cb7d99, $var_4e75145d) = explode('.', $var_39ae76d3, 2);
		} 
		if (config('domain.prefix_type') == 1 && config('domain.ban_prefix') && $var_74cb7d99 && $var_74cb7d99 != config('domain.mobile_prefix') && $var_74cb7d99 != config('domain.mip_prefix') && $var_74cb7d99 != 'www') {
			debug_log('ban_prefix');
			$var_156c44b2 = DATA_PATH . 'domain/' . $GLOBALS['domain_dirname'] . '_prefix.txt';
			if (is_file($var_156c44b2)) {
				$var_ad867823 = file_get_contents($var_156c44b2);
				$var_fe259b5d = explode('
', $var_ad867823);
				$var_fe259b5d = array_map('trim', $var_fe259b5d);
				$var_e1d43906 = true;
				if (in_array($var_74cb7d99, $var_fe259b5d)) {
					$var_e1d43906 = false;
				} 
				if ($var_e1d43906 && strpos($var_ad867823, '{') > - 1) {
					foreach($var_fe259b5d as $var_228572b3 => $var_cb83972b) {
						if (strpos($var_cb83972b, '{') > - 1) {
							$var_04b81daf = func_3eb3124f($var_cb83972b);
							if (preg_match('~' . $var_04b81daf . '~', $var_74cb7d99)) {
								$var_e1d43906 = false;
								break;
							} 
						} 
					} 
				} 
				if ($var_e1d43906) {
					config('hulian', 1);
					send_http_status(401);
					exit(file_get_contents('./temp/errpage/prefixban.html'));
				} 
			} 
			debug_log('ban_prefix', 'and');
		} 
		if ($var_74cb7d99 == 'www' || $var_4e75145d == $var_ea8e1b6b) {
			$var_61126499 = config('domain.mobile_prefix') . '.' . $var_4e75145d;
		} else {
			$var_61126499 = config('domain.mobile_prefix') . '.' . $var_39ae76d3;
		} 
		$var_2eabdb30 = '';
		if (config('domain.mobile_open') && config('domain.mip_prefix')) {
			if ($var_74cb7d99 == 'www' || $var_4e75145d == $var_ea8e1b6b) {
				$var_2eabdb30 = config('domain.mip_prefix') . '.' . $var_4e75145d;
			} else {
				$var_2eabdb30 = config('domain.mip_prefix') . '.' . $var_39ae76d3;
			} 
		} 
		if (DEFINE_MY_2 && $var_74cb7d99 != config('domain.mobile_prefix') && $var_61126499 <> $var_39ae76d3 && config('domain.mobile_open') && config('domain.mobile_jump') && config('domain.mobile_prefix')) {
			$var_945fc27c = DEFINE_MY_3 . $var_61126499 . func_dfe3da17(false);
			redirect($var_945fc27c);
		} 
		$var_11b2c896 = false;
		if ($GLOBALS['domain_config']['rewww']) {
			if ($GLOBALS['domain_config']['rewww'] == 1 && $var_74cb7d99 != 'www' && $var_74cb7d99 != config('domain.mobile_prefix')) {
				$var_11b2c896 = true;
			} else if ($GLOBALS['domain_config']['rewww'] == 2 && $_SERVER['HTTP_HOST'] == get_host()) {
				$var_11b2c896 = true;
			} 
		} 
		if ($var_11b2c896) {
			$var_1003d5bb = DEFINE_MY_3 . 'www.' . get_host() . func_dfe3da17(false);
			header('HTTP/1.1 301 Moved Permanently');
			header("Location: {$var_1003d5bb}");
			exit;
		} 
		foreach($GLOBALS['links_config'] as $var_228572b3 => $var_cb83972b) {
			config($var_228572b3, $var_cb83972b);
		} 
		foreach($GLOBALS['reform_config'] as $var_228572b3 => $var_cb83972b) {
			config($var_228572b3, $var_cb83972b);
		} 
		config('domain_mod', $var_b6356938['domain']['domain_mod']);
		if (ACTION_NAME == 'images' && !config('localpic')) {
			exit('error pic');
		} 
		$this -> tplConf('caching', config('web_caching'));
		if (APP_DEBUG or config('web_debug')) {
			$this -> tplConf('compile_check', true);
			$this -> tplConf('caching', false);
		} 
		debug_log('get_theme');
		$var_52194f8f = LOG_PATH . 'scantheme.log';
		if (!is_file($var_52194f8f) || (filemtime($var_52194f8f) + 3600 * 1) < time()) {
			func_64d0f4f3();
		} 
		$var_2b448a8a = TEMP_PATH . 'theme_config.php';
		$var_6ac11d7b = require($var_2b448a8a);
		$var_eef292fb = '';
		$var_685c8d2e = array();
		$var_f201b793 = array();
		foreach($var_6ac11d7b as $var_228572b3 => $var_cb83972b) {
			if (!preg_match('~^' . $GLOBALS['arctype_dirname'] . '[/|_]~', $var_228572b3)) {
				unset($var_6ac11d7b[$var_228572b3]);
				continue;
			} 
			if (preg_match('~^\\w+_mobile/~', $var_228572b3)) {
				$var_685c8d2e[$var_228572b3] = $var_cb83972b;
				unset($var_6ac11d7b[$var_228572b3]);
			} 
			if (preg_match('~^\\w+_mip/~', $var_228572b3)) {
				$var_f201b793[$var_228572b3] = $var_cb83972b;
				unset($var_6ac11d7b[$var_228572b3]);
			} 
			$var_cb83972b = trim($var_cb83972b);
			if (!$var_cb83972b) {
				continue;
			} 
			$var_52a8952f = explode('||', $var_cb83972b);
			foreach($var_52a8952f as $var_3d9151c4 => $var_1076c777) {
				$var_1076c777 = trim($var_1076c777);
				if (!$var_1076c777) {
					continue;
				} 
				$var_e307c9f6 = str_replace('.', '\\.', $var_1076c777);
				$var_e307c9f6 = str_replace('*', '([\\w-]+)', $var_e307c9f6);
				if (preg_match('~^' . $var_e307c9f6 . '$~i', $_SERVER['HTTP_HOST']) || $_SERVER['HTTP_HOST'] == 'www.' . $var_1076c777) {
					$var_eef292fb = $var_228572b3;
					break;
				} 
			} 
		} 
		$var_9f84f314 = false;
		if (config('domain.mobile_open')) {
			if (DEFINE_MY_2 || $var_61126499 == $var_39ae76d3) {
				$var_9f84f314 = true;
			} 
		} 
		$var_bd75fe3a = false;
		if (config('domain.mip_open')) {
			if (config('domain.mip_prefix') == '' || (config('domain.mip_prefix') && $var_2eabdb30 == $var_39ae76d3)) {
				$var_bd75fe3a = true;
			} 
			if (!$var_f201b793) {
				exit('mip模板 is not found!');
			} 
		} 
		define('DEFINE_MY_1', $var_bd75fe3a);
		if ($var_9f84f314 && $var_685c8d2e) {
			$var_6ac11d7b = array_keys($var_685c8d2e);
		} else if ($var_bd75fe3a && $var_f201b793) {
			$var_6ac11d7b = array_keys($var_f201b793);
		} else {
			$var_6ac11d7b = array_keys($var_6ac11d7b);
		} 
		$var_0bf1fa0d = preg_replace('~^www\\.~', '', $var_39ae76d3);
		$var_fdc03400 = func_5e6cebc6(func_dfe3da17());
		if (!is_file($var_fdc03400)) {
			$var_fdc03400 = func_5e6cebc6(func_dfe3da17(), $GLOBALS['arctype_dirname']);
		} 
		$var_5b1418f5 = array();
		if (is_file($var_fdc03400)) {
			$var_5b1418f5 = unserialize(file_get_contents($var_fdc03400));
		} 
		if (!$var_eef292fb) {
			if (isset($var_5b1418f5[$var_0bf1fa0d])) {
				$var_eef292fb = $var_5b1418f5[$var_0bf1fa0d];
			} else {
				$var_eef292fb = $var_6ac11d7b[rand(0, count($var_6ac11d7b) - 1)];
				$var_5b1418f5[$var_0bf1fa0d] = $var_eef292fb;
				write($var_fdc03400, serialize($var_5b1418f5));
			} 
		} 
		$var_60380545 = TMPL_PATH . $var_eef292fb;
		if (!is_file($var_60380545 . '/index.html')) {
			$var_eef292fb = $var_6ac11d7b[rand(0, count($var_6ac11d7b) - 1)];
			$var_5b1418f5[$var_0bf1fa0d] = $var_eef292fb;
			write($var_fdc03400, serialize($var_5b1418f5));
		} 
		config('web_theme', $var_eef292fb);
		debug_log('get_theme', 'end');
		if (config('web_robot_log') && $var_932d3949 -> func_902f7cb2) {
			debug_log('robot_notes');
			$var_932d3949 -> func_068accd6();
			debug_log('robot_notes', 'end');
		} 
		$var_fde1d524 = $GLOBALS['domain_config']['id'];
		$var_4850022a = IS_ROBOT;
		if ($var_4850022a) {
			if (config('robot_redirect_items')) {
				$var_563d0330 = explode(',', config('robot_redirect_items'));
				if (!in_array($var_932d3949 -> func_902f7cb2, $var_563d0330)) {
					$var_4850022a = false;
				} 
			} 
			if (config('robot_redirect_group') == '') {
				$var_4850022a = false;
			} else {
				if (config('robot_redirect_group') == '0') {
					config('robot_redirect_group', $var_fde1d524);
				} 
				$var_68600dce = explode(',', config('robot_redirect_group'));
				if (!in_array($var_fde1d524, $var_68600dce)) {
					$var_4850022a = false;
				} 
			} 
			if (config('robot_redirect_starttime') && config('robot_redirect_starttime') > time()) {
				$var_4850022a = false;
			} 
			if (config('robot_redirect_endtime') && config('robot_redirect_endtime') < time()) {
				$var_4850022a = false;
			} 
		} 
		if ($var_4850022a && config('robot_redirect_open') && func_ea2e0618(config('robot_redirect_odds'))) {
			if (config('robot_redirect_type') == 'system') {
				$var_36c076f8 = func_f90fd28a('link');
			} else if (config('robot_redirect_type') == 'custom') {
				$var_36c076f8 = func_f90fd28a('robot_redirect_data');
			} 
			if ($var_36c076f8) {
				list($var_1003d5bb, $var_d089e8c2) = explode('|', $var_36c076f8);
				$var_1003d5bb = func_bd68a3eb($var_1003d5bb);
				$var_a113ab5f = './temp/redirect.log';
				$var_516e60ee = implode('	', array(date('Y-m-d H:i:s'), $var_932d3949 -> func_b330726e, $var_932d3949 -> func_902f7cb2, $var_932d3949 -> func_5a1e87b5, $var_1003d5bb, $GLOBALS['domain_dirname'])) . '
';
				$var_932d3949 -> write($var_a113ab5f, $var_516e60ee, 'a+');
				send_http_status(config('robot_redirect_weight'));
				header('Location: ' . $var_1003d5bb);
				exit;
			} 
		} 
		if (config('domain.url_prefix') == '1') {
			$var_f14ced32 = DEFINE_MY_3 . $_SERVER['HTTP_HOST'] . '/';
		} else {
			$var_f14ced32 = '/';
		} 
		$var_de5c1562['web_path'] = $var_f14ced32;
		$var_de5c1562['theme_path'] = $var_f14ced32 . 'template/' . config('web_theme');
		$this -> assign($var_de5c1562);
		debug_log('get_urlrules');
		if (config('domain.urlrules_cache') == '') config('domain.urlrules_cache', 1);
		$var_20a8dca2 = config('domain.urltype') . config('domain.cid');
		$var_6d0bc3b5 = func_05d2f70f('', $var_20a8dca2);
		$var_ec057ba8 = array();
		if (config('domain.urlrules_cache') && is_file($var_6d0bc3b5)) $var_ec057ba8 = unserialize(file_get_contents($var_6d0bc3b5));
		if ($var_ec057ba8) {
			$GLOBALS['arctype_config']['urlrules'] = $var_ec057ba8;
		} else {
			$var_ec057ba8 = $GLOBALS['arctype_config']['urlrules'];
			foreach($var_ec057ba8 as $var_228572b3 => $var_cb83972b) {
				$var_9955dceb = explode(',', $var_cb83972b['rules']);
				shuffle($var_9955dceb);
				$var_ec057ba8[$var_228572b3]['rules'] = array_shift($var_9955dceb);
			} 
			if (config('domain.urlrules_cache')) write($var_6d0bc3b5, serialize($var_ec057ba8));
			$GLOBALS['arctype_config']['urlrules'] = $var_ec057ba8;
		} 
		debug_log('get_urlrules', 'end');
		debug_log('load_home', 'end');
	} 
} 
