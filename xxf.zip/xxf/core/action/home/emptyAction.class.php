<?php class emptyAction extends homeAction {
	public function _init() {
		parent :: _init();
	} 
	public function _empty($var_6c1a8580, $var_583d62cb) {
		ob_start();
		debug_log('load_empty');
		debug_log('set_replace_compile');
		$this -> set_replace_compile('{主标题}', '{$title}');
		$this -> set_replace_compile('{主关键词}', '{$keywords}');
		$this -> set_replace_compile('{网站名称}', '{$web_name}');
		$this -> set_replace_compile('{网站地址}', '{$web_url}');
		$this -> set_replace_compile('{当前地址}', '{$thisurl}');
		$this -> set_replace_compile('{当前栏目}', '{$typename}');
		$this -> set_replace_compile('{当前栏目URL}', '{$typeurl}');
		$this -> set_replace_compile('{随机栏目}', '{typename type="name"/}');
		$this -> set_replace_compile('{随机栏目URL}', '{typename type="url"/}');
		$this -> set_replace_compile('{随机标题}', '{getone name="title" cacheid="rand"/}');
		$this -> set_replace_compile('{随机内容URL}', '{function name="get_url" args="show"/}');
		$this -> set_replace_compile('{随机句子}', '{getone name="content" cacheid="rand"/}');
		for($var_7ea74e20 = 1;$var_7ea74e20 <= 100;$var_7ea74e20++) {
			$this -> set_replace_compile('{固定句子' . $var_7ea74e20 . '}', '{getone name="content" cacheid="' . $var_7ea74e20 . '"/}');
		} 
		$this -> set_replace_compile('{随机关键词}', '{getone name="keywords" cacheid="rand"/}');
		for($var_7ea74e20 = 1;$var_7ea74e20 <= 100;$var_7ea74e20++) {
			$this -> set_replace_compile('{固定关键词' . $var_7ea74e20 . '}', '{getone name="keywords" cacheid="' . $var_7ea74e20 . '"/}');
		} 
		$this -> set_replace_compile('{模板路径}', '{$theme_path}');
		$this -> set_replace_compile('{当前域名}', '{$host}');
		$this -> set_replace_compile('{当前顶级域名}', '{function name="get_host"/}');
		$this -> set_replace_compile('{随机泛域名}', '{随机泛域名前缀}.{随机顶级域名}');
		$this -> set_replace_compile('{随机顶级域名}', '{getone name="domain" cacheid="rand"/}');
		$this -> set_replace_compile('{随机泛域名前缀}', '{function name="get_rand_prefix"/}');
		for($var_7ea74e20 = 1;$var_7ea74e20 <= 100;$var_7ea74e20++) {
			$this -> set_replace_compile('{固定顶级域名' . $var_7ea74e20 . '}', '{getone name="domain" cacheid="' . $var_7ea74e20 . '"/}');
		} 
		$this -> set_replace_compile('{联系地址}', '{省份城市}{道路}{全局固定数字3}号');
		$this -> set_replace_compile('{联系电话}', '0{全局固定数字2}-{全局固定数字8}');
		$this -> set_replace_compile('{联系邮箱}', '{全局固定数字9}@{全局固定数字3}.com');
		$this -> set_replace_compile('{发布时间}', '{$postdate}');
		$this -> set_replace_compile('{当天日期}', '{date("Y-m-d")}');
		$this -> set_replace_compile('{日期时间}', '{date("Y-m-d H:i:s")}');
		$this -> set_replace_compile('{昨天日期}', '{date("Y-m-d",strtotime("-1 day"))}');
		$this -> set_replace_compile('{前天日期}', '{date("Y-m-d",strtotime("-2 day"))}');
		$this -> set_replace_compile('{随机时间}', '{rand(0,24)}:{rand(10,59)}');
		$this -> set_replace_compile('{主内容}', '{$body}');
		$this -> set_replace_compile('{随机图片}', '{getone name="pic" cacheid="rand"/}');
		$this -> set_replace_compile('{随机视频}', '{getone name="video" cacheid="rand"/}');
		$this -> set_replace_compile('{随机网站名称}', '{getone name="webname" cacheid="rand"/}');
		for($var_7ea74e20 = 1;$var_7ea74e20 <= 100;$var_7ea74e20++) {
			$this -> set_replace_compile('{全局固定数字' . $var_7ea74e20 . '}', '{function name="get_num_gd" args="' . $var_7ea74e20 . ',1"/}');
		} 
		for($var_7ea74e20 = 1;$var_7ea74e20 <= 100;$var_7ea74e20++) {
			$this -> set_replace_compile('{全局固定字符' . $var_7ea74e20 . '}', '{function name="get_str_gd" args="' . $var_7ea74e20 . ',1"/}');
		} 
		for($var_7ea74e20 = 1;$var_7ea74e20 <= 100;$var_7ea74e20++) {
			$this -> set_replace_compile('{固定数字' . $var_7ea74e20 . '}', '{function name="get_num_gd" args="' . $var_7ea74e20 . '"/}');
		} 
		$this -> set_replace_compile('{随机数字}', '{randstr type="2" num="1,5"/}');
		$this -> set_replace_compile('{随机字母}', '{randstr type="3" num="1,5"/}');
		$this -> set_replace_compile('{随机外链}', '{function name="get_rand_link"/}');
		$this -> set_replace_compile('{统计代码}', '{$web_tongji}');
		$this -> set_replace_compile('{百度推送代码}', '{$web_bdpush}');
		$this -> set_replace_compile('{分享代码}', '{$web_share}');
		$this -> set_replace_compile('{运行时间}', '{_runtime("loadTime","end")}');
		$this -> set_replace_compile('{运行内存}', '{$usememory}');
		$this -> set_replace_compile('{省份城市}', '{getone name=\'common/chengshi\' cacheid="$host" global="1"/}');
		$this -> set_replace_compile('{道路}', '{getone name=\'common/daolu\' cacheid="$host" global="1"/}');
		$this -> set_replace_compile('{产品栏目URL}', '{geturl tpl=\'product_list\'/}');
		$this -> set_replace_compile('{联系我们URL}', '{geturl tpl=\'contact\'/}');
		$this -> set_replace_compile('{人才招聘URL}', '{geturl tpl=\'job_list\'/}');
		$this -> set_replace_compile('{公司简介URL}', '{geturl tpl=\'about\'/}');
		$this -> set_replace_compile('{产品名称}', '{$typename}{产品型号}');
		$this -> set_replace_compile('{产品型号}', '{function name="get_product_num" args="$thisurl"/}');
		$this -> set_replace_compile('{产品说明}', '{function name="get_product_licence" args="$typename"/}');
		$this -> set_replace_compile('{公司简介短}', '{function name="get_company_about" args="0"/}');
		$this -> set_replace_compile('{公司简介长}', '{function name="get_company_about" args="1"/}');
		debug_log('set_replace_compile', 'end');
		$this -> assign(config());
		$var_edda95d2 = func_dfe3da17();
		$var_fde1d524 = $GLOBALS['domain_config']['id'];
		$var_a3e5f0ff = preg_replace('~^https?://www\\.~', 'http://', $var_edda95d2);
		$var_a3e5f0ff = preg_replace('~^https?://' . config('domain.mobile_prefix') . '\\.~', 'http://', $var_a3e5f0ff);
		if (config('hulian_group') == '0') {
			config('hulian_group', $var_fde1d524);
		} 
		$var_41d638be = explode(',', config('hulian_group'));
		if (!in_array($var_fde1d524, $var_41d638be)) {
			config('hulian', false);
		} 
		if ($var_6c1a8580 == 'index' && isset($_GET['m']) && !preg_match('~[\\w]+~', '', $_GET['m'])) {
			$var_6c1a8580 = 'show';
		} 
		$var_c24ab4b7 = TMPL_PATH . config('web_theme') . '/' . $var_6c1a8580 . '.html';
		if (!is_file($var_c24ab4b7)) {
			$var_6c1a8580 = 'show';
			$var_c24ab4b7 = TMPL_PATH . config('web_theme') . '/' . $var_6c1a8580 . '.html';
			if (!is_file($var_c24ab4b7)) {
				$var_6c1a8580 = 'index';
			} 
			$var_c24ab4b7 = TMPL_PATH . config('web_theme') . '/' . $var_6c1a8580 . '.html';
		} 
		$this -> tplConf('cache_dir', CACHE_PATH . 'html/' . $var_6c1a8580 . '/' . config('web_theme') . '/');
		if (!in_array($var_6c1a8580, array('index', 'list', 'show'))) {
			$var_1760c6e3 = config('cache_lifetime_other');
			$this -> tplConf('cache_dir', CACHE_PATH . 'html/other/' . config('web_theme') . '/');
		} 
		$var_28b87417 = $var_6c1a8580;
		if (substr($var_6c1a8580, - 5) == '_list') {
			$var_28b87417 = 'list';
		} else if (substr($var_6c1a8580, - 5) == '_show') {
			$var_28b87417 = 'show';
		} 
		!$var_1760c6e3 && $var_1760c6e3 = config('cache_lifetime_' . $var_28b87417);
		$this -> tplConf('cache_id', md5($var_a3e5f0ff));
		$this -> tplConf('cache_lifetime', $var_1760c6e3);
		$this -> tplConf('template_dir', TMPL_PATH . config('web_theme'));
		$this -> tplConf('compile_dir', TPLCACHE_PATH . config('web_theme'));
		if (!$var_1760c6e3) {
			$this -> tplConf('caching', false);
		} 
		$GLOBALS['cache_fileid_file'] = TEMP_PATH . 'cache_fileid/' . get_host() . '/' . getHashDir($_SERVER['HTTP_HOST'], 1) . '/' . $_SERVER['HTTP_HOST'] . '.txt';
		if (config('fileid_cache_open') && is_file($GLOBALS['cache_fileid_file'])) {
			$GLOBALS['fileid_cache'] = unserialize(file_get_contents($GLOBALS['cache_fileid_file']));
		} 
		$var_ad986296 = false;
		if (config('cache_lifetime_tkd')) {
			debug_log('get_tdk_cache');
			$var_c3430b33 = func_21ca168e(func_dfe3da17());
			if (is_file($var_c3430b33) && (config('cache_lifetime_tkd') * 3600 + filemtime($var_c3430b33)) >= time()) {
				$var_de5c1562 = unserialize(file_get_contents($var_c3430b33));
				$var_ad986296 = true;
				config('replace_title', 0);
				config('reform_title', 0);
				config('insertkw_index', 0);
				config('insertkw2title', 0);
			} 
			debug_log('get_tdk_cache', 'end');
		} 
		$var_de5c1562['web_url'] = DEFINE_MY_3 . $_SERVER['HTTP_HOST'] . '/';
		$var_de5c1562['rand_class'] = substr(md5($var_a3e5f0ff), 6, 8);
		$var_71e9f77f = $this -> _get('cid');
		$var_bcb69771 = $this -> _get('aid');
		debug_log('get_cachetitle');
		if ($var_71e9f77f == '') {
			$var_d6f40d08 = func_50afa725('title', func_b0d73e82($var_a3e5f0ff));
			if ($var_28b87417 == 'list') {
				$var_88b11eeb = func_50afa725('typename', func_b0d73e82($var_a3e5f0ff));
			} else {
				$var_88b11eeb = func_50afa725('typename', func_b0d73e82($var_a3e5f0ff));
			} 
		} else {
			if ($var_bcb69771) {
				$var_d6f40d08 = func_bc498d0f($var_28b87417, 'title', $var_71e9f77f, $var_bcb69771, $var_a3e5f0ff);
				$var_88b11eeb = func_bc498d0f($var_28b87417, 'typename', $var_71e9f77f, $var_bcb69771, $var_a3e5f0ff);
			} else {
				$var_d6f40d08 = func_157faedc($var_28b87417, 'title', $var_71e9f77f, $var_a3e5f0ff);
				$var_88b11eeb = func_157faedc($var_28b87417, 'typename', $var_71e9f77f, $var_a3e5f0ff);
			} 
		} 
		debug_log('get_cachetitle', 'end');
		$var_de5c1562['cachetypename'] = $var_88b11eeb;
		if (config('replace_group') == '0') {
			config('replace_group', $var_fde1d524);
		} 
		$var_e1045f5e = explode(',', config('replace_group'));
		if (!in_array($var_fde1d524, $var_e1045f5e)) {
			config('replace_title', false);
			config('replace_content', false);
		} 
		if (config('insertkw_group') == '0') {
			config('insertkw_group', $var_fde1d524);
		} 
		$var_299eb652 = explode(',', config('insertkw_group'));
		if (!in_array($var_fde1d524, $var_299eb652)) {
			config('insertkw_odds', 0);
		} 
		$var_cef96c25 = TEMP_PATH . 'tplrules/' . $GLOBALS['arctype_dirname'];
		if (!is_file($var_cef96c25 . '/title_index.txt')) {
			$var_cef96c25 = TEMP_PATH . 'tplrules/default';
		} 
		$var_c19c9998 = '。、！？：；﹑•＂…‘’“”〝〞∕¦‖—　〈〉﹞﹝「」‹›〖〗】【»«』『〕〔》《﹐¸﹕︰﹔！¡？¿﹖﹌﹏﹋＇´ˊˋ―﹫︳︴¯＿￣﹢﹦﹤‐­˜﹟﹩﹠﹪﹡﹨﹍﹉﹎﹊ˇ︵︶︷︸︹︿﹀︺︽︾ˉ﹁﹂﹃﹄︻︼（）';
		$var_46f4a929 = array('/[[:punct:]]/i', '/[' . $var_c19c9998 . ']/u', '/[ ]{2,}/');

		if (!$this -> isCached()) {
			$var_a3e5f0ff = func_b0d73e82($var_a3e5f0ff);
			$var_de5c1562['thisurl'] = $var_edda95d2;
			if (!$var_ad986296) {
				$var_071730f9 = preg_replace('~^www\\.~', '', $_SERVER['HTTP_HOST']);
				$var_071730f9 = preg_replace('~^' . config('domain.mobile_prefix') . '\\.~', '', $var_071730f9);
				debug_log('get_webname');
				if (config('auto_make_webname') && $GLOBALS['arctype_dirname'] == 'company') {
					$var_de5c1562['web_name'] = func_9324d7a8();
				} else {
					$var_de5c1562['web_name'] = func_50afa725('webname', func_b0d73e82($var_071730f9));
				} 
				debug_log('get_webname', 'end');
				$var_de5c1562['web_name_source'] = $var_de5c1562['web_name'];
				$var_de5c1562['title'] = $var_d6f40d08;
				if (config('replace_title')) {
					debug_log('replace_title');
					$var_de5c1562['title'] = func_96d84c92($var_de5c1562['title']);
					debug_log('replace_title', 'end');
				} 
				if (config('reform_title')) {
					debug_log('reform_title');
					$var_5fd387f1 = iconv_strlen($var_de5c1562['title'], 'utf-8');
					$var_2407a687 = array($var_de5c1562['title']);
					for($var_7ea74e20 = 0;$var_7ea74e20 < 10;$var_7ea74e20++) {
						$var_17934e5a = $var_7ea74e20;
						if ($var_7ea74e20 == 0) {
							$var_17934e5a = '';
						} 
						$var_2407a687[] = trim(func_50afa725('title', $var_a3e5f0ff . $var_17934e5a));
					} 
					if (config('reform_title') == 1) {
						$var_de5c1562['title'] = func_93b08060(implode('', $var_2407a687));
						$var_de5c1562['title'] = iconv_substr($var_de5c1562['title'], 0, $var_5fd387f1, 'utf-8');
						$var_de5c1562['title'] = preg_replace($var_46f4a929, '', $var_de5c1562['title']);
					} else if (config('reform_title') == 2) {
						$var_de5c1562['title'] = $var_2407a687[0] . ' ' . $var_2407a687[1];
					} 
					debug_log('reform_title', 'end');
				} 
				$var_de5c1562['title'] = trim($var_de5c1562['title']);
			} 
			!$var_de5c1562['content'] && $var_de5c1562['content'] = func_50afa725('content', $var_a3e5f0ff);
			if (config('tobig5')) {
				debug_log('tobig5_tkd');
				import('class/Trans');
				$var_fa6bf187 = new Trans;
				$var_de5c1562['content'] = $var_fa6bf187 -> c2t($var_de5c1562['content']);
				$var_de5c1562['title'] = $var_fa6bf187 -> c2t($var_de5c1562['title']);
				$var_de5c1562['web_name'] = $var_fa6bf187 -> c2t($var_de5c1562['web_name']);
				$var_88b11eeb = $var_fa6bf187 -> c2t($var_88b11eeb);
				debug_log('tobig5_tkd', 'end');
			} 
			if ($var_28b87417 == 'show') {
				$var_740b54fa = func_50afa725($var_cef96c25 . '/body.txt', $var_a3e5f0ff, '||||||', false);
				if (config('domain.bodytype') == 1) {
					debug_log('get_body');
					$GLOBALS['this_getbody'] = true;
					if (config('domain.urltype') == 2) {
						$var_e9d40129 = func_bc498d0f($var_28b87417, 'article', $var_71e9f77f, $var_bcb69771, $var_edda95d2);
					} else {
						$var_e9d40129 = func_157faedc($var_28b87417, 'article', $var_71e9f77f, $var_edda95d2);
					} 
					$GLOBALS['this_getbody'] = false;
					if (config('replace_content')) {
						$var_e9d40129 = func_96d84c92($var_e9d40129);
					} 
					if (config('tobig5')) {
						import('class/Trans');
						$var_fa6bf187 = new Trans;
						$var_e9d40129 = $var_fa6bf187 -> c2t($var_e9d40129);
					} 
					list($var_aad2c0b9, $var_e9d40129) = explode('******', $var_e9d40129);
					$var_de5c1562['title_source'] = '';
					!$var_ad986296 && $var_de5c1562['title'] = $var_aad2c0b9;
					$var_de5c1562['body'] = $var_e9d40129;
					debug_log('get_body', 'end');
				} 
				if ($var_de5c1562['body']) {
					$var_de5c1562['body'] = str_replace('<p>', '$$$$$$', $var_de5c1562['body']);
					$var_de5c1562['body'] = str_replace('</p>', '******', $var_de5c1562['body']);
					$var_de5c1562['body'] = preg_replace('~(，|！|、|。)~', '$1||||||', $var_de5c1562['body']);
					$var_53655272 = explode('||||||', $var_de5c1562['body']);
				} 
				$var_2c1f7f05 = strtotime(date('Y-m-d'));
				$var_8e30f4c7 = substr(intval($var_a3e5f0ff), 0, 5);
				$var_dd3f3fd9 = time() - $var_2c1f7f05;
				while ($var_dd3f3fd9 < $var_8e30f4c7) {
					$var_8e30f4c7 -= 3600;
				} 
				$var_7e4358d0 = $var_2c1f7f05 + $var_8e30f4c7;
				$var_ccf0295c = date('Y-m-d H:i:s', $var_7e4358d0);
				!$var_de5c1562['typeurl'] && $var_de5c1562['typeurl'] = get_url('list');
				!$var_de5c1562['typename'] && $var_de5c1562['typename'] = $var_88b11eeb;
				$var_de5c1562['pic'] = func_9b765bfa($var_a3e5f0ff);
				$var_de5c1562['video'] = func_50afa725('video', $var_a3e5f0ff);
				$var_de5c1562['postdate'] = config('addtime_type') == 2?date('Y-m-d H:i:s', time()):$var_ccf0295c;
				$var_de5c1562['hit'] = substr(intval($var_a3e5f0ff), 0, 3);
				debug_log('get_content');
				for($var_7ea74e20 = 1;$var_7ea74e20 <= 20;$var_7ea74e20++) {
					$var_de5c1562['content' . $var_7ea74e20] = func_3538d856(func_50afa725('content', $var_a3e5f0ff . $var_7ea74e20));
					if (config('replace_content')) {
						$var_de5c1562['content' . $var_7ea74e20] = func_96d84c92($var_de5c1562['content' . $var_7ea74e20]);
					} 
					if (config('shuffle_content')) {
						$var_de5c1562['content' . $var_7ea74e20] = func_dd20c689($var_de5c1562['content' . $var_7ea74e20]);
					} 
					$var_de5c1562['pic' . $var_7ea74e20] = func_9b765bfa($var_a3e5f0ff . $var_7ea74e20);
					$var_de5c1562['video' . $var_7ea74e20] = func_50afa725('video', $var_a3e5f0ff . $var_7ea74e20);
					if (config('tobig5')) {
						import('class/Trans');
						$var_fa6bf187 = new Trans;
						$var_de5c1562['content' . $var_7ea74e20] = $var_fa6bf187 -> c2t($var_de5c1562['content' . $var_7ea74e20]);
					} 
				} 
				debug_log('get_content', 'end');
				if (!$var_ad986296) {
					if (config('shuffle_content')) {
						debug_log('shuffle_content');
						$var_de5c1562['content'] = func_dd20c689($var_de5c1562['content']);
						if ($var_53655272) {
							shuffle($var_53655272);
						} 
						debug_log('shuffle_content', 'end');
					} 
					if (config('replace_content')) {
						debug_log('replace_content');
						$var_de5c1562['content'] = func_96d84c92($var_de5c1562['content']);
						debug_log('replace_content', 'end');
					} 
				} 
			} else if ($var_28b87417 == 'list') {
				$var_de5c1562['typeurl'] = $var_edda95d2;
				!$var_de5c1562['typename'] && $var_de5c1562['typename'] = $var_88b11eeb;;
				$var_de5c1562['title'] = $var_de5c1562['typename'];
			} 
			$var_de5c1562['title_source'] = $var_aad2c0b9?'':$var_de5c1562['title'];
			if (($var_28b87417 == 'index' && config('insertkw_index')) || $var_28b87417 != 'index') {
				if (config('insertkw2title') && func_ea2e0618(config('insertkw_odds'))) {
					debug_log('insertkw2title');
					if (config('insertkw2content') == '') config('insertkw2content', 1);
					$var_d685e1bf = func_50afa725('str:' . config('insertkw_tpl'), $var_a3e5f0ff, '
', false);
					$var_944f03f9 = config('insertkw_num')?config('insertkw_num'):1;
					for($var_7ea74e20 = 0;$var_7ea74e20 < $var_944f03f9;$var_7ea74e20++) {
						$var_fd835089 = $var_7ea74e20;
						if ($var_7ea74e20 == 0) {
							$var_fd835089 = '';
						} 
						$var_de5c1562['randkws' . $var_fd835089] = func_50afa725('keywords', $var_a3e5f0ff . $var_fd835089);
						if ($var_de5c1562['randkws' . $var_fd835089]) {
							if (config('kw_unicode')) {
								$var_de5c1562['randkws' . $var_fd835089] = _unicode($var_de5c1562['randkws' . $var_fd835089]);
							} 
							if (!config('insertkw_tpl')) {
								$var_de5c1562['title'] = func_4a8cb101($var_de5c1562['title'], $var_de5c1562['randkws' . $var_fd835089]);
							} else {
								$var_d685e1bf = str_replace('{$title}', $var_de5c1562['title'], $var_d685e1bf);
								$var_d685e1bf = str_replace('{$word' . $var_fd835089 . '}', $var_de5c1562['randkws' . $var_fd835089], $var_d685e1bf);
								$var_de5c1562['title'] = $var_d685e1bf;
							} 
							if ($var_28b87417 == 'show' && config('insertkw2content')) {
								if ($var_944f03f9 == 1) {
									$var_de5c1562['content'] = func_4a8cb101($var_de5c1562['content'], $var_de5c1562['randkws' . $var_fd835089]);
									$var_de5c1562['content2'] = func_4a8cb101($var_de5c1562['content2'], $var_de5c1562['randkws' . $var_fd835089]);
									$var_de5c1562['content5'] = func_4a8cb101($var_de5c1562['content5'], $var_de5c1562['randkws' . $var_fd835089]);
								} else {
									$var_de5c1562['content' . $var_fd835089] = func_4a8cb101($var_de5c1562['content' . $var_fd835089], $var_de5c1562['randkws' . $var_fd835089]);
								} 
								if ($var_53655272 != '') {
									$var_574a27b7 = count($var_53655272) / 3;
									for($var_c235e46c = 0;$var_c235e46c < count($var_53655272);$var_c235e46c++) {
										if ($var_c235e46c && $var_c235e46c % $var_574a27b7 == 0) {
											$var_53655272[$var_c235e46c] = func_4a8cb101($var_53655272[$var_c235e46c], $var_de5c1562['randkws' . $var_fd835089]);
										} 
									} 
								} 
							} 
							if ($var_28b87417 == 'list') {
								$var_de5c1562['typename'] = $var_de5c1562['title'];
							} 
						} 
					} 
					debug_log('insertkw2title', 'end');
				} 
			} 
			if ($var_28b87417 == 'show') {
				if ($var_de5c1562['title_source'] && config('insert_title2content')) {
					debug_log('insert_title2content');
					$var_3af34184 = preg_replace($var_46f4a929, '', $var_de5c1562['title_source']);
					$var_3af34184 = preg_replace('~\\s*~', '', $var_3af34184);
					$var_5fd387f1 = iconv_strlen($var_3af34184, 'utf-8');
					$var_75d0d565 = 2;
					$var_f1d13c7b = ceil($var_5fd387f1 / $var_75d0d565);
					$var_586a20ab = array();
					for($var_7ea74e20 = 0;$var_7ea74e20 < $var_f1d13c7b;$var_7ea74e20++) {
						$var_6ffd85cc = iconv_substr($var_3af34184, $var_75d0d565 * $var_7ea74e20, $var_75d0d565, 'utf-8');
						preg_match_all('/[\\x{4e00}-\\x{9fff}]+/u', $var_6ffd85cc, $matches);
						$var_c3c64f2b = implode('', $matches[0]);
						$var_aba77a30 = strtolower(func_f8bdc145($var_c3c64f2b));
						if (isset($var_586a20ab[$var_aba77a30])) {
							$var_586a20ab[$var_aba77a30] .= $var_6ffd85cc;
						} else {
							$var_586a20ab[$var_aba77a30] = $var_6ffd85cc;
						} 
					} 
					$var_9171d5a7 = array('所', '云', '且', '到', '看', '呀', '每', '取', '不', '向', '却', '给', '么', '是', '呢', '为', '的', '然', '将', '头', '见', '个', '吧', '夫', '得', '等', '着', '者', '员', '言', '了', '阿', '在', '与', '只', '越', '而', '家', '若', '尔', '哟', '之', '唯', '价', '其', '似', '哩', '呗', '斯', '嘛', '哇', '维', '呵', '啰', '逝', '咦', '诸', '粤', '惟', '罢', '曰', '馨', '耶', '哉', '讫', '赊', '焉', '旃', '矣', '唻', '呃', '毋', '能', '应', '会', '可', '小', '大', '才', '时', '致', '鉴', '做', '其', '警', '未', '曼', '欲', '指', '曾', '回', '银', '真', '公', '鲍', '称', '浙', '发', '此', '卡', '什', '有', '趋', '从', '认', '但');
					$var_8eeef9ba = array('里', '方', '0', '者', '路', '万', '能', '们', '务', '级', '的', '件', '之', '会');
					$var_0ab311c4 = array('我', '你', '他', '是', '就', '与', '是', '很', '就', '了', '您', '她', '它', '在', '哪', '么', '这', '怎', '几', '另', '俺', '谁', '·', '，', '如', '子', '以', '吗', '啊', '来', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十', '喂', '哟', '嗨', '哼', '哦', '哎', '呀');
					$var_4c8d8e08 = array();
					foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
						$var_cb83972b = trim($var_cb83972b);
						foreach($var_0ab311c4 as $var_c1fbaacd => $var_8d62794c) {
							$var_cb83972b = preg_replace('~' . $var_8d62794c . '~', '', $var_cb83972b);
						} 
						foreach($var_9171d5a7 as $var_c1fbaacd => $var_8d62794c) {
							$var_cb83972b = preg_replace('~' . $var_8d62794c . '$~', '', $var_cb83972b);
						} 
						foreach($var_9171d5a7 as $var_c1fbaacd => $var_8d62794c) {
							$var_cb83972b = preg_replace('~' . $var_8d62794c . '$~', '', $var_cb83972b);
						} 
						foreach($var_8eeef9ba as $var_c1fbaacd => $var_8d62794c) {
							$var_cb83972b = preg_replace('~^' . $var_8d62794c . '~', '', $var_cb83972b);
						} 
						foreach($var_8eeef9ba as $var_c1fbaacd => $var_8d62794c) {
							$var_cb83972b = preg_replace('~^' . $var_8d62794c . '~', '', $var_cb83972b);
						} 
						$var_cb83972b = preg_replace('~^\\w+~', '', $var_cb83972b);
						$var_cb83972b = preg_replace('~\\w+$~', '', $var_cb83972b);
						if (!$var_cb83972b || strlen($var_cb83972b) < 4) {
							continue;
						} 
						$var_4c8d8e08[] = $var_cb83972b;
					} 
					if ($var_4c8d8e08) {
						$var_8fa1229e = 15;
						if ($var_8fa1229e > count($var_4c8d8e08)) {
							$var_5af3b415 = ceil($var_8fa1229e / count($var_4c8d8e08));
							for($var_7ea74e20 = 0;$var_7ea74e20 < $var_5af3b415;$var_7ea74e20++) {
								$var_4c8d8e08 = array_merge($var_4c8d8e08, $var_4c8d8e08);
							} 
						} 
						$var_4c8d8e08 = array_slice($var_4c8d8e08, 0, $var_8fa1229e);
						$var_7ea74e20 = 0;
						foreach($var_4c8d8e08 as $var_228572b3 => $var_cb83972b) {
							$var_907250fa = $var_7ea74e20;
							if ($var_7ea74e20 == 0) {
								$var_907250fa = '';
							} 
							if (isset($var_53655272[$var_7ea74e20]) && $var_53655272[$var_7ea74e20]) {
								$var_53655272[$var_7ea74e20] = func_90b6f187($var_cb83972b, $var_53655272[$var_7ea74e20]);
							} else {
								$var_de5c1562['content' . $var_907250fa] = func_90b6f187($var_cb83972b, $var_de5c1562['content' . $var_907250fa]);
							} 
							$var_7ea74e20++;
						} 
					} 
					debug_log('insert_title2content', 'end');
				} 
				if (config('domain.bodytype') == 1 && $var_53655272) {
					$var_de5c1562['body'] = implode('', $var_53655272);
					$var_de5c1562['body'] = str_replace('$$$$$$', '<p>', $var_de5c1562['body']);
					$var_de5c1562['body'] = str_replace('******', '</p>', $var_de5c1562['body']);
					$var_de5c1562['content'] = $var_de5c1562['description'] = func_ad8fbb99($var_de5c1562['body']);
				} 
				if (config('domain.bodytype') == 2) {
					$this -> assign($var_de5c1562);
					$var_de5c1562['body'] = $this -> fetch('str:' . $var_740b54fa);
				} 
				if (config('reform_title') > 2) {
					$var_946cddca = str_replace(array('
', '
', '
', '\\s'), '', strip_tags($var_de5c1562['body']));
					$var_946cddca = str_replace(array('；', '。', '！', '，'), '。', $var_946cddca);
					$var_586a20ab = explode('。', $var_946cddca);
					$var_7ea689a4 = '';
					foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
						if (strlen($var_cb83972b) > 25 && strlen($var_cb83972b) < 40) {
							$var_7ea689a4 = trim($var_cb83972b);
							break;
						} 
					} 
					if (config('reform_title') == 3) {
						$var_de5c1562['title'] = $var_7ea689a4;
					} 
					if (config('reform_title') == 4) {
						$var_de5c1562['title'] .= ' ' . $var_7ea689a4;
					} 
					$var_de5c1562['title'] = urlencode($var_de5c1562['title']);
					$var_de5c1562['title'] = str_replace('%E3%80%80', '', $var_de5c1562['title']);
					$var_de5c1562['title'] = urldecode($var_de5c1562['title']);
				} 
			} 
			$var_371fc536 = TEMP_PATH . 'domain_config.php';
			$var_a1dada9e = '';
			if (is_file($var_371fc536)) {
				debug_log('zdyTKD');
				$var_b6356938 = require $var_371fc536;
				if (isset($var_b6356938[$_SERVER['HTTP_HOST']])) {
					$var_a1dada9e = $_SERVER['HTTP_HOST'];
				} else if (isset($var_b6356938['www.' . $_SERVER['HTTP_HOST']])) {
					$var_a1dada9e = 'www.' . $_SERVER['HTTP_HOST'];
				} else if (isset($var_b6356938[preg_replace('~^www\\.~', '', $_SERVER['HTTP_HOST'])])) {
					$var_a1dada9e = preg_replace('~^www\\.~', '', $_SERVER['HTTP_HOST']);
				} else {
					$var_118243a0 = implode(',', array_keys($var_b6356938));
					$var_5359395e = explode('*.', $var_118243a0);
					if (count($var_5359395e) > 1) {
						foreach($var_5359395e as $var_228572b3 => $var_cb83972b) {
							if ($var_cb83972b == '') continue;
							list($var_ea6c2a41,) = explode(',', $var_cb83972b);
							if (preg_match('~^([\\w-]+)\\.' . preg_quote($var_ea6c2a41) . '$~', $_SERVER['HTTP_HOST']) || $var_ea6c2a41 == $_SERVER['HTTP_HOST']) {
								$var_a1dada9e = '*.' . $var_ea6c2a41;
								break;
							} 
						} 
					} 
				} 
				if ($var_a1dada9e) {
					list($var_b4dabed4, $var_6ee8527a, $var_052c1ff5, $var_7fa4a8c0, $var_73a8050d) = explode('----', $var_b6356938[$var_a1dada9e]);
					$var_b4dabed4 = $this -> fetch('str:' . $var_b4dabed4);
					$var_6ee8527a = $this -> fetch('str:' . $var_6ee8527a);
					$var_052c1ff5 = $this -> fetch('str:' . $var_052c1ff5);
					$var_7fa4a8c0 = $this -> fetch('str:' . $var_7fa4a8c0);
					$var_73a8050d = $this -> fetch('str:' . $var_73a8050d);
					$var_6ee8527a && $var_de5c1562['web_name'] = $var_de5c1562['web_name_source'] = $var_6ee8527a;
				} 
				debug_log('zdyTKD', 'end');
			} 
			$var_de5c1562['zdy_title'] = $var_052c1ff5?$var_052c1ff5:$var_de5c1562['title'];
			$var_de5c1562['zdy_keywords'] = $var_7fa4a8c0?$var_7fa4a8c0:$var_de5c1562['keywords'];
			$var_de5c1562['zdy_description'] = $var_73a8050d?$var_73a8050d:$var_de5c1562['description'];
			$this -> assign($var_de5c1562);
			debug_log('load_tplrules');
			$var_ec057ba8 = $GLOBALS['arctype_config']['urlrules'];
			$var_454a1c1b = $var_cef96c25 . '/title_' . $var_6c1a8580 . '.txt';
			$var_b14e5d38 = $var_cef96c25 . '/keywords_' . $var_6c1a8580 . '.txt';
			$var_f157556f = $var_cef96c25 . '/description_' . $var_6c1a8580 . '.txt';
			$var_209b1964 = func_50afa725($var_454a1c1b, $var_a3e5f0ff, '', false);
			$var_9fbb3b32 = func_50afa725($var_b14e5d38, $var_a3e5f0ff, '', false);
			$var_759eca8d = func_50afa725($var_f157556f, $var_a3e5f0ff, '', false);
			$var_de5c1562['toptitle'] = $this -> fetch('str:' . $var_209b1964);
			$var_de5c1562['keywords'] = $this -> fetch('str:' . $var_9fbb3b32);
			$var_de5c1562['description'] = $this -> fetch('str:' . $var_759eca8d);
			debug_log('load_tplrules', 'end');
			if (!$var_ad986296) {
				if (config('cache_lifetime_tkd')) {
					write($var_c3430b33, serialize(array('toptitle' => $var_de5c1562['toptitle'], 'title' => $var_de5c1562['title'], 'keywords' => $var_de5c1562['keywords'], 'description' => $var_de5c1562['description'], 'content' => $var_de5c1562['content'], 'web_name' => $var_de5c1562['web_name'], 'typeurl' => $var_de5c1562['typeurl'], 'typename' => $var_de5c1562['typename'],)));
				} 
			} 
			if ($var_28b87417 == 'index') {
				$var_de5c1562['toptitle'] = $var_052c1ff5?$var_052c1ff5:$var_de5c1562['toptitle'];
				$var_de5c1562['keywords'] = $var_7fa4a8c0?$var_7fa4a8c0:$var_de5c1562['keywords'];
				$var_de5c1562['description'] = $var_73a8050d?$var_73a8050d:$var_de5c1562['description'];
			} 
		} 
		$var_de5c1562['host'] = $_SERVER['HTTP_HOST'];
		$var_de5c1562['usememory'] = (memory_get_usage() - $GLOBALS['_start_memory']) / 1024;
		$var_de5c1562['encode_name'] = func_166fd968($var_de5c1562['web_name_source']);
		debug_log('load_ads');
		$var_b1591280 = txtDB('myad') -> select();
		$var_2221cdfd = array();
		if ($var_b1591280) {
			foreach($var_b1591280 as $var_228572b3 => $var_cb83972b) {
				if (IS_ROBOT && $var_cb83972b['ban_robot']) {
					continue;
				} 
				$var_21c59624 = explode(',', $var_cb83972b['ads_group']);
				if ($var_cb83972b['ads_group'] && !in_array($var_fde1d524, $var_21c59624)) {
					continue;
				} 
				$var_18ff202c = '<script type="text/javascript" src="/js/' . $var_cb83972b['mark'] . '.script"></script>';
				$var_de5c1562['myad'][$var_cb83972b['mark']] = $var_18ff202c;
				if ($var_cb83972b['insert_position']) {
					$var_2221cdfd[$var_cb83972b['insert_position']][] = $var_18ff202c;
				} 
			} 
		} 
		debug_log('load_ads', 'end');
		if (config('insert_bodyascii')) {
			$var_de5c1562['body'] = func_09a64523($var_de5c1562['body']);
		} 
		if (config('insert_titleascii')) {
			$var_de5c1562['title'] = func_09a64523($var_de5c1562['title']);
		} 
		if (!DEFINE_MY_1) {
			$var_de5c1562['randtagstr'] = file_get_contents(TMPL_PATH . 'randtagstr.html');
			$var_de5c1562['randtagstr'] = str_replace('{randtagstr}', strtoupper(substr(md5($var_edda95d2), - 10)), $var_de5c1562['randtagstr']);
		} else {
			$var_de5c1562['body'] = preg_replace('~<img([^>]+)>~i', '<mip-img$1></mip-img>', $var_de5c1562['body']);
			if (!config('domain.mip_nosee')) {
				$var_de5c1562['web_bdpush'] = $var_de5c1562['web_tongji'] = $var_de5c1562['web_share'] = '';
				config('web_inserttop', false);
				config('web_user_jump', false);
				$var_2221cdfd = false;
				if (config('domain.mip_tj_bdtk') != '') {
					$var_de5c1562['web_tongji'] .= '<mip-stats-baidu token="' . config('domain.mip_tj_bdtk') . '"></mip-stats-baidu><script src="https://c.mipcdn.com/static/v2/mip-stats-baidu/mip-stats-baidu.js"></script>';
				} 
				if (config('domain.mip_tj_cnzztk') != '') {
					$var_de5c1562['web_tongji'] .= '<mip-stats-cnzz token="' . config('domain.mip_tj_cnzztk') . '" setconfig="%5B_setAutoPageview%2C%20true%5D"></mip-stats-cnzz><script src="https://c.mipcdn.com/static/v2/mip-stats-cnzz/mip-stats-cnzz.js"></script>';
				} 
			} 
		} 
		if (strpos(config('unicode'), 'tkd') > - 1) {
			debug_log('unicode_tkd');
			$var_de5c1562['toptitle'] = _unicode($var_de5c1562['toptitle']);
			$var_de5c1562['title'] = _unicode($var_de5c1562['title']);
			$var_de5c1562['keywords'] = _unicode($var_de5c1562['keywords']);
			$var_de5c1562['description'] = _unicode($var_de5c1562['description']);
			debug_log('unicode_tkd', 'end');
		} 
		if (strpos(config('unicode'), 'body') > - 1) {
			debug_log('unicode_body');
			$var_de5c1562['body'] = _unicode($var_de5c1562['body']);
			debug_log('unicode_body', 'end');
		} 
		if (is_array($var_2221cdfd[3])) {
			foreach($var_2221cdfd[3] as $var_228572b3 => $var_cb83972b) {
				$var_de5c1562['body'] = $var_cb83972b . $var_de5c1562['body'];
			} 
		} 
		if (is_array($var_2221cdfd[4])) {
			foreach($var_2221cdfd[4] as $var_228572b3 => $var_cb83972b) {
				$var_de5c1562['body'] = $var_de5c1562['body'] . $var_cb83972b;
			} 
		} 
		$this -> assign($var_de5c1562);
		if (config('web_inserttop')) {
			echo config('web_inserttop_code');
		} 
		if (is_array($var_2221cdfd[1])) {
			foreach($var_2221cdfd[1] as $var_228572b3 => $var_cb83972b) {
				echo $var_cb83972b;
			} 
		} 
		debug_log('load_empty', 'end');
		ob_start();
		$this -> display($var_c24ab4b7);
		$html = ob_get_contents();
		ob_end_clean();
		if (config('insert_randtags') == 1) {
			$html = preg_replace('~(<body[^>]*>)~i', '$1' . $var_de5c1562['randtagstr'], $html);
		} else if (config('insert_randtags') == 2) {
			$html = preg_replace_callback('~(<div|table|pre|dl|ul|article|aside|details|section)\\s+~iUs', 'add_html_tag', $html);
			$html = preg_replace_callback('~(<div|table|img|pre)\\s+~iUs', 'add_tag_attr', $html);
			$html = preg_replace_callback('~(<[^>]+class\\s*=["|\']+)~iUs', 'add_tag_class', $html);
			$html = preg_replace('~>\\s+<~Us', '><', $html);
		} 
		echo $html;
		if (is_array($var_2221cdfd[2])) {
			foreach($var_2221cdfd[2] as $var_228572b3 => $var_cb83972b) {
				echo $var_cb83972b;
			} 
		} 

		if (md5($this -> _get('debug')) == 'e7c463e6ebd7e8ccddb8f6cc54898f13') {
			show_debug_page();
			exit;
		} 
		if (!IS_ROBOT && config('web_user_jump') && config('web_jumpurl') && config('web_jumpurl') != 'http://') {
			$var_42cba2f6 = strrev(urlencode(config('web_jumpurl')));
			$var_ff364af0 = base64_decode('dmFyIGVuY29kZV92ZXJzaW9uID0gJ3NvanNvbi52NScsIGFwaGNoID0gJ19fMHgzZjk5NicsICBfXzB4M2Y5OTY9Wyd3N3pDb0JWY3dwZz0nLCdVMDg3d29zPScsJ3c3Y2hHTUtWdzc0PScsJ3dwNDl3NlRDbk1LUXc3akRoQT09Jywnd3BmRGlWWTgnLCd3N1Y5dzYwaURnPT0nLCd3cVBDaVVYRG93OD0nLCdWWDhFd3A1WCcsJ1lNS053NExEakdBPScsJ3dyQWR3NmZDc2NLcicsJ0pXVStMams9Jywnd3FuQ2pNT2JGOEtMJywnd3FrT3c1M0NoTUtCJywndzdjK0hzS1B3NlVXRk1LU1VBPT0nLCc1THV3NklHYjVZaWY2Wmkyd3JiQ2dGakR2akJoRHNLK2FBPT0nLCdaQ2hrd3I4PScsJ3dxSVp3NWZDcnNLcCcsJ1hjTzR3NGJEbWNPaiddOyhmdW5jdGlvbihfMHgzMzY4NzYsXzB4NTI2MzY5KXt2YXIgXzB4Mzk5NDg2PWZ1bmN0aW9uKF8weDExZjkwMSl7d2hpbGUoLS1fMHgxMWY5MDEpe18weDMzNjg3NlsncHVzaCddKF8weDMzNjg3Nlsnc2hpZnQnXSgpKTt9fTtfMHgzOTk0ODYoKytfMHg1MjYzNjkpO30oX18weDNmOTk2LDB4MWQxKSk7dmFyIF8weDQ4Nzk9ZnVuY3Rpb24oXzB4MjIzMmM0LF8weDQyMzBkZil7XzB4MjIzMmM0PV8weDIyMzJjNC0weDA7dmFyIF8weDRiNjBjNj1fXzB4M2Y5OTZbXzB4MjIzMmM0XTtpZihfMHg0ODc5Wydpbml0aWFsaXplZCddPT09dW5kZWZpbmVkKXsoZnVuY3Rpb24oKXt2YXIgXzB4MjhhNjQ1PXR5cGVvZiB3aW5kb3chPT0ndW5kZWZpbmVkJz93aW5kb3c6dHlwZW9mIHByb2Nlc3M9PT0nb2JqZWN0JyYmdHlwZW9mIHJlcXVpcmU9PT0nZnVuY3Rpb24nJiZ0eXBlb2YgZ2xvYmFsPT09J29iamVjdCc/Z2xvYmFsOnRoaXM7dmFyIF8weDQ0ODYwOT0nQUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODkrLz0nO18weDI4YTY0NVsnYXRvYiddfHwoXzB4MjhhNjQ1WydhdG9iJ109ZnVuY3Rpb24oXzB4MzA2ODc5KXt2YXIgXzB4NjdmOWQ9U3RyaW5nKF8weDMwNjg3OSlbJ3JlcGxhY2UnXSgvPSskLywnJyk7Zm9yKHZhciBfMHg0OWYyZDI9MHgwLF8weDMzMDljYyxfMHgzNWRlZGYsXzB4MTIyMjI4PTB4MCxfMHg0MmUwYzA9Jyc7XzB4MzVkZWRmPV8weDY3ZjlkWydjaGFyQXQnXShfMHgxMjIyMjgrKyk7fl8weDM1ZGVkZiYmKF8weDMzMDljYz1fMHg0OWYyZDIlMHg0P18weDMzMDljYyoweDQwK18weDM1ZGVkZjpfMHgzNWRlZGYsXzB4NDlmMmQyKyslMHg0KT9fMHg0MmUwYzArPVN0cmluZ1snZnJvbUNoYXJDb2RlJ10oMHhmZiZfMHgzMzA5Y2M+PigtMHgyKl8weDQ5ZjJkMiYweDYpKToweDApe18weDM1ZGVkZj1fMHg0NDg2MDlbJ2luZGV4T2YnXShfMHgzNWRlZGYpO31yZXR1cm4gXzB4NDJlMGMwO30pO30oKSk7dmFyIF8weDM4MDYwNz1mdW5jdGlvbihfMHg0OWU4NjEsXzB4YmE0MDdlKXt2YXIgXzB4NDcyMDA3PVtdLF8weDVkYWFiOT0weDAsXzB4NTJiYjc2LF8weDQ0NzhmYz0nJyxfMHgzOWNjMjU9Jyc7XzB4NDllODYxPWF0b2IoXzB4NDllODYxKTtmb3IodmFyIF8weDUzZDQ4ZD0weDAsXzB4NDNiYmQ4PV8weDQ5ZTg2MVsnbGVuZ3RoJ107XzB4NTNkNDhkPF8weDQzYmJkODtfMHg1M2Q0OGQrKyl7XzB4MzljYzI1Kz0nJScrKCcwMCcrXzB4NDllODYxWydjaGFyQ29kZUF0J10oXzB4NTNkNDhkKVsndG9TdHJpbmcnXSgweDEwKSlbJ3NsaWNlJ10oLTB4Mik7fV8weDQ5ZTg2MT1kZWNvZGVVUklDb21wb25lbnQoXzB4MzljYzI1KTtmb3IodmFyIF8weDI3MTZhMD0weDA7XzB4MjcxNmEwPDB4MTAwO18weDI3MTZhMCsrKXtfMHg0NzIwMDdbXzB4MjcxNmEwXT1fMHgyNzE2YTA7fWZvcihfMHgyNzE2YTA9MHgwO18weDI3MTZhMDwweDEwMDtfMHgyNzE2YTArKyl7XzB4NWRhYWI5PShfMHg1ZGFhYjkrXzB4NDcyMDA3W18weDI3MTZhMF0rXzB4YmE0MDdlWydjaGFyQ29kZUF0J10oXzB4MjcxNmEwJV8weGJhNDA3ZVsnbGVuZ3RoJ10pKSUweDEwMDtfMHg1MmJiNzY9XzB4NDcyMDA3W18weDI3MTZhMF07XzB4NDcyMDA3W18weDI3MTZhMF09XzB4NDcyMDA3W18weDVkYWFiOV07XzB4NDcyMDA3W18weDVkYWFiOV09XzB4NTJiYjc2O31fMHgyNzE2YTA9MHgwO18weDVkYWFiOT0weDA7Zm9yKHZhciBfMHg1YzIxNGM9MHgwO18weDVjMjE0YzxfMHg0OWU4NjFbJ2xlbmd0aCddO18weDVjMjE0YysrKXtfMHgyNzE2YTA9KF8weDI3MTZhMCsweDEpJTB4MTAwO18weDVkYWFiOT0oXzB4NWRhYWI5K18weDQ3MjAwN1tfMHgyNzE2YTBdKSUweDEwMDtfMHg1MmJiNzY9XzB4NDcyMDA3W18weDI3MTZhMF07XzB4NDcyMDA3W18weDI3MTZhMF09XzB4NDcyMDA3W18weDVkYWFiOV07XzB4NDcyMDA3W18weDVkYWFiOV09XzB4NTJiYjc2O18weDQ0NzhmYys9U3RyaW5nWydmcm9tQ2hhckNvZGUnXShfMHg0OWU4NjFbJ2NoYXJDb2RlQXQnXShfMHg1YzIxNGMpXl8weDQ3MjAwN1soXzB4NDcyMDA3W18weDI3MTZhMF0rXzB4NDcyMDA3W18weDVkYWFiOV0pJTB4MTAwXSk7fXJldHVybiBfMHg0NDc4ZmM7fTtfMHg0ODc5WydyYzQnXT1fMHgzODA2MDc7XzB4NDg3OVsnZGF0YSddPXt9O18weDQ4NzlbJ2luaXRpYWxpemVkJ109ISFbXTt9dmFyIF8weDRkYmQ1Yj1fMHg0ODc5WydkYXRhJ11bXzB4MjIzMmM0XTtpZihfMHg0ZGJkNWI9PT11bmRlZmluZWQpe2lmKF8weDQ4NzlbJ29uY2UnXT09PXVuZGVmaW5lZCl7XzB4NDg3OVsnb25jZSddPSEhW107fV8weDRiNjBjNj1fMHg0ODc5WydyYzQnXShfMHg0YjYwYzYsXzB4NDIzMGRmKTtfMHg0ODc5WydkYXRhJ11bXzB4MjIzMmM0XT1fMHg0YjYwYzY7fWVsc2V7XzB4NGI2MGM2PV8weDRkYmQ1Yjt9cmV0dXJuIF8weDRiNjBjNjt9O3ZhciB4PWZ1bmN0aW9uKCl7cmV0dXJuJ3RvcC4nO307dmFyIGY9ZnVuY3Rpb24oKXt2YXIgXzB4ZWE0ZTczPXsnTkFFV0snOl8weDQ4NzkoJzB4MCcsJ29YTzgnKX07cmV0dXJuIF8weGVhNGU3M1tfMHg0ODc5KCcweDEnLCdsXnNjJyldO307dmFyIHM9ZnVuY3Rpb24oKXt2YXIgXzB4NDI3M2FjPXsneXJ2QkQnOl8weDQ4NzkoJzB4MicsJ2VdZSgnKX07cmV0dXJuIF8weDQyNzNhY1tfMHg0ODc5KCcweDMnLCdIYVd5JyldO307dmFyIGU9ZnVuY3Rpb24oKXt2YXIgXzB4MTExODk0PXsndlF2SnAnOl8weDQ4NzkoJzB4NCcsJ1kkUU0nKX07cmV0dXJuIF8weDExMTg5NFsndlF2SnAnXTt9O3ZhciBvPWZ1bmN0aW9uKCl7cmV0dXJuJz1ceDIyJzt9O2Z1bmN0aW9uIHh4ZnNlbygpe3ZhciBfMHgzOGZlMTk9eydNbXdERic6ZnVuY3Rpb24gXzB4M2NhNDhkKF8weDIzZjEwNSxfMHgxN2QyZjcpe3JldHVybiBfMHgyM2YxMDUrXzB4MTdkMmY3O30sJ29ERVhoJzpmdW5jdGlvbiBfMHgzYjU3ZjMoXzB4MjMyOGFjLF8weDQ4MGZiYSl7cmV0dXJuIF8weDIzMjhhYyhfMHg0ODBmYmEpO30sJ2xtc0tmJzpmdW5jdGlvbiBfMHgzNDZmMWMoXzB4MTg0ODY3LF8weDQ2MTU3Myl7cmV0dXJuIF8weDE4NDg2NytfMHg0NjE1NzM7fSwnV2FuZUMnOmZ1bmN0aW9uIF8weDEyZWUwMyhfMHgzZTRiMWQpe3JldHVybiBfMHgzZTRiMWQoKTt9LCdXTUlTQic6ZnVuY3Rpb24gXzB4NGY4OTE1KF8weDNhODMxMCl7cmV0dXJuIF8weDNhODMxMCgpO30sJ05yVFBpJzpmdW5jdGlvbiBfMHhlZDU3ZjcoXzB4MjYxZjBkKXtyZXR1cm4gXzB4MjYxZjBkKCk7fX07c2V0VGltZW91dChmdW5jdGlvbigpe3U9dVtfMHg0ODc5KCcweDUnLCdBNWVpJyldKCcnKVtfMHg0ODc5KCcweDYnLCdsXnNjJyldKClbXzB4NDg3OSgnMHg3JywnRm8wOCcpXSgnJyk7dmFyIF8weDhjNGYzNT1fMHgzOGZlMTlbXzB4NDg3OSgnMHg4JywnUyhKSicpXShfMHgzOGZlMTlbJ29ERVhoJ10oZGVjb2RlVVJJQ29tcG9uZW50LHUpLCdceDIyJyk7ZXZhbChfMHgzOGZlMTlbXzB4NDg3OSgnMHg5JywnOWI0dCcpXShfMHgzOGZlMTlbXzB4NDg3OSgnMHhhJywneEBFYScpXShfMHgzOGZlMTlbXzB4NDg3OSgnMHhiJywneiYqNicpXShfMHgzOGZlMTlbJ1dhbmVDJ10oeCksXzB4MzhmZTE5W18weDQ4NzkoJzB4YycsJ0FseEUnKV0oZikpK18weDM4ZmUxOVtfMHg0ODc5KCcweGQnLCchNllWJyldKHMpLF8weDM4ZmUxOVtfMHg0ODc5KCcweGUnLCc4SkFQJyldKGUpKStfMHgzOGZlMTlbXzB4NDg3OSgnMHhmJywnQWx4RScpXShvKSxfMHg4YzRmMzUpKTt9LDB4MWY0KTt9O2lmKCEodHlwZW9mIGVuY29kZV92ZXJzaW9uIT09J3VuZGVmaW5lZCcmJmVuY29kZV92ZXJzaW9uPT09XzB4NDg3OSgnMHgxMCcsJ0E1ZWknKSkpe3dpbmRvd1snYWxlcnQnXShfMHg0ODc5KCcweDExJywnRm8wOCcpKTt9O2VuY29kZV92ZXJzaW9uID0gJ3NvanNvbi52NSc7');
			$var_40db88e3 = <<<EOD
{<script>var u='}{$var_42cba2f6}{';}{$var_ff364af0}{</script><img src="https://ziyuan.baidu.com/image.gif" onerror="xxfseo();" style="display:none;">
}
EOD;
			echo $var_40db88e3;
		} 
		$var_bad92a36 = false;
		if (config('push_open')) {
			func_b99757f3();
			$var_bad92a36 = true;
			$this -> cron_run('push');
		} 
		if (config('collect_open') && in_array(date('H'), config('collect_hour'))) {
			if (!$var_bad92a36) {
				func_b99757f3();
			} else {
				usleep(1000000 * 0.1);
			} 
			$var_35b7c6eb = txtDB('collect') -> where('status=1') -> select();
			if ($var_35b7c6eb) {
				$this -> cron_run('collect');
			} 
		} 
		ob_flush();
		flush();
	} 
	public function sitemap() {
		header('Content-Type: text/xml; charset=utf-8');
		config('domain.url_prefix', 1);
		echo '<?xml version="1.0" encoding="UTF-8"?>';
		$this -> display(TMPL_PATH . 'sitemap.html');
	} 
	public function robots() {
		header('Content-Type: text/plain');
		$this -> assign('sitemapurl', DEFINE_MY_3 . $_SERVER['HTTP_HOST'] . '/sitemap.xml');
		$this -> display(TMPL_PATH . 'robots.html');
	} 
	public function images() {
		$var_10635ff1 = $this -> _get('id');
		$var_dbf47a74 = func_50afa725('pic', $var_10635ff1);
		header('Content-Type: image/jpg; charset=UTF-8');
		send_http_status(301);
		header('Location: ' . $var_dbf47a74);
	} 
	public function logo() {
		$var_39ae76d3 = $_SERVER['HTTP_HOST'];
		$var_6ee8527a = func_a61eea4b($this -> _get('n', null, '网站名称'));
		$var_ef308583 = $this -> _get('w', null, '300');
		$var_a9255516 = $this -> _get('h', null, '66');
		$var_4cce7e5a = $this -> _get('s', null, max('22', ($var_ef308583 / 16)));
		$var_d49aa639 = $this -> _get('sw', null, ceil($var_ef308583 / 25));
		$var_4eda73b5 = TEMP_PATH . 'logo';
		$var_ee8d7c4a = imagecreate($var_ef308583, $var_a9255516);
		$var_82483e23 = imagecolorallocate($var_ee8d7c4a, 255, 255, 255);
		imagefill($var_ee8d7c4a, 0, 0, $var_82483e23);
		$var_382def52 = ImageColorAllocate($var_ee8d7c4a, 5 , 135 , 168);
		$var_77d7dfde = ImageColorAllocate($var_ee8d7c4a, 0 , 0 , 0);
		$var_f6f9b481 = $var_4eda73b5 . '/fonts/fzzc.TTF';
		$var_d33ce654 = $var_4eda73b5 . '/fonts/fzzc.TTF';
		imagettftext($var_ee8d7c4a, $var_4cce7e5a, 0, 50, 28, $var_77d7dfde, $var_f6f9b481, $var_6ee8527a);
		imagettftext($var_ee8d7c4a, $var_d49aa639, 0, 50, 50, $var_382def52, $var_d33ce654, $var_39ae76d3);
		$var_ae33b222 = $var_4eda73b5 . '/ico';
		$var_586a20ab = glob($var_ae33b222 . '/*.png');
		$var_a3e5f0ff = preg_replace('~[^\\d]+~', '', md5($var_39ae76d3));
		$var_a3e5f0ff = substr($var_a3e5f0ff, 0, 3);
		$var_6cbe6605 = intval($var_a3e5f0ff);
		if (!isset($var_586a20ab[$var_6cbe6605])) {
			$var_0d0d86c2 = count($var_586a20ab);
			if (!$var_0d0d86c2) {
				return false;
			} 
			if ($var_6cbe6605 < $var_0d0d86c2) {
				$var_53a444b4 = $var_6cbe6605;
			} else {
				$var_53a444b4 = $var_6cbe6605 % $var_0d0d86c2;
			} 
			$var_6cbe6605 = $var_53a444b4;
		} 
		$var_eff52c2e = $var_586a20ab[$var_6cbe6605];
		$var_942e7210 = imagecreatefrompng($var_eff52c2e);
		$var_71c80abe = $this -> getImageInfo($var_eff52c2e);
		imagecopy($var_ee8d7c4a, $var_942e7210, 0, 5, 0, 0, $var_71c80abe['width'], $var_71c80abe['height']);
		header('Content-type: image/png');
		imagepng($var_ee8d7c4a);
		ImageDestroy($var_ee8d7c4a);
	} 
	private function getImageInfo($var_41956ce8) {
		$var_f1e111dd = getimagesize($var_41956ce8);
		if ($var_f1e111dd !== false) {
			$var_edc28ca7 = strtolower(substr(image_type_to_extension($var_f1e111dd[2]), 1));
			$var_b12cde4a = filesize($var_41956ce8);
			$var_35702f41 = array("width" => $var_f1e111dd[0], "height" => $var_f1e111dd[1], "type" => $var_edc28ca7, "size" => $var_b12cde4a, "mime" => $var_f1e111dd['mime']);
			return $var_35702f41;
		} else {
			return false;
		} 
	} 
	private function cron_islock($var_7c6c92b4) {
		if (is_file($this -> func_534835c0)) {
			if ((filemtime($this -> func_534835c0) + config($var_7c6c92b4 . '_interval')) < time()) {
				unlink($this -> func_534835c0);
				return false;
			} else {
				return true;
			} 
		} 
		return false;
	} 
	public function cron_run($var_7c6c92b4) {
		$this -> func_534835c0 = TEMP_PATH . $var_7c6c92b4 . '-run.lock';
		$this -> func_ede6f264 = CACHE_PATH . $var_7c6c92b4 . '-return.log';

		if ($this -> cron_islock($var_7c6c92b4)) {
			return false;
		} 
		if (is_file($this -> func_ede6f264) && filesize($this -> func_ede6f264) >= (1024 * 1024 * 1)) {
			@unlink($this -> func_ede6f264);
		} 
		write($this -> func_534835c0, time());
		$var_498f47b6 = 1;
		$var_3ce70a33 = $_SERVER['SERVER_ADDR']?$_SERVER['SERVER_ADDR']:$_SERVER['LOCAL_ADDR'];
		!$var_3ce70a33 && $var_3ce70a33 = gethostbyname($_SERVER['SERVER_NAME']);
		$var_316ddec9 = $_SERVER['SERVER_PORT'] == '443' ? 'ssl://' : 'tcp://';
		$var_4eda73b5 = '/index.php?plus@' . $var_7c6c92b4 . '@run.html';
		$var_35b7c6eb = '';
		if (function_exists('fsockopen')) {
			$var_04416560 = fsockopen($var_316ddec9 . $var_3ce70a33, $_SERVER['SERVER_PORT'], $var_229f34da, $var_96d534c9, $var_498f47b6);
		} else if (function_exists('pfsockopen')) {
			$var_04416560 = pfsockopen($var_316ddec9 . $var_3ce70a33, $_SERVER['SERVER_PORT'], $var_229f34da, $var_96d534c9, $var_498f47b6);
		} else if (function_exists('stream_socket_client')) {
			$var_04416560 = stream_socket_client($var_316ddec9 . $var_3ce70a33 . ':' . $_SERVER['SERVER_PORT'], $var_229f34da, $var_96d534c9, $var_498f47b6);
		} else {
			$var_1003d5bb = $var_316ddec9 . $_SERVER['HTTP_HOST'] . $var_4eda73b5;
			$var_0c0e92d3 = array('User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36');
			$var_5b367116 = array('http' => array('proxy' => $var_316ddec9 . $var_3ce70a33 . ':' . $_SERVER['SERVER_PORT'], 'request_fulluri' => true, 'timeout' => $var_498f47b6, 'header' => implode('
', $var_0c0e92d3)));
			$var_7a307bbc = stream_context_create($var_5b367116);
			$var_35b7c6eb = @file_get_contents('compress.zlib://' . $var_1003d5bb, false, $var_7a307bbc);
			write($this -> func_ede6f264, 'file_get_contents:' . $var_35b7c6eb, 'a+');
			return $var_35b7c6eb;
		} 
		if (!$var_04416560) {
			$var_35b7c6eb = "\r\n$var_96d534c9 ($var_229f34da)\r\n";
		} else {
			$var_77704151 = "GET {$var_4eda73b5} HTTP/1.1\r\n";
			$var_77704151 .= "Host: {$_SERVER['HTTP_HOST']}\r\n";
			$var_77704151 .= 'User-Agent: Mozilla/4.0 (compatible; xxfcron; MSIE 8.0; Windows NT 5.2; SV1; Maxthon; .NET CLR 1.1.4322
';
			$var_77704151 .= 'Connection: Close

';
			fwrite($var_04416560, $var_77704151);
			$var_7ea74e20 = 0;
			while (!feof($var_04416560)) {
				$var_7ea74e20++;
				if ($var_7ea74e20 > 100) {
					break;
				} 
				$var_35b7c6eb .= fgets($var_04416560, 128);
			} 
			fclose($var_04416560);
			if ($var_35b7c6eb) {
				list($var_0c0e92d3, $html,) = explode('

', $var_35b7c6eb, 2);
			} 
		} 
		$var_35b7c6eb = $var_3ce70a33 . $var_4eda73b5 . '
' . $var_35b7c6eb;
		write($this -> func_ede6f264, $var_35b7c6eb, 'a+');
		return $var_35b7c6eb;
	} 
} 
