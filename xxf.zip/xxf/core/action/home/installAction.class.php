<?php class installAction extends xxfseoAction {
	public function _init() {
		parent :: _init();
		$this -> tplConf('tpl_path', APP_ROOT . 'static/');
		$this -> tplConf('template_dir', APP_ROOT . 'static/install/');
		$this -> tplConf('compile_dir', TPLCACHE_PATH . 'install/');
		$this -> tplConf('compile_check', true);
		$this -> tplConf('caching', false);
		config('theme_path', __ROOT__ . '/static/install');
		$this -> assign(config());
		$this -> func_534835c0 = TEMP_PATH . 'install.lock';
		if (is_file($this -> func_534835c0)) {
			exit('安装程序已锁定，如需重新安装，请删除此文件：' . $this -> func_534835c0);
		} 
	} 
	public function index() {
		$var_980a7c7e = './static/install/licence.txt';
		$var_fbe7df40 = file_get_contents($var_980a7c7e);
		$this -> assign('licenceText', $var_fbe7df40);
		$this -> assign('setupclass', 'setup');
		$this -> display();
	} 
	public function step2() {
		$var_de5c1562 = array();
		$var_de5c1562['allow_url_fopen'] = ini_get('allow_url_fopen') ? true:false;
		$var_de5c1562['safe_mode'] = ini_get('safe_mode') ? true:false;
		$var_de5c1562['fetch_mode'] = ((function_exists('curl_init') && function_exists('curl_exec')) || function_exists('fsockopen') || function_exists('pfsockopen') || function_exists('file_get_contents')) ?true : false;
		$var_de5c1562['iconv'] = function_exists('iconv') ? true:false;
		$var_de5c1562['mbstring'] = function_exists('mb_strlen') ? true:false;
		$var_de5c1562['memory_limit'] = intval(@ini_get('memory_limit')) >= 128 ? true:false;
		$var_f6ed4069 = array('temp');
		$var_ebda1630 = array();
		foreach($var_f6ed4069 as $var_228572b3 => $var_cb83972b) {
			$var_4eda73b5 = APP_ROOT . $var_cb83972b;
			$var_ebda1630[$var_cb83972b] = array('path' => $var_cb83972b . '/*', 'isread' => is_readable($var_4eda73b5), 'iswrite' => func_e89f021a($var_4eda73b5),);
		} 
		$var_de5c1562['testlist'] = $var_ebda1630;
		$this -> assign('setupclass', 'setup2');
		$this -> assign($var_de5c1562);
		$this -> display();
	} 
	public function step3() {
		$this -> assign('setupclass', 'setup3');
		$this -> display();
	} 
	public function step4() {
		$var_1b04f3c8 = $_POST['con'];
		$var_5f841fb5 = array();
		$var_5f841fb5['name'] = htmlspecialchars(trim($var_1b04f3c8['username']));
		$var_5f841fb5['pass'] = md5($var_1b04f3c8['password']);
		$this -> func_c9328e9c = txtDB('master');
		$var_35b7c6eb = $this -> func_c9328e9c -> where('id=1') -> data($var_5f841fb5) -> save();
		$var_39b1d0c8 = '';
		if (!$var_35b7c6eb) {
			$var_39b1d0c8 = '<font color="red">管理员密码设置失败！请检查文件权限！</font>';
		} else {
			$var_7c7d0dd9 = require(APP_ROOT . 'static/install/config.php');
			$var_d0a95790 = array_merge($var_7c7d0dd9, $var_1b04f3c8);
			func_3c22ed21(TEMP_PATH . 'config.php', $var_d0a95790);
			write($this -> func_534835c0, 'xxfseo_' . date('Y-m-d H:i:s'));
		} 
		$this -> assign('errmsg', $var_39b1d0c8);
		$this -> assign('setupclass', 'setup4');
		$this -> display();
	} 
} 
