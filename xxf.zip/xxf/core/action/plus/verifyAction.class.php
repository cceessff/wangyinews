<?php class verifyAction extends plusAction {
	public function _init() {
		parent :: _init();
	} 
	public function check() {
		$var_b5ae185e = TEMP_PATH . 'verify.lock';
		$var_10635ff1 = $this -> _get('id');
		if ($var_10635ff1 && is_file($var_b5ae185e)) {
			header('Content-Type: text/plain');
			exit($var_10635ff1);
		} 
		exit('error');
	} 
} 

?>