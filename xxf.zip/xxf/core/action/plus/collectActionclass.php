<?php class collectAction extends plusAction {
	public function _init() {
		parent :: _init();
		$this -> func_09668292 = TEMP_PATH . 'logs/collect_auto.log';
		if (is_file($this -> func_09668292) && filesize($this -> func_09668292) >= (1024 * 1024 * 1)) {
			@unlink($this -> func_09668292);
		} 
	} 
	public function run() {
		write($this -> func_09668292, '-------------start(' . date('Y-m-d H:i:s') . ")\r\n", 'a+');
		load('collect');
		$var_35b7c6eb = txtDB('collect') -> where('status=1') -> select();
		if (!$var_35b7c6eb) {
			write($this -> func_09668292, 'not result' . '
', 'a+');
			return false;
		} 
		shuffle($var_35b7c6eb);
		$var_35b7c6eb = array_shift($var_35b7c6eb);
		$var_e95fba0e = $var_35b7c6eb['id'];
		$var_de5c1562 = array();
		func_2436795e($var_e95fba0e, 0);
		write($this -> func_09668292, 'nid：' . $var_e95fba0e . '
', 'a+');
		$var_afb1db68 = $GLOBALS['collect_rules'];
		if ($var_afb1db68['collect_day_num'] == '0') {
			$var_afb1db68['collect_day_num'] = 999999;
		} 
		$var_5ea61d51 = $var_afb1db68['collect_day_num']?$var_afb1db68['collect_day_num']:1;
		if ($var_35b7c6eb['model'] == 'title' || $var_35b7c6eb['model'] == 'pic') {
			$var_dd71ae91 = CACHE_PATH . 'collect_auto/page-' . $var_e95fba0e . '.php';
			if (is_file($var_dd71ae91)) {
				list($var_cc7d199f, $var_a47a5c70, $var_b0af8371, $var_2d562abf) = explode(',', file_get_contents($var_dd71ae91));
				if ($var_b0af8371 >= $var_5ea61d51 && preg_match('~^' . date('Y-m-d') . '~', $var_2d562abf)) {
					write($this -> func_09668292, 'oknum>=collect_day_num：' . $var_5ea61d51 . '
', 'a+');
					return false;
				} 
			} else {
				$var_cc7d199f = 1;
				$var_a47a5c70 = 0;
			} 
			$var_0b4dc8c4 = func_d88bc8fb();
			$var_f1d13c7b = count($var_0b4dc8c4['url']);
			$var_59adc197 = 3;
			$var_877ab31e = ceil($var_f1d13c7b / $var_59adc197);
			$var_cc7d199f = min($var_cc7d199f, $var_877ab31e);
			$var_64f25176 = ($var_cc7d199f - 1) * $var_59adc197;
			$var_0b4dc8c4['url'] = array_slice($var_0b4dc8c4['url'], $var_64f25176, $var_59adc197);
			$var_0b4dc8c4['urlregx'] = array_slice($var_0b4dc8c4['urlregx'], $var_64f25176, $var_59adc197);
			if ($var_35b7c6eb['model'] == 'title') {
				$var_a47a5c70 = func_3b2fa4cf($var_0b4dc8c4, $var_a47a5c70, $var_afb1db68);
			} else if ($var_35b7c6eb['model'] == 'pic') {
				$var_a47a5c70 = func_7a275322($var_0b4dc8c4, $var_a47a5c70, $var_afb1db68);
			} 
			if ($var_afb1db68['maxnum'] && $var_a47a5c70 >= $var_afb1db68['maxnum']) {
				$var_afcd7486 = true;
			} 
			$var_ca1d3a44 = array('lasttime' => time(), 'numlog' => (int)$var_35b7c6eb['numlog'] + 1,);
			write($this -> func_09668292, 'update num：' . $var_a47a5c70 . '
', 'a+');
			txtDB('collect') -> where('id=' . $var_e95fba0e) -> save($var_ca1d3a44);
			if ($var_afcd7486 || $var_cc7d199f >= $var_877ab31e) {
				if (!$var_b0af8371) {
					$var_b0af8371 = 1;
				} else {
					$var_b0af8371++;
				} 
				write($var_dd71ae91, "{$var_cc7d199f},{$var_a47a5c70},{$var_b0af8371}," . date('Y-m-d H:i:s'));
				return true;
			} 
			$var_cc7d199f++;
			write($var_dd71ae91, "{$var_cc7d199f},{$var_a47a5c70},0," . date('Y-m-d H:i:s'));
		} 
		if ($var_35b7c6eb['model'] == 'body') {
			$var_dd71ae91 = CACHE_PATH . 'collect_auto/page-' . $var_e95fba0e . '.php';
			if (is_file($var_dd71ae91)) {
				list($var_cc7d199f, $var_160b568b, $var_a47a5c70, $var_b0af8371, $var_2d562abf) = explode(',', file_get_contents($var_dd71ae91));
				if ($var_b0af8371 >= $var_5ea61d51 && preg_match('~^' . date('Y-m-d') . '~', $var_2d562abf)) {
					write($this -> func_09668292, 'oknum>=collect_day_num：' . $var_5ea61d51 . '
', 'a+');
					return false;
				} 
			} else {
				$var_cc7d199f = $var_160b568b = 1;
				$var_a47a5c70 = 0;
			} 
			$var_0b4dc8c4 = func_d88bc8fb();
			$var_877ab31e = count($var_0b4dc8c4['url']);
			$var_bc246193 = $var_cc7d199f - 1;
			$var_75f57b3a = $var_0b4dc8c4['url'][$var_bc246193];
			if ($var_cc7d199f > 1) {
				$var_f8c8d3b2 = CACHE_PATH . 'collect_auto/content-' . $var_e95fba0e . '-' . ($var_bc246193 - 1) . '.tmp';
				is_file($var_f8c8d3b2) && unlink($var_f8c8d3b2);
			} 
			$var_76628617 = CACHE_PATH . 'collect_auto/content-' . $var_e95fba0e . '-' . $var_bc246193 . '.tmp';
			if (is_file($var_76628617)) {
				$var_8bb5268f = unserialize(file_get_contents($var_76628617));
			} else {
				$html = func_28b50565($var_75f57b3a);
				$var_8bb5268f = func_6f5f7eb8($html, $var_75f57b3a, $var_afb1db68);
				if ($var_8bb5268f) write($var_76628617, serialize($var_8bb5268f));
			} 
			$var_ef20458d = 3;
			$var_9d83ed8b = ceil(count($var_8bb5268f) / $var_ef20458d);
			$var_160b568b = min($var_160b568b, $var_9d83ed8b);
			$var_64f25176 = ($var_160b568b - 1) * $var_ef20458d;
			$var_8bb5268f = array_slice($var_8bb5268f, $var_64f25176, $var_ef20458d);
			$var_a47a5c70 = func_5be97940($var_8bb5268f, $var_afb1db68['body_area_regx'], $var_a47a5c70, $var_afb1db68['maxnum']);
			if ($var_afb1db68['maxnum'] && $var_a47a5c70 >= $var_afb1db68['maxnum']) {
				$var_afcd7486 = true;
			} 
			$var_ca1d3a44 = array('lasttime' => time(), 'numlog' => (int)$var_35b7c6eb['numlog'] + 1,);
			txtDB('collect') -> where('id=' . $var_e95fba0e) -> save($var_ca1d3a44);
			if ($var_afcd7486 || $var_cc7d199f >= $var_877ab31e) {
				@unlink($var_76628617);
				if (!$var_b0af8371) {
					$var_b0af8371 = 1;
				} else {
					$var_b0af8371++;
				} 
				write($var_dd71ae91, "{$var_cc7d199f},{$var_160b568b},{$var_a47a5c70},{$var_b0af8371}," . date('Y-m-d H:i:s'));
				return true;
			} else {
				$var_160b568b++;
				if ($var_160b568b >= $var_9d83ed8b) {
					$var_cc7d199f++;
				} 
				write($var_dd71ae91, "{$var_cc7d199f},{$var_160b568b},{$var_a47a5c70},0," . date('Y-m-d H:i:s'));
			} 
		} 
		if ($var_35b7c6eb['model'] == 'typename') {
			$var_dd71ae91 = CACHE_PATH . 'collect_auto/page-' . $var_e95fba0e . '.php';
			if (is_file($var_dd71ae91)) {
				list($var_cc7d199f, $var_160b568b, $var_a47a5c70, $var_b0af8371, $var_2d562abf) = explode(',', file_get_contents($var_dd71ae91));
				if ($var_b0af8371 >= $var_5ea61d51 && preg_match('~^' . date('Y-m-d') . '~', $var_2d562abf)) {
					return false;
				} 
			} else {
				$var_cc7d199f = $var_160b568b = 1;
				$var_a47a5c70 = 0;
			} 
			$var_0b4dc8c4 = func_d88bc8fb();
			$var_877ab31e = count($var_0b4dc8c4['url']);
			$var_bc246193 = $var_cc7d199f - 1;
			$var_75f57b3a = $var_0b4dc8c4['url'][$var_bc246193];
			if ($var_cc7d199f > 1) {
				$var_f8c8d3b2 = CACHE_PATH . 'collect_auto/typename-' . $var_e95fba0e . '-' . ($var_bc246193 - 1) . '.tmp';
				is_file($var_f8c8d3b2) && unlink($var_f8c8d3b2);
			} 
			$var_76628617 = CACHE_PATH . 'collect_auto/typename-' . $var_e95fba0e . '-' . $var_bc246193 . '.tmp';
			if (is_file($var_76628617)) {
				$var_8bb5268f = unserialize(file_get_contents($var_76628617));
			} else {
				$html = func_28b50565($var_75f57b3a);
				$var_8bb5268f = func_6f5f7eb8($html, $var_75f57b3a, $var_afb1db68);
				if ($var_8bb5268f) write($var_76628617, serialize($var_8bb5268f));
			} 
			$var_ef20458d = 3;
			$var_9d83ed8b = ceil(count($var_8bb5268f) / $var_ef20458d);
			$var_160b568b = min($var_160b568b, $var_9d83ed8b);
			$var_64f25176 = ($var_160b568b - 1) * $var_ef20458d;
			$var_8bb5268f = array_slice($var_8bb5268f, $var_64f25176, $var_ef20458d);
			$var_a47a5c70 = func_12361f5f($var_8bb5268f, $var_a47a5c70);
			if ($var_afb1db68['maxnum'] && $var_a47a5c70 >= $var_afb1db68['maxnum']) {
				$var_afcd7486 = true;
			} 
			$var_ca1d3a44 = array('lasttime' => time(), 'numlog' => (int)$var_35b7c6eb['numlog'] + 1,);
			txtDB('collect') -> where('id=' . $var_e95fba0e) -> save($var_ca1d3a44);
			if ($var_afcd7486 || $var_cc7d199f >= $var_877ab31e) {
				@unlink($var_76628617);
				if (!$var_b0af8371) {
					$var_b0af8371 = 1;
				} else {
					$var_b0af8371++;
				} 
				write($var_dd71ae91, "{$var_cc7d199f},{$var_160b568b},{$var_a47a5c70},{$var_b0af8371}," . date('Y-m-d H:i:s'));
				return true;
			} else {
				$var_160b568b++;
				if ($var_160b568b >= $var_9d83ed8b) {
					$var_cc7d199f++;
				} 
				write($var_dd71ae91, "{$var_cc7d199f},{$var_160b568b},{$var_a47a5c70},0," . date('Y-m-d H:i:s'));
			} 
		} 
		write($this -> func_09668292, '-------------end' . '
', 'a+');
	} 
} 

?>