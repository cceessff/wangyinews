<?php class adsAction extends plusAction {
	public function _init() {
		parent :: _init();
	} 
	public function index() {
		import('class/Robot');
		$var_932d3949 = new Robot(config('ROBOT_LIST'));
		$var_10635ff1 = $this -> _get('id');
		$var_35b7c6eb = txtDB('myad') -> where('mark=' . $var_10635ff1) -> find();
		header('Content-type: application/javascript');
		header('X-Powered-By: xxfseo');
		if (!$var_35b7c6eb) {
			exit('var a;');
		} 
		if ($var_932d3949 -> func_0a3c77ef() && $var_35b7c6eb['ban_robot']) {
			exit('var b;');
		} 
		exit($var_35b7c6eb['code']);
	} 
} 

?>