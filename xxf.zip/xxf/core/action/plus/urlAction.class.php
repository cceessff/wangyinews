<?php class urlAction extends adminAction {
	public function _init() {
		parent :: _init();
	} 
	public function index() {
		$var_10635ff1 = $this -> _get('id', 'intval', 0);
		$var_907250fa = $this -> _get('num', 'intval', '');
		!$var_907250fa && $var_907250fa = 1;
		$var_ae21f2d5 = '';
		if ($var_10635ff1) {
			$var_ae21f2d5 = 'id=' . $var_10635ff1;
		} 
		$var_35b7c6eb = txtDB('domain') -> where($var_ae21f2d5) -> select();
		$var_d688deb2 = txtDB('arctype') -> select();
		$var_d688deb2 = func_809cbb58($var_d688deb2, 'id');
		$var_e122cdb8 = array();
		$var_8bb5268f = array();
		foreach($var_35b7c6eb as $var_228572b3 => $var_cb83972b) {
			$var_1b04f3c8 = $var_cb83972b;
			$var_6eb887f1 = DATA_PATH . 'domain/' . $var_cb83972b['dirname'] . '_config.txt';
			if (is_file($var_6eb887f1) && $var_586a20ab = unserialize(file_get_contents($var_6eb887f1))) {
				$var_1b04f3c8 = array_merge($var_1b04f3c8, $var_586a20ab);
			} 
			$var_119ad111 = DATA_PATH . 'domain/' . $var_cb83972b['dirname'] . '_domain.txt';
			$var_e122cdb8 = file_get_contents($var_119ad111);
			if (!$var_e122cdb8) {
				continue;
			} 
			$GLOBALS['domain_dirname'] = $var_1b04f3c8['dirname'];
			$GLOBALS['domain_config'] = $var_1b04f3c8;
			$var_20a8dca2 = $var_1b04f3c8['urltype'] . $var_1b04f3c8['cid'];
			$var_6d0bc3b5 = func_05d2f70f('', $var_20a8dca2);
			$var_ec057ba8 = array();
			if ($var_1b04f3c8['urlrules_cache'] && is_file($var_6d0bc3b5)) {
				$var_ec057ba8 = unserialize(file_get_contents($var_6d0bc3b5));
			} else {
				$var_ec057ba8 = unserialize($var_d688deb2[$var_1b04f3c8['cid']]['urlrules' . $var_1b04f3c8['urltype']]);
				foreach($var_ec057ba8 as $var_3d9151c4 => $var_1076c777) {
					$var_9955dceb = explode(',', $var_1076c777['rules']);
					shuffle($var_9955dceb);
					$var_ec057ba8[$var_3d9151c4]['rules'] = array_shift($var_9955dceb);
				} 
				if ($var_1b04f3c8['urlrules_cache']) write($var_6d0bc3b5, serialize($var_ec057ba8));
			} 
			$var_50b89a7c = explode('
', $var_e122cdb8);
			foreach($var_50b89a7c as $var_3d9151c4 => $var_1076c777) {
				$var_b4dabed4 = trim($var_1076c777);
				for($var_fd835089 = 0;$var_fd835089 < $var_907250fa;$var_fd835089++) {
					$var_4ff7f406 = '';
					if ($var_1b04f3c8['domain_mod'] != 2) {
						$var_4ff7f406 = get_rand_prefix(true);
						$var_4ff7f406 = func_bd68a3eb($var_4ff7f406);
					} 
					$var_5a970161 = $var_4ff7f406?$var_4ff7f406 . '.' . $var_b4dabed4:$var_b4dabed4;
					$var_3e3241fe = 'http://';
					if (func_c48fbcc2($var_5a970161)) {
						$var_3e3241fe = 'https://';
					} 
					$var_1003d5bb = func_bd68a3eb($var_ec057ba8['show']['rules']);
					$var_1003d5bb = func_593b8141($var_1003d5bb, 'show');
					$var_1003d5bb = $var_3e3241fe . $var_5a970161 . '/' . $var_1003d5bb;
					$var_8bb5268f[] = $var_1003d5bb;
				} 
			} 
		} 
		header('Content-Type: text/plain');
		echo implode('
', $var_8bb5268f);
		exit();
	} 
} 

?>