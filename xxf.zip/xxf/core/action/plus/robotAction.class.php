<?php class robotAction extends plusAction {
	public function _init() {
		$this -> func_29faed00 = TEMP_PATH . 'cron-run.lock';
		$this -> func_3d0cd613 = TEMP_PATH . 'cron-open.lock';
		$this -> func_15fd0356 = func_ab30c30f;
	} 
	public function close() {
		@unlink($this -> func_3d0cd613);
		@unlink($this -> func_29faed00);
		echo 'ok';
	} 
	public function open($var_9cef1abd = 1) {
		write($this -> func_3d0cd613, time());

		if ($this -> islock()) {
			exit('is run');
		} 
		set_time_limit(func_3f2f2c7d);
		$var_253990b8 = 'http://' . $_SERVER['HTTP_HOST'] . '/index.php?plus@robot@run';
		$var_27348aac = array('http' => array('timeout' => func_a30f7028));
		$var_08658966 = stream_context_create($var_27348aac);
		$var_de5c1562 = @file_get_contents('compress.zlib://' . $var_253990b8, func_68c21728, $var_08658966);

		if (!$this -> islock()) {
			$var_9cef1abd++;
			if ($var_9cef1abd < func_220d3e2b) {
				return $this -> open($var_9cef1abd);
			} 
			exit('run fail：' . $var_de5c1562);
		} 
		exit('runing');
	} 
	public function run() {
		if ($this -> _get('debug') == '') {
			@ini_set('ignore_user_abort', 'On');
			ignore_user_abort(func_9392b7cc);
		} else {
			@ini_set('display_errors', 'On');
			error_reporting(func_b52f0f66);
		} 
		set_time_limit(func_d02ba7e2 * func_402145b2 * func_477bcb95);
		import('class/Robot2');
		$var_27a137b4 = new Robot(config('ROBOT_LIST'));

		if ($this -> islock()) {
			exit('is run');
		} 
		$var_7ea74e20 = array();
		do {
			if (!$this -> check_open()) {
				exit('close');
			} 
			$this -> func_db4cc981 = func_f634b549 + $this -> get_day_range();
			$this -> func_cac1240b = TEMP_PATH . 'robotcron/' . date('Ymd') . '.log';
			if (!is_file($this -> func_cac1240b)) {
				$var_2a7454e7 = $this -> get_hour_range($this -> func_db4cc981, ($this -> func_db4cc981 / func_8ef9e655));
				$var_27a137b4 -> write($this -> func_cac1240b, serialize($var_2a7454e7));
				foreach($var_2a7454e7 as $var_228572b3 => $var_cb83972b) {
					$var_7ea74e20[date('Ymd') . $var_228572b3] = $var_cb83972b;
				} 
			} 
			$var_ca8ca2fc = date('Ymd') . intval(date('H'));
			if (!isset($var_7ea74e20[$var_ca8ca2fc])) {
				$var_2a7454e7 = unserialize(file_get_contents($this -> func_cac1240b));
				foreach($var_2a7454e7 as $var_228572b3 => $var_cb83972b) {
					$var_7ea74e20[date('Ymd') . $var_228572b3] = $var_cb83972b;
				} 
			} 
			$var_7c3e9a74 = $var_7ea74e20[$var_ca8ca2fc];
			touch($this -> func_29faed00, time());
			$var_4edaccf5 = rand(func_87a09524, func_220d3e2b);
			sleep($var_4edaccf5);
			$var_5aed16ca = intval(($var_7c3e9a74 / func_d02ba7e2) * rand(func_87a09524, func_b985a93d));
			$var_5aed16ca = max($var_5aed16ca, func_87a09524);
			$var_27a137b4 -> func_d24a35d7($var_5aed16ca);
		} while (func_9392b7cc);
	} 
	public function check_open() {
		return is_file($this -> func_3d0cd613);
	} 
	public function islock() {
		if (is_file($this -> func_29faed00)) {
			if ((filemtime($this -> func_29faed00) + $this -> func_15fd0356) < time()) {
				unlink($this -> func_29faed00);
				return func_68c21728;
			} else {
				return func_9392b7cc;
			} 
		} 
		return func_68c21728;
	} 
	public function get_day_time_total($var_3fcdfe70 = '') {
		!$var_3fcdfe70 && $var_3fcdfe70 = date('Y-m-d');
		return strtotime($var_3fcdfe70 . ' 23:59:59');
	} 
	public function get_day_range($var_6cbe6605 = 3) {
		$var_3fcdfe70 = date('Y-m-d');
		$var_31b7b1f9 = $this -> get_day_time_total($var_3fcdfe70);
		$var_9cef1abd = func_a30f7028 - substr($var_31b7b1f9, - func_a30f7028, func_87a09524);
		$var_9cef1abd = max($var_9cef1abd, (func_9df9afc5 - $var_6cbe6605));
		$var_9cef1abd = min($var_9cef1abd, $var_6cbe6605);
		return $var_9cef1abd * func_51b7ab35 + intval(substr($var_31b7b1f9, func_bdfe9155, func_bdfe9155));
	} 
	public function get_hour_range($var_f1d13c7b, $var_71919e64) {
		$var_9cef1abd = 24;
		$var_1ffe317b = array();
		for ($var_9955dceb = func_87a09524;$var_9955dceb < $var_9cef1abd;$var_9955dceb++) {
			$var_5c45411b = ($var_f1d13c7b - ($var_9cef1abd - $var_9955dceb) * $var_71919e64) / ($var_9cef1abd - $var_9955dceb);
			$var_4c9dff78 = mt_rand($var_71919e64, $var_5c45411b);
			$var_f1d13c7b = $var_f1d13c7b - $var_4c9dff78;
			$var_1ffe317b[] = $var_4c9dff78;
		} 
		$var_1ffe317b[] = $var_f1d13c7b;
		shuffle($var_1ffe317b);
		return $var_1ffe317b;
	} 
} 

?>