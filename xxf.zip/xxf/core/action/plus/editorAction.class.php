<?php class editorAction extends plusAction {
	public function _init() {
		parent :: _init();
	} 
	public function fileManager() {
		$var_aaf2f8ed = $this -> _get('dir', '', 'title');
		$var_fae1bb2a = 'temp/data/' . $var_aaf2f8ed . '/';
		$var_689de1a2 = APP_PATH . $var_fae1bb2a;
		$var_59be2dca = __ROOT__ . '/' . $var_fae1bb2a;
		if (!file_exists($var_689de1a2)) {
			$this -> ajaxReturn(array('error' => 1, 'message' => 'Invalid Directory name.'));
		} 
		$var_57ffb863 = $this -> _get('path');
		if (empty($var_57ffb863)) {
			$var_27a137b4 = realpath($var_689de1a2) . '/';
			$var_5b6031e6 = $var_59be2dca;
			$var_63b10a16 = '';
			$var_9cef1abd = '';
		} else {
			$var_27a137b4 = realpath($var_689de1a2) . '/' . $var_57ffb863;
			$var_5b6031e6 = $var_59be2dca . $var_57ffb863;
			$var_63b10a16 = $var_57ffb863;
			$var_9cef1abd = preg_replace('/(.*?)[^\\/]+\\/$/', '$1', $var_63b10a16);
		} 
		echo realpath($var_689de1a2);
		$var_253990b8 = empty($_GET['order']) ? 'name' : strtolower($_GET['order']);
		if (preg_match('/\\.\\./', $var_27a137b4)) {
			$this -> ajaxReturn(array('error' => 1, 'message' => 'Access is not allowed.'));
		} 
		if (!preg_match('/\\/$/', $var_27a137b4)) {
			$this -> ajaxReturn(array('error' => 1, 'message' => 'Parameter is not valid.'));
		} 
		if (!file_exists($var_27a137b4) || !is_dir($var_27a137b4)) {
			$this -> ajaxReturn(array('error' => 1, 'message' => 'Directory does not exist.'));
		} 
		$var_27348aac = array();
		if ($var_08658966 = opendir($var_27a137b4)) {
			$var_7ea74e20 = 0;
			while (false !== ($var_3d815bdc = readdir($var_08658966))) {
				if ($var_3d815bdc {
						0} == '.') continue;
				$var_980a7c7e = $var_27a137b4 . $var_3d815bdc;
				if (is_dir($var_980a7c7e)) {
					$var_27348aac[$var_7ea74e20]['is_dir'] = true;
					$var_27348aac[$var_7ea74e20]['has_file'] = (count(func_9193adfb($var_980a7c7e)) > 2);
					$var_27348aac[$var_7ea74e20]['filesize'] = 0;
					$var_27348aac[$var_7ea74e20]['is_photo'] = false;
					$var_27348aac[$var_7ea74e20]['filetype'] = '';
				} else {
					$var_27348aac[$var_7ea74e20]['is_dir'] = false;
					$var_27348aac[$var_7ea74e20]['has_file'] = false;
					$var_27348aac[$var_7ea74e20]['filesize'] = filesize($var_980a7c7e);
					$var_27348aac[$var_7ea74e20]['dir_path'] = '';
					$var_2a7454e7 = strtolower(pathinfo($var_980a7c7e, 4));
					$var_27348aac[$var_7ea74e20]['is_photo'] = in_array($var_2a7454e7, $var_ca8ca2fc);
					$var_27348aac[$var_7ea74e20]['filetype'] = $var_2a7454e7;
				} 
				$var_27348aac[$var_7ea74e20]['filename'] = $var_3d815bdc;
				$var_27348aac[$var_7ea74e20]['datetime'] = date('Y-m-d H:i:s', filemtime($var_980a7c7e));
				if ($var_aaf2f8ed == 'images' && $var_27348aac[$var_7ea74e20]['is_dir'] == false && $var_27348aac[$var_7ea74e20]['is_photo'] == false) {
					unset($var_27348aac[$var_7ea74e20]);
				} 
				$var_7ea74e20++;
			} 
			closedir($var_08658966);
		} 
		usort($var_27348aac, array('editorAction', 'cmp_func'));
		$var_35b7c6eb = array();
		$var_35b7c6eb['moveup_dir_path'] = $var_9cef1abd;
		$var_35b7c6eb['current_dir_path'] = $var_63b10a16;
		$var_35b7c6eb['current_url'] = $var_5b6031e6;
		$var_35b7c6eb['total_count'] = count($var_27348aac);
		$var_35b7c6eb['file_list'] = $var_27348aac;
		$this -> ajaxReturn($var_35b7c6eb);
	} 
	private function cmp_func($var_55df87ba, $var_7c3e9a74) {
		global $var_253990b8;
		if ($var_55df87ba['is_dir'] && !$var_7c3e9a74['is_dir']) {
			return - 1;
		} else if (!$var_55df87ba['is_dir'] && $var_7c3e9a74['is_dir']) {
			return 1;
		} else {
			if ($var_253990b8 == 'size') {
				if ($var_55df87ba['filesize'] > $var_7c3e9a74['filesize']) {
					return 1;
				} else if ($var_55df87ba['filesize'] < $var_7c3e9a74['filesize']) {
					return - 1;
				} else {
					return 0;
				} 
			} else if ($var_253990b8 == 'type') {
				return strcmp($var_55df87ba['filetype'], $var_7c3e9a74['filetype']);
			} else {
				return strcmp($var_55df87ba['filename'], $var_7c3e9a74['filename']);
			} 
		} 
	} 
} 

?>