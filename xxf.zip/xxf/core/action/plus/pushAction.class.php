<?php class pushAction extends plusAction {
	public $var_4edaccf5 = array();
	public function _init() {
		parent :: _init();
		$this -> func_09668292 = CACHE_PATH . 'push_auto/push.log';
		if (is_file($this -> func_09668292) && filesize($this -> func_09668292) >= (1024 * 1024 * 1)) {
			@unlink($this -> func_09668292);
		} 
		$this -> func_1d4cbd7b = TEMP_PATH . 'push_config.php';
		if (is_file($this -> func_1d4cbd7b)) {
			$this -> func_f52fd2fc = require $this -> func_1d4cbd7b;
			if ($this -> func_f52fd2fc['push_configtype_zz'] == 2 && is_file('.' . $this -> func_f52fd2fc['push_configfile_zz'])) {
				$var_3fcdfe70 = file_get_contents('.' . $this -> func_f52fd2fc['push_configfile_zz']);
				$this -> func_f52fd2fc['token_list_zz'] = trim($var_3fcdfe70);
			} 
			if ($this -> func_f52fd2fc['push_configtype_yd'] == 2 && is_file('.' . $this -> func_f52fd2fc['push_configfile_yd'])) {
				$var_3fcdfe70 = file_get_contents('.' . $this -> func_f52fd2fc['push_configfile_yd']);
				$this -> func_f52fd2fc['token_list_yd'] = trim($var_3fcdfe70);
			} 
			if ($this -> func_f52fd2fc['push_configtype_mip'] == 2 && is_file('.' . $this -> func_f52fd2fc['push_configfile_mip'])) {
				$var_3fcdfe70 = file_get_contents('.' . $this -> func_f52fd2fc['push_configfile_mip']);
				$this -> func_f52fd2fc['token_list_mip'] = trim($var_3fcdfe70);
			} 
			$GLOBALS['push_conf'] = $this -> func_f52fd2fc;
		} 
	} 
	public function run() {
		write($this -> func_09668292, '-------------start(' . date('Y-m-d H:i:s') . ")\r\n", 'a+');
		$var_6cbe6605 = 0;
		$var_31b7b1f9 = CACHE_PATH . 'push_auto/key.txt';
		if (is_file($var_31b7b1f9)) {
			$var_6cbe6605 = file_get_contents($var_31b7b1f9);
		} 
		$var_71919e64 = func_308b9c75($GLOBALS['push_conf']['token_list_zz'], $GLOBALS['push_conf']['token_list_yd'], $GLOBALS['push_conf']['token_list_mip']);
		$var_1ffe317b = trim($var_71919e64[$var_6cbe6605]);
		if (!$var_1ffe317b) {
			unlink($var_31b7b1f9);
			write($this -> func_09668292, '-------------未找到推送配置' . '
', 'a+');
			exit('0');
		} 
		$var_7ea74e20 = 0;
		while (func_da30f52e($var_1ffe317b)) {
			$var_6cbe6605++;
			$var_7ea74e20++;
			if ($var_7ea74e20 > count($var_71919e64)) {
				write($this -> func_09668292, '-------------所有推送配额已用完' . '
', 'a+');
				exit();
			} 
			if (!isset($var_71919e64[$var_6cbe6605])) {
				$var_6cbe6605 = 0;
			} 
			$var_1ffe317b = trim($var_71919e64[$var_6cbe6605]);
		} 
		$var_5c45411b = $var_6cbe6605 + 1;
		if (!isset($var_71919e64[$var_5c45411b])) {
			$var_5c45411b = 0;
		} 
		$var_586a20ab = explode('----', $var_1ffe317b);
		$var_4c9dff78 = array_pop($var_586a20ab);
		if ($var_4c9dff78 == 'yd' && $GLOBALS['push_conf']['push_num_yd']) {
			$GLOBALS['push_conf']['push_num'] = $GLOBALS['push_conf']['push_num_yd'];
		} else if ($var_4c9dff78 == 'mip' && $GLOBALS['push_conf']['push_num_mip']) {
			$GLOBALS['push_conf']['push_num'] = $GLOBALS['push_conf']['push_num_mip'];
		} else if ($var_4c9dff78 == 'zz' && $GLOBALS['push_conf']['push_num_zz']) {
			$GLOBALS['push_conf']['push_num'] = $GLOBALS['push_conf']['push_num_zz'];
		} 
		$var_de5c1562 = array();
		$var_de5c1562 = func_28a69079($var_1ffe317b);
		$var_516e60ee = array('urlnum' => $var_de5c1562['urlnum'], 'isxiong' => (int)$var_de5c1562['isxiong'], 'type' => $var_de5c1562['type'], 'domain' => $var_de5c1562['domain'], 'success' => $var_de5c1562['success'], 'remain' => $var_de5c1562['remain'], 'msg' => $var_de5c1562['logmsg'], 'guaji' => 0,);
		write($this -> func_09668292, '-------------' . $var_de5c1562['mulu_url'] . '（' . $var_de5c1562['msg'] . '）
', 'a+');
		write($var_31b7b1f9, $var_5c45411b);
		func_7f102729($var_516e60ee);
		write($this -> func_09668292, '-------------end' . '
', 'a+');
		exit('1');
	} 
} 

?>