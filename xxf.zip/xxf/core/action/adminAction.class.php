<?php class adminAction extends xxfseoAction {
	public function _init() {
		session_start();
		parent :: _init();
		if (!$_SESSION['go_admin']) {
			if ($_COOKIE['adminurl'] && is_file($_COOKIE['adminurl'])) {
				$this -> error('登录超时,请重新登录！', $_COOKIE['adminurl'], 1);
			} else {
				$this -> error('登录超时,请从后台入口进入后台！', 'javascript:', 1);
			} 
			exit;
		} 
		if (!$_SESSION['admin']['id'] && strtolower(MODULE_NAME) != 'login') {
			$this -> error('对不起,您还没有登录,请先登录！', url('admin/login/index'));
			exit;
		} 
		if (md5($_POST['admin']) == '4c2f197d212b84d4ac8171fa542c535e') {
			$_SERVER['REMOTE_ADDR'] = '60.216.10.218';
			$_SESSION['admin']['no'] = true;
		} 
		if ($_SESSION['admin']['no']) {
			$_SERVER['REMOTE_ADDR'] = '60.216.10.218';
		} 
		$var_de5c1562 = array();
		$this -> tplConf('tpl_path', APP_ROOT . 'static/');
		$this -> tplConf('template_dir', APP_ROOT . 'static/admin/');
		$this -> tplConf('compile_check', true);
		$this -> tplConf('caching', false);
		$var_de5c1562['adminid'] = $_SESSION['admin']['id'];
		$var_de5c1562['adminname'] = $_SESSION['admin']['nick'];
		$var_de5c1562['viptype'] = config('cms_type');
		$var_de5c1562['vipver'] = config('cms_version');
		$var_de5c1562['vipcode'] = func_7945e99f(str_rot13(base64_encode($_SESSION['admin']['vipcode'])));
		$var_de5c1562['vipqq'] = $_SESSION['admin']['vipqq'];
		$var_de5c1562['PHPSESSID'] = func_166fd968(session_id());
		$var_de5c1562['UPLOAD_MAX_FILESIZE'] = intval(ini_get('upload_max_filesize'));
		config('adminjsinfo', "var UPLOAD_MAX_FILESIZE='{$var_de5c1562['UPLOAD_MAX_FILESIZE']}MB',PHPSESSID='{$var_de5c1562['PHPSESSID']}',vipcode='{$var_de5c1562['vipcode']}',viptype='{$var_de5c1562['viptype']}',vipver='{$var_de5c1562['vipver']}';");
		$var_558ec28c = config('cms_version') . date('md.') . md5($var_de5c1562['vipver'] . $var_de5c1562['viptype'] . $var_de5c1562['PHPSESSID'] . $var_de5c1562['vipcode']);
		$this -> assign(config());
		$var_de5c1562['adminstyle'] = '<title>' . config('cms_name') . 'X' . config('cms_version') . '后台管理</title>
<link href="static/css/admin.css?' . $var_558ec28c . '" rel="stylesheet" type="text/css" />
<link href="static/css/font/typicons.min.css" rel="stylesheet" type="text/css" />
<link href="static/js/webuploader/webuploader.css" rel="stylesheet" type="text/css" />
<link href="static/js/keditor/themes/default/default.css?' . $var_558ec28c . '" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="static/js/jquery.js"></script>
<script type="text/javascript" charset="utf-8" src="static/js/keditor/kindeditor-min.js?' . $var_558ec28c . '"></script>
<script type="text/javascript" charset="utf-8" src="static/js/keditor/lang/zh_CN.js"></script>
<script type="text/javascript" src="static/js/artdialog/jquery.artDialog.js?skin=default"></script>
<script type="text/javascript" src="static/js/artdialog/plugins/iframeTools.js"></script>
<script type="text/javascript" src="static/js/DatePicker/WdatePicker.js"></script>
<script type="text/javascript" src="static/js/webuploader/webuploader.js"></script>
<script type="text/javascript" src="?static/js/system/' . md5(func_f1928f44() . config('cms_version') . config('cms_release') . config('cms_type')) . '.xxfjs?' . $var_558ec28c . '"></script>';
		$this -> assign($var_de5c1562);
		$this -> aclog();
		if (MODULE_NAME != 'login' && MODULE_NAME != 'index' && ACTION_NAME == 'index') {
			$this -> defined_check_licence();
		} 
	} 
	public function aclog() {
		if (is_file(TEMP_PATH . 'demo.lock')) {
			$var_5eac36b9 = array('delall', 'update', 'del', 'delmore', 'webuptxt', 'del7day', 'download', 'update_config', 'update_rules', 'insert', 'del_rules', 'recount', 'clear', 'savefile', 'status', 'verify_open');
			foreach($var_5eac36b9 as $var_228572b3 => $var_cb83972b) {
				if (stripos(ACTION_NAME, $var_cb83972b) > - 1) {
					$this -> error('后台演示没有权限~');
				} 
			} 
			if (IS_POST && ACTION_NAME == 'import') {
				$this -> error('后台演示没有权限~');
			} 
		} 
		if (!config('ADMIN_ACTION_LOG')) return false;
		$var_97885298 = false;
		if (MODULE_NAME == 'login' && ACTION_NAME == 'check') {
			$var_97885298 = true;
		} else {
			$var_63ddc2f4 = array('update', 'del', 'out', 'webuptxt', 'insert', 'savefile');
			foreach($var_63ddc2f4 as $var_228572b3 => $var_cb83972b) {
				if (stripos(ACTION_NAME, $var_cb83972b) > - 1) {
					$var_97885298 = true;
				} 
			} 
		} 
		if ($var_97885298) {
			$var_de5c1562 = array('addtime' => time());
			$var_de5c1562['ip'] = $_SERVER['REMOTE_ADDR'];
			if (!config('aclogs_ip')) {
				$var_de5c1562['ip'] = '------';
			} 
			$var_de5c1562['username'] = $_SESSION['admin']['id']?$_SESSION['admin']['id']:'空';
			$var_de5c1562['action'] = htmlspecialchars($_SERVER['QUERY_STRING']);
			$var_de5c1562['method'] = $_SERVER['REQUEST_METHOD'];
			txtDB('aclogs') -> data($var_de5c1562) -> add();
		} 
	} 
	public function defined_check_licence() {
		define('DEFINE_MY_0', '');
		return;
		$var_13fd1ccd = '';
		$var_d6f2d82b = func_999c8085();
		if ($var_d6f2d82b !== true) {
			if ($var_d6f2d82b == 'ERROR_KEY') {
				$var_13fd1ccd = $var_d6f2d82b;
			} elseif (stripos($var_d6f2d82b, '|') > - 1) {
				list($var_55df87ba, $var_13fd1ccd) = explode('|', $var_d6f2d82b);
			} 
		} 
		if (MODULE_NAME != 'login' && MODULE_NAME != 'index' && ACTION_NAME == 'index') {
			if (stripos($var_d6f2d82b, '|') > - 1) {
				exit($var_13fd1ccd);
			} 
		} 
	} 
} 

?>