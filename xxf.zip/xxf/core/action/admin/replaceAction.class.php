<?php class replaceAction extends adminAction {
	public function _init() {
		parent :: _init();
		$this -> func_1d4cbd7b = TEMP_PATH . 'replace_config.php';
		if (is_file($this -> func_1d4cbd7b)) {
			$this -> func_f52fd2fc = require $this -> func_1d4cbd7b;
			$this -> assign($this -> func_f52fd2fc);
		} 
	} 
	public function index() {
		$this -> display();
	} 
	public function update() {
		$var_1b04f3c8 = $_POST['con'];
		foreach($var_1b04f3c8 as $var_228572b3 => $var_d8bba397) {
			$var_1b04f3c8[$var_228572b3] = func_e838d727(trim($var_1b04f3c8[$var_228572b3]));
		} 
		$var_7c7d0dd9 = array();
		if (is_file($this -> func_1d4cbd7b)) {
			$var_7c7d0dd9 = require $this -> func_1d4cbd7b;
		} 
		$var_be12f82d = array_merge($var_7c7d0dd9, $var_1b04f3c8);
		ksort($var_be12f82d);
		func_3c22ed21($this -> func_1d4cbd7b, $var_be12f82d);
		$this -> success('保存成功！');
	} 
} 

?>