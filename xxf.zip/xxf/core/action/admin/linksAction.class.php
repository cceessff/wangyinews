<?php class linksAction extends adminAction {
	public function _init() {
		parent :: _init();
	} 
	public function config() {
		$var_36a0b2a2 = txtDB('domain') -> select();
		$var_35b7c6eb = txtDB('links') -> select();
		$var_caaeb71d = array('title' => '标题库', 'keywords' => '关键词库', 'url' => '使用URL链接', 'txt' => '指定txt文件',);
		$var_35b7c6eb = func_809cbb58($var_35b7c6eb, 'cid');
		foreach($var_35b7c6eb as $var_228572b3 => $var_cb83972b) {
			$var_35b7c6eb[$var_228572b3]['links_titlename'] = $var_caaeb71d[$var_cb83972b['links_title']];
		} 
		foreach($var_36a0b2a2 as $var_228572b3 => $var_cb83972b) {
			$var_36a0b2a2[$var_228572b3]['isset'] = false;
			if (isset($var_35b7c6eb[$var_cb83972b['id']])) {
				$var_71e9f77f = $var_cb83972b['id'];
				$var_36a0b2a2[$var_228572b3]['isset'] = true;
				$var_36a0b2a2[$var_228572b3]['data'] = $var_35b7c6eb[$var_71e9f77f];
			} 
		} 
		$this -> assign('default', $var_35b7c6eb[0]);
		$this -> assign('list', $var_36a0b2a2);
		$this -> display();
	} 
	public function edit() {
		$var_71e9f77f = $this -> _get('cid');
		$var_35b7c6eb = txtDB('links') -> where('cid=' . $var_71e9f77f) -> find();
		if (!$var_35b7c6eb) {
			$var_35b7c6eb = txtDB('links') -> where('cid=0') -> find();
		} 
		$this -> assign($var_35b7c6eb);
		$this -> assign('cid', $var_71e9f77f);
		$this -> display();
	} 
	public function del() {
		$var_71e9f77f = $this -> _get('cid');
		$var_35b7c6eb = txtDB('links') -> where('cid=' . $var_71e9f77f) -> delete();
		if (!$var_35b7c6eb) $this -> error('删除失败！');
		$this -> success('删除成功！');
	} 
	public function update() {
		$var_c5256d61 = $_POST['r'];
		foreach($var_c5256d61 as $var_228572b3 => $var_d8bba397) {
			$var_c5256d61[$var_228572b3] = func_e838d727(trim($var_c5256d61[$var_228572b3]));
		} 
		$var_c5256d61['addtime'] = time();
		$var_35b7c6eb = txtDB('links') -> where('cid=' . $var_c5256d61['cid']) -> find();
		if ($var_35b7c6eb) {
			$var_ae21f2d5 = array('cid=' . $var_c5256d61['cid']);
			$var_35b7c6eb = txtDB('links') -> where($var_ae21f2d5) -> data($var_c5256d61) -> save();
		} else {
			$var_35b7c6eb = txtDB('links') -> data($var_c5256d61) -> add();
		} 
		if ($var_35b7c6eb) {
			$this -> ajaxReturn(array('status' => 1, 'info' => '保存成功！'));
		} else {
			$this -> ajaxReturn(array('status' => 0, 'info' => '保存失败！'));
		} 
	} 
} 

?>