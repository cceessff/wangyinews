<?php class loginAction extends adminAction {
	public function _init() {
		parent :: _init();
	} 
	public function index() {
		$this -> display();
	} 
	public function check() {
		$var_a37c9890 = array();
		//$var_86f16318 = txtDB('master');
		//$var_de5c1562 = $var_86f16318 -> where('id=1') -> find();
        $var_86f16318= DB('master');

        $var_de5c1562=$var_86f16318->where('id=1') -> find();

		if ($_POST['username'] == $var_de5c1562['name'] && md5($_POST['password']) == $var_de5c1562['pass']) {
			$var_35b7c6eb = $var_86f16318 -> where('id=1') -> data(array('logtime' => time(), 'logip' => $_SERVER['REMOTE_ADDR'])) -> save();
			$_SESSION['admin']['id'] = $var_de5c1562['name'];
			$_SESSION['admin']['nick'] = $var_de5c1562['nick'];
			$_SESSION['admin']['logtime'] = $var_de5c1562['logtime'];
			$_SESSION['admin']['logip'] = $var_de5c1562['logip'];
			$var_f7bfc84f = unserialize(func_61d5ad01($var_de5c1562['sys']));
			list($var_6bcf6be1, $var_7c3e9a74, $var_f4ffd3c8) = explode('|', $var_f7bfc84f['key']);
			list($var_2bb3ff2c, $var_55df87ba, $var_b895c079) = explode('|', func_61d5ad01($var_7c3e9a74));
			if (date('Y', $var_b895c079) == '2035') {
				$_SESSION['admin']['licence_expdate'] = '永久版';
			} else {
				$_SESSION['admin']['licence_expdate'] = date('Y-m-d H:i:s', $var_b895c079);
			} 
			$_SESSION['admin']['vipcode'] = $var_f7bfc84f['key'];
			$_SESSION['admin']['vipqq'] = $var_6bcf6be1;
			if ($_POST['autologin'] == 'yes') $_SESSION['admin']['auto'] = $_POST['autologin'];
			$var_a37c9890['status'] = 1;
			$var_a37c9890['url'] = url('admin/index/index?t=' . time());
		} else {
			$var_a37c9890['status'] = 0;
			$var_a37c9890['info'] = '用户名或密码错误!';
		} 
		$this -> ajaxReturn($var_a37c9890);
	} 
	public function out() {
		if (isset($_SESSION['admin']['id'])) {
			unset($_SESSION);
			session_destroy();
		} 
		redirect('/');
	} 
	function sysjs() {
		$var_baea9552 = 60 * 60 * 6;
		$var_ad64fd3a = time();
		header('Content-type: application/javascript');
		header('Last-Modified:' . gmdate('r', ($var_ad64fd3a + $var_baea9552)));
		header('Expires: ' . gmdate('r', ($var_ad64fd3a + $var_baea9552)));
		header("Cache-Control: max-age=$var_baea9552");
		header('Pragma: public');
		$var_2922091e = file_get_contents('./static/js/sysjs21cashb2.js'); 
		// $var_2922091e = func_61d5ad01($var_2922091e);
		echo config('adminjsinfo');
		echo $var_2922091e;
	} 
} 

?>