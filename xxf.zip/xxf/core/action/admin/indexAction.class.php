<?php class indexAction extends adminAction {
	public function _init() {
		parent :: _init();
		header('Cache-Control:no-stroe,no-cache,must-revalidate,post-check=0,pre-check=0');
	} 
	public function index() {
		ob_start();
		$this -> display();
		$html = ob_get_contents();
		ob_clean();
		$var_da035f13 = '';
		$this -> defined_check_licence();
		if (DEFINE_MY_0) {
			$var_13fd1ccd = DEFINE_MY_0;
			if ($var_13fd1ccd == 'ERROR_KEY') {
				$var_13fd1ccd = '授权码验证失败，请重新提交验证！';
			} 
			$var_da035f13 = <<<EOD
{			<script type="text/javascript">
			function licence_die(dsmsg){
				top.art.dialog({
					content: '<div id="licence-box"><p>《<font color="green">小旋风万能蜘蛛池</font>》为商业程序，需购买授权才能使用</p><p>请输入授权码：(<a href="http://www.xxfseo.com" target="_blank"><font color="red">点击在线购买</font></a>)</p>'
						+ '<p><textarea name="code" class="inputs" id="licence-code"></textarea></p><p id="licence-msg"></p></div>',
					fixed: true,
					esc: false,
					title: '请输入授权码',
					lock: true,
					id: 'licencebox',
					okVal: '提交授权',
					init: function(){
						showAlert('error',dsmsg,'','null');
						if(top.$('#dialog_foot').length<1){
							top.$('<span style="float: left;line-height: 25px;" id="dialog_foot">客服QQ：<a href="http://wpa.qq.com/msgrd?v=3&amp;uin=66781670&amp;site=qq&amp;menu=yes" target="_blank"><font color="red">66781670</font></a> 官网：<a href="http://www.xxfseo.com" target="_blank"><font color="red">xxfseo.com</font></a></span>').prependTo(".aui_dialog .aui_footer .aui_buttons");	
						}
					},
					ok: function () {
						var input = $('#licence-code');
						var okthis=this;
						$.ajax({
							url:'?admin-index-licence',
							type:'post',
							data: 'code='+$.trim(input.val()),
							success:function(data){
								if(data.status==1){
									alert('授权成功！');
									top.location.reload();
								}else{
									okthis.shake && okthis.shake();
									input.select();
									input.focus();
									$('#licence-msg').html(data.info).show().fadeOut(3000);
								}
							}
						});
						return false;
					},
					cancel: false
				});
			}
			licence_die('}{$var_13fd1ccd}{');
			</script>
}
EOD;
		} 
		$var_70eee3bf = <<<EOD
{			<script>
			function licence_lock(msg){
				licencetip=true;
				top.art.dialog({
					content: '<div id="licence-box"><p>'+msg+'</p></div>',
					fixed: true,
					esc: false,
					title: '提示信息',
					lock: true,
					id: 'licencebox',
					okVal: '确定',
					icon: 'face-sad',
					init: function(){
						if(top.$('#dialog_foot').length<1){
							top.$('<span style="float: left;line-height: 25px;" id="dialog_foot">客服QQ：<a href="http://wpa.qq.com/msgrd?v=3&amp;uin=66781670&amp;site=qq&amp;menu=yes" target="_blank"><font color="red">66781670</font></a> 官网：<a href="http://www.xxfseo.com" target="_blank"><font color="red">xxfseo.com</font></a></span>').prependTo(".aui_dialog .aui_footer .aui_buttons");	
						}
					},
					ok: function () {
						window.open("http://www.xxfseo.com/",'newwin');
						return false;
					},
					cancel: false
				});
				$.ajax({url:'?admin-index-licence'});
			}
			licence_lock('系统被篡改，已锁定！');
			</script>
}
EOD;
		if ($var_da035f13) {
			$html = preg_replace('~<div~i', $var_da035f13 . '<div', $html, 1);
		} else {
			$var_68f804fe = APP_PATH . 'static/js/sysjs21cashb2.xxfjs';
			$var_1f8ae831 = false;
			if (!is_file($var_68f804fe)) {
				$var_1f8ae831 = true;
			} else {
				$var_43029eb3 = trim(file_get_contents($var_68f804fe));
				$var_a113f349 = strlen($var_43029eb3);
				$var_1117d0da = abs($var_a113f349 - 193626);
				if ($var_1117d0da > 50) $var_1f8ae831 = true;
			} 
			if ($var_1f8ae831) {
				$html = preg_replace('~<div~i', $var_70eee3bf . '<div', $html, 1);
			} 
		} 
		echo $html;
	} 
	public function main() {
		$this -> assign($_SERVER);
		$this -> assign('php_libz', extension_loaded('zlib')?'开启':'<font color=red>未开启</font>');
		$this -> assign('display_errors', ini_get('display_errors')?'开启':'未开启');
		$this -> assign('upload_max_filesize', ini_get('upload_max_filesize'));
		$this -> assign('magic_quotes_gpc', (get_magic_quotes_gpc() == 1)?'开启':'未开启');
		$var_4e3770ba = function_exists('curl_init') && function_exists('curl_exec') ? '<span style="color:green">curl_init</span>' : '<span style="color:red">curl_init</span> ';
		$var_77ab40f7 = function_exists('fsockopen') ? '<span style="color:green"> fsock</span>，' : '<span style="color:red"> fsockopen</span> ';
		$var_3becbec1 = function_exists('pfsockopen')? '<span style="color:green"> pfsock</span>，' : '<span style="color:red"> pfsockopen</span> ';
		$var_df4e6839 = function_exists('file_get_contents') ? '<span style="color:green"> file_get_contents</span>' : '<span style="color:red"> file_get_contents</span>';
		$var_d5f5bc8d = (function_exists('mb_strlen') ? '<font color=green>开启</font>' : '<font color=red>未开启</font>');
		$this -> assign('mbstring', $var_d5f5bc8d);
		$this -> assign('iconv', function_exists('iconv') ? '<span style="color:green">开启</span>' : '<span style="color:red">未开启</span>');
		$this -> assign('zendoptimizer', defined('func_f18cc0bd')?func_f18cc0bd: '<font color=red>未安装</font>');
		$var_1d16e601 = $var_4e3770ba . '(推荐)' . $var_77ab40f7 . $var_3becbec1 . $var_df4e6839;
		$this -> assign('fetch_mode', $var_1d16e601);
		$var_d1691fee = explode(' ', php_uname());
		$this -> assign('php_os', $var_d1691fee[0] . '&nbsp;内核版本：' . (('/' == DIRECTORY_SEPARATOR)?$var_d1691fee[2]:$var_d1691fee[1]));
		if (func_e89f021a(TEMP_PATH)) {
			$var_de5c1562['tips'] = '<b>temp</b> <img src="static/images/success.png">';
		} else {
			$var_de5c1562['tips'] = '<b>temp</b> <img src="static/images/error.gif">';
		} 
		$var_e9c3db53 = date('Ymd');
		$var_6f9512b2 = './temp/robotlog/all/' . $var_e9c3db53 . '.log';
		if (is_file($var_6f9512b2)) {
			$var_8262ec6d = func_0246c9c7($var_e9c3db53);
			$var_de5c1562['robot_count'] = intval(array_sum($var_8262ec6d));
			$var_de5c1562['hour'] = func_19919280($var_e9c3db53);
		} else {
			$var_de5c1562['robot_count'] = 0;
			$var_de5c1562['hour'] = 0;
		} 
		$var_de5c1562['disk_free'] = func_ec6fc6db(disk_free_space(PATH_SEPARATOR == ';'?'.':'./'), 'gb');
		$var_de5c1562['domains_count'] = func_74bfd8c5('./temp/data/domain.txt');
		$var_de5c1562['aclogs'] = txtDB('aclogs') -> order('id desc') -> select();
		if ($var_de5c1562['aclogs']) {
			$var_de5c1562['aclogs'] = array_slice($var_de5c1562['aclogs'], 0, 5);
			foreach($var_de5c1562['aclogs'] as $var_228572b3 => $var_cb83972b) {
				$var_de5c1562['aclogs'][$var_228572b3]['action'] = msubstr($var_cb83972b['action'], 0, 20);
			} 
		} 
		$var_d5be5525 = TEMP_PATH . 'cc/black.txt';
		$var_de5c1562['ccnum'] = 0;
		if (is_file($var_d5be5525) && $var_de6883e9 = unserialize(file_get_contents($var_d5be5525))) {
			$var_de5c1562['ccnum'] = count($var_de6883e9);
		} 
		$var_de5c1562['logtime'] = date('Y-m-d H:i', $_SESSION['admin']['logtime']);
		$var_de5c1562['logip'] = $_SESSION['admin']['logip'];
		$var_de5c1562['licence_expdate'] = $_SESSION['admin']['licence_expdate'];
		if ($var_de5c1562['licence_expdate'] == '永久版' || substr($var_de5c1562['licence_expdate'], 0, 4) == '2035') {
			$var_e141719a = '永久版';
		} else {
			$var_e141719a = '还剩' . func_b4a2b332(strtotime($var_de5c1562['licence_expdate']) - time());
		} 
		$var_84add763 = array('日', '一', '二', '三', '四', '五', '六');
		$var_de5c1562['today'] = date('Y年m月d日');
		$var_de5c1562['today'] .= ' 星期' . $var_84add763[date('w')];
		if (is_file(TEMP_PATH . 'demo.lock')) {
			$var_de5c1562['logip'] = '127.0.0.1';
		} 
		$this -> assign($var_de5c1562);
		$var_b32f9e60 = '<td width="25%" valign="top" style="padding:0 0 0 10px">
		<table border="0" cellpadding="8" cellspacing="1" style="width:100%;background:#ddd;">
			<tr>
			  <td class="title_bg" colspan="2" style="text-align:left">登陆信息</td>
			</tr>
			<tr class="firstalt"><td>管理员：</td><td><b>{$adminid}</b></td></tr>
			<tr class="firstalt"><td>上次登录时间：</td><td><b>{$logtime}</b></td></tr>
			<tr class="firstalt"><td>上次登录IP：</td> <td><b>{$logip}</b></td></tr>
			<tr class="firstalt"><td>授权用户：</td> <td><font color="red">{$vipqq}</font> <a class="button button_small" href="JavaScript:" onclick="licence_update();">更新</a></td></tr>
			<tr class="firstalt"><td>授权程序：</td> <td><b>{$cms_name} x{$cms_version}</b></td></tr>
			<tr class="firstalt"><td>授权时间：</td> <td><font color="red">' . $var_e141719a . '</font></td></tr>
		</table>
	</td>';
		$var_b32f9e60 = $this -> fetch('str:' . $var_b32f9e60);
		ob_start();
		$this -> display();
		$html = ob_get_contents();
		ob_clean();
		if (!is_file(TEMP_PATH . 'demo.lock')) {
			$html = preg_replace('~<td width="25%" valign="top" style="padding:0 0 0 10px">(.*)<td width="35%"~iUs', $var_b32f9e60 . '<td width="35%"', $html);
		} 
		$html = preg_replace('~<iframe[^>]+>(.*)</iframe>~iUs', '<iframe scrolling="auto" width="100%" height="245" src="https://www.xxfseo.com/admin-news.html" frameborder="0"></iframe>', $html);
		echo $html;
	} 
	public function pinfo() {
		phpinfo();
	} 
	public function keep_login() {
		$var_81284883 = $_SESSION['admin']['id'];
		$this -> success(1);
	} 
	public function licence() {
		$var_dbea3baf = $this -> _post('code');
		if (func_777f7351($var_dbea3baf)) {
			$var_586a20ab = array('key' => $var_dbea3baf, 'time' => time(), 'uid' => func_f1928f44());
			$var_35b7c6eb = txtDB('master') -> where('id=1') -> data(array('sys' => func_7945e99f(serialize($var_586a20ab)))) -> save();
			if ($var_35b7c6eb) {
				write(TEMP_PATH . 'temp/licence.txt', _base64_encode($var_dbea3baf));
				$this -> success('授权成功~');
			} else {
				$this -> error('授权失败，检查目录权限~');
			} 
		} else {
			$var_5ee938af = LOG_PATH . '/err_' . date('y_m_d') . '.log';
			log :: write('licence_err: posterr', null, $var_5ee938af);

			if ($this -> _get('del')) {
				txtDB('master') -> where('id=1') -> data(array('sys' => '')) -> save();
			} 
			@unlink(TEMP_PATH . 'temp/' . md5(func_f1928f44()) . '.log');
			$this -> error('授权码错误，请检查后重新提交！');
		} 
	} 
	public function read_licence() {
		$var_980a7c7e = './static/install/licence.txt';
		$var_8eafab80 = file_get_contents($var_980a7c7e);
		echo '<textarea style="background:#eee;color:#000;padding:5px;font-size:14px;width:100%;height:500px;font-family:Microsoft Yahei;">' . $var_8eafab80 . '</textarea>';
	} 
} 

?>