<?php class keywordsAction extends adminAction {
	public function _init() {
		parent :: _init();
		$this -> func_1d4cbd7b = TEMP_PATH . 'config.php';
	} 
	public function config() {
		$var_36a0b2a2 = txtDB('arctype') -> select();
		$var_36a0b2a2 = func_809cbb58($var_36a0b2a2, 'id');
		$var_35b7c6eb = txtDB('domain') -> select();
		foreach($var_35b7c6eb as $var_228572b3 => $var_cb83972b) {
			$var_35b7c6eb[$var_228572b3]['typename'] = $var_36a0b2a2[$var_cb83972b['cid']]['name'];
			$var_35b7c6eb[$var_228572b3]['addtime'] = now_date_color($var_35b7c6eb[$var_228572b3]['addtime']);
			$var_119ad111 = DATA_PATH . 'domain/' . $var_cb83972b['dirname'] . '_domain.txt';
			$var_b4dabed4 = file_get_contents($var_119ad111);
			$var_b4dabed4 = str_replace('
', ',', $var_b4dabed4);
			$var_35b7c6eb[$var_228572b3]['domain'] = substr($var_b4dabed4, 0, 20) . (strlen($var_b4dabed4) > 20?'...':'');
			$var_8c622afe = explode(',', $var_cb83972b['cid']);
			if (count($var_8c622afe) > 1) {
				$var_bad6c929 = array();
				foreach($var_8c622afe as $var_3d9151c4 => $var_1076c777) {
					$var_bad6c929[] = $var_36a0b2a2[$var_1076c777]['name'];
				} 
				$var_35b7c6eb[$var_228572b3]['typename'] = '多模型<a href="javascript:" title="' . implode(',', $var_bad6c929) . '">☢</a>';
			} 
		} 
		$var_35b7c6eb = func_809cbb58($var_35b7c6eb, 'id');
		$var_de5c1562['group_list'] = $var_35b7c6eb;
		if (config('insertkw_group') == '0') {
			$var_de5c1562['insertkw_group_name'] = '全部分组';
		} else if (config('insertkw_group')) {
			$var_586a20ab = explode(',', config('insertkw_group'));
			foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
				$var_fa979a58[] = $var_de5c1562['group_list'][$var_cb83972b]['name'];
			} 
			$var_de5c1562['insertkw_group_name'] = implode($var_fa979a58, ',');
		} 
		$this -> assign($var_de5c1562);
		$this -> display();
	} 
	public function update() {
		$var_1b04f3c8 = $_POST["con"];
		foreach($var_1b04f3c8 as $var_228572b3 => $var_d8bba397) {
			$var_1b04f3c8[$var_228572b3] = trim($var_1b04f3c8[$var_228572b3]);
			$var_1b04f3c8[$var_228572b3] = func_e838d727($var_1b04f3c8[$var_228572b3]);
		} 
		$var_7c7d0dd9 = require $this -> func_1d4cbd7b;
		$var_be12f82d = array_merge($var_7c7d0dd9, $var_1b04f3c8);
		ksort($var_be12f82d);
		func_3c22ed21($this -> func_1d4cbd7b, $var_be12f82d);
		$this -> success('设置成功');
	} 
} 

?>