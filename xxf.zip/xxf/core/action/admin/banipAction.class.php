<?php class banipAction extends adminAction {
	public function _init() {
		parent :: _init();
		$this -> func_1d4cbd7b = TEMP_PATH . 'config.php';
	} 
	public function index() {
		$this -> assign('web_banip_list', implode(PHP_EOL, explode("|||", config('web_banip_list'))));
		$this -> display();
	} 
	public function update() {
		$var_1b04f3c8 = $_POST['con'];
		$var_1b04f3c8['web_banip_list'] = trim($var_1b04f3c8['web_banip_list']);
		$var_1b04f3c8['web_banip_list'] = str_replace(array('
', '', '
', '

'), '|||', $var_1b04f3c8['web_banip_list']);
		$var_586a20ab = explode('|||', $var_1b04f3c8['web_banip_list']);
		foreach($var_586a20ab as $var_228572b3 => $var_d8bba397) {
			$var_586a20ab[$var_228572b3] = trim($var_586a20ab[$var_228572b3]);
			if (empty($var_586a20ab[$var_228572b3])) unset($var_586a20ab[$var_228572b3]);
			if (!preg_match('#^(\\*|\\d{1,3})\\.(\\*|\\d{1,3})\\.(\\*|\\d{1,3})\\.(\\*|\\d{1,3})$#', $var_586a20ab[$var_228572b3]) && !preg_match('#^\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\~\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}$#', $var_586a20ab[$var_228572b3]) && $var_586a20ab[$var_228572b3] != '') {
				$this -> error('格式不正确,请看说明重新设置');
			} 
		} 
		$var_1b04f3c8['web_banip'] = (bool)$var_1b04f3c8['web_banip'];
		$var_a37c9890 = array();
		$var_a37c9890['status'] = 1;
		$var_7c7d0dd9 = require $this -> func_1d4cbd7b;
		$var_be12f82d = array_merge($var_7c7d0dd9, $var_1b04f3c8);
		ksort($var_be12f82d);
		func_3c22ed21($this -> func_1d4cbd7b, $var_be12f82d);
		$this -> ajaxReturn($var_a37c9890);
	} 
} 

?>