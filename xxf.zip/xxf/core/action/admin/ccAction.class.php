<?php class ccAction extends adminAction {
	public function _init() {
		parent :: _init();
		$this -> func_1d4cbd7b = TEMP_PATH . 'config.php';
	} 
	public function index() {
		if (is_file($this -> func_1d4cbd7b)) {
			$var_7c7d0dd9 = require $this -> func_1d4cbd7b;
			config($var_7c7d0dd9);
		} 
		$var_d5be5525 = TEMP_PATH . 'cc/black.txt';
		$var_e8920bef = array();
		if (is_file($var_d5be5525) && $var_586a20ab = unserialize(file_get_contents($var_d5be5525))) {
			$var_fd835089 = count($var_586a20ab);
			foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
				$var_e8920bef[] = array('id' => $var_fd835089, 'ip' => $var_228572b3, 'addtime' => $var_cb83972b,);
				$var_fd835089--;
			} 
		} 
		$var_352304ce = array_merge(config('ROBOT_LIST'), array("other" => '其他蜘蛛'));
		$var_de5c1562['robot_list'] = $var_352304ce;
		$var_de5c1562['list_last'] = count($var_de5c1562['robot_list']);
		$var_9f4dcfb9 = TEMP_PATH . 'cc/white.txt';
		$var_de5c1562['cc_white'] = is_file($var_9f4dcfb9) ? file_get_contents($var_9f4dcfb9) :'';
		if (config('web_cc_robot_items')) {
			$var_de5c1562['robot_items_v'] = config('web_cc_robot_items');
			$var_de5c1562['robot_items'] = @explode(',', config('web_cc_robot_items'));
			$var_aca22417 = array();
			foreach($var_de5c1562['robot_items'] as $var_228572b3 => $var_cb83972b) {
				$var_aca22417[] = $var_352304ce[$var_cb83972b];
			} 
			$var_de5c1562['robot_items_name'] = implode($var_aca22417, ',');
		} 
		$this -> assign($var_de5c1562);
		$this -> assign('list', $var_e8920bef);
		$this -> del_cclog();
		$this -> display();
	} 
	public function del() {
		$var_332fc2f2 = $this -> _get('ip');
		if ($var_332fc2f2) {
			$var_d5be5525 = TEMP_PATH . 'cc/black.txt';
			$var_e8920bef = array();
			if (is_file($var_d5be5525) && $var_586a20ab = unserialize(file_get_contents($var_d5be5525))) {
				$var_e8920bef = $var_586a20ab;
			} 
			if (isset($var_e8920bef[$var_332fc2f2])) {
				unset($var_e8920bef[$var_332fc2f2]);
				write($var_d5be5525, serialize($var_e8920bef));
			} 
		} 
		$this -> success('删除成功！');
	} 
	public function update() {
		$var_1b04f3c8 = $_POST['con'];
		$var_9f4dcfb9 = TEMP_PATH . 'cc/white.txt';
		$var_afa35782 = $this -> _post('cc_white', '', '');
		write($var_9f4dcfb9, $var_afa35782);
		$var_7c7d0dd9 = require $this -> func_1d4cbd7b;
		$var_be12f82d = array_merge($var_7c7d0dd9, $var_1b04f3c8);
		ksort($var_be12f82d);
		func_3c22ed21($this -> func_1d4cbd7b, $var_be12f82d);
		$var_a37c9890 = array();
		$var_a37c9890['status'] = 1;
		$this -> ajaxReturn($var_a37c9890);
	} 
} 

?>