<?php class themeAction extends adminAction {
	public function _init() {
		parent :: _init();
		$this -> func_1d4cbd7b = TEMP_PATH . 'config.php';
	} 
	public function index() {
		$var_7c6c92b4 = $this -> _get('type');
		$var_36a0b2a2 = txtDB('arctype') -> select();
		$var_e5789fbb = $var_7c6c92b4 . '_' . $this -> _get('mtype');
		if ($var_e5789fbb == 'pc' || $var_7c6c92b4 == '') {
			$var_e5789fbb = $var_7c6c92b4;
		} 
		$var_6ac11d7b = func_64d0f4f3($var_e5789fbb);
		$var_36a0b2a2 = func_809cbb58($var_36a0b2a2, 'dirname');
		$var_370ebc88 = array();
		$var_de5c1562['total_mip'] = $var_de5c1562['total_mobile'] = $var_de5c1562['total_pc'] = 0;
		$var_de5c1562['total'] = count($var_6ac11d7b);
		$var_c4bd6ced = array();
		$var_8ca98899 = TEMP_PATH . 'temp/typecount.txt';
		if ($var_7c6c92b4) {
			if (is_file($var_8ca98899)) {
				$var_c9727f76 = file_get_contents($var_8ca98899);
				$var_c4bd6ced = unserialize($var_c9727f76);
				foreach($var_36a0b2a2 as $var_228572b3 => $var_cb83972b) {
					$var_36a0b2a2[$var_228572b3]['num'] = $var_c4bd6ced[$var_228572b3]['num'];
				} 
			} 
		} 
		foreach($var_6ac11d7b as $var_228572b3 => $var_cb83972b) {
			if (is_dir(TMPL_PATH . $var_228572b3)) {
				$var_f512ffae = './template/' . $var_228572b3 . '/preview.jpg';
				$var_938ce18d = './template/' . $var_228572b3 . '/name.txt';
				list($var_59d3c6b6, $var_aca22417) = explode('/', $var_228572b3);
				if (preg_match('~^\\w+_mobile~', $var_59d3c6b6)) {
					$var_229e7bf6 = 'num_mobile';
					$var_de5c1562['total_mobile']++;
					$var_59d3c6b6 = str_replace('_mobile', '', $var_59d3c6b6);
				} else if (preg_match('~^\\w+_mip~', $var_59d3c6b6)) {
					$var_229e7bf6 = 'num_mip';
					$var_de5c1562['total_mip']++;
					$var_59d3c6b6 = str_replace('_mip', '', $var_59d3c6b6);
				} else {
					$var_229e7bf6 = 'num_pc';
					$var_de5c1562['total_pc']++;
				} 
				!isset($var_36a0b2a2[$var_59d3c6b6][$var_229e7bf6]) && $var_36a0b2a2[$var_59d3c6b6][$var_229e7bf6] = 0;
				$var_36a0b2a2[$var_59d3c6b6][$var_229e7bf6]++;
				$var_c4bd6ced[$var_228572b3][$var_229e7bf6] = $var_36a0b2a2[$var_59d3c6b6][$var_229e7bf6];
				if ($var_7c6c92b4 && !preg_match('~^' . $var_7c6c92b4 . '/~', $var_228572b3) && !preg_match('~^' . $var_7c6c92b4 . '_mobile/~', $var_228572b3) && !preg_match('~^' . $var_7c6c92b4 . '_mip/~', $var_228572b3)) {
					continue;
				} 
				$var_c128156f = is_file($var_938ce18d)?func_4f521b6d(file_get_contents($var_938ce18d)):'';
				if ($var_c128156f) {
					$var_aca22417 = $var_c128156f . '(<font color="#999999">' . $var_aca22417 . '</font>)';
				} 
				$var_370ebc88[$var_228572b3]['name'] = $var_aca22417;
				$var_370ebc88[$var_228572b3]['typedir'] = $var_59d3c6b6;
				$var_370ebc88[$var_228572b3]['typename'] = $var_36a0b2a2[$var_59d3c6b6]['name'];
				$var_370ebc88[$var_228572b3]['dir'] = $var_228572b3;
				$var_370ebc88[$var_228572b3]['pic'] = is_file($var_f512ffae)?$var_f512ffae:'./static/images/nopic.gif';
				$var_370ebc88[$var_228572b3]['domain'] = str_replace('||', '
', $var_cb83972b);
			} 
		} 
		write($var_8ca98899, serialize($var_c4bd6ced));
		$var_462ccaaf = $var_63c9c8c6 = $var_e799f218 = array();
		foreach($var_370ebc88 as $var_228572b3 => $var_cb83972b) {
			if (preg_match('~^\\w+_mobile/~', $var_228572b3)) {
				$var_63c9c8c6[$var_228572b3] = $var_cb83972b;
			} else if (preg_match('~^\\w+_mip/~', $var_228572b3)) {
				$var_e799f218[$var_228572b3] = $var_cb83972b;
			} else {
				$var_462ccaaf[$var_228572b3] = $var_cb83972b;
			} 
		} 
		$this -> assign('mtype', $this -> _get('mtype', '', 'pc'));
		$this -> assign('type', $var_7c6c92b4);
		$this -> assign('class_list', $var_36a0b2a2);
		$this -> assign('pclist', $var_462ccaaf);
		$this -> assign('mlist', $var_63c9c8c6);
		$this -> assign('miplist', $var_e799f218);
		$this -> assign($var_de5c1562);
		$this -> display();
	} 
	public function update_config() {
		$var_10635ff1 = $_POST['id'];
		$var_b4dabed4 = $_POST['domain'];
		$var_b4dabed4 = str_replace(array('
', '', '
'), '||', $var_b4dabed4);
		$var_980a7c7e = TEMP_PATH . 'theme_config.php';
		$var_fce1a9da = require $var_980a7c7e;
		$var_fce1a9da[$var_10635ff1] = $var_b4dabed4;
		func_3c22ed21($var_980a7c7e, $var_fce1a9da);
		exit('更新成功');
	} 
} 

?>