<?php class pushAction extends adminAction {
	public $var_4edaccf5 = array();
	public function _init() {
		parent :: _init();
		$this -> func_1d4cbd7b = TEMP_PATH . 'push_config.php';
		if (is_file($this -> func_1d4cbd7b)) {
			$this -> func_f52fd2fc = require $this -> func_1d4cbd7b;
			$this -> assign($this -> func_f52fd2fc);
		} 
	} 
	public function index() {
		func_97869657(DATA_PATH . 'push_config');
		$var_7c6c92b4 = $this -> _get('type');
		$var_36588d5f = array('baidu' => '百度');
		$var_de5c1562 = array();
		$var_de5c1562['type'] = $var_7c6c92b4;
		$var_de5c1562['typename'] = $var_36588d5f[$var_7c6c92b4];
		$this -> display();
	} 
	public function guaji() {
		$this -> display();
	} 
	public function verify() {
		$this -> display();
	} 
	public function verify_check() {
		$var_b5ae185e = TEMP_PATH . 'verify.lock';
		if (is_file($var_b5ae185e)) {
			exit('1');
		} 
		exit('0');
	} 
	public function verify_open() {
		$var_b5ae185e = TEMP_PATH . 'verify.lock';
		$var_b945b287 = $this -> _get('sid');
		if ($var_b945b287 == 1 && is_file($var_b5ae185e)) {
			$var_35b7c6eb = unlink($var_b5ae185e);
		} else {
			$var_35b7c6eb = write($var_b5ae185e, time());
		} 
		if ($var_35b7c6eb) exit('1');
		exit('0');
	} 
	private function push_islock() {
		$var_b5ae185e = TEMP_PATH . 'push.lock';
		if (is_file($var_b5ae185e)) {
			if ((filemtime($var_b5ae185e) + config('push_interval')) < time()) {
				unlink($var_b5ae185e);
				return false;
			} else {
				return true;
			} 
		} 
		return false;
	} 
	public function guaji_run() {
		session_write_close();
		set_time_limit(180);
		$var_cb1bb906 = $this -> _get('isrun');
		$var_725c1d22 = $this -> _get('urlnum');
		$var_baea9552 = $this -> _get('interval');
		if (!$var_cb1bb906) {
			$var_84461e26 = '?admin-push-guaji_run-isrun-1-urlnum-' . $var_725c1d22 . '-interval-' . $var_baea9552;
			$this -> assign('iframeurl', $var_84461e26);
			$this -> assign('isrun', false);
			$this -> display();
			exit;
		} 
		$var_6cbe6605 = $this -> _get('key', '', 0);
		if ($this -> func_f52fd2fc['push_configtype_zz'] == 2 && is_file('.' . $this -> func_f52fd2fc['push_configfile_zz'])) {
			$var_3fcdfe70 = file_get_contents('.' . $this -> func_f52fd2fc['push_configfile_zz']);
			$this -> func_f52fd2fc['token_list_zz'] = $var_55df87ba = trim($var_3fcdfe70);
		} 
		if ($this -> func_f52fd2fc['push_configtype_yd'] == 2 && is_file('.' . $this -> func_f52fd2fc['push_configfile_yd'])) {
			$var_3fcdfe70 = file_get_contents('.' . $this -> func_f52fd2fc['push_configfile_yd']);
			$this -> func_f52fd2fc['token_list_yd'] = trim($var_3fcdfe70);
		} 
		if ($this -> func_f52fd2fc['push_configtype_mip'] == 2 && is_file('.' . $this -> func_f52fd2fc['push_configfile_mip'])) {
			$var_3fcdfe70 = file_get_contents('.' . $this -> func_f52fd2fc['push_configfile_mip']);
			$this -> func_f52fd2fc['token_list_mip'] = trim($var_3fcdfe70);
		} 
		$GLOBALS['push_conf'] = $this -> func_f52fd2fc;
		$GLOBALS['push_conf']['push_num'] = $var_725c1d22;
		$var_71919e64 = func_308b9c75($this -> func_f52fd2fc['token_list_zz'], $this -> func_f52fd2fc['token_list_yd'], $this -> func_f52fd2fc['token_list_mip']);
		$var_1ffe317b = trim($var_71919e64[$var_6cbe6605]);
		if (!$var_1ffe317b) {
			exit('未找到推送配置');
		} 
		$var_7ea74e20 = 0;
		while (func_da30f52e($var_1ffe317b)) {
			$var_6cbe6605++;
			$var_7ea74e20++;
			if ($var_7ea74e20 > count($var_71919e64)) {
				exit('所有推送配额已用完');
			} 
			if (!isset($var_71919e64[$var_6cbe6605])) {
				$var_6cbe6605 = 0;
			} 
			$var_1ffe317b = trim($var_71919e64[$var_6cbe6605]);
		} 
		$var_5c45411b = $var_6cbe6605 + 1;
		if (!isset($var_71919e64[$var_5c45411b])) {
			$var_5c45411b = 0;
		} 
		$var_586a20ab = explode('----', $var_1ffe317b);
		$var_4c9dff78 = array_pop($var_586a20ab);
		list($var_2206f326, $var_6a1d5650, $var_4d4a75bf) = explode('.', $var_725c1d22);
		if ($var_4c9dff78 == 'yd') {
			$GLOBALS['push_conf']['push_num'] = $var_2206f326;
		} else if ($var_4c9dff78 == 'mip') {
			$GLOBALS['push_conf']['push_num'] = $var_6a1d5650;
		} else if ($var_4c9dff78 == 'zz') {
			$GLOBALS['push_conf']['push_num'] = $var_4d4a75bf;
		} 
		$var_598dffd3 = '?admin-push-guaji_run-isrun-1-key-' . $var_5c45411b . '-urlnum-' . $var_725c1d22 . '-interval-' . $var_baea9552;
		$var_63ebed95 = TEMP_PATH . 'arctype_config.php';
		$var_00ecf83b = TEMP_PATH . 'domaindb_config.php';
		$GLOBALS['domainConfArr'] = require $var_00ecf83b;
		$GLOBALS['arctypeArr'] = require $var_63ebed95;
		$var_de5c1562 = array();
		$var_de5c1562 = func_28a69079($var_1ffe317b);
		$var_de5c1562['jumpurl'] = $var_598dffd3;
		$var_de5c1562['isrun'] = true;
		$var_de5c1562['jumptime'] = $var_baea9552;
		$var_516e60ee = array('urlnum' => $var_de5c1562['urlnum'], 'isxiong' => (int)$var_de5c1562['isxiong'], 'type' => $var_de5c1562['type'], 'domain' => $var_de5c1562['domain'], 'success' => $var_de5c1562['success'], 'remain' => $var_de5c1562['remain'], 'msg' => $var_de5c1562['logmsg'], 'guaji' => 1,);
		func_7f102729($var_516e60ee);
		$this -> assign($var_de5c1562);
		$this -> display();
	} 
	public function logs() {
		$var_cc7d199f = $this -> _get('p', null, 1);
		$var_a113ab5f = './temp/pushlogs.log';
		if (is_file($var_a113ab5f)) {
			$var_de5c1562 = func_61f5400b($var_a113ab5f, 0, 5000);
			$var_586a20ab = array_filter(explode('
', $var_de5c1562));
			krsort($var_586a20ab);
			$var_59adc197 = 15;
			$var_f1d13c7b = count($var_586a20ab);
			$var_97cecbb2 = @ceil($var_f1d13c7b / $var_59adc197);
			if ($var_cc7d199f > $var_97cecbb2) {
				$var_cc7d199f = $var_97cecbb2;
			} 
			$var_64f25176 = ($var_cc7d199f - 1) * $var_59adc197;
			$var_586a20ab = array_slice($var_586a20ab, $var_64f25176, $var_59adc197);
			$var_586a20ab = array_values($var_586a20ab);
			foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
				list($var_1bf5ad22, $var_3771f8bd, $var_de41f5d8, $var_7c6c92b4, $var_725c1d22, $var_b4dabed4, $var_a47a5c70, $var_e7ac0e01, $var_7584211d, $var_da035f13) = explode('	', $var_cb83972b);
				$var_10635ff1 = $var_f1d13c7b - $var_64f25176 - $var_228572b3;
				if (date('Y-m-d') == date('Y-m-d', strtotime($var_1bf5ad22))) {
					$var_1bf5ad22 = '<font color=red>' . $var_1bf5ad22 . '</font>';
				} 
				$var_36588d5f = array('zz' => '主动推送', 'mip' => 'MIP推送', 'realtime' => '天级收录', 'batch' => '周级收录');
				if ($var_da035f13 == '提交成功') {
					$var_da035f13 = '<font color=green>' . $var_da035f13 . '</font>';
				} else {
					$var_da035f13 = '<font color=red>' . $var_da035f13 . '</font>';
				} 
				$var_35b7c6eb[] = array('id' => $var_10635ff1, 'time' => $var_1bf5ad22, 'isxiong' => $var_de41f5d8?'熊掌ID':'百度站长', 'type' => $var_36588d5f[$var_7c6c92b4], 'urlnum' => $var_725c1d22, 'domain' => $var_b4dabed4, 'success' => $var_a47a5c70, 'remain' => $var_e7ac0e01, 'guaji' => $var_7584211d?'手动挂机':'自动触发', 'msg' => $var_da035f13,);
			} 
			$var_75f57b3a = url('admin/push/logs?p=!page!');
			$var_a0a4a1e4 = $var_97cecbb2 > 1?func_9242882b($var_cc7d199f, $var_97cecbb2, 4, $var_75f57b3a, false):'';
			$this -> assign('pages', $var_a0a4a1e4);
			$this -> assign('total', $var_f1d13c7b);
			$this -> assign('list', $var_35b7c6eb);
		} 
		$this -> display();
	} 
	public function logs_del() {
		$var_980a7c7e = './temp/pushlogs.log';
		is_file($var_980a7c7e) && unlink($var_980a7c7e);
		$this -> success('删除成功！');
	} 
	public function update() {
		$var_1b04f3c8 = $_POST['con'];
		foreach($var_1b04f3c8 as $var_228572b3 => $var_d8bba397) {
			$var_1b04f3c8[$var_228572b3] = func_e838d727(trim($var_1b04f3c8[$var_228572b3]));
		} 
		if ($var_1b04f3c8['push_configtype_zz'] == 2 && !$var_1b04f3c8['push_configfile_zz']) {
			$this -> error('文件模式时，token配置文件不能为空！');
		} 
		if ($var_1b04f3c8['push_configtype_yd'] == 2 && !$var_1b04f3c8['push_configfile_yd']) {
			$this -> error('文件模式时，token配置文件不能为空！');
		} 
		if ($var_1b04f3c8['push_configtype_mip'] == 2 && !$var_1b04f3c8['push_configtype_mip']) {
			$this -> error('文件模式时，token配置文件不能为空！');
		} 
		if ($var_1b04f3c8['push_configtype_zz'] == 2) {
			$var_1b04f3c8['token_list_zz'] = '';
		} 
		if ($var_1b04f3c8['push_configtype_yd'] == 2) {
			$var_1b04f3c8['token_list_yd'] = '';
		} 
		if ($var_1b04f3c8['push_configtype_mip'] == 2) {
			$var_1b04f3c8['token_list_mip'] = '';
		} 
		$var_7c7d0dd9 = array();
		if (is_file($this -> func_1d4cbd7b)) {
			$var_7c7d0dd9 = require $this -> func_1d4cbd7b;
		} 
		$var_be12f82d = array_merge($var_7c7d0dd9, $var_1b04f3c8);
		ksort($var_be12f82d);
		func_3c22ed21($this -> func_1d4cbd7b, $var_be12f82d);
		$var_dc5b5cc2 = TEMP_PATH . 'config.php';
		$var_7c7d0dd9 = require $var_dc5b5cc2;
		$var_be12f82d = array_merge($var_7c7d0dd9, array('push_open' => $var_1b04f3c8['push_open'], 'push_interval' => $var_1b04f3c8['push_interval']));
		func_3c22ed21($var_dc5b5cc2, $var_be12f82d);
		$this -> success('保存成功！');
	} 
} 

?>