<?php class robotAction extends adminAction {
	public function _init() {
		parent :: _init();
		$this -> func_1d4cbd7b = TEMP_PATH . 'config.php';
		$this -> defined_check_licence();
	} 
	public function index() {
		$var_352304ce = array_merge(config('ROBOT_LIST'), array("other" => "其他蜘蛛"));
		$var_586a20ab = glob('./temp/robotlog/all/20*.log');
		$var_586a20ab = array_map('basename', $var_586a20ab);
		$var_586a20ab = array_map('intval', $var_586a20ab);
		$var_5794c650 = max($var_586a20ab);
		$var_cc7d199f = $this -> _get('p', null, 1);
		$var_1c0134dd = $this -> _get('day')?$this -> _get('day'):$var_5794c650;
		$var_8262ec6d = func_0246c9c7($var_1c0134dd);
		$var_9e00f4d1 = intval(array_sum($var_8262ec6d));

		if ($this -> _get('spider')) {
			$var_f1d13c7b = $var_8262ec6d[$this -> _get('spider')];
		} else {
			$var_f1d13c7b = $var_9e00f4d1;
		} 
		$var_59adc197 = 15;
		$var_97cecbb2 = @ceil($var_f1d13c7b / $var_59adc197);
		if ($var_cc7d199f > $var_97cecbb2) {
			$var_cc7d199f = $var_97cecbb2;
		} 

		if ($this -> _get('day')) {
			$var_75f57b3a = url('admin/robot/index?p=!page!&day=' . $this -> _get('day') . '&spider=' . $this -> _get('spider'));
		} else {
			$var_75f57b3a = url('admin/robot/index?p=!page!');
		} 
		$var_de5c1562['pages'] = $var_97cecbb2 > 1?func_9242882b($var_cc7d199f, $var_97cecbb2, 4, $var_75f57b3a, false):'';
		$var_b1276260 = ($var_cc7d199f - 1) * $var_59adc197 + 1;
		$var_de5c1562['list'] = func_4284abb0($var_1c0134dd, $var_f1d13c7b, $var_b1276260, $var_59adc197, $this -> _get('spider'));
		!$var_de5c1562['list'] && $var_de5c1562['list'] = array();
		$var_fdb29ac1 = config('ROBOT_MUST_KEYS');
		$var_de5c1562['scount'][] = array('key' => null, 'name' => '全部', 'count' => $var_9e00f4d1, 'url' => '?admin-robot-index-day-' . $var_1c0134dd,);
		foreach($var_fdb29ac1 as $var_228572b3 => $var_cb83972b) {
			$var_de5c1562['scount'][] = array('key' => $var_cb83972b, 'name' => $var_352304ce[$var_cb83972b], 'count' => intval($var_8262ec6d[$var_cb83972b]), 'url' => '?admin-robot-index-day-' . $var_1c0134dd . '-spider-' . $var_cb83972b,);
		} 

		if ($this -> _get('spider')) {
			$var_a113ab5f = './temp/robotlog/' . $this -> _get('spider') . '/' . $var_1c0134dd . '.log';
			if (!is_file($var_a113ab5f)) {
				$var_de5c1562['list'][] = array('id' => 0, 'name' => '----', 'ip' => '----', 'url' => '<font color="red">错误，未生成该蜘蛛的记录文件！请等待~</font>', 'typename' => '----', 'themename' => '----', 'time' => '----', 'sourl' => '');
				$var_de5c1562['pages'] = '';
				$var_f1d13c7b = 0;
			} 
		} 
		$var_de5c1562['spider'] = $this -> _get('spider');
		if (IS_AJAX) {
			$this -> ajaxReturn(array('list' => $var_de5c1562['list'], 'scount' => $var_de5c1562['scount'], 'pages' => $var_de5c1562['pages'], 'total' => $var_f1d13c7b, 'scount' => $var_de5c1562['scount'], 'spider' => $var_de5c1562['spider']));
			exit;
		} 
		$var_de5c1562['sday'] = $var_1c0134dd;
		$var_de5c1562['total'] = $var_f1d13c7b;
		$var_de5c1562['todayArr'] = func_3a9eff96(date('Ymd'));
		unset($var_de5c1562['todayArr']['全部']);
		$var_de5c1562['todayCount'] = intval(array_sum($var_de5c1562['todayArr']));
		$var_de5c1562['hour'] = func_19919280(date('Ymd'));
		$var_de5c1562['weekArr'] = func_c8b0e3ba(10);
		$var_de5c1562['weekArr'] = array('全部' => $var_de5c1562['weekArr']['全部']);
		$var_de5c1562['weekKeys'][] = date('Ymd');
		for($var_7ea74e20 = 1;$var_7ea74e20 < 10;$var_7ea74e20++) {
			$var_de5c1562['weekKeys'][] = date('Ymd', strtotime('-' . $var_7ea74e20 . ' day'));
		} 
		krsort($var_de5c1562['weekKeys']);
		$var_de5c1562['weekcount'] = 0;
		foreach($var_de5c1562['weekArr'] as $var_228572b3 => $var_cb83972b) {
			$var_de5c1562['weekcount'] += array_sum(explode(',', $var_cb83972b));
		} 
		$var_de5c1562['errmsg'] = '暂时没有蜘蛛访问记录！';
		$this -> assign($var_de5c1562);
		$this -> display();
	} 
	public function getchartpie() {
		$var_2ddd548e = $this -> _get('value');
		if ($var_2ddd548e == '0') {
			$var_d089e8c2 = '今日访问比率';
			$var_de5c1562['todayArr'] = func_3a9eff96(date('Ymd'));
		} else if ($var_2ddd548e == '1') {
			$var_d089e8c2 = '昨日访问比率';
			$var_de5c1562['todayArr'] = func_3a9eff96(date('Ymd', strtotime('-1 day')));
		} else {
			$var_020302ec = intval($var_2ddd548e);
			$var_d089e8c2 = '近' . $var_020302ec . '日访问比率';
			if ($var_2ddd548e == '365') {
				$var_d089e8c2 = '近1年访问比率';
			} 
			$var_586a20ab = array();
			$var_586a20ab[date('Ymd')] = func_3a9eff96(date('Ymd'));
			for($var_7ea74e20 = 1;$var_7ea74e20 < $var_020302ec;$var_7ea74e20++) {
				$var_2f42d152 = date('Ymd', strtotime('-' . $var_7ea74e20 . ' day'));
				$var_586a20ab[] = func_3a9eff96($var_2f42d152);
			} 
			foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
				foreach($var_cb83972b as $var_3d9151c4 => $var_1076c777) {
					$var_7eba6ab8[$var_3d9151c4] += $var_1076c777;
				} 
			} 
			$var_de5c1562['todayArr'] = $var_7eba6ab8;
		} 
		unset($var_de5c1562['todayArr']['全部']);
		$var_de5c1562['title'] = $var_d089e8c2;
		$this -> assign($var_de5c1562);
		$html = $this -> fetch('./static/admin/chart_pie_day.html');
		$this -> ajaxReturn(array('html' => $html));
	} 
	public function getchartline() {
		$var_2ddd548e = $this -> _get('value');
		$var_de5c1562 = array();
		$var_de5c1562['count'] = 0;
		$var_020302ec = intval($var_2ddd548e);
		$var_73a2b17f = strtotime('-' . $var_020302ec . ' day');
		if ($var_2ddd548e == '0') {
			$var_d089e8c2 = '今日蜘蛛时段走势图';
			$var_a8dba778 = '今日蜘蛛访问数量：';
		} else if ($var_2ddd548e == '1') {
			$var_d089e8c2 = '昨日蜘蛛时段走势图';
			$var_a8dba778 = '昨日蜘蛛访问数量：';
		} else if ($var_2ddd548e == '2') {
			$var_d089e8c2 = '前日蜘蛛时段走势图';
			$var_a8dba778 = '前日蜘蛛访问数量：';
		} else {
			$var_2f42d152 = date('Y/m/d', $var_73a2b17f);
			$var_d089e8c2 = $var_2f42d152 . '蜘蛛时段走势图';
			$var_a8dba778 = $var_2f42d152 . '蜘蛛访问数量：';
		} 
		$var_de5c1562['hour'] = func_19919280(date('Ymd', $var_73a2b17f));
		$var_9a89e30a = explode(',', $var_de5c1562['hour']);
		foreach($var_9a89e30a as $var_228572b3 => $var_cb83972b) {
			if ($var_cb83972b != 'null' && $var_cb83972b > 0) {
				$var_de5c1562['count'] += $var_cb83972b;
			} 
		} 
		$var_de5c1562['count'] = intval($var_de5c1562['count']);
		$var_de5c1562['title'] = $var_d089e8c2;
		$var_de5c1562['subtitle'] = $var_a8dba778 . $var_de5c1562['count'];
		$this -> assign($var_de5c1562);
		$html = $this -> fetch('./static/admin/chart_line_day.html');
		$this -> ajaxReturn(array('html' => $html));
	} 
	public function getchartweek() {
		$var_2ddd548e = $this -> _get('value');
		$var_7c6c92b4 = $this -> _get('type');
		$var_020302ec = intval($var_2ddd548e);
		$var_d089e8c2 = '近' . $var_020302ec . '日蜘蛛走势图';
		$var_a8dba778 = '近' . $var_020302ec . '日蜘蛛数量：';
		if ($var_2ddd548e == '365') {
			$var_d089e8c2 = '近1年蜘蛛走势图';
			$var_a8dba778 = '近1年蜘蛛数量：';
		} 
		$var_de5c1562['weekArr'] = func_c8b0e3ba($var_020302ec);
		if ($var_7c6c92b4 == '') {
			$var_de5c1562['weekArr'] = array('全部' => $var_de5c1562['weekArr']['全部']);
		} else {
			unset($var_de5c1562['weekArr']['全部']);
		} 
		$var_de5c1562['weekKeys'][] = date('Ymd');
		for($var_7ea74e20 = 1;$var_7ea74e20 < $var_020302ec;$var_7ea74e20++) {
			$var_de5c1562['weekKeys'][] = date('Ymd', strtotime('-' . $var_7ea74e20 . ' day'));
		} 
		krsort($var_de5c1562['weekKeys']);
		$var_de5c1562['weekcount'] = 0;
		foreach($var_de5c1562['weekArr'] as $var_228572b3 => $var_cb83972b) {
			$var_de5c1562['weekcount'] += array_sum(explode(',', $var_cb83972b));
		} 
		$var_de5c1562['title'] = $var_d089e8c2;
		$var_de5c1562['daynum'] = $var_020302ec;
		$var_de5c1562['subtitle'] = $var_a8dba778 . $var_de5c1562['weekcount'];
		$this -> assign($var_de5c1562);
		$html = $this -> fetch('./static/admin/chart_line_week.html');
		$this -> ajaxReturn(array('html' => $html));
	} 
	public function redirect_del() {
		$var_980a7c7e = './temp/redirect.log';
		is_file($var_980a7c7e) && unlink($var_980a7c7e);
		$this -> success('删除成功！');
	} 
	public function redirect() {
		$var_cc7d199f = $this -> _get('p', null, 1);
		$var_a113ab5f = './temp/redirect.log';
		if (is_file($var_a113ab5f)) {
			$var_de5c1562 = func_61f5400b($var_a113ab5f, 0, 5000);
			$var_586a20ab = array_filter(explode('
', $var_de5c1562));
			krsort($var_586a20ab);
			$var_59adc197 = 15;
			$var_f1d13c7b = count($var_586a20ab);
			$var_97cecbb2 = @ceil($var_f1d13c7b / $var_59adc197);
			if ($var_cc7d199f > $var_97cecbb2) {
				$var_cc7d199f = $var_97cecbb2;
			} 
			$var_64f25176 = ($var_cc7d199f - 1) * $var_59adc197;
			$var_586a20ab = array_slice($var_586a20ab, $var_64f25176, $var_59adc197);
			$var_586a20ab = array_values($var_586a20ab);
			$var_bc5efb53 = config('ROBOT_LIST');
			$var_50b89a7c = txtDB('domain') -> select();
			$var_50b89a7c = func_809cbb58($var_50b89a7c, 'dirname');
			foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
				list($var_1bf5ad22, $var_332fc2f2, $var_4ea4cc94, $var_1003d5bb, $var_42cba2f6, $var_1e649227) = explode('	', $var_cb83972b);
				$var_bad6c929 = $var_50b89a7c[$var_1e649227]['name'];
				$var_10635ff1 = $var_f1d13c7b - $var_64f25176 - $var_228572b3;
				$var_1003d5bb = htmlspecialchars($var_1003d5bb);
				$var_42cba2f6 = htmlspecialchars($var_42cba2f6);
				$var_1003d5bb = '<a target=_blank title="打开此链接" href="' . $var_1003d5bb . '">' . substr($var_1003d5bb, 0, 65) . '</a>';
				$var_42cba2f6 = '<a target=_blank title="打开此链接" href="' . $var_42cba2f6 . '">' . substr($var_42cba2f6, 0, 65) . '</a>';
				$var_aca22417 = $var_bc5efb53[$var_4ea4cc94];
				if (date('Y-m-d') == date('Y-m-d', strtotime($var_1bf5ad22))) {
					$var_1bf5ad22 = '<font color=red>' . $var_1bf5ad22 . '</font>';
				} 
				$var_35b7c6eb[] = array('id' => $var_10635ff1, 'name' => $var_aca22417, 'ip' => $var_332fc2f2, 'url' => $var_1003d5bb, 'jumpurl' => $var_42cba2f6, 'time' => $var_1bf5ad22, 'typename' => $var_bad6c929);
			} 
			$var_75f57b3a = url('admin/robot/redirect?p=!page!');
			$var_a0a4a1e4 = $var_97cecbb2 > 1?func_9242882b($var_cc7d199f, $var_97cecbb2, 4, $var_75f57b3a, false):'';
			$this -> assign('pages', $var_a0a4a1e4);
			$this -> assign('total', $var_f1d13c7b);
			$this -> assign('list', $var_35b7c6eb);
		} 
		$this -> display();
	} 
	public function config() {
		$var_980a7c7e = DATA_PATH . 'robot_redirect_data.txt';
		$var_aa00bf86 = '';
		if (is_file($var_980a7c7e)) {
			$var_aa00bf86 = @func_14a7221d($var_980a7c7e);
		} 
		$var_352304ce = array_merge(config('ROBOT_LIST'), array("other" => '其他蜘蛛'));
		$var_de5c1562['robot_list'] = $var_352304ce;
		$var_de5c1562['list_last'] = count($var_de5c1562['robot_list']);
		if (config('robot_redirect_items')) {
			$var_de5c1562['robot_redirect_items_v'] = config('robot_redirect_items');
			$var_de5c1562['robot_redirect_items'] = @explode(',', config('robot_redirect_items'));
			$var_aca22417 = array();
			foreach($var_de5c1562['robot_redirect_items'] as $var_228572b3 => $var_cb83972b) {
				$var_aca22417[] = $var_352304ce[$var_cb83972b];
			} 
			$var_de5c1562['robot_redirect_itemsname'] = implode($var_aca22417, ',');
		} 
		$var_de5c1562['group_list'] = raction('admin/domain/get_grouplist');
		if (config('robot_redirect_group') == '0') {
			$var_de5c1562['robot_redirect_group_name'] = '全部分组';
		} else if (config('robot_redirect_group')) {
			$var_586a20ab = explode(',', config('robot_redirect_group'));
			foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
				$var_19b70d02[] = $var_de5c1562['group_list'][$var_cb83972b]['name'];
			} 
			$var_de5c1562['robot_redirect_group_name'] = implode($var_19b70d02, ',');
		} 
		$this -> assign($var_de5c1562);
		$this -> assign('robot_redirect_data', $var_aa00bf86);
		$this -> display();
	} 
	public function ban() {
		$var_de5c1562 = array();
		$var_352304ce = array_merge(config('ROBOT_LIST'), array("other" => '其他蜘蛛'));
		$var_de5c1562['robot_list'] = $var_352304ce;
		$var_de5c1562['list_last'] = count($var_de5c1562['robot_list']);
		$var_de5c1562['web_robot_ban_list'] = @explode(',', config('web_robot_ban_list'));
		$this -> assign($var_de5c1562);
		$this -> display();
	} 
	public function update() {
		$var_1b04f3c8 = $_POST['con'];
		if (isset($var_1b04f3c8['web_robot_ban_list'])) {
			if ($var_1b04f3c8['web_robot_ban_list']) {
				$var_1b04f3c8['web_robot_ban_list'] = implode(',', $var_1b04f3c8['web_robot_ban_list']);
			} else {
				$var_1b04f3c8['web_robot_ban_list'] = array();
			} 
		} 
		$var_1b04f3c8['robot_redirect_starttime'] = $var_1b04f3c8['robot_redirect_starttime']?strtotime($var_1b04f3c8['robot_redirect_starttime']):'';
		$var_1b04f3c8['robot_redirect_endtime'] = $var_1b04f3c8['robot_redirect_endtime']?strtotime($var_1b04f3c8['robot_redirect_endtime']):'';
		$var_7c7d0dd9 = require $this -> func_1d4cbd7b;
		$var_be12f82d = array_merge($var_7c7d0dd9, $var_1b04f3c8);
		ksort($var_be12f82d);
		func_3c22ed21($this -> func_1d4cbd7b, $var_be12f82d);
		if (isset($_POST['robot_redirect_data'])) {
			$var_980a7c7e = DATA_PATH . 'robot_redirect_data.txt';
			$var_de5c1562 = trim($_POST['robot_redirect_data']);
			write($var_980a7c7e, $var_de5c1562);
		} 
		$this -> success('保存成功！');
	} 
	public function recount() {
		set_time_limit(3600);
		session_write_close();
		import('class/Robot');
		$var_932d3949 = new Robot(config('ROBOT_LIST'));
		$var_1b04f3c8 = require $this -> func_1d4cbd7b;
		$var_1b04f3c8['web_robot_log'] = 0;
		func_3c22ed21($this -> func_1d4cbd7b, $var_1b04f3c8);
		$var_932d3949 -> recount();
		$var_1b04f3c8['web_robot_log'] = 1;
		func_3c22ed21($this -> func_1d4cbd7b, $var_1b04f3c8);
		echo '重新计算成功！';
	} 
} 

?>