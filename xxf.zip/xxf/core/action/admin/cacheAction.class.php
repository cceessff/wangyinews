<?php class cacheAction extends adminAction {
	public $var_5aed16ca;
	public function _init() {
		parent :: _init();
		session_write_close();
		$this -> func_1d4cbd7b = TEMP_PATH . 'config.php';
	} 
	public function index() {
		$var_370ebc88 = config('web_url_route');
		unset($var_370ebc88['list'], $var_370ebc88['show']);
		$this -> assign('list', $var_370ebc88);
		$this -> display();
	} 
	public function update() {
		$var_1b04f3c8 = $_POST['con'];
		foreach($var_1b04f3c8 as $var_228572b3 => $var_d8bba397) {
			$var_1b04f3c8[$var_228572b3] = trim($var_1b04f3c8[$var_228572b3]);
		} 
		$var_a37c9890 = array();
		$var_a37c9890['status'] = 1;
		$var_7c7d0dd9 = require $this -> func_1d4cbd7b;
		$var_be12f82d = array_merge($var_7c7d0dd9, $var_1b04f3c8);
		ksort($var_be12f82d);
		func_3c22ed21($this -> func_1d4cbd7b, $var_be12f82d);
		$this -> ajaxReturn($var_a37c9890);
	} 
	public function clear() {
		$var_de5c1562['compile_cache'] = func_ec6fc6db(func_eeb67ad2(TPLCACHE_PATH), 'MB');
		$var_de5c1562['session_cache'] = func_ec6fc6db(func_eeb67ad2(SESSION_PATH), 'MB');
		$var_370ebc88 = config('web_url_route');
		unset($var_370ebc88['list'], $var_370ebc88['show']);
		$this -> assign('list', $var_370ebc88);
		$this -> assign($var_de5c1562);
		$this -> display();
	} 
	public function clearzd() {
		$this -> display();
	} 
	public function del() {
		$var_980a7c7e = isset($_POST['file'])?$_POST['file']:$this -> ajaxReturn(array('status' => 0, "info" => "参数不完整！"));
		$var_88fe0209 = isset($_POST['action'])?$_POST['action']:$this -> ajaxReturn(array('status' => 0, "info" => '参数不完整'));
		$var_7c6c92b4 = $this -> _post('type');

		if ($this -> _get('zd') || preg_match('~^http~', $var_980a7c7e)) {
			$var_1003d5bb = $var_980a7c7e;
			$var_980a7c7e = 'url';
		} 
		switch ($var_980a7c7e) {
			case 'url': switch ($var_7c6c92b4) {
					case 'tdk': $var_980a7c7e = func_21ca168e($var_1003d5bb);
						break;
					case 'menu': $var_b9b17a69 = parse_url($var_1003d5bb);
						$var_980a7c7e = CACHE_PATH . 'tags/menu/' . getHashDir($var_b9b17a69['host'], 2) . '/' . $var_b9b17a69['host'];
						break;
					case 'link': $var_980a7c7e = func_a76dc06d($var_1003d5bb);
						break;
					case 'urlrules': $var_b9b17a69 = parse_url($var_1003d5bb);
						$var_980a7c7e = dirname(func_05d2f70f($var_b9b17a69['host']));
						break;
					case 'theme': $var_980a7c7e = func_5e6cebc6($var_1003d5bb);
						break;
					case 'html': $var_980a7c7e = func_0b6db7ad($var_1003d5bb);
						break;
					default: $this -> ajaxReturn(array('status' => 0, "info" => '参数错误'));
				} 
				if (!$var_980a7c7e) {
					$this -> ajaxReturn(array('status' => 0, "info" => '文件不存在！'));
				} 
				break;
			case 'robotlog': $var_980a7c7e = TEMP_PATH . 'robotlog';
				break;
			case 'compile': $var_980a7c7e = TPLCACHE_PATH;
				break;
			case 'html': $var_980a7c7e = CACHE_PATH . 'html';
				break;
			case 'tempcache': $var_980a7c7e = CACHE_PATH . 'temp';
				break;
			case 'urlrules': $var_980a7c7e = CACHE_PATH . 'urlrules';
				break;
			case 'theme': $var_980a7c7e = CACHE_PATH . 'theme';
				break;
			case 'filelist': $var_fae1bb2a = $var_980a7c7e = TEMP_PATH . 'cache_filelist';
				if ($var_88fe0209 == 'del' && is_dir($var_fae1bb2a) && 1 == 2) {
					$var_a2035dee = func_9193adfb($var_fae1bb2a);
					foreach($var_a2035dee as $var_228572b3 => $var_cb83972b) {
						if (is_dir($var_fae1bb2a . '/' . $var_cb83972b)) {
							$var_586a20ab = glob($var_fae1bb2a . '/' . $var_cb83972b . '/*_time.php');
							if ($var_586a20ab) {
								foreach($var_586a20ab as $var_1076c777) {
									@unlink($var_1076c777);
								} 
							} 
						} 
					} 
					$this -> ajaxReturn(array('status' => 1, "info" => '更新成功！'));
				} 
				break;
			case 'courl': $var_980a7c7e = TEMP_PATH . 'cache_collecturl';
				break;
			case 'session': $var_980a7c7e = SESSION_PATH;
				break;
			case 'collect_auto': $var_980a7c7e = CACHE_PATH . 'collect_auto';
				break;
			case 'link': $var_980a7c7e = CACHE_PATH . 'tags/loop_link';
				break;
			case 'tkd': $var_980a7c7e = CACHE_PATH . 'tags/tkd';
				break;
			case 'menu': $var_980a7c7e = CACHE_PATH . 'tags/menu';
				break;
			case 'all': $var_980a7c7e = CACHE_PATH;
				break;
			default: $var_980a7c7e = preg_replace('~^tpl_~', '', $var_980a7c7e);
				$var_980a7c7e = CACHE_PATH . 'html/' . $var_980a7c7e;
		} 
		if ($var_88fe0209 == 'del') {
			if (is_dir($var_980a7c7e)) {
				if (func_891a6fb0($var_980a7c7e)) {
					$this -> ajaxReturn(array('status' => 1));
				} else {
					$this -> ajaxReturn(array('status' => 0, "info" => '清除失败！'));
				} 
			} else if (is_file($var_980a7c7e)) {
				if (unlink($var_980a7c7e)) {
					$this -> ajaxReturn(array('status' => 2, "info" => '清除成功！'));
				} else {
					$this -> ajaxReturn(array('status' => 0, "info" => '清除失败！'));
				} 
			} else {
				$this -> ajaxReturn(array('status' => 0, "info" => '文件不存在！'));
			} 
		} 
		if ($var_88fe0209 == 'checksize') {
			$var_35b7c6eb = 0;
			if (is_dir($var_980a7c7e)) {
				$var_a113f349 = func_eeb67ad2($var_980a7c7e);
				if ($var_a113f349 < 200) {
					$var_35b7c6eb = $var_a113f349 . ' 字节';
				} else {
					$var_35b7c6eb = func_ec6fc6db($var_a113f349 / 1024, 'kb') . ' MB';
				} 
			} else if (is_file($var_980a7c7e)) {
				$var_a113f349 = filesize($var_980a7c7e);
				if ($var_a113f349 < 200) {
					$var_35b7c6eb = $var_a113f349 . ' 字节';
				} else {
					$var_35b7c6eb = func_ec6fc6db($var_a113f349 / 1024, 'kb') . ' MB';
				} 
			} 
			$this -> ajaxReturn(array('status' => 1, "size" => $var_35b7c6eb));
		} 
	} 
} 

?>