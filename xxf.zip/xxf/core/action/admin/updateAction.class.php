<?php class updateAction extends adminAction {
	public function _init() {
		parent :: _init();
		$this -> func_8c7e1827 = $this -> __get('viptype');
		$this -> func_45d21917 = $this -> __get('vipver');
		$this -> func_bf53554c = $this -> __get('vipcode');
	} 
	public function index() {
		$this -> display();
	} 
	public function check() {
		@set_time_limit(1200);
		$var_de5c1562 = array();
		$var_28b4a294 = func_fbc5150c() . '?ajax=1&m=check&a=update&type=' . $this -> func_8c7e1827 . '&vs=' . $this -> func_45d21917 . '&code=' . $this -> func_bf53554c . '&host=' . $_SERVER['HTTP_HOST'];
		$var_35b7c6eb = func_28b50565($var_28b4a294, 20);
		if ($var_35b7c6eb) {
			$var_35b7c6eb = json_decode($var_35b7c6eb, true);
			if ($var_35b7c6eb) {
				$var_de5c1562['status'] = $var_35b7c6eb['status'];
				$var_de5c1562['info'] = $var_35b7c6eb['msg'];
				$var_de5c1562['url'] = $var_35b7c6eb['url']?$var_35b7c6eb['url']:url('admin/update/update');
			} else {
				$var_de5c1562['status'] = 0;
				$var_de5c1562['info'] = '检测失败，未知参数！';
			} 
		} else {
			$var_de5c1562['status'] = 0;
			$var_de5c1562['info'] = '检测失败，无法链接服务器！';
		} 
		$this -> ajaxReturn($var_de5c1562);
	} 
	public function update() {
		@set_time_limit(2400);
		$var_de5c1562 = array();
		$var_de5c1562['status'] = 0;
		if (!func_e89f021a(APP_PATH)) {
			$var_de5c1562['info'] = '根目录需给读写权限！';
			$this -> ajaxReturn($var_de5c1562);
		} 
		$var_1003d5bb = func_fbc5150c() . '?m=download&type=' . $this -> func_8c7e1827 . '&vs=' . $this -> func_45d21917 . '&code=' . $this -> func_bf53554c . '&host=' . $_SERVER['HTTP_HOST'];
		import('class/Http');
		$var_8251eda0 = new Http();
		$var_8251eda0 -> func_7fef4f3b = 600;
		$var_8251eda0 -> func_ff1f28a7 = $var_1003d5bb;
		session_write_close();
		$var_8251eda0 -> func_d80f7f6b();
		if ($var_8251eda0 -> func_9228f088() == '200' && $var_8251eda0 -> func_1a559174) {
			$var_980a7c7e = TEMP_PATH . 'xbwupdate.zip';
			write($var_980a7c7e, $var_8251eda0 -> func_1a559174);
			import('class/PclZip');
			$var_1a733f24 = new PclZip($var_980a7c7e);

			if ($var_1a733f24 -> extract(PCLZIP_OPT_PATH, APP_PATH, PCLZIP_OPT_REPLACE_NEWER) == 0) {
				$var_de5c1562['info'] = '解压失败，Error : ' . $var_1a733f24 -> errorInfo(true);
			} else {
				@unlink($var_980a7c7e);
				$var_de5c1562['status'] = 1;
				$var_b25b74b9 = './upgrade' . $this -> func_8c7e1827 . '.php';
				$var_de5c1562['info'] = '恭喜你，升级成功！';
				if (is_file($var_b25b74b9)) {
					$var_de5c1562['url'] = $var_b25b74b9;
				} 
			} 
		} else {
			$var_de5c1562['info'] = '抱歉，文件下载失败！';
		} 
		$this -> ajaxReturn($var_de5c1562);
	} 
} 

?>