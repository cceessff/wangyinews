<?php class toolsAction extends adminAction {
	public function get_post_title() {
		$var_d089e8c2 = translate_titleurl($this -> _post('title'));
		$this -> success($var_d089e8c2);
	} 
	public function downBodyImg() {
		$var_5afc80a1 = trim($_POST['body']);
		if (!empty($var_5afc80a1)) {
			$var_5afc80a1 = trim(func_e838d727($var_5afc80a1));
			echo trim(downBodyImg($var_5afc80a1));
		} 
	} 
	public function ping() {
		$var_6cbe6605 = $this -> _post('key');
		$var_1003d5bb = $this -> _post('url');
		$var_35b7c6eb = baiduping($var_1003d5bb);
		if ($var_35b7c6eb) {
			$var_de5c1562 = array('key' => $var_6cbe6605, 'url' => $var_1003d5bb,);
			txtDB('ping') -> data($var_de5c1562) -> add();
			echo '1';
		} else {
			echo '0';
		} 
	} 
	public function webuptxt() {
		@set_time_limit(10 * 60);
		$var_3d815bdc = $this -> _request('filename');
		$var_34ab1c85 = $this -> _request('filetype');
		$var_1e649227 = $this -> _request('dirname');
		list($var_d688deb2, $var_1e649227) = explode('/', $var_1e649227);
		if ($var_d688deb2 == 'article') {
			$var_d688deb2 = 'body';
		} 
		$var_3d815bdc = preg_replace('~[^\\w]+~', '', $var_3d815bdc);
		$var_1e649227 = preg_replace('~[^\\w/]+~', '', $var_1e649227);
		$var_1e649227 = $var_1e649227?$var_1e649227 . '/':'';
		$var_1814f2ad = APP_PATH . 'temp/data/' . $var_d688deb2 . '/' . $var_1e649227;
		$var_ca8ca2fc = array('txt', 'zip');
		if (!empty($_FILES['file']['error'])) {
			switch ($_FILES['file']['error']) {
				case '1': $var_8e75327e = '超过php.ini允许的大小。';
					break;
				case '2': $var_8e75327e = '超过表单允许的大小。';
					break;
				case '3': $var_8e75327e = '只有部分被上传。';
					break;
				case '4': $var_8e75327e = '请选择图片。';
					break;
				case '6': $var_8e75327e = '找不到临时目录。';
					break;
				case '7': $var_8e75327e = '写文件到硬盘出错。';
					break;
				case '8': $var_8e75327e = 'File upload stopped by extension。';
					break;
				case '999': default: $var_8e75327e = '未知错误。';
			} 
			$this -> error($var_8e75327e, '', true);
		} 
		if (empty($_FILES) === false) {
			$var_912ec459 = $_FILES['file']['name'];
			$var_b9743c03 = $_FILES['file']['tmp_name'];
			$var_def2dd38 = $_FILES['file']['size'];
			if (!$var_912ec459) {
				$this -> error('请选择文件。', '', true);
			} 
			if (@is_dir($var_1814f2ad) === false) {
				mkdir($var_1814f2ad, 511, true);
			} 
			if (@is_writable($var_1814f2ad) === false) {
				$this -> error('上传目录没有写权限。', '', true);
			} 
			if (@is_uploaded_file($var_b9743c03) === false) {
				$this -> error('上传失败。', '', true);
			} 
			if ($var_34ab1c85 == 'txt') {
				$var_2a7454e7 = 'txt';
			} else {
				$var_90413365 = explode('.', $var_912ec459);
				$var_2a7454e7 = array_pop($var_90413365);
				$var_2a7454e7 = trim($var_2a7454e7);
				$var_2a7454e7 = strtolower($var_2a7454e7);
			} 
			if (!in_array($var_2a7454e7, $var_ca8ca2fc)) {
				$this -> error('上传文件扩展名是不允许的扩展名。', '', true);
			} 
			if (!$var_3d815bdc) {
				list($var_3d815bdc,) = explode('.', $var_912ec459);
				$var_3d815bdc = func_62ff8293(str_replace('.', '', $var_3d815bdc));
			} 
			$var_3d815bdc = str_replace(array(';', ':', '.'), '', $var_3d815bdc);
			$var_a06d7b3d = $var_1814f2ad . $var_3d815bdc . '.' . $var_2a7454e7;
			if (is_file($var_a06d7b3d)) {
				$var_a06d7b3d = $var_1814f2ad . $var_3d815bdc . '_' . rand(1, 99) . '.' . $var_2a7454e7;
			} 
			if (move_uploaded_file($var_b9743c03, $var_a06d7b3d) === false) {
				$this -> error('上传文件失败。', '', true);
			} 
			if ($var_d688deb2 == 'body') {
				$var_04416560 = new SplFileObject($var_a06d7b3d, 'rb');
				$var_f1d13c7b = func_74bfd8c5($var_a06d7b3d);
				$var_f809eec7 = DATA_PATH . 'article/' . $var_1e649227 . '/' . basename($var_a06d7b3d);
				for($var_7ea74e20 = 0;$var_7ea74e20 < $var_f1d13c7b;$var_7ea74e20++) {
					$var_04416560 -> seek($var_7ea74e20);
					$var_4c8e8f67 = $var_04416560 -> current();
					list($var_d089e8c2, $var_5afc80a1) = explode('******', $var_4c8e8f67);
					$var_b7fcdf19 = func_6d71dea8($var_5afc80a1);
					if ($var_b7fcdf19) {
						$var_d089e8c2 .= '******' . $var_b7fcdf19[0];
					} 
					write($var_f809eec7, $var_d089e8c2 . '
', 'a+');
					$var_04416560 -> next();
				} 
			} 
			func_aeff0c79($var_d688deb2, $var_1e649227);
			$this -> ajaxReturn(array('status' => 1));
		} 
		$this -> error('请选择文件', '', true);
	} 
	public function get_file_info() {
		$var_980a7c7e = $this -> _post('file');
		if (!is_file($var_980a7c7e)) {
			exit('0');
		} 
		$var_de5c1562 = array();
		$var_de5c1562['count'] = func_74bfd8c5($var_980a7c7e);
		$var_de5c1562['filesize'] = func_ec6fc6db(filesize($var_980a7c7e));
		$var_de5c1562['filemtime'] = date('Y-m-d H:i', filemtime($var_980a7c7e));
		$this -> ajaxReturn($var_de5c1562);
	} 
	public function scanpic() {
		$var_79b3774e = $this -> _get('ac');
		session_write_close();
		set_time_limit(3600);
		$GLOBALS['logfile'] = TEMP_PATH . 'temp/temp_scandir_status.log';
		if (IS_POST) {
			$var_1e649227 = $this -> _post('dirname');
			$var_3d815bdc = $this -> _post('filename');
			$var_59d3c6b6 = $this -> _post('typedir');
			$var_59d3c6b6 = preg_replace('~[^\\w]+~', '', $var_59d3c6b6);
			if (!$var_1e649227) {
				exit('请填写图片文件夹');
			} 
			if (!$var_3d815bdc) {
				exit('文件名不能为空');
			} 
			write($GLOBALS['logfile'], '');
			$var_3d815bdc = str_replace('.', '', $var_3d815bdc);
			$var_3d815bdc = DATA_PATH . 'pic/' . $var_59d3c6b6 . '/' . $var_3d815bdc . '.txt';
			$var_1e649227 = str_replace('..', '', $var_1e649227);
			$var_1e649227 = str_replace('\\', '/', $var_1e649227);
			$var_1c95cf50 = APP_PATH . trim($var_1e649227, '/');
			$GLOBALS['count'] = 0;
			$var_9db27f60 = $this -> _scanpic($var_1c95cf50);
			write($GLOBALS['logfile'], 'ok');
			if ($GLOBALS['count'] > 0) {
				write($var_3d815bdc, trim($var_9db27f60));
			} 
			echo '扫描结束，共扫描到' . $GLOBALS['count'] . '个图片文件！';
		} else if ($var_79b3774e == 'check') {
			echo is_file($GLOBALS['logfile'])?file_get_contents($GLOBALS['logfile']):'';
		} else {
			write($GLOBALS['logfile'], '');
			$var_36a0b2a2 = txtDB('arctype') -> select();
			$this -> assign('class_list', $var_36a0b2a2);
			$var_de5c1562['rootpath'] = APP_PATH;
			$this -> assign($var_de5c1562);
			$this -> display();
		} 
	} 
	private function _scanpic($var_4eda73b5, &$var_9db27f60 = '') {
		write($GLOBALS['logfile'], '正在扫描：' . $var_4eda73b5 . '，已扫描到 ' . $GLOBALS['count'] . '个图片');
		$var_ff44612c = func_9193adfb($var_4eda73b5);
		usleep(100000);
		foreach($var_ff44612c as $var_980a7c7e) {
			if ($var_980a7c7e != '.' && $var_980a7c7e != '..') {
				$var_653b5af0 = $var_4eda73b5 . '/' . $var_980a7c7e;
				if (is_dir($var_653b5af0)) {
					$var_9db27f60 .= $this -> _scanpic($var_653b5af0);
				} else {
					if (!preg_match('~\\.(jpg|jpeg|gif|bmp|png)$~i', $var_980a7c7e)) {
						continue;
					} 
					$var_653b5af0 = str_replace('\\', '/', $var_653b5af0);
					$var_653b5af0 = str_replace(APP_PATH, '/', $var_653b5af0);
					$GLOBALS['count']++;
					$var_9db27f60 .= $var_653b5af0 . '
';
				} 
			} 
		} 
		return $var_9db27f60;
	} 
	public function linkget() {
		$var_79b3774e = $this -> _get('ac');
		session_write_close();
		set_time_limit(3600);
		if (IS_POST) {
			$var_75f57b3a = $this -> _post('url');
			$var_7c6c92b4 = $this -> _post('type');
			if (!preg_match('~^https?://[\\w]+~', $var_75f57b3a)) {
				exit('请填写页面地址');
			} 
			$html = func_28b50565($var_75f57b3a, 20);
			$var_b9b17a69 = parse_url($var_75f57b3a);
			$var_8bb5268f = array();
			if ($html) {
				$var_04b81daf = '~<a[^>]+href\\s*=\\s*(["|\']*)([\\w/\\.].*)["\' 
	][^>]*>~iUs';
				if (preg_match_all($var_04b81daf, $html, $var_973d74fe)) {
					foreach($var_973d74fe[2] as $var_228572b3 => $var_cb83972b) {
						$var_1003d5bb = func_a6aabd8f($var_cb83972b);
						list($var_1003d5bb,) = explode('#', $var_1003d5bb);
						$var_1003d5bb = func_d24a35d7($var_1003d5bb, $var_75f57b3a);
						if (!preg_match('~^https?://[\\w]+~', $var_1003d5bb)) {
							continue;
						} 
						$var_bcd910d4 = str_replace('.', '\\.', $var_b9b17a69['host']);
						if ($var_7c6c92b4 == 1 && !preg_match('~^https?://' . $var_bcd910d4 . '~', $var_1003d5bb)) {
							continue;
						} 
						$var_8bb5268f[] = $var_1003d5bb;
					} 
					$var_8bb5268f = array_unique($var_8bb5268f);
				} 
			} 
			if ($var_8bb5268f) {
				exit(implode('
', $var_8bb5268f));
			} else {
				exit('没有找到链接');
			} 
		} else {
			$this -> display();
		} 
	} 
	public function retpl() {
		session_write_close();
		set_time_limit(3600);
		echo str_repeat(' ', 1024);
		ob_implicit_flush(1);
		ob_end_flush();
		$var_21b07ec2 = './template/company/xys_blue';
		$var_1c0ac015 = glob($var_21b07ec2 . '/*.htm');
		if (!$var_1c0ac015) {
			echo ' [<font color="red">模板文件不在</font>]<br>';
			exit;
		} 
		foreach($var_1c0ac015 as $var_228572b3 => $var_cb83972b) {
			if (!$var_cb83972b) {
				continue;
			} 
			$var_3d815bdc = str_ireplace('.htm', '.html', basename($var_cb83972b));
			$var_dd5c1306 = array('index.html' => 'index.html', 'head.html' => 'head.html', 'foot.html' => 'footer.html', 'article_article.html' => 'show.html', 'list_article.html' => 'list.html', 'list_chanpin.html' => 'product_list.html', 'article_chanpin.html' => 'product_show.html', 'index_article.html' => 'about.html', 'index_lianxi.html' => 'contact.html',);
			if (isset($var_dd5c1306[$var_3d815bdc])) {
				$var_3d815bdc = $var_dd5c1306[$var_3d815bdc];
			} 
			$var_a4765e11 = $var_21b07ec2 . '/' . $var_3d815bdc;
			echo $var_a4765e11;
			if (rename($var_cb83972b, $var_a4765e11)) {
				$html = func_fb96d752($var_a4765e11);
				$var_209b1964 = '<title>{$toptitle}</title>';
				if ($var_3d815bdc == 'about.html') {
					$var_209b1964 = '<title>关于我们 - {网站名称}</title>';
				} else if ($var_3d815bdc == 'contact.html') {
					$var_209b1964 = '<title>联系我们 - {网站名称}</title>';
				} else if ($var_3d815bdc == 'list.html') {
					$var_209b1964 = '<title>{当前栏目}新闻中心 - {网站名称}</title>';
				} else if ($var_3d815bdc == 'product_list.html') {
					$var_209b1964 = '<title>{当前栏目}产品展示 - {网站名称}</title>';
				} else if ($var_3d815bdc == 'product_show.html') {
					$var_209b1964 = '<title>{产品名称}产品展示 - {网站名称}</title>';
				} 
				$html = preg_replace('#<title>(.*)</title>#i', $var_209b1964 , $html);
				$html = preg_replace('~

~', '
', $html);
				$html = str_replace('/skin/', '{$theme_path}/skin/', $html);
				$html = str_replace('/about/index.html', '{geturl tpl="about"/}', $html);
				write($var_a4765e11, $html);
				echo ' [<font color="red">ok</font>]<br>';
			} else {
				echo ' [err]<br>';
			} 
		} 
		echo ' [<font color="red">ok</font>]<br>';
	} 
	public function retpl_dir() {
		session_write_close();
		set_time_limit(3600);
		echo str_repeat(' ', 1024);
		ob_implicit_flush(1);
		ob_end_flush();
		$var_21b07ec2 = './dedetemplate/';
		$var_c96e290e = './dedetemplate2/';
		$var_586a20ab = func_9193adfb($var_21b07ec2);
		$var_586a20ab = array_slice($var_586a20ab, 2);
		$var_3c86f19e = array();
		foreach($var_586a20ab as $var_3d9151c4 => $var_1076c777) {
			$var_b26cf4e7 = $var_c96e290e . 'zq' . $var_1076c777 . '/';
			$var_4eda73b5 = $var_21b07ec2 . $var_1076c777 . '/';
			echo $var_4eda73b5;
			$var_f0c09750 = scandir($var_4eda73b5 . 'templets/');
			if (count($var_f0c09750) > 3) {
				echo ' [<font color="red">风格文件不在，跳过</font>]<br>';
				continue;
			} 
			$var_1c0ac015 = glob($var_4eda73b5 . 'templets/default/*.htm');
			if (!$var_1c0ac015) {
				echo ' [<font color="red">模板文件不在，跳过</font>]<br>';
				continue;
			} 
			$var_ea90d938 = $var_4eda73b5 . $var_1076c777 . '.jpg';
			foreach($var_1c0ac015 as $var_228572b3 => $var_cb83972b) {
				$var_3d815bdc = str_ireplace('.htm', '.html', basename($var_cb83972b));
				if ($var_3d815bdc == 'index.html') {
					$var_3d815bdc = 'index.html';
				} else if ($var_3d815bdc == 'article_article.html') {
					$var_3d815bdc = 'show.html';
				} else if ($var_3d815bdc == 'list_article.html') {
					$var_3d815bdc = 'list.html';
				} else if ($var_3d815bdc == 'footer.html') {
					$var_3d815bdc = 'footer.html';
				} else if ($var_3d815bdc == 'head.html') {
					$var_3d815bdc = 'head.html';
				} else {
					unlink($var_cb83972b);
					continue;
				} 
				$var_3c86f19e[] = basename($var_cb83972b);
				$var_a4765e11 = $var_b26cf4e7 . $var_3d815bdc;
				if (!is_dir(dirname($var_a4765e11))) {
					@mkdir(dirname($var_a4765e11), 511, true);
				} 
				if (rename($var_cb83972b, $var_a4765e11)) {
					$html = func_fb96d752($var_a4765e11);
					$html = preg_replace('#<title>(.*)</title>#i', '<title>{$toptitle}</title>', $html);
					if ($var_3d815bdc == 'footer.html') {
						$html = '<!-- flink -->
<div class="flink w960 center clear">
<dl class="tbox">
	<dt>
	<strong>友情链接</strong>
	</dt>
	<dd>
	<ul class="f4">{loop type="domain"}<a href="{$vo.url}" target="_blank">{$vo.title}</a>&nbsp;&nbsp;{/loop}  </ul>
	 {if $links_open}
	 <ul class="f5">
	   {loop type="link"}
       <li ><a href="{$vo.url}" target="_blank">{$vo.title}</a></li>
	   {/loop}
	   </ul>
	   {/if}
	</dd>
  </dl>
</div>
<!-- /flink  --><div><a href="{$thisurl}">{$title}</a>,<a href="{$web_url}">{$web_name}</a>&nbsp;&nbsp;{$web_tongji} <a href="http://{$host}/sitemap.xml">sitemap</a></p>{$web_share}{$web_bdpush}</div>' . $html;
					} 
					write($var_a4765e11, $html);
				} 
			} 
			if (is_file($var_ea90d938)) {
				@copy($var_ea90d938, $var_b26cf4e7 . 'preview.jpg');
			} 
			$this -> copydirs($var_4eda73b5 . 'templets/default', $var_b26cf4e7, $var_3c86f19e);
			echo ' [<font color="red">ok</font>]<br>';
		} 
		dump('ok');
	} 
} 

?>