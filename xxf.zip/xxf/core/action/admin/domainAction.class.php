<?php class domainAction extends adminAction {
	public function _init() {
		parent :: _init();
		$this -> func_1d4cbd7b = TEMP_PATH . 'domain_config.php';
		$this -> func_cce23920 = txtDB('domain');
	} 
	public function index() {
		func_4638be96();
		$var_36a0b2a2 = txtDB('arctype') -> select();
		$var_36a0b2a2 = func_809cbb58($var_36a0b2a2, 'id');
		$var_35b7c6eb = $this -> func_cce23920 -> select();
		foreach($var_35b7c6eb as $var_228572b3 => $var_cb83972b) {
			$var_6eb887f1 = DATA_PATH . 'domain/' . $var_cb83972b['dirname'] . '_config.txt';
			if (is_file($var_6eb887f1) && $var_586a20ab = unserialize(file_get_contents($var_6eb887f1))) {
				$var_35b7c6eb[$var_228572b3] = array_merge($var_35b7c6eb[$var_228572b3], $var_586a20ab);
			} 
			$var_119ad111 = DATA_PATH . 'domain/' . $var_cb83972b['dirname'] . '_domain.txt';
			$var_b4dabed4 = file_get_contents($var_119ad111);
			$var_66b55ca5 = file_get_contents(DATA_PATH . 'domain/' . $var_cb83972b['dirname'] . '_prefix.txt');
			$var_35b7c6eb[$var_228572b3]['typename'] = $var_36a0b2a2[$var_cb83972b['cid']]['name'];
			$var_35b7c6eb[$var_228572b3]['domain_num'] = $var_b4dabed4?count(explode('
', $var_b4dabed4)):0;
			$var_35b7c6eb[$var_228572b3]['prefix_num'] = $var_cb83972b['prefix_type']?count(explode('
', $var_66b55ca5)):'<font class="c9">自动生成</font>';
			$var_b4dabed4 = str_replace('
', ',', $var_b4dabed4);
			$var_35b7c6eb[$var_228572b3]['domain'] = substr($var_b4dabed4, 0, 20) . (strlen($var_b4dabed4) > 20?'...':'');
			$var_35b7c6eb[$var_228572b3]['addtime'] = now_date_color($var_35b7c6eb[$var_228572b3]['addtime'], 'Y-m-d H:i');
			$var_35b7c6eb[$var_228572b3]['haslink'] = count(glob(DATA_PATH . 'link/' . $var_cb83972b['dirname'] . '/*.txt')) > 0?'<font color="blue">有</font>':'无';
			$var_35b7c6eb[$var_228572b3]['haskeywords'] = count(glob(DATA_PATH . 'keywords/' . $var_cb83972b['dirname'] . '/*.txt')) > 0?'<font color="blue">有</font>':'无';
			$var_8c622afe = explode(',', $var_cb83972b['cid']);
			if (count($var_8c622afe) < 2) {
				$var_35b7c6eb[$var_228572b3]['typename'] = $var_36a0b2a2[$var_cb83972b['cid']]['name'];
			} else {
				foreach($var_8c622afe as $var_3d9151c4 => $var_1076c777) {
					$var_bad6c929[] = $var_36a0b2a2[$var_1076c777]['name'];
				} 
				$var_35b7c6eb[$var_228572b3]['typename'] = '多模型<a href="javascript:" title="' . implode(',', $var_bad6c929) . '">☢</a>';
			} 
		} 
		$var_de5c1562['list'] = $var_35b7c6eb;
		$this -> assign($var_de5c1562);
		$this -> display();
	} 
	public function edit() {
		$var_10635ff1 = isset($_GET['id'])?intval($_GET['id']):'';
		if ($var_10635ff1 <> '') {
			$var_de5c1562 = $this -> func_cce23920 -> where('id=' . $var_10635ff1) -> find();
			$var_6eb887f1 = DATA_PATH . 'domain/' . $var_de5c1562['dirname'] . '_config.txt';
			if (is_file($var_6eb887f1) && $var_586a20ab = unserialize(file_get_contents($var_6eb887f1))) {
				$var_de5c1562 = array_merge($var_de5c1562, $var_586a20ab);
			} 
			$var_119ad111 = DATA_PATH . 'domain/' . $var_de5c1562['dirname'] . '_domain.txt';
			$var_de5c1562['domain'] = file_get_contents($var_119ad111);
			$var_156c44b2 = DATA_PATH . 'domain/' . $var_de5c1562['dirname'] . '_prefix.txt';
			$var_de5c1562['domain_prefix'] = file_get_contents($var_156c44b2);
		} 
		$var_36a0b2a2 = txtDB('arctype') -> select();
		if ($var_36a0b2a2) {
			$var_265537f7 = func_bf43bb58($var_36a0b2a2, 0, $var_de5c1562['cid']);
		} 
		$this -> assign('class_option', $var_265537f7);
		$this -> assign('classlist', $var_36a0b2a2);
		$this -> assign($var_de5c1562);
		$this -> display();
	} 
	public function update() {
		$var_c5256d61 = $_POST['r'];
		$var_1b04f3c8 = $_POST['con'];
		foreach($var_c5256d61 as $var_228572b3 => $var_d8bba397) {
			$var_c5256d61[$var_228572b3] = func_e838d727(trim($var_c5256d61[$var_228572b3]));
		} 
		foreach($var_1b04f3c8 as $var_228572b3 => $var_d8bba397) {
			$var_1b04f3c8[$var_228572b3] = func_e838d727(trim($var_1b04f3c8[$var_228572b3]));
		} 
		$var_e122cdb8 = $_POST['domain'];
		$var_66b55ca5 = $_POST['domain_prefix'];
		if ($var_e122cdb8 == '') {
			$this -> ajaxReturn(array('status' => 0, 'info' => '域名不能为空！'));
		} 
		$var_c5256d61['addtime'] = time();
		if ($var_c5256d61['id'] > 0) {
			$var_ae21f2d5 = array('id=' . $var_c5256d61['id']);
			$var_35b7c6eb = $this -> func_cce23920 -> where($var_ae21f2d5) -> data($var_c5256d61) -> save();
		} else {
			$var_35b7c6eb = $this -> func_cce23920 -> data($var_c5256d61) -> add();
			$var_c5256d61['id'] = $var_35b7c6eb;
		} 
		if ($var_35b7c6eb) {
			$var_6eb887f1 = DATA_PATH . 'domain/' . $var_c5256d61['dirname'] . '_config.txt';
			write($var_6eb887f1, serialize($var_1b04f3c8));
			$var_119ad111 = DATA_PATH . 'domain/' . $var_c5256d61['dirname'] . '_domain.txt';
			write($var_119ad111, $var_e122cdb8);
			$var_156c44b2 = DATA_PATH . 'domain/' . $var_c5256d61['dirname'] . '_prefix.txt';
			write($var_156c44b2, $var_66b55ca5);
			$this -> ajaxReturn(array('status' => 1, 'info' => '保存成功！'));
		} else {
			$this -> ajaxReturn(array('status' => 0, 'info' => '保存失败！'));
		} 
	} 
	public function del() {
		$var_10635ff1 = isset($_GET['id'])?intval($_GET['id']):$this -> error('id 不能为空');
		$var_35b7c6eb = $this -> func_cce23920 -> where('id=' . $var_10635ff1) -> find();
		$var_1e649227 = $var_35b7c6eb['dirname'];
		$var_35b7c6eb = $this -> func_cce23920 -> where('id=' . $var_10635ff1) -> delete();
		if (!$var_35b7c6eb) {
			$this -> error('删除失败！');
		} else {
			$var_64edb935 = array('config', 'domain', 'prefix', 'robot_redirect');
			foreach($var_64edb935 as $var_228572b3 => $var_cb83972b) {
				$var_980a7c7e = DATA_PATH . 'domain/' . $var_1e649227 . '_' . $var_cb83972b . '.txt';
				is_file($var_980a7c7e) && unlink($var_980a7c7e);
			} 
			$var_a2035dee = array('keywords', 'link');
			foreach($var_a2035dee as $var_228572b3 => $var_cb83972b) {
				$var_fae1bb2a = DATA_PATH . $var_cb83972b . '/' . $var_1e649227;
				is_dir($var_fae1bb2a) && func_891a6fb0($var_fae1bb2a);
			} 
		} 
		$this -> success('删除成功！', url('admin/domain/index'));
	} 
	public function del_cidfile() {
		$var_10635ff1 = isset($_GET['id'])?intval($_GET['id']):$this -> error('id 不能为空');
		$var_35b7c6eb = $this -> func_cce23920 -> where('id=' . $var_10635ff1) -> find();
		$var_a1bc5f9c = DATA_PATH . 'domain/' . $var_35b7c6eb['dirname'] . '_typecids.txt';
		is_file($var_a1bc5f9c) && unlink($var_a1bc5f9c);
		$this -> success('删除成功！', url('admin/domain/index'));
	} 
	public function get_grouplist() {
		$var_36a0b2a2 = txtDB('arctype') -> select();
		$var_36a0b2a2 = func_809cbb58($var_36a0b2a2, 'id');
		$var_35b7c6eb = txtDB('domain') -> select();
		foreach($var_35b7c6eb as $var_228572b3 => $var_cb83972b) {
			$var_35b7c6eb[$var_228572b3]['typename'] = $var_36a0b2a2[$var_cb83972b['cid']]['name'];
			$var_35b7c6eb[$var_228572b3]['addtime'] = now_date_color($var_35b7c6eb[$var_228572b3]['addtime']);
			$var_119ad111 = DATA_PATH . 'domain/' . $var_cb83972b['dirname'] . '_domain.txt';
			$var_b4dabed4 = file_get_contents($var_119ad111);
			$var_b4dabed4 = str_replace('
', ',', $var_b4dabed4);
			$var_35b7c6eb[$var_228572b3]['domain'] = substr($var_b4dabed4, 0, 20) . (strlen($var_b4dabed4) > 20?'...':'');
			$var_8c622afe = explode(',', $var_cb83972b['cid']);
			if (count($var_8c622afe) < 2) {
				$var_35b7c6eb[$var_228572b3]['typename'] = $var_36a0b2a2[$var_cb83972b['cid']]['name'];
			} else {
				foreach($var_8c622afe as $var_3d9151c4 => $var_1076c777) {
					$var_bad6c929[] = $var_36a0b2a2[$var_1076c777]['name'];
				} 
				$var_35b7c6eb[$var_228572b3]['typename'] = '多模型<a href="javascript:" title="' . implode(',', $var_bad6c929) . '">☢</a>';
			} 
		} 
		$var_35b7c6eb = func_809cbb58($var_35b7c6eb, 'id');
		return $var_35b7c6eb;
	} 
	public function config() {
		$this -> display();
	} 
	public function hulian() {
		$var_de5c1562 = array();
		$var_de5c1562['group_list'] = $this -> get_grouplist();
		if (config('hulian_group') == '0') {
			$var_de5c1562['hulian_group_name'] = '全部分组';
		} else if (config('hulian_group')) {
			$var_586a20ab = explode(',', config('hulian_group'));
			foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
				$var_1ce7219b[] = $var_de5c1562['group_list'][$var_cb83972b]['name'];
			} 
			$var_de5c1562['hulian_group_name'] = implode($var_1ce7219b, ',');
		} 
		$this -> assign($var_de5c1562);
		$this -> display();
	} 
	public function reform() {
		$var_36a0b2a2 = txtDB('domain') -> select();
		$var_35b7c6eb = txtDB('reform') -> select();
		$var_36a0b2a2 = func_809cbb58($var_36a0b2a2, 'id');
		$var_e849981f = array('关闭', '打散重组', '2个标题重组', '内容取一句话作为标题', '内容取一句话加在标题后面');
		$var_29fe6e2a = array('tkd' => 'TKD', 'body' => '内容');
		$var_35b7c6eb = func_809cbb58($var_35b7c6eb, 'cid');
		foreach($var_35b7c6eb as $var_228572b3 => $var_cb83972b) {
			$var_1e649227 = $var_36a0b2a2[$var_cb83972b['cid']]['dirname'];
			if ($var_cb83972b['cid'] == '0') $var_1e649227 = 'default';
			$var_eca54f0c = DATA_PATH . 'domain/' . $var_1e649227 . '_reform.txt';
			if (is_file($var_eca54f0c) && $var_586a20ab = unserialize(file_get_contents($var_eca54f0c))) {
				$var_35b7c6eb[$var_228572b3] = array_merge($var_35b7c6eb[$var_228572b3], $var_586a20ab);
			} 
			$var_35b7c6eb[$var_228572b3]['reform_titlename'] = $var_e849981f[$var_cb83972b['reform_title']];
			if ($var_35b7c6eb[$var_228572b3]['unicode']) {
				$var_586a20ab = explode(',', $var_35b7c6eb[$var_228572b3]['unicode']);
				$var_a7269200 = array();
				foreach($var_586a20ab as $var_3d9151c4 => $var_1076c777) {
					$var_a7269200[] = $var_29fe6e2a[$var_1076c777];
				} 
				$var_35b7c6eb[$var_228572b3]['unicode'] = implode(',', $var_a7269200);
			} else {
				$var_35b7c6eb[$var_228572b3]['unicode'] = '未开启';
			} 
		} 
		foreach($var_36a0b2a2 as $var_228572b3 => $var_cb83972b) {
			$var_36a0b2a2[$var_228572b3]['isset'] = false;
			$var_eca54f0c = DATA_PATH . 'domain/' . $var_36a0b2a2[$var_228572b3]['dirname'] . '_reform.txt';
			if (is_file($var_eca54f0c)) $var_36a0b2a2[$var_228572b3]['isset'] = true;
			if (isset($var_35b7c6eb[$var_cb83972b['id']])) {
				$var_71e9f77f = $var_cb83972b['id'];
				$var_36a0b2a2[$var_228572b3]['isset'] = true;
				$var_36a0b2a2[$var_228572b3]['data'] = $var_35b7c6eb[$var_71e9f77f];
			} 
		} 
		$this -> assign('default', $var_35b7c6eb[0]);
		$this -> assign('list', $var_36a0b2a2);
		$this -> display();
	} 
	public function reform_edit() {
		$var_71e9f77f = $this -> _get('cid');
		$var_36a0b2a2 = txtDB('domain') -> where('id=' . $var_71e9f77f) -> find();
		$var_35b7c6eb = txtDB('reform') -> where('cid=' . $var_71e9f77f) -> find();
		if (!$var_71e9f77f) {
			$var_35b7c6eb = txtDB('reform') -> where('cid=0') -> find();
			$var_1e649227 = 'default';
		} else {
			$var_1e649227 = $var_36a0b2a2['dirname'];
		} 
		$var_eca54f0c = DATA_PATH . 'domain/' . $var_1e649227 . '_reform.txt';
		if (is_file($var_eca54f0c) && $var_586a20ab = unserialize(file_get_contents($var_eca54f0c))) {
			$var_35b7c6eb = array_merge($var_35b7c6eb, $var_586a20ab);
		} 
		$var_35b7c6eb['classname'] = $var_36a0b2a2['name']?$var_36a0b2a2['name']:'默认配置';
		$var_35b7c6eb['unicode'] = explode(',', $var_35b7c6eb['unicode']);
		$var_35b7c6eb['cid'] = $var_71e9f77f;
		$this -> assign($var_35b7c6eb);
		$this -> display();
	} 
	public function reform_update() {
		$var_4a82ca50 = $_POST['con'];
		$var_77e37c59 = txtDB('reform');
		foreach($var_4a82ca50 as $var_228572b3 => $var_d8bba397) {
			$var_4a82ca50[$var_228572b3] = func_e838d727(trim($var_4a82ca50[$var_228572b3]));
		} 
		$var_4a82ca50['addtime'] = time();
		$var_35b7c6eb = $var_77e37c59 -> where('cid=' . $var_4a82ca50['cid']) -> find();
		if ($_POST['unicode']) {
			$var_4a82ca50['unicode'] = implode(',', $_POST['unicode']);
		} else {
			$var_4a82ca50['unicode'] = '';
		} 
		if ($var_35b7c6eb) {
			$var_ae21f2d5 = array('cid=' . $var_4a82ca50['cid']);
			$var_35b7c6eb = $var_77e37c59 -> where($var_ae21f2d5) -> data($var_4a82ca50) -> save();
		} else {
			$var_35b7c6eb = $var_77e37c59 -> data($var_4a82ca50) -> add();
		} 
		if ($var_35b7c6eb) {
			if ($var_4a82ca50['cid'] == '0') {
				$var_1e649227 = 'default';
			} else {
				$var_36a0b2a2 = txtDB('domain') -> where('id=' . $var_4a82ca50['cid']) -> find();
				$var_1e649227 = $var_36a0b2a2['dirname'];
			} 
			$var_eca54f0c = DATA_PATH . 'domain/' . $var_1e649227 . '_reform.txt';
			write($var_eca54f0c, serialize($var_4a82ca50));
			$this -> ajaxReturn(array('status' => 1, 'info' => '保存成功！'));
		} else {
			$this -> ajaxReturn(array('status' => 0, 'info' => '保存失败！'));
		} 
	} 
	public function reform_del() {
		$var_71e9f77f = $this -> _get('cid');
		$var_35b7c6eb = txtDB('reform') -> where('cid=' . $var_71e9f77f) -> delete();
		$var_36a0b2a2 = txtDB('domain') -> where('id=' . $var_71e9f77f) -> find();
		$var_1e649227 = $var_36a0b2a2['dirname'];
		$var_eca54f0c = DATA_PATH . 'domain/' . $var_1e649227 . '_reform.txt';
		if (is_file($var_eca54f0c)) @unlink($var_eca54f0c);
		$this -> success('删除成功！');
	} 
	public function replace() {
		$var_de5c1562 = array();
		$var_de5c1562['group_list'] = $this -> get_grouplist();
		if (config('replace_group') == '0') {
			$var_de5c1562['replace_group_name'] = '全部分组';
		} else if (config('replace_group')) {
			$var_586a20ab = explode(',', config('replace_group'));
			foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
				$var_49cffc69[] = $var_de5c1562['group_list'][$var_cb83972b]['name'];
			} 
			$var_de5c1562['replace_group_name'] = implode($var_49cffc69, ',');
		} 
		$var_de5c1562['replaceword'] = file_get_contents(DATA_PATH . 'replaceword.txt');
		$this -> assign($var_de5c1562);
		$this -> display();
	} 
	public function https() {
		$var_980a7c7e = DATA_PATH . 'domain_https.txt';
		if (is_file($var_980a7c7e)) {
			$var_370ebc88 = file_get_contents($var_980a7c7e);
		} 
		$this -> assign('https_list', $var_370ebc88);
		$this -> display();
	} 
	public function update_https() {
		$var_370ebc88 = trim($_POST['list']);
		$var_980a7c7e = DATA_PATH . 'domain_https.txt';
		file_put_contents($var_980a7c7e, $var_370ebc88);
		$this -> success('保存成功！');
	} 
	public function tkd() {
		$var_370ebc88 = array();
		if (is_file($this -> func_1d4cbd7b)) {
			$var_059216c4 = require $this -> func_1d4cbd7b;
			if ($var_059216c4) {
				$var_d880a135 = array_values($var_059216c4);
				$var_4ef34282 = array_shift($var_d880a135);
				if (strpos($var_4ef34282, '----') > - 1) $var_370ebc88 = $var_059216c4;
			} 
		} 
		$this -> assign('list', implode(PHP_EOL, $var_370ebc88));
		$this -> display();
	} 
	public function update_tkd() {
		$var_1b04f3c8 = $_POST['list'];
		$var_1b04f3c8 = trim($var_1b04f3c8);
		$var_1b04f3c8 = str_replace(array('
', '', '
', '

'), '|||', $var_1b04f3c8);
		$var_586a20ab = explode('|||', $var_1b04f3c8);
		$var_7eba6ab8 = array();
		foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
			$var_cb83972b = trim($var_cb83972b);
			if (empty($var_cb83972b)) {
				continue;
			} 
			list($var_b4dabed4, $var_6ee8527a, $var_d089e8c2, $var_df56ffa6, $var_9e193a4d) = explode('----', $var_cb83972b);
			$var_7eba6ab8[$var_b4dabed4] = $var_cb83972b;
		} 
		func_3c22ed21($this -> func_1d4cbd7b, $var_7eba6ab8);
		$this -> success('保存成功！');
	} 
} 

?>