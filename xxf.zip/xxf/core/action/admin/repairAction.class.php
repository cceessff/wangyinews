<?php class repairAction extends adminAction {
	public $var_5aed16ca;
	public function _init() {
		parent :: _init();
	} 
	public function index() {
		$this -> display();
	} 
	public function run() {
		$var_b2f8d2d7 = $this -> _get('step');
		!$var_b2f8d2d7 && $var_b2f8d2d7 = 1;
		$var_a112d52b = 5;
		$var_de5c1562 = array();
		$var_de5c1562['url'] = '';
		if ($var_a112d52b < $var_b2f8d2d7) {
			$var_de5c1562['status'] = 0;
			$var_de5c1562['info'] = '错误';
			$this -> ajaxReturn($var_de5c1562);
		} 
		$var_42efabf9 = array();
		switch ($var_b2f8d2d7) {
			case 1: $var_35702f41 = '检测系统环境';
				$var_f1fd87ff = func_ec6fc6db(disk_free_space(PATH_SEPARATOR == ';'?'.':'./'), 'mb');
				if ($var_f1fd87ff < 1024) {
					$var_42efabf9[] = '<font color="red">磁盘空间剩余不足1GB，请处理！</font>';
				} 
				if (!extension_loaded('zlib')) {
					$var_42efabf9[] = '<font color="red">php未开启zlib扩展，请处理！</font>';
				} 
				if (!function_exists('mb_strlen')) {
					$var_42efabf9[] = '<font color="red">php未开启mbstring扩展，请处理！</font>';
				} 
				if (!function_exists('iconv')) {
					$var_42efabf9[] = '<font color="red">php未开启iconv扩展，请处理！</font>';
				} 
				if (!version_compare(PHP_VERSION, '5.2.0', '>=') || !version_compare(PHP_VERSION, '7.3.0', '<')) {
					$var_42efabf9[] = '<font color="red">程序运行需要PHP版本 5.2~7.2 ，请处理！</font>';
				} 
				if (!function_exists('curl_init') || !function_exists('curl_exec')) {
					$var_42efabf9[] = '未开启curl_init函数，开启后采集速度更快，推荐开启！';
				} 
				break;
			case 2: $var_35702f41 = '检测目录权限';
				$var_3f177263 = array('../', '', 'data', 'db', 'logs', 'temp', 'cache', 'cache_filelist', 'errpage', 'robotlog', 'session', 'tplrules');
				foreach($var_3f177263 as $var_228572b3 => $var_cb83972b) {
					$var_980a7c7e = realpath(TEMP_PATH . $var_cb83972b);
					$var_980a7c7e = str_replace('\\/', '/', $var_980a7c7e);
					if (!func_e89f021a($var_980a7c7e)) {
						$var_42efabf9[] = '<font color="black">' . $var_980a7c7e . '</font> 没有读写权限，请处理！';
					} 
				} 
				break;
			case 3: $var_35702f41 = '检测网站必要文件';
				$var_980a7c7e = TEMP_PATH . 'theme_config.php';
				if (is_file($var_980a7c7e) && !unlink($var_980a7c7e)) {
					$var_42efabf9[] = $var_980a7c7e . '无法删除，请手动删除！';
				} else {
					func_64d0f4f3();
				} 
				$var_980a7c7e = TEMP_PATH . 'domaindb_config.php';
				if (is_file($var_980a7c7e) && !unlink($var_980a7c7e)) {
					$var_42efabf9[] = $var_980a7c7e . '无法删除，请手动删除！';
				} else {
					func_4638be96();
				} 
				break;
			case 4: $var_35702f41 = '检测数据表结构';
				$var_3f177263 = array('aclogs', 'arctype', 'collect', 'domain', 'links', 'master', 'reform', 'myad');
				foreach($var_3f177263 as $var_228572b3 => $var_cb83972b) {
					$var_980a7c7e = DB_PATH . $var_cb83972b;
					$var_8d07a625 = $var_980a7c7e . '.FRM';
					$var_fc15b88a = $var_980a7c7e . '.MYD';
					$var_39b1d0c8 = '';
					$var_a139bad9 = @file_get_contents($var_8d07a625);
					if (filesize($var_8d07a625) < 10 || !is_array(unserialize($var_a139bad9))) {
						$var_39b1d0c8 = $var_cb83972b . '表结构错误，正在尝试修复';
						$var_ff47571c = DB_PATH . 'FRMback/' . $var_cb83972b . '.FRM';
						$var_2f187abd = 0;
						if (is_file($var_ff47571c)) {
							$var_a139bad9 = file_get_contents($var_ff47571c);
							if (stripos($var_a139bad9, '===autocount===')) {
								if (filesize($var_fc15b88a) > 10) {
									$var_cd202931 = file_get_contents($var_fc15b88a);
									$var_4264ecf4 = unserialize($var_cd202931);
									$var_d181ce1c = max($var_4264ecf4);
									$var_32c3cba6 = $var_d181ce1c[0];
									if ($var_d181ce1c[0]) {
										$var_a139bad9 = str_replace('===autocount===', $var_d181ce1c[0], $var_a139bad9);
										$var_2f187abd = 1;
										write($var_8d07a625, $var_a139bad9);
									} 
								} 
							} else {
								$var_2f187abd = 1;
								write($var_8d07a625, $var_a139bad9);
							} 
						} 
					} 
					if ($var_39b1d0c8) {
						$var_39b1d0c8 .= $var_2f187abd?' [<font color="green">修复成功</font>]':' [<font color="red">修复失败</font>]';
						$var_42efabf9[] = $var_39b1d0c8;
					} 
					$var_39b1d0c8 = '';
					if (filesize($var_fc15b88a) < 6) {
						$var_39b1d0c8 = $var_cb83972b . '表数据丢失，已重置';
						write($var_fc15b88a, 'a:0:{}');
					} 
					$var_cd202931 = file_get_contents($var_fc15b88a);
					if (!is_array(unserialize($var_cd202931))) {
						$var_39b1d0c8 = $var_cb83972b . '表数据损坏，正在尝试修复';
						$var_2f187abd = 0;
						if ($var_40db88e3 = repairSerialize($var_cd202931)) {
							$var_2f187abd = 1;
							write($var_fc15b88a, $var_40db88e3);
						} 
					} 
					if ($var_39b1d0c8) {
						$var_39b1d0c8 .= $var_2f187abd?' [<font color="green">修复成功</font>]':' [<font color="red">修复失败</font>]';
						$var_42efabf9[] = $var_39b1d0c8;
					} 
				} 
				break;
			case 5: $var_35702f41 = '恭喜你，修复完成！';
				break;
		} 
		if ($var_42efabf9) {
			$var_35702f41 = '<img src="./static/images/warning.png" /> ' . $var_35702f41;
			foreach($var_42efabf9 as $var_228572b3 => $var_cb83972b) {
				$var_35702f41 .= '<p style="padding-left:30px;color:#ff8800">' . $var_cb83972b . '</p>';
			} 
		} else {
			$var_35702f41 = '<img src="./static/images/success.png" /> ' . $var_35702f41;
		} 
		if ($var_a112d52b > $var_b2f8d2d7) {
			$var_de5c1562['url'] = url('admin/repair/run?step=' . ($var_b2f8d2d7 + 1));
		} 
		$var_de5c1562['status'] = 1;
		$var_de5c1562['info'] = $var_35702f41;
		$this -> ajaxReturn($var_de5c1562);
	} 
} 

?>