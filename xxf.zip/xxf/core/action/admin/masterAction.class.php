<?php class masterAction extends adminAction {
	public $var_86f16318;
	public function _init() {
		parent :: _init();
		$this -> func_c9328e9c = txtDB('master');
	} 
	public function index() {
		$var_de5c1562 = $this -> func_c9328e9c -> where('id=1') -> find();
		$this -> assign($var_de5c1562);
		$this -> display();
	} 
	public function update() {
		$var_de5c1562 = $this -> func_c9328e9c -> where('id=1') -> find();
		$var_a37c9890 = array();
		if (md5($_POST['pass']) == $var_de5c1562['pass']) {
			$var_5f841fb5 = array();
			$var_5f841fb5['name'] = htmlspecialchars(trim($_POST['name']));
			$var_5f841fb5['nick'] = htmlspecialchars(trim($_POST['nick']));
			$var_5f841fb5['pass'] = md5($_POST['pass1']);
			$this -> func_c9328e9c -> where('id=1') -> data($var_5f841fb5) -> save();
			$_SESSION['admin']['id'] = $var_5f841fb5['name'];
			$_SESSION['admin']['nick'] = $var_5f841fb5['nick'];
			$var_a37c9890['status'] = 1;
		} else {
			$var_a37c9890['status'] = 0;
			$var_a37c9890['info'] = '旧密码不正确！';
		} 
		$this -> ajaxReturn($var_a37c9890);
	} 
} 

?>