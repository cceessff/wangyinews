<?php class aclogsAction extends adminAction {
	public $var_d9775b46;
	public $var_d688deb2;
	public function _init() {
		parent :: _init();
		$this -> func_b4c48eaa = txtDB('aclogs');
	} 
	public function index() {
		$var_335d704a = array();
		$var_3923f601 = isset($_GET['p'])?intval($_GET['p']):1;
		if ($var_3923f601 < 1) $var_3923f601 = 1;
		$var_076f5a97 = 20;
		$var_de5c1562 = $this -> func_b4c48eaa -> order('id desc') -> select();
		$var_f1d13c7b = $this -> func_b4c48eaa -> count();
		$var_97cecbb2 = @ceil($var_f1d13c7b / $var_076f5a97);
		if ($var_3923f601 > $var_97cecbb2) {
			$var_3923f601 = $var_97cecbb2;
		} 
		if ($var_de5c1562) {
			$var_9ef0b3aa = ($var_3923f601 - 1) * $var_076f5a97;
			$var_de5c1562 = array_slice($var_de5c1562, $var_9ef0b3aa, $var_076f5a97);
			foreach($var_de5c1562 as $var_228572b3 => $var_cb83972b) {
				$var_de5c1562[$var_228572b3]['action_short'] = msubstr($var_cb83972b['action'], 0, 100);
			} 
			$var_a0a4a1e4 = func_9242882b($var_3923f601, $var_97cecbb2, 4, url('admin/aclogs/index?p=!page!'), false);
		} 
		$_SESSION['archives_reurl'] = url('admin/aclogs/index?p=' . $var_3923f601);
		$var_335d704a['total'] = $var_f1d13c7b;
		$var_335d704a['totalpages'] = $var_97cecbb2;
		$var_335d704a['p'] = $var_3923f601;
		$var_335d704a['pages'] = $var_a0a4a1e4;
		$this -> assign($var_335d704a);
		$this -> assign('list', $var_de5c1562);
		$this -> display();
	} 
	public function del7day() {
		$var_ae21f2d5 = 'addtime<' . strtotime('-7 day');
		$var_35b7c6eb = $this -> func_b4c48eaa -> where($var_ae21f2d5) -> delete();
		$this -> success('删除成功！', $_SESSION['archives_reurl']);
	} 
	public function delmore() {
		$var_46a44e41 = !empty($_POST['ids'])?$_POST['ids']:$this -> error('未选中规则');
		foreach($var_46a44e41 as $var_228572b3 => $var_cb83972b) {
			$this -> func_b4c48eaa -> where('id=' . $var_cb83972b) -> delete();
		} 
		$this -> success('删除成功！', $_SESSION['archives_reurl']);
	} 
} 

?>