<?php class txtdataAction extends adminAction {
	public function _init() {
		parent :: _init();
		load('collect');
	} 
	public function _empty($var_88fe0209) {
		$var_64edb935 = config('txtfile');
		$var_a2035dee = config('txtdir');
		$this -> assign('action', $var_88fe0209);
		$var_7c6c92b4 = $this -> _get('type');
		$var_36a0b2a2 = DB('arctype') -> select();

		$var_36a0b2a2 = func_809cbb58($var_36a0b2a2, 'dirname');
		if (array_key_exists($var_88fe0209, $var_64edb935)) {
			$var_980a7c7e = DATA_PATH . $var_88fe0209 . '.txt';
			$var_de5c1562 = $this -> getfileinfo($var_980a7c7e);
			$var_de5c1562['title'] = $var_64edb935[$var_88fe0209] . '库';
			$var_de5c1562['txt_data'] = file_get_contents($var_980a7c7e);
			$this -> assign($var_de5c1562);
			$this -> display('txtdata_file');
		} else if (array_key_exists($var_88fe0209, $var_a2035dee)) {
			$var_de5c1562['total'] = 0;
			$var_de5c1562['title'] = $var_a2035dee[$var_88fe0209] . '库';
			$var_4eda73b5 = DATA_PATH . $var_88fe0209;
			$var_c4bd6ced = array();
			$var_8ca98899 = TEMP_PATH . 'temp/typecount.txt';
			if ($var_7c6c92b4) {
				$var_4eda73b5 = DATA_PATH . $var_88fe0209 . '/' . $var_7c6c92b4;
				$var_ff44612c = glob($var_4eda73b5 . '/*.txt');
				krsort($var_ff44612c);
				if (is_file($var_8ca98899)) {
					$var_c9727f76 = file_get_contents($var_8ca98899);
					$var_c4bd6ced = unserialize($var_c9727f76);
					foreach($var_36a0b2a2 as $var_228572b3 => $var_cb83972b) {
						$var_36a0b2a2[$var_228572b3]['num'] = $var_c4bd6ced[$var_228572b3]['num'];
					} 
				} 
			} else {
				$var_ff44612c = array();
				foreach($var_36a0b2a2 as $var_228572b3 => $var_cb83972b) {
					$var_4eda73b5 = DATA_PATH . $var_88fe0209 . '/' . $var_cb83972b['dirname'];
					if (!is_dir($var_4eda73b5)) {
						continue;
					} 
					$var_586a20ab = glob($var_4eda73b5 . '/*.txt');
					$var_36a0b2a2[$var_228572b3]['num'] = count($var_586a20ab);
					$var_c4bd6ced[$var_228572b3]['num'] = $var_36a0b2a2[$var_228572b3]['num'];
					$var_de5c1562['total'] += $var_36a0b2a2[$var_228572b3]['num'];
					if ($var_586a20ab) {
						$var_ff44612c = $var_ff44612c?array_merge($var_ff44612c, $var_586a20ab):$var_586a20ab;
					} 
				}
				write($var_8ca98899, serialize($var_c4bd6ced));
			} 
			$var_bb2381fd = array();
			foreach($var_ff44612c as $var_228572b3 => $var_cb83972b) {
				$var_bb2381fd[$var_228572b3] = filemtime($var_cb83972b);
			} 
			array_multisort($var_bb2381fd, 3, $var_ff44612c);
			$var_f1d13c7b = count($var_ff44612c);
			$var_3923f601 = isset($_GET['p'])?intval($_GET['p']):1;
			if ($var_3923f601 < 1) $var_3923f601 = 1;
			$var_076f5a97 = 15;
			$var_97cecbb2 = @ceil($var_f1d13c7b / $var_076f5a97);
			if ($var_3923f601 > $var_97cecbb2) {
				$var_3923f601 = $var_97cecbb2;
			} 
			if ($var_ff44612c) {
				$var_9ef0b3aa = ($var_3923f601 - 1) * $var_076f5a97;
				$var_ff44612c = array_slice($var_ff44612c, $var_9ef0b3aa, $var_076f5a97);
			} 
			foreach($var_ff44612c as $var_228572b3 => $var_cb83972b) {
				$var_980a7c7e = $var_cb83972b;
				if (is_file($var_980a7c7e)) {
					$var_f7682d0b = $this -> getfileinfo($var_980a7c7e);
					$var_f7682d0b['path_encode'] = $this -> encodefile($var_88fe0209 . '/' . $var_f7682d0b['dirname'] . '/' . $var_f7682d0b['filename']);
					$var_f7682d0b['id'] = $var_f1d13c7b - (($var_3923f601 - 1) * $var_076f5a97) - $var_228572b3;
					$var_f7682d0b['typename'] = $var_36a0b2a2[$var_f7682d0b['dirname']]['name'];
					if ($var_88fe0209 == 'article') {
						$var_bad0310f = DATA_PATH . 'body/' . $var_f7682d0b['dirname'] . '/' . $var_f7682d0b['filename'];
						$var_f7682d0b['hasbody'] = is_file($var_bad0310f);
					} 
					$var_de5c1562['list'][] = $var_f7682d0b;
				} 
			} 
			$var_a0a4a1e4 = func_9242882b($var_3923f601, $var_97cecbb2, 4, url("admin/txtdata/{$var_88fe0209}?p=!page!"), false);
			$var_de5c1562['type'] = $var_7c6c92b4;
			$var_de5c1562['totalpages'] = $var_97cecbb2;
			$var_de5c1562['p'] = $var_3923f601;
			$var_de5c1562['pages'] = $var_a0a4a1e4;
			$var_de5c1562['input_dir'] = $var_88fe0209;
			$this -> assign('class_list', $var_36a0b2a2);
			$this -> assign($var_de5c1562);
			if ($var_88fe0209 == 'article') {
				$this -> display('article');
				exit;
			} 
			$this -> display('txtdata_dirfile');
		} else {
			exit('err');
		} 
	} 
	public function getfileinfo($var_980a7c7e) {
		$var_de5c1562 = array();
		$var_de5c1562['input_file'] = $var_980a7c7e;
		$var_a113f349 = filesize($var_980a7c7e);
		if ($var_a113f349 < 200) {
			$var_a113f349 = $var_a113f349 . ' 字节';
		} else {
			$var_a113f349 = func_ec6fc6db($var_a113f349 / 1024, 'kb') . ' MB';
		} 
		$var_de5c1562['filesize'] = $var_a113f349;
		$var_de5c1562['count'] = func_74bfd8c5($var_de5c1562['input_file']);
		$var_de5c1562['filemtime'] = date('Y-m-d H:i', filemtime($var_de5c1562['input_file']));
		if (date('Y-m-d') == date('Y-m-d', strtotime($var_de5c1562['filemtime']))) {
			$var_de5c1562['filemtime'] = '<font color=red>' . $var_de5c1562['filemtime'] . '</font>';
		} 
		$var_980a7c7e = func_4f521b6d($var_980a7c7e);
		$var_de5c1562['filename'] = substr($var_980a7c7e, strrpos($var_980a7c7e, '/') + 1);
		$var_586a20ab = explode('/', $var_980a7c7e);
		$var_de5c1562['dirname'] = $var_586a20ab[count($var_586a20ab) - 2];
		$var_de5c1562['file_encode'] = $this -> encodefile($var_de5c1562['filename']);
		list($var_de5c1562['input_name'],) = explode('.', $var_de5c1562['filename']);
		if ($var_d4041b4a) $var_de5c1562['txt_data_review'] = func_1fe69150($var_de5c1562['input_file'], 500);
		$var_de5c1562['input_name'] .= '库';
		return $var_de5c1562;
	} 
	public function download() {
		$var_980a7c7e = $this -> _post('f');
		$var_fae1bb2a = $this -> _post('d');
		$var_fae1bb2a = str_replace('.', '', $var_fae1bb2a);
		if (is_array($var_980a7c7e)) {
			foreach($var_980a7c7e as $var_228572b3 => $var_cb83972b) {
				$var_980a7c7e[$var_228572b3] = $this -> decodefile($var_980a7c7e[$var_228572b3]);
				$var_980a7c7e[$var_228572b3] = str_replace('..', '', $var_980a7c7e[$var_228572b3]);
				$var_980a7c7e[$var_228572b3] = DATA_PATH . $var_980a7c7e[$var_228572b3];
				if (!is_file($var_980a7c7e[$var_228572b3])) {
					unset($var_980a7c7e[$var_228572b3]);
				} 
			} 
		} else {
			$var_980a7c7e = DATA_PATH . $this -> decodefile($var_980a7c7e);
			$var_980a7c7e = str_replace('..', '', $var_980a7c7e);
			list($var_fae1bb2a,) = explode('.', basename($var_980a7c7e));
		} 
		import('class/PclZip');
		$var_aa21c6fd = CACHE_PATH . $var_fae1bb2a . '.zip';
		$var_3d815bdc = basename($var_aa21c6fd);
		$var_809fd072 = new PclZip("{$var_aa21c6fd}");
		$var_2e6f6e66 = $var_809fd072 -> create($var_980a7c7e, PCLZIP_OPT_REMOVE_PATH, DATA_PATH);
		if ($var_2e6f6e66 == 0) {
			exit('打包文件时出错，error: ' . $var_809fd072 -> errorInfo(true));
		} 
		$var_34ab1c85 = trim(substr(strrchr($var_3d815bdc, '.'), 1));
		$var_a113f349 = filesize($var_aa21c6fd);
		header('Cache-control: max-age=31536000');
		header('Expires: ' . gmdate('D, d M Y H:i:s', time() + 31536000) . ' GMT');
		header('Content-Encoding: none');
		header('Content-Length: ' . $var_a113f349);
		header('Content-Disposition: attachment; filename=' . $var_3d815bdc);
		header('Content-Type: ' . $var_34ab1c85);
		readfile($var_aa21c6fd);
		@unlink($var_aa21c6fd);
		exit;
	} 
	public function delall() {
		$var_248f4f5e = !empty($_POST['f'])?$_POST['f']:$this -> error('未选中文件');
		foreach($var_248f4f5e as $var_228572b3 => $var_cb83972b) {
			$this -> del($var_cb83972b, false);
		} 
		$this -> success('删除成功！');
	} 
	public function del($var_4eda73b5 = '', $var_da035f13 = true) {
		$var_980a7c7e = $this -> _get('f');
		$var_4eda73b5 && $var_980a7c7e = $var_4eda73b5;
		$var_980a7c7e = $this -> decodefile($var_980a7c7e);
		$var_980a7c7e = DATA_PATH . $var_980a7c7e;
		$var_980a7c7e = str_replace('..', '', $var_980a7c7e);
		if (is_file($var_980a7c7e)) {
			@unlink($var_980a7c7e);
			if (stripos($var_980a7c7e, '/data/article') > - 1) {
				$var_bad6c929 = basename(dirname($var_980a7c7e));
				$var_bad0310f = DATA_PATH . 'body/' . $var_bad6c929 . '/' . basename($var_980a7c7e);
				if (is_file($var_980a7c7e)) @unlink($var_bad0310f);
			} 
		} 
		if ($var_da035f13) {
			$this -> success('删除成功！');
		} 
	} 
	public function review() {
		$var_2f44f078 = 500;
		$var_980a7c7e = $this -> _get('f');
		$var_980a7c7e = $this -> decodefile($var_980a7c7e);
		$var_a1c8c470 = false;
		if (preg_match('~^article/~', $var_980a7c7e)) {
			$var_2f44f078 = 100;
			$var_a1c8c470 = true;
		} 
		$var_980a7c7e = DATA_PATH . $var_980a7c7e;
		$var_980a7c7e = str_replace('..', '', $var_980a7c7e);
		if (!is_file($var_980a7c7e)) {
			exit('文件不存在！' . $var_980a7c7e);
		} 
		$var_09497274 = func_4f521b6d(func_1fe69150($var_980a7c7e, $var_2f44f078));
		$this -> assign('file', func_4f521b6d($var_980a7c7e));
		$this -> assign('linenum', $var_2f44f078);
		$this -> assign('txt_data', $var_09497274);
		if ($var_a1c8c470 && $var_09497274) {
			$var_370ebc88 = array();
			$var_cd1bb131 = explode('
', $var_09497274);
			foreach($var_cd1bb131 as $var_228572b3 => $var_cb83972b) {
				list($var_d089e8c2, $var_63503092) = explode('******', $var_cb83972b);
				if ($var_d089e8c2 == '') continue;
				$var_370ebc88[] = array('title' => $var_d089e8c2, 'litpic' => $var_63503092);
			} 
			$this -> assign('list', $var_370ebc88);
			$this -> display('article_review');
			exit;
		} 
		$this -> display();
	} 
	public function savefile() {
		$var_980a7c7e = $this -> _get('f');
		$var_de5c1562 = trim($_POST['data']);
		$var_980a7c7e = $this -> decodefile($var_980a7c7e);
		$var_980a7c7e = DATA_PATH . $var_980a7c7e;
		$var_980a7c7e = str_replace('..', '', $var_980a7c7e);
		$var_980a7c7e = str_replace(';', '', $var_980a7c7e);
		$var_980a7c7e = preg_replace('~\\.txt$~', '', $var_980a7c7e) . '.txt';
		$var_35b7c6eb = write($var_980a7c7e, $var_de5c1562);
		if ($var_de5c1562 && !$var_35b7c6eb) {
			$this -> error('保存失败！');
		} 
		$this -> success('保存成功！');
	} 
	public function upload_more() {
		$var_36a0b2a2 = txtDB('arctype') -> select();
		$this -> assign('class_list', $var_36a0b2a2);
		$this -> assign('input_name', $this -> _get('d'));
		$this -> display();
	} 
	public function encodefile($var_980a7c7e) {
		return _base64_encode($var_980a7c7e);
	} 
	public function decodefile($var_980a7c7e) {
		return func_62ff8293(_base64_decode($var_980a7c7e));
	} 
} 

?>