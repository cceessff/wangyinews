<?php class collectAction extends adminAction {
	public $var_0d0e8dfe;
	public function _init() {
		parent :: _init();
		$this -> func_352f4ea2 = txtDB('collect');
		load('collect');
		$this -> func_1d4cbd7b = TEMP_PATH . 'config.php';
	} 
	public function index() {
		$var_335d704a = array();
		$var_3923f601 = isset($_GET['p'])?intval($_GET['p']):1;
		if ($var_3923f601 < 1) $var_3923f601 = 1;
		$var_076f5a97 = 15;
		$var_de5c1562 = $this -> func_352f4ea2 -> order('id desc') -> select();
		$var_f1d13c7b = $this -> func_352f4ea2 -> count();
		$var_36a0b2a2 = txtDB('arctype') -> select();
		if ($var_de5c1562) {
			$var_36a0b2a2 = func_809cbb58($var_36a0b2a2, 'id');
			$var_97cecbb2 = ceil($var_f1d13c7b / $var_076f5a97);
			if ($var_3923f601 > $var_97cecbb2) {
				$var_3923f601 = $var_97cecbb2;
			} 
			$var_9ef0b3aa = ($var_3923f601 - 1) * $var_076f5a97;
			$var_de5c1562 = array_slice($var_de5c1562, $var_9ef0b3aa, $var_076f5a97);
			foreach($var_de5c1562 as $var_6cbe6605 => $var_cb83972b) {
				if ($var_cb83972b['model'] == 'title') {
					$var_de5c1562[$var_6cbe6605]['modelname'] = '标题';
				} else if ($var_cb83972b['model'] == 'body') {
					if (!$var_cb83972b['split']) {
						$var_de5c1562[$var_6cbe6605]['modelname'] = '内容';
					} else {
						$var_de5c1562[$var_6cbe6605]['modelname'] = $var_cb83972b['split'] == 1?'句子':'段落';
					} 
				} else if ($var_cb83972b['model'] == 'pic') {
					$var_de5c1562[$var_6cbe6605]['modelname'] = '图片';
				} else if ($var_cb83972b['model'] == 'typename') {
					$var_de5c1562[$var_6cbe6605]['modelname'] = '子页标题';
				} 
				$var_de5c1562[$var_6cbe6605]['rules'] = unserialize($var_cb83972b['rules']);
				$var_8c622afe = explode(',', $var_cb83972b['arctype']);
				if (count($var_8c622afe) < 2) {
					$var_de5c1562[$var_6cbe6605]['typename'] = $var_36a0b2a2[$var_cb83972b['arctype']]['name'];
				} else {
					$var_bad6c929 = array();
					foreach($var_8c622afe as $var_3d9151c4 => $var_1076c777) {
						$var_bad6c929[] = $var_36a0b2a2[$var_1076c777]['name'];
					} 
					$var_de5c1562[$var_6cbe6605]['typename'] = '多模型<a href="javascript:" title="' . implode(',', $var_bad6c929) . '">☢</a>';
				} 
				if ($var_de5c1562[$var_6cbe6605]['rules']['replace_naipan']) {
					$var_de5c1562[$var_6cbe6605]['name'] .= ' <sup class=red>奶盘</sup>';
				} 
			} 
			$var_a0a4a1e4 = func_9242882b($var_3923f601, $var_97cecbb2, 4, url('admin/collect/index?p=!page!'), false);
		} 
		$_SESSION['archives_reurl'] = url('admin/collect/index?p=' . $var_3923f601);
		$var_335d704a['total'] = $var_f1d13c7b;
		$var_335d704a['totalpages'] = $var_97cecbb2;
		$var_335d704a['p'] = $var_3923f601;
		$var_335d704a['pages'] = $var_a0a4a1e4;
		$var_335d704a['class_list'] = $var_36a0b2a2;
		$this -> assign($var_335d704a);
		$this -> assign('list', $var_de5c1562);
		$this -> display();
	} 
	public function edit() {
		$var_335d704a = array();
		$var_10635ff1 = isset($_GET['id'])?intval($_GET['id']):0;
		$var_caed482b = $this -> _get('model', null, 'title');
		$var_35b7c6eb = $this -> func_352f4ea2 -> where('id=' . $var_10635ff1) -> find();
		$var_335d704a['model'] = $var_caed482b;
		$var_335d704a['split'] = $this -> _get('split');
		if ($var_35b7c6eb) {
			$var_335d704a = $var_35b7c6eb;
			$var_335d704a['rules'] = func_2adc7aeb($var_35b7c6eb);
		} 
		if ($var_335d704a['model'] == 'title') {
			$var_335d704a['modelname'] = '标题';
		} else if ($var_335d704a['model'] == 'body') {
			if (!$var_335d704a['split']) {
				$var_335d704a['modelname'] = '内容';
			} else {
				$var_335d704a['modelname'] = $var_335d704a['split'] == 1?'句子':'段落';
			} 
		} else if ($var_335d704a['model'] == 'pic') {
			$var_335d704a['modelname'] = '图片';
		} 
		$var_36a0b2a2 = txtDB('arctype') -> select();
		if ($var_36a0b2a2) {
			$var_265537f7 = func_bf43bb58($var_36a0b2a2, 0, $var_335d704a['arctype']);
		} 
		$var_8c622afe = explode(',', $var_335d704a['arctype']);
		$this -> assign('arctypes', $var_8c622afe);
		$this -> assign('class_option', $var_265537f7);
		$this -> assign('classlist', $var_36a0b2a2);
		$this -> assign($var_335d704a);
		$var_cce0a90f = './static/admin/collect_' . $var_335d704a['model'] . '_edit.html';
		$this -> display($var_cce0a90f);
	} 
	public function update() {
		$var_afb1db68 = $_POST['rules'];
		$var_de5c1562 = $_POST['r'];
		foreach($var_de5c1562 as $var_228572b3 => $var_d8bba397) {
			$var_de5c1562[$var_228572b3] = func_e838d727(trim($var_de5c1562[$var_228572b3]));
		} 
		if ($var_de5c1562['name'] == '') {
			$this -> error('请输入规则名称！');
		} 
		foreach($var_afb1db68 as $var_228572b3 => $var_d8bba397) {
			$var_afb1db68[$var_228572b3] = func_e838d727(trim($var_afb1db68[$var_228572b3]));
		} 
		$var_de5c1562['arctype'] = implode(',', $_POST['arctype']);
		$var_de5c1562['rules'] = serialize($var_afb1db68);
		$var_de5c1562['addtime'] = time();
		$var_10635ff1 = $var_de5c1562['id'];
		$var_ae21f2d5 = array('id=' . $var_10635ff1);
		if ($var_10635ff1 > 0) {
			$var_35b7c6eb = $this -> func_352f4ea2 -> where($var_ae21f2d5) -> data($var_de5c1562) -> save();
		} else {
			$var_35b7c6eb = $this -> func_352f4ea2 -> data($var_de5c1562) -> add();
		} 
		$var_42cba2f6 = url('admin/collect/index');
		if ($_POST['addnext']) {
			$var_42cba2f6 = url('admin/collect/edit?id=' . $var_35b7c6eb);
		} 
		if ($var_35b7c6eb) {
			$this -> success('恭喜，保存成功！', $var_42cba2f6);
		} else {
			$this -> error('保存失败！');
		} 
	} 
	public function config() {
		$this -> display();
	} 
	public function confupdate() {
		$var_1b04f3c8 = $_POST["con"];
		$var_4582f15b = $_POST['collect_hour'];
		foreach($var_1b04f3c8 as $var_228572b3 => $var_d8bba397) {
			$var_1b04f3c8[$var_228572b3] = trim($var_1b04f3c8[$var_228572b3]);
			$var_1b04f3c8[$var_228572b3] = func_e838d727($var_1b04f3c8[$var_228572b3]);
		} 
		$var_1b04f3c8['collect_hour'] = $var_4582f15b;
		$var_7c7d0dd9 = require $this -> func_1d4cbd7b;
		$var_be12f82d = array_merge($var_7c7d0dd9, $var_1b04f3c8);
		ksort($var_be12f82d);
		func_3c22ed21($this -> func_1d4cbd7b, $var_be12f82d);
		$this -> success('恭喜你，修改成功');
	} 
	public function tempdb() {
		$var_36a0b2a2 = txtDB('arctype') -> select();
		$var_36a0b2a2 = func_809cbb58($var_36a0b2a2, 'dirname');
		$var_4eda73b5 = TEMP_PATH . 'cache_tempdb';
		$var_ff44612c = glob($var_4eda73b5 . '/*.txt');
		$var_de5c1562 = array();
		$var_5c49da62 = config('txtdir');
		foreach($var_ff44612c as $var_228572b3 => $var_cb83972b) {
			$var_980a7c7e = $var_cb83972b;
			$var_f7682d0b = raction('admin/txtdata/getfileinfo', array($var_980a7c7e));
			list($var_1e649227, $var_225f1e59) = explode('_', basename($var_980a7c7e));
			list($var_225f1e59,) = explode('.', $var_225f1e59);
			if ($var_225f1e59 == 'body') {
				$var_225f1e59 = 'article';
			} 
			$var_f7682d0b['txtname'] = $var_5c49da62[$var_225f1e59];
			$var_f7682d0b['typename'] = $var_36a0b2a2[$var_1e649227]['name'];
			$var_de5c1562['list'][] = $var_f7682d0b;
		} 
		$this -> assign($var_de5c1562);
		$this -> display();
	} 
	public function tempdb_review() {
		$var_2f44f078 = 500;
		$var_980a7c7e = $this -> _get('f');
		$var_980a7c7e = raction('admin/txtdata/decodefile', array($var_980a7c7e));
		$var_a1c8c470 = false;
		if (preg_match('~_body$~', $var_980a7c7e)) {
			$var_2f44f078 = 100;
			$var_a1c8c470 = true;
		} 
		$var_980a7c7e = TEMP_PATH . 'cache_tempdb/' . $var_980a7c7e;
		$var_980a7c7e = str_replace('..', '', $var_980a7c7e);
		if (!is_file($var_980a7c7e)) {
			exit('文件不存在！' . $var_980a7c7e);
		} 
		$var_09497274 = func_4f521b6d(func_1fe69150($var_980a7c7e, $var_2f44f078));
		$this -> assign('file', func_4f521b6d($var_980a7c7e));
		$this -> assign('linenum', $var_2f44f078);
		$this -> assign('txt_data', $var_09497274);
		if ($var_a1c8c470 && $var_09497274) {
			$var_370ebc88 = array();
			$var_cd1bb131 = explode('
', $var_09497274);
			foreach($var_cd1bb131 as $var_228572b3 => $var_cb83972b) {
				list($var_d089e8c2, $var_63503092) = explode('******', $var_cb83972b);
				if ($var_d089e8c2 == '') continue;
				$var_370ebc88[] = array('title' => $var_d089e8c2, 'litpic' => $var_63503092);
			} 
			$this -> assign('list', $var_370ebc88);
			$this -> display('article_review');
			exit;
		} 
		$this -> display('txtdata_review');
	} 
	public function tempdb_del() {
		$var_980a7c7e = $this -> _get('f');
		$var_980a7c7e = raction('admin/txtdata/decodefile', array($var_980a7c7e));
		$var_980a7c7e = TEMP_PATH . 'cache_tempdb/' . $var_980a7c7e;
		$var_980a7c7e = str_replace('..', '', $var_980a7c7e);
		if (is_file($var_980a7c7e)) {
			@unlink($var_980a7c7e);
		} 
		$this -> success('删除成功！');
	} 
	public function test() {
		$var_e95fba0e = isset($_GET['nid'])?$this -> _get('nid'):$this -> error('id 不能为空');
		$var_ae21f2d5 = array('id=' . $var_e95fba0e);
		$var_35b7c6eb = txtDB('collect') -> where($var_ae21f2d5) -> find();
		if ($var_35b7c6eb['model'] == 'body') {
			$this -> test_body($var_e95fba0e);
		} 
		if ($var_35b7c6eb['model'] == 'title') {
			$this -> test_title($var_e95fba0e);
		} 
		if ($var_35b7c6eb['model'] == 'pic') {
			$this -> test_pic($var_e95fba0e);
		} 
		if ($var_35b7c6eb['model'] == 'typename') {
			$this -> test_title($var_e95fba0e, 'typename');
		} 
	} 
	public function run() {
		$var_e95fba0e = isset($_GET['nid'])?$this -> _get('nid'):$this -> error('id 不能为空');
		$var_cc7d199f = $this -> _param('page', 'intval', 1);
		$var_a47a5c70 = $this -> _param('success', 'intval', 0);
		$var_ae21f2d5 = array('id=' . $var_e95fba0e);
		$var_35b7c6eb = txtDB('collect') -> where($var_ae21f2d5) -> find();
		$var_de5c1562 = array();
		func_2436795e($var_e95fba0e, 0);
		$var_afb1db68 = $GLOBALS['collect_rules'];
		$var_ca1d3a44 = array('lasttime' => time(),);
		if ($var_cc7d199f == 1) {
			$var_ca1d3a44['numlog'] = (int)$var_35b7c6eb['numlog'] + 1;
		} 
		txtDB('collect') -> where('id=' . $var_e95fba0e) -> save($var_ca1d3a44);
		if ($var_35b7c6eb['model'] == 'body') {
			$var_0b4dc8c4 = func_d88bc8fb();
			$var_877ab31e = count($var_0b4dc8c4['url']);
			$var_bc246193 = $var_cc7d199f - 1;
			$var_75f57b3a = $var_0b4dc8c4['url'][$var_bc246193];
			$var_160b568b = $this -> _param('page2', 'intval', 1);
			if ($var_160b568b == 1 && is_file(CACHE_PATH . 'collect_content/0.tmp')) {
				unlink(CACHE_PATH . 'collect_content/0.tmp');
			} 
			if ($var_cc7d199f > 1) {
				$var_f8c8d3b2 = CACHE_PATH . 'collect_content/' . ($var_bc246193 - 1) . '.tmp';
				is_file($var_f8c8d3b2) && unlink($var_f8c8d3b2);
			} 
			$var_76628617 = CACHE_PATH . 'collect_content/' . $var_bc246193 . '.tmp';
			if (is_file($var_76628617) && (filemtime($var_76628617) + 3600 * 3) > time()) {
				$var_8bb5268f = unserialize(file_get_contents($var_76628617));
			} else {
				$html = func_28b50565($var_75f57b3a);
				$var_8bb5268f = func_6f5f7eb8($html, $var_75f57b3a, $var_afb1db68);
				if ($var_8bb5268f) write($var_76628617, serialize($var_8bb5268f));
			} 
			$var_ef20458d = 3;
			$var_9d83ed8b = ceil(count($var_8bb5268f) / $var_ef20458d);
			$var_160b568b = min($var_160b568b, $var_9d83ed8b);
			$var_64f25176 = ($var_160b568b - 1) * $var_ef20458d;
			$var_8bb5268f = array_slice($var_8bb5268f, $var_64f25176, $var_ef20458d);
			$var_a47a5c70 = func_5be97940($var_8bb5268f, $var_afb1db68['body_area_regx'], $var_a47a5c70, $var_afb1db68['maxnum']);
			$var_afcd7486 = false;
			if ($var_afb1db68['maxnum'] && $var_a47a5c70 >= $var_afb1db68['maxnum']) {
				$var_afcd7486 = true;
			} 
			if ($var_afb1db68['split']) {
				$var_bad6c929 = $var_afb1db68['split'] == 1?'句子':'段落';
			} else {
				$var_bad6c929 = '内容';
			} 
			if ($var_afcd7486 || ($var_cc7d199f >= $var_877ab31e && $var_160b568b >= $var_9d83ed8b)) {
				@unlink($var_76628617);
				$this -> assign('msgTitle', '采集完成！');
				$this -> success('采集完成！共采集到<font color="red">' . ($var_a47a5c70 - 1) . '条' . $var_bad6c929 . '！', 'javascript:');
			} else {
				$this -> assign('msgTitle', '正在采集' . $var_bad6c929 . '...(' . $var_cc7d199f . '/' . $var_877ab31e . ')');
				unset($_GET['g'], $_GET['m'], $_GET['a']);
				$_GET['page2'] = $var_160b568b + 1;
				$_GET['success'] = $var_a47a5c70;
				if ($var_160b568b >= $var_9d83ed8b) {
					$_GET['page'] = $var_cc7d199f + 1;
					unset($_GET['page2']);
				} 
				$var_42cba2f6 = '?g=admin&m=collect&a=run&' . http_build_query($_GET);
				$this -> success('已采集到<font color="red">' . $var_a47a5c70 . '</font>条' . $var_bad6c929 . '！采集了<font color="red">' . count($var_8bb5268f) . '</font>条网址，<font color="red">' . $GLOBALS['collect_repeatnum'] . '</font>重复！继续采集...(' . $var_160b568b . '/' . $var_9d83ed8b . ')', $var_42cba2f6);
			} 
		} 
		if ($var_35b7c6eb['model'] == 'typename') {
			$var_0b4dc8c4 = func_d88bc8fb();
			$var_877ab31e = count($var_0b4dc8c4['url']);
			$var_bc246193 = $var_cc7d199f - 1;
			$var_75f57b3a = $var_0b4dc8c4['url'][$var_bc246193];
			$var_160b568b = $this -> _param('page2', 'intval', 1);
			if ($var_160b568b == 1 && is_file(CACHE_PATH . 'collect_typename/0.tmp')) {
				unlink(CACHE_PATH . 'collect_typename/0.tmp');
			} 
			if ($var_cc7d199f > 1) {
				$var_f8c8d3b2 = CACHE_PATH . 'collect_typename/' . ($var_bc246193 - 1) . '.tmp';
				is_file($var_f8c8d3b2) && unlink($var_f8c8d3b2);
			} 
			$var_76628617 = CACHE_PATH . 'collect_typename/' . $var_bc246193 . '.tmp';
			if (is_file($var_76628617) && (filemtime($var_76628617) + 3600 * 3) > time()) {
				$var_8bb5268f = unserialize(file_get_contents($var_76628617));
			} else {
				$html = func_28b50565($var_75f57b3a);
				$var_8bb5268f = func_6f5f7eb8($html, $var_75f57b3a, $var_afb1db68);
				if ($var_8bb5268f) write($var_76628617, serialize($var_8bb5268f));
			} 
			$var_ef20458d = 3;
			$var_9d83ed8b = ceil(count($var_8bb5268f) / $var_ef20458d);
			$var_160b568b = min($var_160b568b, $var_9d83ed8b);
			$var_64f25176 = ($var_160b568b - 1) * $var_ef20458d;
			$var_8bb5268f = array_slice($var_8bb5268f, $var_64f25176, $var_ef20458d);
			$var_a47a5c70 = func_12361f5f($var_8bb5268f, $var_a47a5c70);
			$var_afcd7486 = false;
			if ($var_afb1db68['maxnum'] && $var_a47a5c70 >= $var_afb1db68['maxnum']) {
				$var_afcd7486 = true;
			} 
			if ($var_afcd7486 || $var_cc7d199f >= $var_877ab31e) {
				@unlink($var_76628617);
				$this -> assign('msgTitle', '采集完成！');
				$this -> success('采集完成！共采集到' . ($var_a47a5c70 - 1) . '子页标题！', 'javascript:');
			} else {
				$this -> assign('msgTitle', '正在采集子页标题' . '...(' . $var_cc7d199f . '/' . $var_877ab31e . ')');
				unset($_GET['g'], $_GET['m'], $_GET['a']);
				$_GET['page2'] = $var_160b568b + 1;
				$_GET['success'] = $var_a47a5c70;
				if ($var_160b568b >= $var_9d83ed8b) {
					$_GET['page'] = $var_cc7d199f + 1;
					unset($_GET['page2']);
				} 
				$var_42cba2f6 = '?g=admin&m=collect&a=run&' . http_build_query($_GET);
				$this -> success('已采集到' . $var_a47a5c70 . '条子页标题！' . $GLOBALS['collect_repeatnum'] . '条重复！继续采集...(' . $var_160b568b . '/' . $var_9d83ed8b . ')', $var_42cba2f6);
			} 
		} 
		if ($var_35b7c6eb['model'] == 'title' || $var_35b7c6eb['model'] == 'pic') {
			$var_0b4dc8c4 = func_d88bc8fb();
			$var_f1d13c7b = count($var_0b4dc8c4['url']);
			$var_59adc197 = 3;
			$var_877ab31e = ceil($var_f1d13c7b / $var_59adc197);
			$var_cc7d199f = min($var_cc7d199f, $var_877ab31e);
			$var_64f25176 = ($var_cc7d199f - 1) * $var_59adc197;
			$var_0b4dc8c4['url'] = array_slice($var_0b4dc8c4['url'], $var_64f25176, $var_59adc197);
			$var_0b4dc8c4['urlregx'] = array_slice($var_0b4dc8c4['urlregx'], $var_64f25176, $var_59adc197);
			if ($var_35b7c6eb['model'] == 'pic') {
				$var_a47a5c70 = func_7a275322($var_0b4dc8c4, $var_a47a5c70, $var_afb1db68);
				$var_aca22417 = '图片';
			} 
			if ($var_35b7c6eb['model'] == 'title') {
				$var_a47a5c70 = func_3b2fa4cf($var_0b4dc8c4, $var_a47a5c70, $var_afb1db68);
				$var_aca22417 = '标题';
			} 
			$var_afcd7486 = false;
			if ($var_afb1db68['maxnum'] && $var_a47a5c70 >= $var_afb1db68['maxnum']) {
				$var_afcd7486 = true;
			} 
			if ($var_afcd7486 || $var_cc7d199f >= $var_877ab31e) {
				$this -> assign('msgTitle', '采集完成！');
				$this -> success('采集完成！共采集到' . ($var_a47a5c70 - 1) . '个' . $var_aca22417 . '！', 'javascript:');
			} else {
				$this -> assign('msgTitle', '正在采集' . $var_aca22417 . '...(' . $var_cc7d199f . '/' . $var_877ab31e . ')');
				unset($_GET['g'], $_GET['m'], $_GET['a']);
				$_GET['page'] = $var_cc7d199f + 1;
				$_GET['success'] = $var_a47a5c70;
				$var_42cba2f6 = '?g=admin&m=collect&a=run&' . http_build_query($_GET);
				$this -> success('已采集到' . $var_a47a5c70 . '个' . $var_aca22417 . '！' . $GLOBALS['collect_repeatnum'] . '条重复！继续采集...', $var_42cba2f6);
			} 
		} 
	} 
	public function test_pic($var_e95fba0e) {
		$var_de5c1562 = array();
		func_2436795e($var_e95fba0e, 0);
		$var_afb1db68 = $GLOBALS['collect_rules'];
		$var_de5c1562['listurlarr'] = func_d88bc8fb();
		$var_4df2dd93 = $var_de5c1562['listurlarr']['url'];
		shuffle($var_4df2dd93);
		$var_de5c1562['listurl'] = $var_4df2dd93[0];
		$html = func_28b50565($var_de5c1562['listurl']);
		$var_de5c1562['html'] = $html;
		$var_c5224860 = func_6d71dea8($html, $var_de5c1562['listurl']);
		if ($var_c5224860) {
			$var_186934fa = func_6f42332b($var_de5c1562['listurlarr']['urlregx'][0]);
			foreach($var_c5224860 as $var_228572b3 => $var_cb83972b) {
				if ($var_186934fa && !preg_match('~^' . $var_186934fa . '$~i', $var_cb83972b)) {
					unset($var_c5224860[$var_228572b3]);
				} 
			} 
		} 
		$var_c5224860 = array_unique($var_c5224860);
		$var_de5c1562['imgArr'] = $var_c5224860;
		$this -> assign($var_de5c1562);
		$this -> display('collect_test_pic');
	} 
	public function test_title($var_e95fba0e, $var_7c6c92b4 = 'title') {
		$var_de5c1562 = array();
		func_2436795e($var_e95fba0e, 0);
		$var_afb1db68 = $GLOBALS['collect_rules'];
		$var_de5c1562['listurlarr'] = func_d88bc8fb();
		$var_4df2dd93 = $var_de5c1562['listurlarr']['url'];
		shuffle($var_4df2dd93);
		$var_de5c1562['listurl'] = $var_4df2dd93[0];
		$html = func_28b50565($var_de5c1562['listurl']);
		$var_de5c1562['html'] = $html;
		$var_04b81daf = '~<a[^>]+href\\s*=\\s*(["|\']*)([\\w/\\.].*)["\' 
	][^>]*>(.*)</a>~iUs';
		$var_2407a687 = $var_adea2cff = array();
		if (preg_match_all($var_04b81daf, $html, $var_973d74fe)) {
			$var_186934fa = func_6f42332b($var_de5c1562['listurlarr']['urlregx'][0]);
			if ($var_afb1db68['sift_words']) {
				$var_d4fc5ace = explode('
', $var_afb1db68['sift_words']);
				$var_d4fc5ace = array_map('trim', $var_d4fc5ace);
			} 
			if ($var_afb1db68['replace_words']) {
				$var_3ba1d834 = explode('
', $var_afb1db68['replace_words']);
				$var_3ba1d834 = array_map('trim', $var_3ba1d834);
			} 
			$var_5a24a0fa = $var_afb1db68['min_num']?$var_afb1db68['min_num']:30;
			foreach($var_973d74fe[2] as $var_228572b3 => $var_cb83972b) {
				$var_1003d5bb = func_a6aabd8f($var_cb83972b);
				list($var_1003d5bb,) = explode('#', $var_1003d5bb);
				$var_1003d5bb = func_d24a35d7($var_1003d5bb, $var_de5c1562['listurl']);
				if ($var_186934fa && !preg_match('~^' . $var_186934fa . '$~i', $var_1003d5bb)) {
					continue;
				} 
				$var_d089e8c2 = strip_tags($var_973d74fe[3][$var_228572b3]);
				$var_d089e8c2 = preg_replace('~\\s+~', ' ', $var_d089e8c2);
				$var_d089e8c2 = preg_replace('~\\.+$~', '', $var_d089e8c2);
				if (func_bd6dd0d8($var_d089e8c2)) {
					continue;
				} 
				$var_d089e8c2 = preg_replace('~^\\d{2}-\\d{2}~', '', $var_d089e8c2);
				if ($var_afb1db68['body_filter_regx']) {
					$var_beba630c = explode('
', $var_afb1db68['body_filter_regx']);
					foreach($var_beba630c as $var_04b81daf) {
						$var_04b81daf = trim($var_04b81daf);
						if ($var_04b81daf == '') continue;
						$var_d089e8c2 = preg_replace('~' . $var_04b81daf . '~Us', '', $var_d089e8c2);
					} 
				} 
				if ($var_d4fc5ace) {
					foreach($var_d4fc5ace as $var_3d9151c4 => $var_1076c777) {
						if (substr($var_1076c777, 0, 1) == '*') {
							$var_d089e8c2 = str_replace(substr($var_1076c777, 1), '', $var_d089e8c2);
							continue;
						} 
						if (strpos($var_d089e8c2, $var_1076c777) !== false) {
							$var_adea2cff[] = '【该词语已过滤】' . $var_d089e8c2;
							continue 2;
						} 
					} 
				} 
				if ($var_3ba1d834) {
					foreach($var_3ba1d834 as $var_3d9151c4 => $var_1076c777) {
						if (!$var_1076c777) continue;
						list($var_55df87ba, $var_7c3e9a74) = explode('=', $var_1076c777);
						if (strpos($var_7c3e9a74, ',') > - 1) {
							$var_865a966f = explode(',', $var_7c3e9a74);
							shuffle($var_865a966f);
							$var_7c3e9a74 = trim($var_865a966f[0]);
						} 
						$var_d089e8c2 = str_replace($var_55df87ba, $var_7c3e9a74, $var_d089e8c2);
					} 
				} 
				if ($var_d089e8c2 && strlen($var_d089e8c2) >= $var_5a24a0fa && strlen($var_d089e8c2) < 100) {
					$var_2407a687[] = trim($var_d089e8c2);
				} 
			} 
		} 
		$var_2407a687 = array_unique($var_2407a687);
		if ($var_adea2cff) {
			$var_2407a687 = array_merge($var_2407a687, $var_adea2cff);
		} 
		if ($var_2407a687 && $var_afb1db68['replace_naipan']) {
			$var_3b835166 = implode('******', $var_2407a687);
			$var_1c019175 = func_ca6476e6($var_3b835166);
			$var_2407a687 = explode('******', $var_1c019175['body']);
			if ($var_1c019175['status']) {
				array_unshift($var_2407a687, '<font color=green>【已经过奶盘伪原创API处理】</font>');
			} else {
				array_unshift($var_2407a687, '<font class=red>【奶盘伪原创API处理失败，msg：' . $var_1c019175['msg'] . '】</font>');
			} 
		} 
		$var_de5c1562['titleArr'] = $var_2407a687;
		$this -> assign($var_de5c1562);
		$this -> display('collect_test_' . $var_7c6c92b4);
	} 
	public function test_body($var_e95fba0e) {
		$var_de5c1562 = array();
		func_2436795e($var_e95fba0e, 0);
		$var_afb1db68 = $GLOBALS['collect_rules'];
		$var_de5c1562['listurlarr'] = func_d88bc8fb();
		$var_4df2dd93 = $var_de5c1562['listurlarr']['url'];
		shuffle($var_4df2dd93);
		$var_de5c1562['listurl'] = $var_4df2dd93[0];
		$html = func_28b50565($var_de5c1562['listurl']);
		$var_8bb5268f = func_6f5f7eb8($html, $var_de5c1562['listurl'], $var_afb1db68);
		$var_de5c1562['showurlarr'] = $var_8bb5268f;
		$var_3ec0b958 = $var_8bb5268f;
		shuffle($var_3ec0b958);
		$var_de5c1562['showurl'] = $var_afb1db68['testurl_show']?$var_afb1db68['testurl_show']:$var_3ec0b958[0];
		$html = func_28b50565($var_de5c1562['showurl']);
		$var_de5c1562['html'] = $html;
		$var_beba630c = explode('
', $var_afb1db68['body_area_regx']);
		$var_8eafab80 = '';
		foreach($var_beba630c as $var_3d9151c4 => $var_1076c777) {
			$var_1076c777 = trim($var_1076c777);
			if (preg_match('~' . $var_1076c777 . '~Us', $html, $var_973d74fe)) {
				$var_8eafab80 = $var_973d74fe[1];
				break;
			} 
		} 
		if ($var_8eafab80) {
			$var_de5c1562['content'] = $var_8eafab80;
			if ($var_afb1db68['body_filter_regx']) {
				$var_beba630c = explode('
', $var_afb1db68['body_filter_regx']);
				foreach($var_beba630c as $var_04b81daf) {
					$var_04b81daf = trim($var_04b81daf);
					if ($var_04b81daf == '') continue;
					$var_8eafab80 = preg_replace('~' . $var_04b81daf . '~Us', '', $var_8eafab80);
				} 
				$var_de5c1562['content'] = trim($var_8eafab80);
			} 
			if ($var_afb1db68['sift_words']) {
				$var_d4fc5ace = explode('
', $var_afb1db68['sift_words']);
				$var_d4fc5ace = array_map('trim', $var_d4fc5ace);
			} 
			if ($var_afb1db68['replace_words']) {
				$var_3ba1d834 = explode('
', $var_afb1db68['replace_words']);
				$var_3ba1d834 = array_map('trim', $var_3ba1d834);
			} 
			$var_5a24a0fa = $var_afb1db68['min_num']?$var_afb1db68['min_num']:40;
			if ($var_afb1db68['split']) {
				$var_7346876d = $var_afb1db68['lang'] == 'en'?true:false;
				$var_de5c1562['content'] = func_9afb6ee1($var_8eafab80, $var_5a24a0fa, $var_7346876d);
			} else {
				$var_de5c1562['title'] = func_229d8716($html);
				$var_de5c1562['content'] = func_2bd6b23a($var_de5c1562['content']);
				if ($var_5f5e702e = func_6d71dea8($var_de5c1562['content'])) {
					foreach($var_5f5e702e as $var_05c594b9) {
						$var_15661e48 = func_d24a35d7($var_05c594b9, $var_7d1800bf);
						$var_de5c1562['content'] = str_replace($var_05c594b9, $var_15661e48, $var_de5c1562['content']);
					} 
				} 
			} 
			$var_de5c1562['picarr'] = func_6d71dea8($var_de5c1562['content'], $var_de5c1562['showurl']);
			if ($var_d4fc5ace) {
				foreach($var_d4fc5ace as $var_3d9151c4 => $var_1076c777) {
					if (substr($var_1076c777, 0, 1) == '*') {
						$var_de5c1562['content'] = str_replace(substr($var_1076c777, 1), '', $var_de5c1562['content']);
						continue;
					} 
					if (strpos($var_de5c1562['content'], $var_1076c777) !== false) {
						$var_de5c1562['content'] = str_replace($var_1076c777, '【该词语已过滤】', $var_de5c1562['content']);
						continue;
					} 
				} 
			} 
			if ($var_3ba1d834) {
				foreach($var_3ba1d834 as $var_3d9151c4 => $var_1076c777) {
					if (!$var_1076c777) continue;
					list($var_55df87ba, $var_7c3e9a74) = explode('=', $var_1076c777);
					if (strpos($var_7c3e9a74, ',') > - 1) {
						$var_865a966f = explode(',', $var_7c3e9a74);
						shuffle($var_865a966f);
						$var_7c3e9a74 = trim($var_865a966f[0]);
					} 
					$var_de5c1562['content'] = str_replace($var_55df87ba, $var_7c3e9a74, $var_de5c1562['content']);
				} 
			} 
			if (strlen($var_de5c1562['content']) < $var_5a24a0fa) {
				$var_de5c1562['content'] .= '【此内容长度小于设定值，将会被过滤】';
			} 
			if ($var_afb1db68['replace_naipan']) {
				$var_1c019175 = func_ca6476e6($var_de5c1562['content']);
				if ($var_1c019175['status']) {
					$var_de5c1562['content'] = $var_1c019175['body'];
					$var_de5c1562['content'] = '<font color=green>【此内容已经过奶盘伪原创API处理】</font><br>' . $var_de5c1562['content'];
				} else {
					$var_de5c1562['content'] = '<font class=red>【奶盘伪原创API处理失败，msg：' . $var_1c019175['msg'] . '】</font><br>' . $var_de5c1562['content'];
				} 
			} 
		} 
		$var_de5c1562['rules'] = $var_afb1db68;
		$this -> assign($var_de5c1562);
		$this -> display('collect_test_body');
	} 
	public function testurl() {
		$var_1003d5bb = array();
		$var_6cc04fbb = urldecode($_GET['url']);
		echo implode('<br>', func_d88bc8fb());
	} 
	public function status() {
		$var_10635ff1 = isset($_GET['id'])?intval($_GET['id']):$this -> error('error');
		$var_b945b287 = isset($_GET['sid'])?intval($_GET['sid']):$this -> error('error');
		$this -> func_352f4ea2 -> where('id=' . $var_10635ff1) -> data(array('status' => $var_b945b287)) -> save();
		$this -> success('操作成功！', $_SESSION['archives_reurl']);
	} 
	public function statusAll() {
		$var_b945b287 = $this -> _get('sid', 'intval');
		$var_46a44e41 = !empty($_POST['ids'])?$_POST['ids']:$this -> error('未选中规则');
		foreach($var_46a44e41 as $var_228572b3 => $var_cb83972b) {
			$this -> func_352f4ea2 -> where('id=' . $var_cb83972b) -> data(array('status' => $var_b945b287)) -> save();
		} 
		$this -> success('操作成功！', $_SESSION['archives_reurl']);
	} 
	public function del() {
		$var_10635ff1 = isset($_GET['id'])?intval($_GET['id']):$this -> error('id 不能为空');
		$var_ae21f2d5 = 'id=' . $var_10635ff1;
		$var_35b7c6eb = $this -> func_352f4ea2 -> where($var_ae21f2d5) -> delete();
		if (!$var_35b7c6eb) $this -> error('删除失败！');
		$this -> success('删除成功！', url('admin/collect/index'));
	} 
	public function delmore() {
		$var_46a44e41 = !empty($_POST['ids'])?$_POST['ids']:$this -> error('未选中规则');
		foreach($var_46a44e41 as $var_228572b3 => $var_cb83972b) {
			$this -> func_352f4ea2 -> where('id=' . $var_cb83972b) -> delete();
		} 
		$this -> success('删除成功！', url('admin/collect/index'));
	} 
	public function export() {
		$var_10635ff1 = isset($_GET['nid'])?intval($_GET['nid']):$this -> error('id 不能为空');
		$var_35b7c6eb = $this -> func_352f4ea2 -> where('id=' . $var_10635ff1) -> find();
		if ($var_35b7c6eb) {
			foreach($var_35b7c6eb as $var_228572b3 => $var_cb83972b) {
				if (preg_match('~temp\\d+~', $var_228572b3)) unset($var_35b7c6eb[$var_228572b3]);
			} 
			$var_335d704a = $var_35b7c6eb;
			$var_335d704a['rules'] = unserialize($var_335d704a['rules']);
			foreach($var_335d704a['rules'] as $var_228572b3 => $var_cb83972b) {
				if ($var_cb83972b == '') unset($var_335d704a['rules'][$var_228572b3]);
			} 
			$var_8b9085ac = array('id', 'proxyid', 'loginid', 'is_header', 'ip_type', 'refurl', 'lasttime', 'status', 'numlog');
			foreach($var_8b9085ac as $var_228572b3 => $var_cb83972b) {
				if (isset($var_335d704a['rules'][$var_cb83972b])) unset($var_335d704a['rules'][$var_cb83972b]);
				if (isset($var_335d704a[$var_cb83972b])) unset($var_335d704a[$var_cb83972b]);
			} 
			$var_335d704a['rules'] = serialize($var_335d704a['rules']);
			$var_606fb2e4 = 'xxfseo:' . base64_encode(serialize($var_335d704a)) . ':end';
			$this -> assign($var_35b7c6eb);
			$this -> assign(array('code' => $var_606fb2e4));
		} 
		$this -> display();
	} 
	public function import() {
		$var_10635ff1 = $this -> _get('id');
		if ($var_10635ff1) {
			$var_7a921b30 = $this -> func_352f4ea2 -> where('id=' . $var_10635ff1) -> find();
		} 
		if (IS_POST) {
			$var_de5c1562 = $var_afb1db68 = array();
			$var_606fb2e4 = $_POST['code'];
			$var_d688deb2 = $_POST['arctype'];
			$var_606fb2e4 = func_e838d727($var_606fb2e4);
			$var_606fb2e4 = str_replace(array('xxfseo:', ':end'), '', $var_606fb2e4);
			$var_de5c1562 = unserialize(base64_decode($var_606fb2e4));
			if ($var_de5c1562) {
				if ($var_10635ff1) {
					$var_de5c1562['arctype'] = $var_7a921b30['arctype'];
				} else {
					$var_de5c1562['arctype'] = $var_d688deb2;
				} 
				$var_de5c1562['addtime'] = time();
				$var_de5c1562['numlog'] = 0;
				if (!isset($var_de5c1562['split']) && $var_de5c1562['model'] == 'body') {
					$var_de5c1562['split'] = 1;
				} 
				$var_de5c1562['rules'] = unserialize($var_de5c1562['rules']);
				if (!$var_de5c1562['rules']['collect_day_num']) {
					$var_de5c1562['rules']['collect_day_num'] = 0;
				} 
				$var_de5c1562['rules'] = serialize($var_de5c1562['rules']);
				if ($var_10635ff1) {
					$var_35b7c6eb = $this -> func_352f4ea2 -> where('id=' . $var_10635ff1) -> data($var_de5c1562) -> save();
				} else {
					$var_35b7c6eb = $this -> func_352f4ea2 -> data($var_de5c1562) -> add();
				} 
				if ($var_35b7c6eb) {
					$this -> success('导入成功!', url('admin/collect/index'));
				} else {
					$this -> error('导入失败!');
				} 
			} else {
				$this -> error('导入失败，规则不正确!');
			} 
		} else {
			$var_36a0b2a2 = txtDB('arctype') -> select();
			if ($var_36a0b2a2) {
				$var_265537f7 = func_bf43bb58($var_36a0b2a2, 0, $var_335d704a['arctype']);
			} 
			if ($var_10635ff1) {
				$this -> assign('id', $var_10635ff1);
				$this -> assign('name', $var_7a921b30['name']);
			} 
			$this -> assign('class_option', $var_265537f7);
			$this -> display();
		} 
	} 
} 

?>