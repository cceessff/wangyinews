<?php class arctypeAction extends adminAction {
	public $var_401ddad4;
	public $var_d688deb2;
	public $var_36317ca5;
	public function _init() {
		parent :: _init();
		$this -> func_291a8ad2 = txtDB('arctype');
	} 
	public function index() {
		func_4638be96();
		$var_35b7c6eb = $this -> func_291a8ad2 -> select();
		$var_6ac11d7b = func_64d0f4f3($var_cb83972b['dirname']);
		foreach($var_35b7c6eb as $var_228572b3 => $var_cb83972b) {
			$var_586a20ab = txtDB('domain') -> where('cid=' . $var_cb83972b['id']) -> select();
			$var_cbefd511 = 0;
			if ($var_586a20ab) {
				foreach($var_586a20ab as $var_3d9151c4 => $var_1076c777) {
					$var_119ad111 = DATA_PATH . 'domain/' . $var_1076c777['dirname'] . '_domain.txt';
					$var_b4dabed4 = file_get_contents($var_119ad111);
					$var_cbefd511 += $var_b4dabed4?count(explode('
', $var_b4dabed4)):0;
				} 
			} 
			$var_35b7c6eb[$var_228572b3]['domain_num'] = $var_cbefd511;
			$var_35b7c6eb[$var_228572b3]['theme_num'] = 0;
			if ($var_6ac11d7b) {
				foreach($var_6ac11d7b as $var_3d9151c4 => $var_1076c777) {
					if (preg_match('~^' . $var_cb83972b['dirname'] . '/~', $var_3d9151c4)) {
						$var_35b7c6eb[$var_228572b3]['theme_num']++;
					} 
				} 
			} 
			$var_35b7c6eb[$var_228572b3]['theme_num'] == 0 && $var_35b7c6eb[$var_228572b3]['theme_num'] = '无';
			$var_35b7c6eb[$var_228572b3]['domain_num'] == 0 && $var_35b7c6eb[$var_228572b3]['domain_num'] = '无';
			$var_35b7c6eb[$var_228572b3]['collect_num'] = txtDB('collect') -> where('arctype=' . $var_cb83972b['id']) -> count();
		} 
		$var_de5c1562['list'] = $var_35b7c6eb;
		$this -> assign($var_de5c1562);
		$this -> display();
	} 
	public function edit() {
		$var_10635ff1 = isset($_GET['id'])?intval($_GET['id']):'';
		if ($var_10635ff1 <> '') {
			$var_35b7c6eb = $this -> func_291a8ad2 -> where('id=' . $var_10635ff1) -> find();
		} 
		$this -> assign($var_35b7c6eb);
		$this -> display();
	} 
	public function urlrules_edit() {
		$var_10635ff1 = $this -> _get('id');
		$var_50cb9083 = $this -> _get('urltype');
		$var_35b7c6eb = $this -> func_291a8ad2 -> where('id=' . $var_10635ff1) -> find();
		$var_35b7c6eb['urlrules'] = unserialize($var_35b7c6eb['urlrules' . $var_50cb9083]);
		if ($var_35b7c6eb['tplfiles']) $var_419a06ba = explode(',', $var_35b7c6eb['tplfiles']);
		$var_419a06ba = $var_419a06ba?array_merge(array('list', 'show'), $var_419a06ba):array('list', 'show');
		foreach($var_419a06ba as $var_228572b3 => $var_cb83972b) {
			if (!isset($var_35b7c6eb['urlrules'][$var_cb83972b])) {
				$var_35b7c6eb['urlrules'][$var_cb83972b] = array('tplfile' => $var_cb83972b, 'rules' => '',);
			} 
		} 
		foreach($var_35b7c6eb['urlrules'] as $var_228572b3 => $var_cb83972b) {
			if (in_array($var_cb83972b['tplfile'], array('index', 'list', 'show'))) {
				$var_35b7c6eb['urlrules'][$var_228572b3]['system'] = 1;
			} else if ($var_419a06ba && !in_array($var_228572b3, $var_419a06ba)) {
				unset($var_35b7c6eb['urlrules'][$var_228572b3]);
				continue;
			} 
			$var_35b7c6eb['urlrules'][$var_228572b3]['rules'] = str_replace(',', '
', $var_cb83972b['rules']);
		} 
		$var_de5c1562 = $var_35b7c6eb;
		$var_de5c1562['urltype'] = $var_50cb9083;
		$var_de5c1562['urltype_name'] = $var_50cb9083 == 1?'随机模式':'固定模式';
		$this -> assign($var_de5c1562);
		$this -> display();
	} 
	public function urlrules_update() {
		$var_10635ff1 = $this -> _post('id');
		$var_50cb9083 = $this -> _post('urltype');
		$var_c24ab4b7 = $_POST['tplfile'];
		$var_ec057ba8 = $_POST['urlrules'];
		$var_06a7fc59 = $_POST['system'];
		$var_a7d640ea = array();
		foreach($var_c24ab4b7 as $var_228572b3 => $var_cb83972b) {
			$var_cb83972b = trim($var_cb83972b);
			if ($var_cb83972b == '') {
				continue;
			} 
			$var_ec057ba8[$var_228572b3] = str_replace('{id}{aid}', '{id}-{aid}', $var_ec057ba8[$var_228572b3]);
			$var_ec057ba8[$var_228572b3] = str_replace('{aid}{id}', '{aid}-{id}', $var_ec057ba8[$var_228572b3]);
			$var_ec057ba8[$var_228572b3] = str_replace(array('
', '', '
'), ',', $var_ec057ba8[$var_228572b3]);
			$var_a7d640ea[$var_cb83972b] = array('tplfile' => $var_cb83972b, 'rules' => $var_ec057ba8[$var_228572b3], 'system' => $var_06a7fc59[$var_228572b3]);
		} 
		$var_de5c1562 = array();
		$var_de5c1562['urlrules' . $var_50cb9083] = $var_a7d640ea?serialize($var_a7d640ea):'';
		$var_ae21f2d5 = array('id=' . $var_10635ff1);
		$var_35b7c6eb = $this -> func_291a8ad2 -> where($var_ae21f2d5) -> data($var_de5c1562) -> save();
		if ($var_35b7c6eb) {
			$this -> success('保存成功！');
		} else {
			$this -> error('保存失败！');
		} 
	} 
	public function update() {
		$var_66b061f1 = $this -> _post('musttpl');
		$var_1b04f3c8 = $_POST['con'];
		foreach($var_1b04f3c8 as $var_228572b3 => $var_d8bba397) {
			$var_1b04f3c8[$var_228572b3] = func_e838d727(trim($var_1b04f3c8[$var_228572b3]));
		} 
		if ($var_1b04f3c8['name'] == '') {
			$this -> ajaxReturn(array('status' => 0, 'info' => '请输入分类名称！'));
		} 
		if (!$var_1b04f3c8['id'] && $var_1b04f3c8['dirname'] == '') {
			$this -> ajaxReturn(array('status' => 0, 'info' => '请输入文件夹名称！'));
		} 
		$var_2762bb34 = $this -> func_291a8ad2 -> where(array('dirname' => $var_1b04f3c8['dirname'])) -> find();
		if ($var_2762bb34) {
			if ($var_1b04f3c8['id'] != $var_2762bb34['id']) {
				$this -> error('文件夹名称已存在，请换一个！');
			} 
		} 
		$var_1b04f3c8['tplfiles'] = trim($var_1b04f3c8['tplfiles'], ',');
		$var_ae21f2d5 = array('id=' . $var_1b04f3c8['id']);
		if ($var_1b04f3c8['id'] > 0) {
			$var_35b7c6eb = $this -> func_291a8ad2 -> where($var_ae21f2d5) -> data($var_1b04f3c8) -> save();
		} else {
			$var_1b04f3c8['urlrules1'] = serialize(array('list' => array('tplfile' => 'list', 'rules' => 'list/{id}{字母3}/,list/{id}{数字字母5}.html', 'system' => 1), 'show' => array('tplfile' => 'show', 'rules' => 'html/{id}{数字5}.html,newshtml/{id}{数字5}.html,news/{id}{数字5}.html', 'system' => 1),));
			$var_1b04f3c8['urlrules2'] = serialize(array('list' => array('tplfile' => 'list', 'rules' => 'list/{id}-{aid}/,cate/{id}-{aid}.html', 'system' => 1), 'show' => array('tplfile' => 'show', 'rules' => 'html/{id}-{aid}.html,show/{id}-{aid}.html', 'system' => 1),));
			$var_35b7c6eb = $this -> func_291a8ad2 -> data($var_1b04f3c8) -> add();
			foreach(config('txtdir') as $var_228572b3 => $var_cb83972b) {
				$var_1e649227 = DATA_PATH . $var_228572b3 . '/' . $var_1b04f3c8['dirname'];
				if (!is_dir($var_1e649227)) {
					mkdir($var_1e649227, 511, true);
				} 
			} 
		} 
		if ($var_35b7c6eb) {
			$this -> success('保存成功！');
		} else {
			$this -> error('保存失败！');
		} 
	} 
	public function del() {
		$var_10635ff1 = isset($_GET['id'])?intval($_GET['id']):$this -> error('id 不能为空');
		$var_35b7c6eb = $this -> func_291a8ad2 -> where('id=' . $var_10635ff1) -> find();
		$var_1e649227 = $var_35b7c6eb['dirname'];
		$var_35b7c6eb = $this -> func_291a8ad2 -> where('id=' . $var_10635ff1) -> delete();
		if (!$var_35b7c6eb) $this -> error('删除失败！');
		$var_64edb935 = array('article', 'body', 'content', 'diy', 'pic', 'title', 'typename', 'video', 'webname');
		foreach($var_64edb935 as $var_228572b3 => $var_cb83972b) {
			$var_fae1bb2a = DATA_PATH . $var_cb83972b . '/' . $var_1e649227;
			is_dir($var_fae1bb2a) && func_891a6fb0($var_fae1bb2a);
		} 
		$this -> success('删除成功！', url('admin/arctype/index'));
	} 
	public function tplrules() {
		$var_7c6c92b4 = $this -> _get('type');
		$var_36a0b2a2 = txtDB('arctype') -> select();
		foreach($var_36a0b2a2 as $var_228572b3 => $var_cb83972b) {
			$var_1c95cf50 = TEMP_PATH . 'tplrules/' . $var_cb83972b['dirname'];
			$var_36a0b2a2[$var_228572b3]['isset'] = false;
			if (is_file($var_1c95cf50 . '/title_index.txt') || is_file($var_1c95cf50 . '/description_index.txt') || is_file($var_1c95cf50 . '/body.txt')) {
				$var_36a0b2a2[$var_228572b3]['isset'] = true;
			} 
		} 
		$this -> assign('type', $var_7c6c92b4);
		$this -> assign('class_list', $var_36a0b2a2);
		$this -> assign('list', $var_370ebc88);
		$this -> display();
	} 
	public function tplrules_edit() {
		$var_fae1bb2a = $this -> _get('dir');
		$var_fae1bb2a = str_replace('.', '', $var_fae1bb2a);
		$var_36a0b2a2 = txtDB('arctype') -> where('dirname=' . $var_fae1bb2a) -> find();
		if ($var_36a0b2a2['tplfiles']) $var_419a06ba = explode(',', $var_36a0b2a2['tplfiles']);
		$var_419a06ba = $var_419a06ba?array_merge(array('list', 'show'), $var_419a06ba):array('list', 'show');
		$var_de5c1562 = $var_e15112f9 = $var_8d83b09f = $var_e0d4aa7c = array();
		$var_1c95cf50 = TEMP_PATH . 'tplrules/' . $var_fae1bb2a;
		if (!is_dir($var_1c95cf50)) {
			$var_1c95cf50 = TEMP_PATH . 'tplrules/default';
		} 
		$var_e15112f9['index'] = @file_get_contents($var_1c95cf50 . '/title_index.txt');
		$var_68b6ef64['index'] = @file_get_contents($var_1c95cf50 . '/keywords_index.txt');
		$var_e0d4aa7c['index'] = @file_get_contents($var_1c95cf50 . '/description_index.txt');
		foreach($var_419a06ba as $var_228572b3 => $var_cb83972b) {
			$var_7a44f1af = $var_1c95cf50 . '/title_' . $var_cb83972b . '.txt';
			$var_0376324a = $var_1c95cf50 . '/keywords_' . $var_cb83972b . '.txt';
			$var_c3b7d0ae = $var_1c95cf50 . '/description_' . $var_cb83972b . '.txt';
			$var_e15112f9[$var_cb83972b] = is_file($var_7a44f1af)?file_get_contents($var_7a44f1af):'';
			$var_68b6ef64[$var_cb83972b] = is_file($var_0376324a)?file_get_contents($var_0376324a):'';
			$var_e0d4aa7c[$var_cb83972b] = is_file($var_c3b7d0ae)?file_get_contents($var_c3b7d0ae):'';
		} 
		$var_de5c1562['dirname'] = $var_fae1bb2a;
		$var_de5c1562['titletpls'] = $var_e15112f9;
		$var_de5c1562['kwtpls'] = $var_68b6ef64;
		$var_de5c1562['desctpls'] = $var_e0d4aa7c;
		$var_de5c1562['bodytpls'] = @file_get_contents($var_1c95cf50 . '/body.txt');
		if ($var_de5c1562['bodytpls']) {
			$var_de5c1562['bodytpls'] = @explode('||||||', $var_de5c1562['bodytpls']);
		} 
		$this -> assign($var_de5c1562);
		$this -> display();
	} 
	public function update_tplrules() {
		$var_fae1bb2a = $this -> _get('dir');
		$var_fae1bb2a = str_replace('.', '', $var_fae1bb2a);
		$var_36a0b2a2 = txtDB('arctype') -> where('dirname=' . $var_fae1bb2a) -> find();
		if ($var_36a0b2a2['tplfiles']) $var_419a06ba = explode(',', $var_36a0b2a2['tplfiles']);
		$var_419a06ba = $var_419a06ba?array_merge(array('index', 'list', 'show'), $var_419a06ba):array('index', 'list', 'show');
		$var_1c95cf50 = TEMP_PATH . 'tplrules/' . $var_fae1bb2a;
		foreach($var_419a06ba as $var_228572b3 => $var_cb83972b) {
			$var_7a44f1af = $var_1c95cf50 . '/title_' . $var_cb83972b . '.txt';
			$var_0376324a = $var_1c95cf50 . '/keywords_' . $var_cb83972b . '.txt';
			$var_c3b7d0ae = $var_1c95cf50 . '/description_' . $var_cb83972b . '.txt';
			$var_7cd12fe3 = func_e838d727(trim($_POST['titletpl'][$var_cb83972b]));
			write($var_7a44f1af, $var_7cd12fe3);
			$var_f3554430 = func_e838d727(trim($_POST['kwtpl'][$var_cb83972b]));
			write($var_0376324a, $var_f3554430);
			$var_402d58df = func_e838d727(trim($_POST['desctpl'][$var_cb83972b]));
			write($var_c3b7d0ae, $var_402d58df);
		} 
		$var_586a20ab = $_POST['bodytpls'];
		$var_586a20ab = array_unique($var_586a20ab);
		foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
			if (trim($var_cb83972b) == '') {
				unset($var_586a20ab[$var_228572b3]);
				continue;
			} 
			$var_586a20ab[$var_228572b3] = func_e838d727($var_cb83972b);
		} 
		$var_de5c1562 = implode('||||||', $var_586a20ab);
		$var_980a7c7e = $var_1c95cf50 . '/body.txt';
		write($var_980a7c7e, $var_de5c1562);
		$this -> success('保存成功');
	} 
	public function tplrules_del() {
		$var_fae1bb2a = $this -> _get('dir');
		$var_fae1bb2a = str_replace('.', '', $var_fae1bb2a);
		$var_de5c1562 = array();
		$var_1c95cf50 = TEMP_PATH . 'tplrules/' . $var_fae1bb2a;
		if (func_891a6fb0($var_1c95cf50)) {
			$this -> success('删除成功！');
		} else {
			$this -> error('删除失败！');
		} 
	} 
	public function import() {
		if (IS_POST) {
			$var_de5c1562 = $var_afb1db68 = array();
			$var_10635ff1 = (int)$_POST['id'];
			$var_606fb2e4 = $_POST['code'];
			$var_606fb2e4 = func_e838d727($var_606fb2e4);
			$var_606fb2e4 = str_replace(array('xxfseo_model:', ':end'), '', $var_606fb2e4);
			$var_de5c1562 = unserialize(base64_decode($var_606fb2e4));
			if ($var_de5c1562) {
				$var_de5c1562['addtime'] = time();
				if ($var_10635ff1) {
					$var_de5c1562['id'] = $var_10635ff1;
					$var_ae21f2d5 = array('id=' . $var_de5c1562['id']);
					$var_35b7c6eb = $this -> func_291a8ad2 -> where($var_ae21f2d5) -> data($var_de5c1562) -> save();
				} else {
					$var_35b7c6eb = $this -> func_291a8ad2 -> where('dirname=' . $var_de5c1562['dirname']) -> find();
					if ($var_35b7c6eb) {
						$var_de5c1562['dirname'] .= '_';
					} 
					$var_35b7c6eb = $this -> func_291a8ad2 -> data($var_de5c1562) -> add();
				} 
				if ($var_35b7c6eb) {
					$this -> success('导入成功!', url('admin/arctype/index'));
				} else {
					$this -> error('导入失败!');
				} 
			} else {
				$this -> error('导入失败，规则不正确!');
			} 
		} else {
			$var_36a0b2a2 = txtDB('arctype') -> select();
			$var_10635ff1 = (int)$_GET['id'];
			if ($var_36a0b2a2) {
				$var_265537f7 = func_bf43bb58($var_36a0b2a2, 0, $var_10635ff1);
			} 
			$this -> assign('class_option', $var_265537f7);
			$this -> display();
		} 
	} 
	public function export() {
		$var_10635ff1 = isset($_GET['id'])?intval($_GET['id']):$this -> error('id 不能为空');
		$var_35b7c6eb = $this -> func_291a8ad2 -> where('id=' . $var_10635ff1) -> find();
		if ($var_35b7c6eb) {
			foreach($var_35b7c6eb as $var_228572b3 => $var_cb83972b) {
				if (preg_match('~temp\\d+~', $var_228572b3)) unset($var_35b7c6eb[$var_228572b3]);
			} 
			$var_335d704a = $var_35b7c6eb;
			$var_8b9085ac = array('id');
			foreach($var_8b9085ac as $var_228572b3 => $var_cb83972b) {
				if (isset($var_335d704a[$var_cb83972b])) unset($var_335d704a[$var_cb83972b]);
			} 
			$var_606fb2e4 = 'xxfseo_model:' . base64_encode(serialize($var_335d704a)) . ':end';
			$this -> assign($var_35b7c6eb);
			$this -> assign(array('code' => $var_606fb2e4));
		} 
		$this -> display();
	} 
} 

?>