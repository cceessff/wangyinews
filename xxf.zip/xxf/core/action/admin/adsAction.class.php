<?php class adsAction extends adminAction {
	public $var_b12d4fcf;
	public function _init() {
		parent :: _init();
		$this -> func_fcc22b13 = txtDB('myad');
	} 
	public function index() {
		$var_de5c1562 = $this -> func_fcc22b13 -> select();
		$var_320df380 = txtDB('domain') -> select();
		$var_320df380 = func_809cbb58($var_320df380, 'id');
		foreach($var_de5c1562 as $var_228572b3 => $var_cb83972b) {
			$var_de5c1562[$var_228572b3]['groupname'] = $var_cb83972b['ads_group'] == 0?'全部分组':$var_320df380[$var_cb83972b['ads_group']]['name'];
		} 
		$this -> assign('list', $var_de5c1562);
		$this -> display();
	} 
	public function edit() {
		$var_10635ff1 = isset($_GET['id'])?intval($_GET['id']):0;
		$var_de5c1562 = $this -> func_fcc22b13 -> where('id=' . $var_10635ff1) -> find();
		$var_de5c1562['group_list'] = $this -> get_grouplist();
		if ($var_de5c1562['ads_group'] == '0') {
			$var_de5c1562['ads_group_name'] = '全部分组';
		} else if ($var_de5c1562['ads_group']) {
			$var_586a20ab = explode(',', $var_de5c1562['ads_group']);
			foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
				$var_85c7c823[] = $var_de5c1562['group_list'][$var_cb83972b]['name'];
			} 
			$var_de5c1562['ads_group_name'] = implode($var_85c7c823, ',');
		} 
		$this -> assign($var_de5c1562);
		$this -> display();
	} 
	public function preview() {
		$var_10635ff1 = isset($_GET['id'])?$_GET['id']:$this -> error('id 不能为空');
		$var_35b7c6eb = $this -> func_fcc22b13 -> where('id=' . $var_10635ff1) -> find();
		if ($var_35b7c6eb) {
			header('Content-type: text/html; charset=utf-8');
			echo '<head><title>' . $var_35b7c6eb['name'] . ' 广告预览</title></head><body style="font-size:12px"><p>标识符：' . $var_35b7c6eb['mark'] . '</p><p>广告说明：' . $var_35b7c6eb['name'] . '</p><p>调用标签：<font color="#990000">{$myad.' . $var_35b7c6eb['mark'] . '}</font></p><p>以下为广告预览：</p><hr size=1><script>' . $var_35b7c6eb['code'] . '</script></body>';
		} 
	} 
	public function update() {
		$var_10635ff1 = isset($_GET['id'])?intval($_GET['id']):0;
		$var_1b04f3c8 = $_POST['con'];
		foreach($var_1b04f3c8 as $var_228572b3 => $var_d8bba397) {
			$var_1b04f3c8[$var_228572b3] = func_e838d727(trim($var_1b04f3c8[$var_228572b3]));
		} 
		if ($var_1b04f3c8['mark'] == '' || $var_1b04f3c8['name'] == '') $this -> ajaxReturn(array('status' => 0, 'info' => '关键项不能为空！'));
		$var_ae21f2d5 = array('id=' . $var_10635ff1);
		if ($var_10635ff1 > 0) {
			$var_35b7c6eb = $this -> func_fcc22b13 -> where($var_ae21f2d5) -> data($var_1b04f3c8) -> save();
		} else {
			$var_35b7c6eb = $this -> func_fcc22b13 -> data($var_1b04f3c8) -> add();
		} 
		if ($var_35b7c6eb) {
			$this -> ajaxReturn(array('status' => 1));
		} else {
			$this -> ajaxReturn(array('status' => 0, 'info' => '保存失败！'));
		} 
	} 
	public function del() {
		$var_10635ff1 = isset($_GET['id'])?intval($_GET['id']):$this -> error('id 不能为空');
		$var_ae21f2d5 = 'id=' . $var_10635ff1;
		$var_35b7c6eb = $this -> func_fcc22b13 -> where($var_ae21f2d5) -> delete();
		if (!$var_35b7c6eb) $this -> error('删除失败！');
		$this -> success('删除成功！', url('admin/ads/index'));
	} 
	public function get_grouplist() {
		$var_35b7c6eb = txtDB('domain') -> select();
		foreach($var_35b7c6eb as $var_228572b3 => $var_cb83972b) {
			$var_35b7c6eb[$var_228572b3]['addtime'] = now_date_color($var_35b7c6eb[$var_228572b3]['addtime']);
			$var_119ad111 = DATA_PATH . 'domain/' . $var_cb83972b['dirname'] . '_domain.txt';
			$var_b4dabed4 = file_get_contents($var_119ad111);
			$var_b4dabed4 = str_replace('
', ',', $var_b4dabed4);
			$var_35b7c6eb[$var_228572b3]['domain'] = substr($var_b4dabed4, 0, 20) . (strlen($var_b4dabed4) > 20?'...':'');
		} 
		$var_35b7c6eb = func_809cbb58($var_35b7c6eb, 'id');
		return $var_35b7c6eb;
	} 
} 

?>