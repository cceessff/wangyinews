<?php @ini_set('pcre.backtrack_limit', 1000000);
@set_time_limit(0);
function func_2adc7aeb($var_de5c1562) {
	$var_afb1db68 = unserialize($var_de5c1562['rules']);
	return $var_afb1db68;
} 
function func_2436795e($var_e95fba0e, $var_2f187abd = 0) {
	$var_ae21f2d5 = array('id=' . $var_e95fba0e);
	if ($var_2f187abd) {
		$var_ae21f2d5[] = 'and';
		$var_ae21f2d5[] = 'status=' . $var_2f187abd;
	} 
	$var_35b7c6eb = txtDB('collect') -> where($var_ae21f2d5) -> find();
	if (!$var_35b7c6eb) {
		return false;
	} 
	$var_36a0b2a2 = txtDB('arctype') -> select();
	$var_36a0b2a2 = func_809cbb58($var_36a0b2a2, 'id');
	$GLOBALS['collect_rules'] = func_2adc7aeb($var_35b7c6eb);
	$var_8c622afe = explode(',', $var_35b7c6eb['arctype']);
	foreach($var_8c622afe as $var_228572b3 => $var_cb83972b) {
		$var_d688deb2 = $var_36a0b2a2[$var_cb83972b];
		$var_d688deb2 && $GLOBALS['collect_rules']['dirname'][] = $var_d688deb2['dirname'];
	} 
	unset($var_35b7c6eb['rules']);
	$GLOBALS['collect_rules'] = array_merge($GLOBALS['collect_rules'], $var_35b7c6eb);
	return true;
} 
function func_46518cf1($var_56d286bd, $html) {
	$var_afb1db68 = $GLOBALS['collect_rules'];
	$var_de5c1562 = array();
	$var_294d9df2 = array_keys($var_56d286bd);
	foreach($var_294d9df2 as $var_dce42d17) {
		if (isset($var_afb1db68[$var_dce42d17 . '_type']) === false) $var_afb1db68[$var_dce42d17 . '_type'] = '0';
		switch ($var_afb1db68[$var_dce42d17 . '_type']) {
			case '1': if ($var_afb1db68[$var_dce42d17 . '_start'] == '' && $var_afb1db68[$var_dce42d17 . '_end'] == '') {
					$var_de5c1562[$var_dce42d17] = ACTION_NAME == 'test' ? '<font class="c9">未设置规则</font>':'';
					break 2;
				} 
				if ($var_afb1db68[$var_dce42d17 . '_loop'] || $var_56d286bd[$var_dce42d17]['loop'] == 1) {
					$var_19c4496a = func_660d54f8($var_afb1db68[$var_dce42d17 . '_start'], $var_afb1db68[$var_dce42d17 . '_end'], $html);
					if ($var_19c4496a) $var_de5c1562[$var_dce42d17] = implode('<!--loop-->', $var_19c4496a);
				} else {
					$var_de5c1562[$var_dce42d17] = func_15a6c8df($var_afb1db68[$var_dce42d17 . '_start'], $var_afb1db68[$var_dce42d17 . '_end'], $html);
				} 
				break;
			case '2': if ($var_afb1db68[$var_dce42d17 . '_regx'] == '') {
					if (ACTION_NAME == 'test') {
						$var_de5c1562[$var_dce42d17] = '<font class="c9">未设置规则</font>';
						continue 2;
					} 
				} 
				if ($var_afb1db68[$var_dce42d17 . '_loop'] || $var_56d286bd[$var_dce42d17]['loop'] == 1) {
					$var_19c4496a = func_8497e681($var_afb1db68[$var_dce42d17 . '_regx'], $html);
					if ($var_19c4496a) $var_de5c1562[$var_dce42d17] = implode('<!--loop-->', $var_19c4496a);
				} else {
					$var_de5c1562[$var_dce42d17] = func_8497e681($var_afb1db68[$var_dce42d17 . '_regx'], $html);
				} 
				break;
			case '0': if (ACTION_NAME == 'test') {
					$var_de5c1562[$var_dce42d17] = '<font class="c9">未设置规则</font>';
					continue 2;
				} 
				break;
			default: break;
		} 
		if ($var_afb1db68[$var_dce42d17 . '_replace'] != '') {
			$var_de5c1562[$var_dce42d17] = col_rules_replace($var_dce42d17, $var_de5c1562[$var_dce42d17]);
		} 
		if ($var_dce42d17 == 'body' || $var_56d286bd[$var_dce42d17]['isbody']) {
			$var_de5c1562[$var_dce42d17] = co_replace_img($var_de5c1562[$var_dce42d17]);
			$var_de5c1562[$var_dce42d17] = remove_link($var_de5c1562[$var_dce42d17]);
		} 
		if ($var_56d286bd[$var_dce42d17]['validate']) {
			if (!preg_match($var_56d286bd[$var_dce42d17]['validate'], $var_de5c1562[$var_dce42d17])) {
				$var_de5c1562[$var_dce42d17] = '';
				if (ACTION_NAME == 'test') {
					$var_de5c1562[$var_dce42d17] = '<font class="red">数据未通过验证</font>';
					if ($var_afb1db68[$var_dce42d17 . '_default']) {
						$var_de5c1562[$var_dce42d17] .= '<font class="red">( 将使用默认值: ' . $var_afb1db68[$var_dce42d17 . '_default'] . ' )</font>';
					} 
					continue;
				} 
			} 
		} 
		if (empty($var_de5c1562[$var_dce42d17]) && $var_afb1db68[$var_dce42d17 . '_default']) {
			$var_de5c1562[$var_dce42d17] = '<font class="red">使用默认值: ' . $var_afb1db68[$var_dce42d17 . '_default'] . '</font>';
		} 
		$var_de5c1562[$var_dce42d17] = removeXss(trim($var_de5c1562[$var_dce42d17]));
	} 
	return $var_de5c1562;
} 
function func_eb9a9dd8($var_71e9f77f, $var_10635ff1, $html) {
	$var_afb1db68 = $GLOBALS['collect_rules'];
	$var_2b841305 = co_get_show_pagetotal($html);
	if (!$var_2b841305) return false;
	$var_2b841305 = min($var_2b841305, 100);
	$var_fde107aa = $var_afb1db68['showpage_addv'];
	$var_dd5414d2 = $var_afb1db68['regxurl_show'];
	$var_6cc04fbb = str_replace('{id}', $var_10635ff1, $var_dd5414d2);
	$var_6cc04fbb = str_replace('{cid}', $var_71e9f77f, $var_6cc04fbb);
	$var_87eef044 = array();
	if (substr($var_fde107aa, 0, 1) == '-') {
		$var_fde107aa = abs($var_fde107aa);
		for($var_7ea74e20 = 0;$var_7ea74e20 < $var_2b841305;$var_7ea74e20++) {
			$var_cc7d199f = $var_2b841305 - $var_fde107aa * $var_7ea74e20;
			if ($var_cc7d199f < 0) break;
			$var_87eef044[] = str_replace('{p}', $var_cc7d199f, $var_6cc04fbb);
		} 
	} else {
		for($var_7ea74e20 = 0;$var_7ea74e20 < $var_2b841305;$var_7ea74e20++) {
			$var_cc7d199f = $var_fde107aa * $var_7ea74e20;
			$var_87eef044[] = str_replace('{p}', $var_cc7d199f, $var_6cc04fbb);
		} 
	} 
	foreach($_GET as $var_228572b3 => $var_cb83972b) {
		$var_87eef044 = str_replace('{' . $var_228572b3 . '}', htmlspecialchars($var_cb83972b), $var_87eef044);
	} 
	$var_87eef044 = array_unique($var_87eef044);
	$var_87eef044 = array_slice($var_87eef044, 0, 2000);
	return $var_87eef044;
} 
function func_4ba14343($var_b945b287, $var_10635ff1, $var_cc7d199f = 1) {
	$var_afb1db68 = $GLOBALS['collect_rules'];
	$var_6cc04fbb = str_replace('{id}', $var_10635ff1, $var_afb1db68['regxurl_show']);
	$var_6cc04fbb = str_replace('{all}', $var_10635ff1, $var_6cc04fbb);
	$var_6cc04fbb = str_replace('{cid}', $var_b945b287, $var_6cc04fbb);
	$var_7d1800bf = str_replace('{p}', $var_cc7d199f, $var_6cc04fbb);
	return $var_7d1800bf;
} 
function func_ca6476e6($var_5afc80a1) {
	$var_afb1db68 = $GLOBALS['collect_rules'];
	if (!$var_afb1db68['replace_naipan']) {
		return $var_1c019175;
	} 
	$var_1c019175 = array('body' => $var_5afc80a1, 'status' => 0);
	$var_dc3627b8 = TEMP_PATH . 'replace_config.php';
	if (!isset($GLOBALS['replace_api']) && is_file($var_dc3627b8)) {
		$GLOBALS['replace_api'] = require $var_dc3627b8;
	} 
	if (!$GLOBALS['replace_api']['nanpan_user'] || !$GLOBALS['replace_api']['nanpan_sign']) {
		$var_1c019175['msg'] = '未设置API配置';
		return $var_1c019175;
	} 
	$var_ffebf89f = 'http://www.naipan.com/open/weiyuanchuang/towei.html';
	import('class/Http');
	$var_8251eda0 = new Http();
	$var_8251eda0 -> func_7fef4f3b = 5;
	$var_8251eda0 -> func_a2b0a95b = 'POST';
	$var_8251eda0 -> func_ff1f28a7 = $var_ffebf89f;
	$var_8251eda0 -> func_27d15989 = 'regname=' . $GLOBALS['replace_api']['nanpan_user'] . '&regsn=' . urlencode($GLOBALS['replace_api']['nanpan_sign']) . '&content=' . urlencode($var_5afc80a1);
	session_write_close();
	$var_8251eda0 -> func_d80f7f6b();
	$html = $var_8251eda0 -> func_1a559174;
	if (!$html) {
		$var_1c019175['msg'] = '请求API失败';
		return $var_1c019175;
	} 
	$var_12eb4460 = json_decode($html, true);
	if ($var_12eb4460['result'] == 1) {
		$var_1c019175['status'] = 1;
		$var_1c019175['body'] = $var_12eb4460['content'];
	} else {
		$var_1c019175['msg'] = '返回错误信息：' . $var_12eb4460['message'];
	} 
	return $var_1c019175;
} 
function func_d88bc8fb() {
	$var_afb1db68 = $GLOBALS['collect_rules'];
	$var_477e89d0 = array();
	$var_586a20ab = explode('
', $var_afb1db68['regxurl_list']);
	foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
		list($var_1003d5bb, $var_32b85394) = explode('->', $var_cb83972b);
		$var_1003d5bb = trim($var_1003d5bb);
		$var_32b85394 = trim($var_32b85394);
		if (preg_match('~(\\{p,(\\d+),(\\d+),(\\d+)\\})~', $var_1003d5bb, $var_973d74fe)) {
			$var_b109b337 = $var_973d74fe[1];
			$var_973d74fe = array_slice($var_973d74fe, 2);
			list($var_5929a5be, $var_7c3ef7c3, $var_fde107aa) = $var_973d74fe;
			$var_fde107aa = max($var_fde107aa, 1);
			if ($var_5929a5be <= $var_7c3ef7c3) {
				while ($var_5929a5be <= $var_7c3ef7c3) {
					$var_75f57b3a = str_replace($var_b109b337, $var_5929a5be, $var_1003d5bb);
					$var_477e89d0['url'][] = $var_75f57b3a;
					$var_477e89d0['urlregx'][] = $var_32b85394;
					$var_5929a5be += $var_fde107aa;
				} 
			} else {
				while ($var_7c3ef7c3 <= $var_5929a5be) {
					$var_75f57b3a = str_replace($var_b109b337, $var_5929a5be, $var_1003d5bb);
					$var_477e89d0['url'][] = $var_75f57b3a;
					$var_477e89d0['urlregx'][] = $var_32b85394;
					$var_5929a5be -= $var_fde107aa;
				} 
			} 
		} else {
			$var_477e89d0['url'][] = $var_1003d5bb;
			$var_477e89d0['urlregx'][] = $var_32b85394;
		} 
	} 
	return $var_477e89d0;
} 

?>