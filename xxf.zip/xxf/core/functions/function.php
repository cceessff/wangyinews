<?php function add_tag_class($matches) {
	!isset($GLOBALS['add_tag_class']) && $GLOBALS['add_tag_class'] = 1;
	$var_ed252828 = range('a', 'z');
	$var_228572b3 = $GLOBALS['add_tag_class'] % 26;
	$var_4ff7f406 = $var_ed252828[$var_228572b3];
	$var_8d9ffc1f = $var_4ff7f406 . substr(md5(func_dfe3da17() . $GLOBALS['add_tag_class']), 0, 5);
	$var_40db88e3 = $matches[1] . $var_8d9ffc1f . ' ';
	$GLOBALS['add_tag_class']++;
	return $var_40db88e3;
} 
function add_tag_attr($matches) {
	!isset($GLOBALS['add_tag_attr']) && $GLOBALS['add_tag_attr'] = 1;
	if (strpos($matches[1], '<') === false) return $matches[1] . ' ';
	$var_e9945d1d = array('date-time', 'dir', 'lang', 'draggable', 'dropzone');
	$var_228572b3 = $GLOBALS['add_tag_attr'] % count($var_e9945d1d);
	$var_d43c4947 = $var_e9945d1d[$var_228572b3];
	$var_8d9ffc1f = substr(md5(func_dfe3da17() . $GLOBALS['add_tag_attr']), 0, 6);
	$var_40db88e3 = $matches[1] . ' ' . $var_d43c4947 . '="' . $var_8d9ffc1f . '" ';
	$GLOBALS['add_tag_attr']++;
	return $var_40db88e3;
} 
function add_html_tag($matches) {
	$var_47904b8f = md5(func_dfe3da17() . date('Y'));
	$var_47904b8f = preg_replace('~[^\\d]+~', '', $var_47904b8f);
	$var_47904b8f = intval(substr($var_47904b8f, 0, 3));
	!isset($GLOBALS['add_html_tag']) && $GLOBALS['add_html_tag'] = $var_47904b8f;
	if (strpos($matches[1], '<') === false) {
		return $matches[1] . ' ';
	} 
	$var_ed252828 = array('bdo', 'dfn', 'font', 'ins', 'kbd', 'small', 'sup', 'time', 'tt', 'var', 'area', 'map');
	$var_e9945d1d = array('date-time', 'dir', 'lang', 'draggable', 'dropzone');
	$var_40db88e3 = '';
	for($var_7ea74e20 = 0;$var_7ea74e20 < 3;$var_7ea74e20++) {
		$var_228572b3 = $GLOBALS['add_html_tag'] % count($var_ed252828);
		$var_d8b4f508 = $var_ed252828[$var_228572b3];
		$var_228572b3 = $GLOBALS['add_html_tag'] % count($var_e9945d1d);
		$var_d43c4947 = $var_e9945d1d[$var_228572b3];
		$var_8d9ffc1f = substr(md5(func_dfe3da17() . $GLOBALS['add_html_tag']), 0, 6);
		$var_40db88e3 .= '<' . $var_d8b4f508 . ' ' . $var_d43c4947 . '="' . $var_8d9ffc1f . '"></' . $var_d8b4f508 . '>';
		$GLOBALS['add_html_tag']++;
	} 
	$var_40db88e3 = $var_40db88e3 . $matches[1] . ' ';
	return $var_40db88e3;
} 
function func_b4a2b332($var_9327cb55) {
	$var_2f42d152 = floor($var_9327cb55 / (3600 * 24));
	$var_9327cb55 = $var_9327cb55 % (3600 * 24);
	$var_eea30f43 = floor($var_9327cb55 / 3600);
	$var_9327cb55 = $var_9327cb55 % 3600;
	$var_77937c92 = floor($var_9327cb55 / 60);
	$var_9327cb55 = $var_9327cb55 % 60;
	return $var_2f42d152 . '天' . $var_eea30f43 . '小时';
} 
function func_09a64523($var_e7221837) {
	global $var_1b04f3c8;
	static $var_7fbd95e1;
	if (!$var_7fbd95e1) {
		$var_7fbd95e1 = array('05', '06', '07', '08', '05', '06', '07', '08', '05', '06', '07', '08', '05', '06', '07', '08', '05', '06', '07', '08', '05', '06', '07', '08', '05', '06', '07', '08', '05', '06', '07', '08', '09', '10', '11');
		foreach($var_7fbd95e1 as $var_228572b3 => $var_cb83972b) {
			$var_7fbd95e1[$var_228572b3] = chr(hexdec($var_7fbd95e1[$var_228572b3]));
		} 
	} 
	$var_8d812ebe = '，*。*！*：*、*？';
	$var_04b81daf = str_replace('*', '|', $var_8d812ebe);
	preg_match_all('~(' . $var_04b81daf . ')~', $var_e7221837, $var_973d74fe);
	if ($var_973d74fe) {
		foreach($var_973d74fe[1] as $var_73bb3a5d) {
			if ($var_73bb3a5d == '') continue;
			$var_e7221837 = str_replace($var_73bb3a5d, '@@@' . base64_encode($var_73bb3a5d) . '@@@', $var_e7221837);
		} 
		preg_match_all('~@@@(.*)@@@~U', $var_e7221837, $var_4924010e);
		if ($var_4924010e) {
			foreach($var_4924010e[1] as $var_73bb3a5d) {
				shuffle($var_7fbd95e1);
				$var_b7f13a15 = rand(3, 5);
				$var_40db88e3 = implode('', array_slice($var_7fbd95e1, 0, $var_b7f13a15));
				$var_444e9cac = base64_decode($var_73bb3a5d);
				$var_e7221837 = preg_replace('~@@@' . $var_73bb3a5d . '@@@~', $var_40db88e3 . $var_444e9cac, $var_e7221837, 1);
			} 
		} 
	} 
	return $var_e7221837;
} 
function func_308b9c75($var_97766d65, $var_296fb57d, $var_b71b3ba2) {
	$var_370ebc88 = array();
	foreach(explode('
', trim($var_296fb57d)) as $var_228572b3 => $var_cb83972b) {
		$var_cb83972b = trim($var_cb83972b);
		if (!$var_cb83972b) continue;
		$var_370ebc88[] = $var_cb83972b . '----yd';
	} 
	foreach(explode('
', trim($var_b71b3ba2)) as $var_228572b3 => $var_cb83972b) {
		$var_cb83972b = trim($var_cb83972b);
		if (!$var_cb83972b) continue;
		$var_370ebc88[] = $var_cb83972b . '----mip';
	} 
	foreach(explode('
', trim($var_97766d65)) as $var_228572b3 => $var_cb83972b) {
		$var_cb83972b = trim($var_cb83972b);
		if (!$var_cb83972b) continue;
		$var_370ebc88[] = $var_cb83972b . '----zz';
	} 
	return $var_370ebc88;
} 
function func_da30f52e($var_1ffe317b) {
	$var_0c40ef77 = explode('----', $var_1ffe317b);
	$var_4c9dff78 = array_pop($var_0c40ef77);
	if ($var_4c9dff78 == 'yd') {
		list($var_b4dabed4, $var_5b9d1369, $var_2226d637, $var_076f5a97) = $var_0c40ef77;
		$var_f930169f = TEMP_PATH . 'cache_push/' . date('Ymd') . '/' . $var_b4dabed4 . '_realtime_' . $var_4c9dff78 . '_daylimit.txt';
		$var_1ad3127d = TEMP_PATH . 'cache_push/' . date('Ymd') . '/' . $var_b4dabed4 . '_batch_' . $var_4c9dff78 . '_daylimit.txt';
		if (is_file($var_f930169f) && is_file($var_1ad3127d)) {
			return true;
		} 
	} else if ($var_4c9dff78 == 'zz') {
		list($var_b4dabed4, $var_2226d637) = $var_0c40ef77;
	} else if ($var_4c9dff78 == 'mip') {
		list($var_b4dabed4, $var_2226d637) = $var_0c40ef77;
	} 
	$var_9d7733a9 = TEMP_PATH . 'cache_push/' . date('Ymd') . '/' . $var_b4dabed4 . '_' . $var_4c9dff78 . '_daylimit.txt';
	if (is_file($var_9d7733a9)) {
		return true;
	} 
	return false;
} 
function func_28a69079($var_1ffe317b) {
	import('class/Http');
	$var_0c40ef77 = explode('----', $var_1ffe317b);
	$var_4c9dff78 = array_pop($var_0c40ef77);
	$var_de41f5d8 = false;
	$var_9d7733a9 = '';
	if ($var_4c9dff78 == 'yd') {
		$var_de41f5d8 = true;
		list($var_b4dabed4, $var_5b9d1369, $var_2226d637, $var_076f5a97) = $var_0c40ef77;
		$var_7c6c92b4 = 'realtime';
		$var_9d7733a9 = TEMP_PATH . 'cache_push/' . date('Ymd') . '/' . $var_b4dabed4 . '_realtime_' . $var_4c9dff78 . '_daylimit.txt';
		if (is_file($var_9d7733a9)) {
			$var_7c6c92b4 = 'batch';
			$var_9d7733a9 = TEMP_PATH . 'cache_push/' . date('Ymd') . '/' . $var_b4dabed4 . '_batch_' . $var_4c9dff78 . '_daylimit.txt';
		} else {
			$var_076f5a97 && $GLOBALS['push_conf']['push_num'] = min($GLOBALS['push_conf']['push_num'], $var_076f5a97);
		} 
		$var_ffebf89f = 'http://data.zz.baidu.com/urls?appid=' . $var_5b9d1369 . '&token=' . $var_2226d637 . '&type=' . $var_7c6c92b4;
	} else if ($var_4c9dff78 == 'zz') {
		$var_7c6c92b4 = 'zz';
		list($var_b4dabed4, $var_2226d637) = $var_0c40ef77;
		$var_ffebf89f = 'http://data.zz.baidu.com/urls?site=' . $var_b4dabed4 . '&token=' . $var_2226d637;
	} else if ($var_4c9dff78 == 'mip') {
		$var_7c6c92b4 = 'mip';
		list($var_b4dabed4, $var_2226d637) = $var_0c40ef77;
		$var_ffebf89f = 'http://data.zz.baidu.com/urls?site=' . $var_b4dabed4 . '&token=' . $var_2226d637 . '&type=mip';
	} 
	if (!$var_9d7733a9) $var_9d7733a9 = TEMP_PATH . 'cache_push/' . date('Ymd') . '/' . $var_b4dabed4 . '_' . $var_4c9dff78 . '_daylimit.txt';
	for($var_7ea74e20 = 0;$var_7ea74e20 < 1;$var_7ea74e20++) {
		if ($GLOBALS['domainConfArr']) {
			$var_ec057ba8 = get_domain_conf($var_b4dabed4);
		} else {
			$var_cdf90f70 = $var_da035f13 = '未找到站点配置';
			break;
		} 
		if (preg_match('~^\\*\\.~', $var_b4dabed4)) {
			$GLOBALS['domain_config']['prefix_type'] = 1;
			$var_4ff7f406 = get_rand_prefix();
			$var_b4dabed4 = preg_replace('~^\\*\\.~', $var_4ff7f406 . '.', $var_b4dabed4);
		} 
		$var_8bb5268f = array();
		for($var_fd835089 = 0;$var_fd835089 < $GLOBALS['push_conf']['push_num'];$var_fd835089++) {
			$var_8bb5268f[] = get_url('show', '', $var_b4dabed4);
		} 
		$var_725c1d22 = count($var_8bb5268f);
		$var_c3d575e8 = implode('
', array_slice($var_8bb5268f, 0, 50));
		$var_8251eda0 = new Http();
		$var_8251eda0 -> func_7fef4f3b = 60;
		$var_8251eda0 -> func_a2b0a95b = 'POST';
		$var_8251eda0 -> func_5d0a4796('User-Agent', 'curl/7.12.1');
		$var_8251eda0 -> func_5d0a4796('Content-Type', 'text/plain');
		$var_8251eda0 -> func_27d15989 = implode('
', $var_8bb5268f);
		$var_8251eda0 -> func_ff1f28a7 = $var_ffebf89f;
		$var_8251eda0 -> func_d80f7f6b();
		$var_35b7c6eb = $var_8251eda0 -> func_1a559174;
		$var_12eb4460 = json_decode($var_35b7c6eb, true);
		if (!is_array($var_12eb4460)) {
			$var_cdf90f70 = $var_da035f13 = '返回格式错误';
			continue;
		} 
		if ($var_12eb4460['error']) {
			$var_cdf90f70 = $var_da035f13 = '返回错误：' . $var_12eb4460['message'];
			continue;
		} 
		$var_a47a5c70 = isset($var_12eb4460['success_realtime'])?$var_12eb4460['success_realtime']:$var_12eb4460['success'];
		$var_e7ac0e01 = isset($var_12eb4460['remain_realtime'])?$var_12eb4460['remain_realtime']:$var_12eb4460['remain'];
		$var_da035f13 = '推送成功：' . $var_a47a5c70 . ' 条链接，剩余额度：' . $var_e7ac0e01;
		$var_cdf90f70 = '提交成功';
		if ($var_e7ac0e01 == '0' || ($var_a47a5c70 == $GLOBALS['push_conf']['push_num'] && $var_de41f5d8 && $var_7c6c92b4 == 'realtime')) {
			if ($var_a47a5c70 < 1) {
				$var_cdf90f70 = '超额';
			} 
			write($var_9d7733a9, time());
			continue;
		} 
	} 
	return array('type' => $var_7c6c92b4, 'isxiong' => (int)$var_de41f5d8, 'domain' => $var_b4dabed4, 'msg' => $var_da035f13, 'urlnum' => $var_725c1d22, 'success' => (int)$var_a47a5c70, 'remain' => (int)$var_e7ac0e01, 'logmsg' => $var_cdf90f70, 'urllist' => $var_c3d575e8,);
} 
function func_7f102729($var_516e60ee) {
	$var_a113ab5f = './temp/pushlogs.log';
	$var_45c80446 = implode('	', array(date('Y-m-d H:i:s'), $var_516e60ee['mulu_url'], $var_516e60ee['isxiong'], $var_516e60ee['type'], $var_516e60ee['urlnum'], $var_516e60ee['domain'], $var_516e60ee['success'], $var_516e60ee['remain'], $var_516e60ee['guaji'], $var_516e60ee['msg'])) . '
';
	write($var_a113ab5f, $var_45c80446, 'a+');
} 
function get_domain_conf($var_39ae76d3) {
	if (!$GLOBALS['domainConfArr'] && !$GLOBALS['arctypeArr']) {
		return false;
	}
	$var_3b2dab8d = $GLOBALS['domainConfArr'];
	$var_1bdc2630 = $GLOBALS['arctypeArr'];
	$var_ec057ba8 = array();
	foreach($var_3b2dab8d as $var_228572b3 => $var_cb83972b) {
		$var_2e79d61a = $var_228572b3;
		if (isset($var_3b2dab8d[$var_39ae76d3]) || isset($var_3b2dab8d['www.' . $var_39ae76d3])) {
			$var_2e79d61a = $var_39ae76d3;
			$var_cb83972b = $var_3b2dab8d[$var_39ae76d3];
		} 
		if ($var_39ae76d3 == $var_2e79d61a || preg_match('~\\.' . preg_quote($var_2e79d61a) . '$~i', $var_39ae76d3)) {
			$GLOBALS['domain_root'] = $var_2e79d61a;
			if (!isset($var_1bdc2630[$var_cb83972b['cid']])) {
				return false;
			} 
			$GLOBALS['domain_id'] = $var_cb83972b['id'];
			$GLOBALS['domain_cid'] = $var_cb83972b['cid'];
			$var_ec057ba8 = unserialize($var_1bdc2630[$var_cb83972b['cid']]['urlrules' . $var_cb83972b['urltype']]);
			$GLOBALS['arctype_config'] = $var_1bdc2630[$var_cb83972b['cid']];
			$GLOBALS['arctype_config']['urlrules'] = $var_ec057ba8;
			$GLOBALS['domain_dirname'] = $var_cb83972b['dirname'];
			$GLOBALS['arctype_dirname'] = $GLOBALS['arctype_config']['dirname'];
			break;
		} 
	} 
	return $var_ec057ba8;
} 
function func_c6d21d61($var_39ae76d3 = '') {
	static $var_586a20ab;
	$var_071730f9 = preg_replace('~^www\\.~', '', $_SERVER['HTTP_HOST']);
	$var_071730f9 = preg_replace('~^' . config('domain.mobile_prefix') . '\\.~', '', $var_071730f9);
	!$var_39ae76d3 && $var_39ae76d3 = $var_071730f9;
	if (isset($var_586a20ab[$var_39ae76d3])) {
		return $var_586a20ab[$var_39ae76d3];
	} 
	$var_47904b8f = md5($var_39ae76d3);
	$var_b8aa0587 = str_split($var_47904b8f);
	$var_907250fa = 1;
	foreach($var_b8aa0587 as $var_228572b3 => $var_cb83972b) {
		if (is_numeric($var_cb83972b)) {
			$var_907250fa = $var_cb83972b;
			break;
		} 
	} 
	$var_cc8a2eeb = array();
	for($var_7ea74e20 = 1;$var_7ea74e20 <= 10;$var_7ea74e20++) {
		$var_6cbe6605 = 10 - $var_907250fa - $var_7ea74e20;
		if ($var_6cbe6605 < 0) {
			$var_6cbe6605 = $var_6cbe6605 + 10;
		} 
		$var_cc8a2eeb[] = $var_6cbe6605;
	} 
	$var_586a20ab[$var_39ae76d3] = $var_cc8a2eeb;
	return $var_cc8a2eeb;
} 
function func_72f9bc98($var_10635ff1) {
	$var_cc8a2eeb = func_c6d21d61();
	$var_99d419f9 = str_split($var_10635ff1);
	$var_06740a60 = '';
	foreach($var_99d419f9 as $var_228572b3 => $var_cb83972b) {
		$var_06740a60 .= $var_cc8a2eeb[$var_cb83972b];
	} 
	return $var_06740a60;
} 
function func_1626770a($var_10635ff1) {
	return func_72f9bc98($var_10635ff1);
} 
function parse_urlrules($var_ec057ba8) {
	if (!is_array($var_ec057ba8) || !$var_ec057ba8) return false;
	$var_f55bed2c = array();
	foreach($var_ec057ba8 as $var_228572b3 => $var_cb83972b) {
		list($var_6c1a8580) = explode('.', $var_cb83972b['tplfile']);
		$var_9955dceb = explode(',', $var_cb83972b['rules']);
		foreach($var_9955dceb as $var_3d9151c4 => $var_1076c777) {
			$var_afb1db68 = $var_1076c777;
			$var_d83c6930 = '';
			preg_match_all('~\\{([^\\}\\d]+)(\\d*)\\}~', $var_afb1db68, $var_973d74fe);
			foreach($var_973d74fe[0] as $var_3d9151c4 => $var_1076c777) {
				$var_907250fa = $var_973d74fe[2][$var_3d9151c4];
				$var_907250fa = max($var_907250fa, 1);
				$var_82286830 = $var_973d74fe[1][$var_3d9151c4];
				if ($var_82286830 == '日期') {
					$var_907250fa = 8;
				} else if ($var_82286830 == '年') {
					$var_907250fa = 4;
				} else if ($var_82286830 == '月' || $var_82286830 == '日' || $var_82286830 == '时' || $var_82286830 == '分' || $var_82286830 == '秒') {
					$var_907250fa = 2;
				} 
				if ($var_1076c777 == '{id}') {
					$var_afb1db68 = str_replace($var_1076c777, '([\\w]+)', $var_afb1db68);
					$var_d83c6930 = '&cid=:2';
				} else if ($var_1076c777 == '{aid}') {
					$var_afb1db68 = str_replace($var_1076c777, '([\\w]+)', $var_afb1db68);
					$var_6bcd8b53 = '&aid=:3';
				} else {
					$var_afb1db68 = str_replace($var_1076c777, '[\\w]{' . $var_907250fa . '}', $var_afb1db68);
				} 
			} 
			$var_afb1db68 = str_replace('.', '\\.', $var_afb1db68);
			$var_afb1db68 = str_replace('/', '\\/', $var_afb1db68);
			$var_afb1db68 = '/^(' . $var_afb1db68 . ')$/';
			$var_f55bed2c[$var_afb1db68] = 'home/' . config('DEFAULT_MODULE') . '/' . $var_6c1a8580 . '?id=:1' . $var_d83c6930 . $var_6bcd8b53;
		} 
	} 
	return $var_f55bed2c;
} 
function func_05d2f70f($var_39ae76d3 = '', $var_20a8dca2 = 1) {
	!$var_39ae76d3 && $var_39ae76d3 = $_SERVER['HTTP_HOST'];
	$var_654d357d = preg_replace('~^www\\.~', '', $var_39ae76d3);
	$var_654d357d = preg_replace('~^' . config('domain.mobile_prefix') . '\\.~', '', $var_654d357d);
	$var_f5abc85c = CACHE_PATH . 'urlrules/' . getHashDir($var_654d357d, 1) . '/' . $var_20a8dca2 . '_' . $var_654d357d . '.txt';
	return $var_f5abc85c;
} 
function func_06a8574b() {
	if (isset ($_SERVER['HTTP_X_WAP_PROFILE'])) return true;
	if (isset ($_SERVER['HTTP_CLIENT']) && 'PhoneClient' == $_SERVER['HTTP_CLIENT']) return true;
	if (isset ($_SERVER['HTTP_VIA'])) return stristr($_SERVER['HTTP_VIA'], 'wap') ? true : false;
	if (isset ($_SERVER['HTTP_USER_AGENT'])) {
		$var_a5cfc0b5 = array('nokia', 'sony', 'ericsson', 'mot', 'samsung', 'htc', 'sgh', 'lg', 'sharp', 'sie-', 'philips', 'panasonic', 'alcatel', 'lenovo', 'iphone', 'ipod', 'blackberry', 'meizu', 'android', 'netfront', 'symbian', 'ucweb', 'windowsce', 'palm', 'operamini', 'operamobi', 'openwave', 'nexusone', 'cldc', 'midp', 'wap', 'mobile');
		if (preg_match('/(' . implode('|', $var_a5cfc0b5) . ')/i', strtolower($_SERVER['HTTP_USER_AGENT']))) {
			return true;
		} 
	} 
	if (isset ($_SERVER['HTTP_ACCEPT'])) {
		if ((strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') !== false) && (strpos($_SERVER['HTTP_ACCEPT'], 'text/html') === false || (strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') < strpos($_SERVER['HTTP_ACCEPT'], 'text/html')))) {
			return true;
		} 
	} 
	return false;
} 
function func_2bd6b23a($var_5afc80a1) {
	$var_5afc80a1 = preg_replace('~<(?!img)(\\w+)\\s+[^>]*>~i', '<$1>', $var_5afc80a1);
	$var_5afc80a1 = preg_replace('/<(iframe.*?)>(.*?)<(\\/iframe.*?)>/si', "", $var_5afc80a1);
	$var_5afc80a1 = preg_replace('/<(object.*?)>(.*?)<(\\/object.*?)>/si', "", $var_5afc80a1);
	$var_5afc80a1 = preg_replace('/<(script.*?)>(.*?)<\\/script>/si', "", $var_5afc80a1);
	$var_5afc80a1 = preg_replace('~<(|/)form([^>]*)>~i', "", $var_5afc80a1);
	$var_5afc80a1 = preg_replace('~<input([^>]*)>~i', "", $var_5afc80a1);
	$var_5afc80a1 = preg_replace('/<(textarea.*?)>(.*?)<\\/textarea>/si', "", $var_5afc80a1);
	$var_5afc80a1 = preg_replace('/<(botton.*?)>(.*?)<\\/botton>/si', "", $var_5afc80a1);
	$var_5afc80a1 = preg_replace('/<(select.*?)>(.*?)<\\/select>/si', "", $var_5afc80a1);
	$var_5afc80a1 = preg_replace('~<(|/)div([^>]*)>~i', "", $var_5afc80a1);
	$var_5afc80a1 = preg_replace('~<(|/)span([^>]*)>~i', "", $var_5afc80a1);
	$var_5afc80a1 = preg_replace('~<(|/)font([^>]*)>~i', "", $var_5afc80a1);
	$var_5afc80a1 = preg_replace('~<(|/)a([^>]*)>~i', "", $var_5afc80a1);
	$var_5afc80a1 = preg_replace('~<style[^>]*>(.*?)</style>~iUs', "", $var_5afc80a1);
	$var_5afc80a1 = preg_replace('~<xml[^>]*>(.*?)</xml>~iUs', '', $var_5afc80a1);
	$var_5afc80a1 = preg_replace('~<(|/)b>~i', "", $var_5afc80a1);
	$var_5afc80a1 = preg_replace('~<!--(.*)-->~', '', $var_5afc80a1);
	$var_5afc80a1 = preg_replace('~<!--\\[if [^\\]]+\\]>(.*?)<!\\[endif\\]-->~iUs', '', $var_5afc80a1);
	$var_5afc80a1 = preg_replace('~<(\\w+)[^>]*>\\s*</\\1>~Us', '', $var_5afc80a1);
	$var_5afc80a1 = preg_replace('~[
]+~', '', $var_5afc80a1);
	$var_5afc80a1 = preg_replace('~>\\s*~', '>', $var_5afc80a1);
	$var_5afc80a1 = str_replace('</object>', '', $var_5afc80a1);
	return trim($var_5afc80a1);
} 
function func_0fbcf2a8($var_de5c1562, $var_7ea3e8ce = 0, $var_3464d12e = 0) {
	$html = '';
	$var_16cd4e42 = str_repeat('&nbsp;&nbsp;', $var_3464d12e) . $var_16cd4e42;
	foreach($var_de5c1562 as $var_228572b3 => $var_d8bba397) {
		if ($var_d8bba397['pid'] == $var_7ea3e8ce) {
			if ($var_3464d12e > 0) {
				$var_f4ffd3c8 = $var_7ea3e8ce;
				$var_16cd4e42 = '<span style="color:#CCC">' . str_repeat('&nbsp;&nbsp;&nbsp;&nbsp;', ($var_3464d12e - 1)) . '|— </span>';
				$var_5d439484 = '';
			} 
			if ($var_d8bba397['pid'] == 0) {
			} 
			$html .= "<tr onmouseover=this.bgColor='#EDF8FE'; onmouseout=this.bgColor='#ffffff'; bgcolor='#ffffff'><td align='center' height='25'>{$var_d8bba397['id']}</td>";
			$html .= "<td>&nbsp;&nbsp;{$var_16cd4e42}{$var_d8bba397['name']}</td>";
			$html .= '<td align=\'center\'>' . $var_d8bba397['dirname'] . '</td>';
			$html .= '<td align=\'center\'>' . ($var_d8bba397['sid'] ? $var_d8bba397['sid'] :'<font class="c9">无</font>') . '</td>';
			$html .= '<td align=\'center\'>' . ($var_d8bba397['pagetotal'] ? $var_d8bba397['pagetotal'] :'<font class="c9">无</font>') . '</td>';
			!$var_7fddbe16 && $var_7fddbe16 = '<font class="c9">不绑定</font>';
			$html .= '<td align=\'center\'>' . $var_7fddbe16 . '</td>';
			$html .= '<td align=\'center\'>' . ($var_d8bba397['collect_status'] ? '<a href="' . url('admin/arctype/collect_status?sid=0&id=' . $var_d8bba397['id']) . '"><font class="red">已开启</font></a>' :'<a href="' . url('admin/arctype/collect_status?sid=1&id=' . $var_d8bba397['id']) . '"><font class="c9">已关闭</font></a>') . '</td>';
			$html .= '<td align=\'center\'>' . ($var_d8bba397['isshow'] ? '<a href="' . url('admin/arctype/status?sid=0&id=' . $var_d8bba397['id']) . '">显示</a>' :'<a href="' . url('admin/arctype/status?sid=1&id=' . $var_d8bba397['id']) . '"><font class="red">已隐藏</font></a>') . '</td>';
			$html .= '<td align=\'center\'><a href=\'' . url('admin/arctype/edit?pid=' . $var_d8bba397['id']) . '\'>添加</a>&nbsp;&nbsp;<a href=\'javascript:\' onclick=\'add_moreclass(' . $var_d8bba397['id'] . ',"' . $var_d8bba397['nid'] . '");\'>批量添加</a></td>';
			$html .= '<td align=\'center\'><a href=\'' . url('home/article/lists?e=' . $var_d8bba397['ename']) . '\' target=\'_blank\'>预览</a>&nbsp;&nbsp;<a href=\'' . url('admin/arctype/edit?id=' . $var_d8bba397['id']) . '\'>更改</a>&nbsp;&nbsp;<a onclick=\'return confirm("确定删除此分类及其下文档?不可恢复!");\' href=\'' . url('admin/arctype/del?id=' . $var_d8bba397['id']) . '\'>删除</a></td>';
			$html .= "<td align='center'><input class='text' style='width:50px' type='text' name='order[{$var_d8bba397['id']}]' value='{$var_d8bba397['order']}'></td><td>&nbsp;</td></tr>";
			if (isset($var_d8bba397['son'])) {
				$html .= func_0fbcf2a8($var_d8bba397['son'], $var_d8bba397['id'], $var_3464d12e + 1);
			} 
		} 
	} 
	return $html;
} 
function func_f6dbad63($var_74ec8cd1, $var_10635ff1 = 'id', $var_7ea3e8ce = 'pid', $var_c1d3a0f2 = 'son', $var_62448e83 = 0) {
	$var_a1ebf574 = array();
	if (is_array($var_74ec8cd1)) {
		$var_335d704a = array();
		foreach ($var_74ec8cd1 as $var_6cbe6605 => $var_c73949df) {
			$var_335d704a[$var_c73949df[$var_10635ff1]] = &$var_74ec8cd1[$var_6cbe6605];
		} 
		foreach($var_74ec8cd1 as $var_6cbe6605 => $var_c73949df) {
			$var_641dc825 = $var_c73949df[$var_7ea3e8ce];
			if ($var_62448e83 == $var_641dc825) {
				$var_a1ebf574[] = &$var_74ec8cd1[$var_6cbe6605];
			} else {
				if (isset($var_335d704a[$var_641dc825])) {
					$var_758ae708 = &$var_335d704a[$var_641dc825];
					$var_758ae708[$var_c1d3a0f2][] = &$var_74ec8cd1[$var_6cbe6605];
				} 
			} 
		} 
	} 
	if (empty($var_a1ebf574)) $var_a1ebf574 = $var_74ec8cd1;
	return $var_a1ebf574;
} 
function func_bf43bb58($var_de5c1562, $var_7ea3e8ce = 0, $var_10635ff1 = 0, $var_3464d12e = 0, $var_09289acf = false) {
	$html = '';
	if ($var_7ea3e8ce > 0) {
		$var_16cd4e42 = '|─';
	} else {
		$var_16cd4e42 = '-';
	} 
	$var_16cd4e42 = str_repeat('&nbsp;&nbsp;', $var_3464d12e) . $var_16cd4e42;
	foreach($var_de5c1562 as $var_228572b3 => $var_d8bba397) {
		if ($var_d8bba397['pid'] == $var_7ea3e8ce) {
			$var_7e9e3f6f = '';
			if ($var_09289acf && !$var_d8bba397['nid']) {
				$var_7e9e3f6f = 'disabled="disabled" style="background:#eee"';
			} 
			if ($var_d8bba397['id'] == $var_10635ff1) {
				$html .= '<option value="' . $var_d8bba397['id'] . "\" selected=\"selected\" {$var_7e9e3f6f}>" . $var_16cd4e42 . $var_d8bba397['name'] . '</option>';
			} else {
				$html .= '<option value="' . $var_d8bba397['id'] . "\" {$var_7e9e3f6f}>" . $var_16cd4e42 . $var_d8bba397['name'] . '</option>';
			} 
			$html .= func_bf43bb58($var_de5c1562, $var_d8bba397['id'], $var_10635ff1, $var_3464d12e + 1, $var_09289acf);
		} 
	} 
	return $html;
} 
function func_b99757f3() {
	$var_f6a0d07b = ob_get_length();
	header('X-Accel-Buffering: no');
	header('Content-Length: ' . $var_f6a0d07b);
	header('Connection: close');
	ob_flush();
	flush();
} 
function func_1ca8c11f($var_f4ffd3c8) {
	$var_3464d12e = (ord($var_f4ffd3c8[0]) &31) << 12;
	$var_3464d12e += (ord($var_f4ffd3c8[1]) &63) << 6;
	$var_3464d12e += ord($var_f4ffd3c8[2]) &63;
	return $var_3464d12e;
} 
function sortByLen($var_55df87ba, $var_7c3e9a74) {
	if (strlen($var_55df87ba) == strlen($var_7c3e9a74)) {
		return 0;
	} else {
		return (strlen($var_55df87ba) < strlen($var_7c3e9a74)) ? 1 : - 1;
	} 
} 
function _unicode($var_40db88e3) {
	preg_match_all('/[\\x{4e00}-\\x{9fff}]+/u', $var_40db88e3, $var_973d74fe);
	if ($var_973d74fe) {
		$var_e224fc9d = array();
		usort($var_973d74fe[0], 'sortByLen');
		foreach($var_973d74fe[0] as $var_228572b3 => $var_cb83972b) {
			if (!isset($var_e224fc9d[$var_cb83972b])) {
				$var_e224fc9d[$var_cb83972b] = 1;
				$var_90fbba3a = _unicode2($var_cb83972b);
				$var_40db88e3 = str_replace($var_cb83972b, $var_90fbba3a, $var_40db88e3);
			} 
		} 
	} 
	return $var_40db88e3;
} 
function func_3ad4d85d($var_40db88e3, $var_0be95d47 = 'UTF-8', $var_4ff7f406 = '&#', $var_b983c56a = ';') {
	$var_40db88e3 = iconv($var_0be95d47, 'UCS-2', $var_40db88e3);
	$var_8647c89d = str_split($var_40db88e3, 2);
	$var_5dc7da13 = '';
	for($var_7ea74e20 = 0, $var_28de5dd7 = count($var_8647c89d); $var_7ea74e20 < $var_28de5dd7; $var_7ea74e20++) {
		$var_b7368ff3 = hexdec(bin2hex($var_8647c89d[$var_7ea74e20]));
		$var_5dc7da13 .= $var_4ff7f406 . $var_b7368ff3 . $var_b983c56a;
	} 
	return $var_5dc7da13;
} 
function _unicode2($var_40db88e3) {
	$var_ecf42c74 = '';
	for($var_7ea74e20 = 0;$var_7ea74e20 < strlen($var_40db88e3);$var_7ea74e20++) {
		if (ord(substr($var_40db88e3, $var_7ea74e20, 1)) > 160) {
			$var_ecf42c74 .= '&#' . func_1ca8c11f(substr($var_40db88e3, $var_7ea74e20, 3)) . ';';
			$var_7ea74e20 += 2;
		} else {
			$var_ecf42c74 .= '&#' . ord($var_40db88e3[$var_7ea74e20]) . ';';
		} 
	} 
	return $var_ecf42c74;
} 
function get_host($var_39ae76d3 = '') {
	!$var_39ae76d3 && $var_39ae76d3 = $_SERVER['HTTP_HOST'];
	if (preg_match('~zhizhuchi\\.xxfseo\\.com$~', $var_39ae76d3)) {
		return 'zhizhuchi.xxfseo.com';
	} 
	$var_b9b17a69 = parse_url($var_39ae76d3);
	$var_39ae76d3 = isset($var_b9b17a69['host']) ?$var_b9b17a69['host'] : $var_b9b17a69['path'];
	$var_39ae76d3 = strtolower($var_39ae76d3);
	if (strpos($var_39ae76d3, '/') !== false) {
		$var_b9b17a69 = @parse_url($var_39ae76d3);
		$var_39ae76d3 = $var_b9b17a69['host'];
	} 
	$var_2001680e = array('com', 'net', 'wang', 'vip', 'tech', 'online', 'shop', 'win', 'store', 'red', 'bid', 'gs', 'cx', 'xin', 'vc', 'tm', 'ltd', 'date', 'website', 'loan', 'space', 'ink', 'kim', 'group', 'auto', 'link', 'tw', 'com.tw', 'sc', 'lc', 'us', 'bz', 'com.cn', 'asia', 'men', 'gov.cn', 'org.cn', 'top', 'tv', 'cc', 'ren', 'info', 'biz', 'mobi', 'name', 'hk', 'com.hk', 'site  ', 'net.cn', 'me', 'co', 'com.co', 'gg', 'love', 'ws', 'pw', 'in', 'xyz', 'org', 'club', 'pro', 'la', 'lol', 'cm', 'top', 'club', 'site', 'online', 'wang', 'ltd', 'lol', 'vip', 'shop', 'store', 'win', 'ren', 'date', 'red', 'kim', 'website', 'bid', 'live', 'sale', 'run', 'gold', 'help', 'gift', 'faith', 'loan', 'trade', 'zone', 'ink', 'game', 'party', 'pub', 'news', 'men', 'vin', 'fund', 'wiki', 'pink', 'mom', 'blue', 'pet', 'link', 'space', 'fit', 'cool', 'life', 'city', 'webcam', 'science', 'accountant', 'review', 'download', 'cricket', 'racing', 'taipei', 'yoga', 'games', 'cn.com', 'wtf', 'world', 'works', 'wine', 'watch', 'video', 'town', 'tools', 'today', 'tips', 'team', 'tax', 'style', 'studio', 'sexy', 'sex', 'school', 'press', 'plus', 'pics', 'photo', 'ooo', 'band', 'fyi', 'money', 'lawyer', 'land', 'media', 'mba', 'flowers', 'love', 'haus', 'guru', 'fish', 'house', 'hosting', 'host', 'holiday', 'fans', 'family', 'email', 'domains', 'dog', 'diet', 'design', 'company', 'click', 'chat', 'ceo', 'center', 'cash', 'cars', 'cards', 'car', 'camera', 'cafe', 'cab', 'black', 'bike', 'best', 'bar', 'auto', 'audio', 'credit', 'coffee', 'business', 'network', 'auction', 'show', 'rip', 'vet', 'rent', 'work', 'marketmarket', 'ac.cn', 'bj.cn', 'sh.cn', 'tj.cn', 'cq.cn', 'he.cn', 'sn.cn', 'sx.cn', 'nm.cn', 'ln.cn', 'jl.cn', 'hl.cn', 'js.cn', 'zj.cn', 'ah.cn', 'fj.cn', 'jx.cn', 'sd.cn', 'ha.cn', 'hb.cn', 'hn.cn', 'gd.cn', 'gx.cn', 'hi.cn', 'sc.cn', 'gz.cn', 'yn.cn', 'gs.cn', 'qh.cn', 'nx.cn', 'xj.cn', 'tw.cn', 'hk.cn', 'mo.cn', 'xz.cn', 'cn');
	$var_04b81daf = '';
	foreach($var_2001680e as $var_cb83972b) {
		$var_04b81daf .= ($var_04b81daf ?'|': '') . $var_cb83972b;
	} 
	$var_04b81daf = '[^\\.]+\\.(?:(' . $var_04b81daf . ')|\\w{2}|((' . $var_04b81daf . ')\\.\\w{2}))$';
	if (preg_match('/' . $var_04b81daf . '/is', $var_39ae76d3, $var_973d74fe)) {
		$var_280f1567 = $var_973d74fe['0'];
	} else {
		$var_280f1567 = $var_39ae76d3;
	} 
	return $var_280f1567;
} 
function func_f8bdc145($var_a941a3a5) {
	$var_78009205 = ord(strtoupper($var_a941a3a5 {
				0} 
			));
	if (($var_78009205 >= 65 and $var_78009205 <= 91)or($var_78009205 >= 48 and $var_78009205 <= 57)) return strtoupper($var_a941a3a5 {
			0} 
		);
	$var_4cce7e5a = func_62ff8293($var_a941a3a5);
	$var_d05c35a1 = ord($var_4cce7e5a {
			0} 
		) * 256 + ord($var_4cce7e5a {
			1} 
		) - 65536;
	if ($var_d05c35a1 >= - 20319 and $var_d05c35a1 <= - 20284)return 'A';
	if ($var_d05c35a1 >= - 20283 and $var_d05c35a1 <= - 19776)return 'B';
	if ($var_d05c35a1 >= - 19775 and $var_d05c35a1 <= - 19219)return 'C';
	if ($var_d05c35a1 >= - 19218 and $var_d05c35a1 <= - 18711)return 'D';
	if ($var_d05c35a1 >= - 18710 and $var_d05c35a1 <= - 18527)return 'E';
	if ($var_d05c35a1 >= - 18526 and $var_d05c35a1 <= - 18240)return 'F';
	if ($var_d05c35a1 >= - 18239 and $var_d05c35a1 <= - 17923)return 'G';
	if ($var_d05c35a1 >= - 17922 and $var_d05c35a1 <= - 17418)return 'H';
	if ($var_d05c35a1 >= - 17417 and $var_d05c35a1 <= - 16475)return 'J';
	if ($var_d05c35a1 >= - 16474 and $var_d05c35a1 <= - 16213)return 'K';
	if ($var_d05c35a1 >= - 16212 and $var_d05c35a1 <= - 15641)return 'L';
	if ($var_d05c35a1 >= - 15640 and $var_d05c35a1 <= - 15166)return 'M';
	if ($var_d05c35a1 >= - 15165 and $var_d05c35a1 <= - 14923)return 'N';
	if ($var_d05c35a1 >= - 14922 and $var_d05c35a1 <= - 14915)return 'O';
	if ($var_d05c35a1 >= - 14914 and $var_d05c35a1 <= - 14631)return 'P';
	if ($var_d05c35a1 >= - 14630 and $var_d05c35a1 <= - 14150)return 'Q';
	if ($var_d05c35a1 >= - 14149 and $var_d05c35a1 <= - 14091)return 'R';
	if ($var_d05c35a1 >= - 14090 and $var_d05c35a1 <= - 13319)return 'S';
	if ($var_d05c35a1 >= - 13318 and $var_d05c35a1 <= - 12839)return 'T';
	if ($var_d05c35a1 >= - 12838 and $var_d05c35a1 <= - 12557)return 'W';
	if ($var_d05c35a1 >= - 12556 and $var_d05c35a1 <= - 11848)return 'X';
	if ($var_d05c35a1 >= - 11847 and $var_d05c35a1 <= - 11056)return 'Y';
	if ($var_d05c35a1 >= - 11055 and $var_d05c35a1 <= - 10247)return 'Z';
	return 0;
} 
function func_99dbe70c() {
	$var_7ea74e20 = 0;
	while (true) {
		if (!isset($var_2e4c7adf)) {
			$var_2e4c7adf = strtolower(base64_encode(md5($_SERVER['HTTP_HOST'])));
		} 
		$var_2e4c7adf = strtolower(base64_encode($var_2e4c7adf));
		$var_2e4c7adf = preg_replace('~[^a-z]+~', '', $var_2e4c7adf);
		$var_586a20ab = str_split($var_2e4c7adf);
		if (!isset($var_e8e5b9f0)) {
			$var_e8e5b9f0 = $var_586a20ab;
		} else {
			$var_e8e5b9f0 = array_merge($var_e8e5b9f0, $var_586a20ab);
		} 
		$var_e8e5b9f0 = array_flip(array_flip($var_e8e5b9f0));
		if (count($var_e8e5b9f0) >= 26) {
			return $var_e8e5b9f0;
		} 
		if ($var_7ea74e20 > 100) {
			return $var_e8e5b9f0;
		} 
		$var_7ea74e20++;
	} 
} 
function func_dd20c689($var_40db88e3) {
	$var_beba630c = array('，', '。', '；', '
', ',', ';', '……', '？', '\\?', '!', '！');
	$var_f2745cf3 = '~(' . implode($var_beba630c, '|') . ')~';
	$var_40db88e3 = preg_replace($var_f2745cf3, '|||||', $var_40db88e3);
	$var_586a20ab = explode('|||||', $var_40db88e3);
	foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
		preg_match('/[\\x{4e00}-\\x{9fff}]+/u', $var_cb83972b, $matches);
		$var_aba77a30 = strtolower(func_f8bdc145($matches[0]));
		$var_586a20ab[$var_aba77a30] = func_93b08060(preg_replace('~\\s+~', '', rtrim($var_cb83972b, '。')), 'utf-8', 2);
	} 
	$var_e8e5b9f0 = func_99dbe70c();
	$var_40db88e3 = '';
	foreach($var_e8e5b9f0 as $var_228572b3 => $var_cb83972b) {
		if (isset($var_586a20ab[$var_cb83972b])) {
			$var_40db88e3 .= $var_586a20ab[$var_cb83972b] . '，';
		} 
	} 
	$var_40db88e3 = str_replace('|||||', '。', $var_40db88e3);
	$var_40db88e3 = preg_replace('~(，|,)$~', '。', $var_40db88e3);
	return $var_40db88e3;
} 
function func_93b08060($var_40db88e3, $var_caf118e7 = 'utf-8', $var_75d0d565 = '') {
	$var_5fd387f1 = iconv_strlen($var_40db88e3, $var_caf118e7);
	!$var_75d0d565 && $var_75d0d565 = config('reform_title_base');
	$var_f1d13c7b = ceil($var_5fd387f1 / $var_75d0d565);
	$var_586a20ab = array();
	for($var_7ea74e20 = 0;$var_7ea74e20 < $var_f1d13c7b;$var_7ea74e20++) {
		$var_6ffd85cc = iconv_substr($var_40db88e3, $var_75d0d565 * $var_7ea74e20, $var_75d0d565, $var_caf118e7);
		preg_match_all('/[\\x{4e00}-\\x{9fff}]+/u', $var_6ffd85cc, $matches);
		$var_c3c64f2b = implode('', $matches[0]);
		$var_aba77a30 = strtolower(func_f8bdc145($var_c3c64f2b));
		if (isset($var_586a20ab[$var_aba77a30])) {
			$var_586a20ab[$var_aba77a30] .= $var_6ffd85cc;
		} else {
			$var_586a20ab[$var_aba77a30] = $var_6ffd85cc;
		} 
	} 
	$var_e8e5b9f0 = func_99dbe70c();
	$var_40db88e3 = '';
	foreach($var_e8e5b9f0 as $var_228572b3 => $var_cb83972b) {
		if (isset($var_586a20ab[$var_cb83972b])) {
			$var_40db88e3 .= $var_586a20ab[$var_cb83972b];
		} 
	} 
	return $var_40db88e3;
} 
function func_90b6f187($var_df56ffa6, $var_8eafab80) {
	if (config('insert_title2content') == '0') {
	} 
	if ($var_8eafab80 == '') {
		return $var_df56ffa6;
	} 
	if (!preg_match('~(，|！|、)~', $var_8eafab80)) {
		return $var_df56ffa6 . $var_8eafab80;
	} 
	$var_907250fa = ceil(strlen($var_8eafab80) / 200);
	$var_907250fa = min($var_907250fa, 2);
	return preg_replace('~(，|！|、|：)~', '\\1' . $var_df56ffa6, $var_8eafab80, $var_907250fa);
} 
function func_96d84c92($html) {
	static $var_586a20ab;
	if ($var_586a20ab === false) {
		return $html;
	} 
	if (!$var_586a20ab) {
		$var_980a7c7e = DATA_PATH . 'replaceword.txt';
		if (is_file($var_980a7c7e)) {
			$var_586a20ab = file($var_980a7c7e);
		} 
		if (!$var_586a20ab) {
			$var_586a20ab = false;
			return $html;
		} 
	} 
	foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
		if (trim($var_cb83972b) == '') break;
		list($var_9b3fa87b, $var_c5256d61) = explode(',', $var_cb83972b);
		$var_9b3fa87b = trim($var_9b3fa87b);
		$var_c5256d61 = trim($var_c5256d61);
		if (function_exists('mb_string')) {
			$html = mb_ereg_replace($var_9b3fa87b, $var_c5256d61, $html);
		} else {
			$html = str_replace($var_9b3fa87b, $var_c5256d61, $html);
		} 
	} 
	return $html;
} 
function func_fb6e429b($var_bbf470ef) {
	$var_023d5eaf = 'arctype' . $var_bbf470ef;
	$var_980a7c7e = DB_PATH . 'arctype/' . $var_023d5eaf . '.MYD';
	if (!is_file($var_980a7c7e)) write($var_980a7c7e, 'a:0:{}');
	return $var_023d5eaf;
} 
function now_date_color($var_1bf5ad22, $var_183858a7 = 'Y-m-d H:i:s', $var_2f8c1a10 = 1) {
	if ($var_1bf5ad22 > func_e199ee97(1)) {
		return '<font color="red">' . date($var_183858a7, $var_1bf5ad22) . '</font>';
	} 
	return date($var_183858a7, $var_1bf5ad22);
} 
function func_e199ee97($var_2f42d152) {
	$var_2f42d152 = intval($var_2f42d152);
	return mktime(23, 59, 59, date('m'), date('d') - $var_2f42d152, date('y'));
} 
function func_809cbb58($var_586a20ab, $var_27e8d10f) {
	if (empty($var_586a20ab)) return;
	$var_09af61e8 = array();
	foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
		$var_3e111377 = $var_cb83972b[$var_27e8d10f];
		$var_09af61e8[$var_3e111377] = $var_cb83972b;
	} 
	return $var_09af61e8;
} 
function _base64_encode($var_de5c1562) {
	return str_rot13(rtrim(strtr(base64_encode($var_de5c1562), '+/', '.,'), '='));
} 
function _base64_decode($var_de5c1562) {
	return base64_decode(str_pad(strtr(str_rot13($var_de5c1562), '.,', '+/'), strlen($var_de5c1562) % 4, '=', STR_PAD_RIGHT));
} 
function func_a75a4e09($var_bca829df, $var_1d1fabd0 = 'ENCODE', $var_2e4c7adf = '') {
	$var_dbea3baf = '';
	$var_1d1fabd0 != 'ENCODE' && $var_bca829df = _base64_decode($var_bca829df);
	! $var_2e4c7adf && $var_2e4c7adf = config('web_url_idencode_key');
	$var_fa93938e = strlen($var_2e4c7adf);
	$var_89e50b15 = strlen($var_bca829df);
	for ($var_7ea74e20 = 0; $var_7ea74e20 < strlen($var_bca829df); $var_7ea74e20 ++) {
		$var_228572b3 = $var_7ea74e20 % $var_fa93938e;
		$var_dbea3baf .= $var_bca829df[$var_7ea74e20] ^ $var_2e4c7adf[$var_228572b3];
	} 
	return ($var_1d1fabd0 != 'DECODE' ? _base64_encode($var_dbea3baf) : $var_dbea3baf);
} 
function func_3049735f($var_40db88e3) {
	$var_d276f10b = '/[ \\x{00a0}\\x{1680}\\x{2000}-\\x{200a}\\x{2028}\\x{2029}\\x{202f}\\x{205f}\\x{3000}\\x{feff}\\x{2060}]/u';
	return preg_replace($var_d276f10b, '', $var_40db88e3);
} 
function func_9242882b($var_c0bec968, $var_a81c87f7, $var_db226936 = 5, $var_1003d5bb, $var_f5cf22cc) {
	$var_0af8bcb2 = '';
	$var_0af8bcb2 .= ($var_c0bec968 > 1) ? '<a href="' . str_replace('!page!', 1, $var_1003d5bb) . '">首页</a><a href="' . str_replace('!page!', ($var_c0bec968 - 1), $var_1003d5bb) . '" class="pre">上一页</a>' : '';
	for($var_7ea74e20 = $var_c0bec968 - $var_db226936, $var_7ea74e20 > 1 || $var_7ea74e20 = 1, $var_0ad02491 = $var_c0bec968 + $var_db226936, $var_0ad02491 < $var_a81c87f7 || $var_0ad02491 = $var_a81c87f7;$var_7ea74e20 < $var_0ad02491 + 1;$var_7ea74e20++) {
		$var_0af8bcb2 .= ($var_7ea74e20 == $var_c0bec968)?'<a class="current">' . $var_7ea74e20 . '</a>':'<a href="' . str_replace('!page!', $var_7ea74e20, $var_1003d5bb) . '">' . $var_7ea74e20 . '</a>';
	} 
	$var_0af8bcb2 .= ($var_c0bec968 < $var_a81c87f7 && $var_a81c87f7 > $var_db226936)? '<i>...</i><a href="' . str_replace('!page!', $var_a81c87f7, $var_1003d5bb) . '">' . $var_a81c87f7 . '</a><a href="' . str_replace('!page!', ($var_c0bec968 + 1), $var_1003d5bb) . '" class="next">下一页</a>' : '';
	if (!empty($var_f5cf22cc)) {
		$var_0af8bcb2 .= '&nbsp;<input type="input" name="page"/><input type="button" value="跳 转" onclick="' . $var_f5cf22cc . '"/>';
	} 
	return str_replace('-1' . RE_SUFFIX, RE_SUFFIX, str_replace('index1' . RE_SUFFIX, '', $var_0af8bcb2));
} 
function func_1ab1f42a($var_586a20ab) {
	if (is_array($var_586a20ab)) {
		foreach($var_586a20ab as $var_228572b3 => $var_d8bba397) {
			$var_586a20ab[$var_228572b3] = func_1ab1f42a($var_d8bba397);
		} 
	} else {
		$var_586a20ab = urlencode($var_586a20ab);
	} 
	return $var_586a20ab;
} 
function func_3c22ed21($var_980a7c7e, $var_586a20ab, $var_7c6c92b4 = 2) {
	if (!is_array($var_586a20ab)) return false;
	if ($var_7c6c92b4 == 2) {
		$var_4a82ca50 = var_export($var_586a20ab, true);
		$var_4a82ca50 = '<?php
' . 'return ' . $var_4a82ca50 . ';' . '
?>';
	} else {
		foreach($var_586a20ab as $var_228572b3 => $var_d8bba397) {
			$var_d8bba397 = str_replace('\'', '\\\'', $var_d8bba397);
			$var_586a20ab[$var_228572b3] = '\'' . $var_d8bba397 . '\',';
		} 
		$var_4a82ca50 = implode('
', $var_586a20ab);
		$var_4a82ca50 = '<?php
return array(
' . $var_4a82ca50 . '
);
?>';
	} 
	return write($var_980a7c7e, $var_4a82ca50);
} 
function func_ec6fc6db($var_f6a0d07b, $var_b8024f27 = 'MB') {
	if ($var_f6a0d07b == 0) return 0;
	$var_b8024f27 = strtolower($var_b8024f27);
	if ($var_b8024f27 == 'gb') $var_3464d12e = 1024 * 1024 * 1024;
	if ($var_b8024f27 == 'mb') $var_3464d12e = 1024 * 1024;
	if ($var_b8024f27 == 'kb') $var_3464d12e = 1024;
	$var_4cce7e5a = round(($var_f6a0d07b / $var_3464d12e), 2);
	if ($var_4cce7e5a == 0) $var_4cce7e5a = round(($var_f6a0d07b / $var_3464d12e), 4);
	return $var_4cce7e5a;
} 
function func_eeb67ad2($var_4eda73b5, &$var_ca17b66a = '0') {
	$var_ff44612c = func_9193adfb($var_4eda73b5);
	foreach($var_ff44612c as $var_980a7c7e) {
		if ($var_980a7c7e != '.' && $var_980a7c7e != '..') {
			$var_2828f3c2 = $var_4eda73b5 . '/' . $var_980a7c7e;
			if (is_dir($var_2828f3c2)) {
				$var_ca17b66a += func_eeb67ad2($var_2828f3c2);
			} else {
				$var_ca17b66a += filesize($var_2828f3c2);
			} 
		} 
	} 
	return $var_ca17b66a;
} 
function func_97869657($var_4eda73b5, $var_cebcf803 = 0766) {
	if (is_dir($var_4eda73b5)) return true;
	mkdir($var_4eda73b5, $var_cebcf803, true);
} 
function func_9193adfb($var_fae1bb2a) {
	$var_586a20ab = array();
	if (!is_dir($var_fae1bb2a)) {
		return false;
	} 
	if (!function_exists('scandir')) {
		$var_08658966 = @opendir($var_fae1bb2a);
		while (($var_586a20ab[] = @readdir($var_08658966)) !== false) {
		} 
		@closedir($var_08658966);
		$var_586a20ab = array_filter($var_586a20ab);
	} else {
		$var_586a20ab = @scandir($var_fae1bb2a);
	} 
	return $var_586a20ab;
} 
function func_891a6fb0($var_fae1bb2a) {
	if (!is_dir($var_fae1bb2a)) return false;
	$var_ff44612c = func_9193adfb($var_fae1bb2a);
	foreach($var_ff44612c as $var_980a7c7e) {
		if ($var_980a7c7e <> '.' && $var_980a7c7e <> '..') {
			if (is_dir("$var_fae1bb2a/$var_980a7c7e")) {
				func_891a6fb0("$var_fae1bb2a/$var_980a7c7e");
			} else if (is_file("$var_fae1bb2a/$var_980a7c7e")) {
				unlink("$var_fae1bb2a/$var_980a7c7e");
			} 
		} 
	} 
	return rmdir($var_fae1bb2a);
} 
function write($var_980a7c7e, $var_de5c1562, $var_6c1a8580 = "w") {
	$var_fae1bb2a = dirname($var_980a7c7e);
	if (!is_dir($var_fae1bb2a)) {
		mkdir($var_fae1bb2a, 511, true);
	} 
	if (is_file($var_980a7c7e) && !is_writable($var_980a7c7e)) {
		return false;
	} 
	$var_35b7c6eb = false;
	if ($var_04416560 = fopen($var_980a7c7e, $var_6c1a8580)) {
		$var_d33931b9 = microtime(true) * 1000;
		do {
			$var_c7179559 = flock($var_04416560, 2 | 4);
			if (!$var_c7179559) {
				usleep(round(rand(0, 100) * 1000));
			} 
		} while ((!$var_c7179559) && ((microtime(true) * 1000 - $var_d33931b9) < 1000));
		if ($var_c7179559) {
			$var_35b7c6eb = fwrite($var_04416560, $var_de5c1562);
			flock($var_04416560, 3);
		} 
		fclose($var_04416560);
	} 
	return $var_35b7c6eb;
} 
function func_14a7221d($var_980a7c7e) {
	if (!is_file($var_980a7c7e)) return false;
	if (!is_readable($var_980a7c7e)) {
		return false;
	} 
	$var_4a82ca50 = false;
	if ($var_04416560 = fopen($var_980a7c7e, 'r')) {
		$var_d33931b9 = microtime();
		do {
			$var_f9d192c6 = flock($var_04416560, 1);
			if (!$var_f9d192c6) {
				usleep(round(rand(0, 100) * 1000));
			} 
		} while ((!$var_f9d192c6) && ((microtime() - $var_d33931b9) < 1000));
		if ($var_f9d192c6) {
			clearstatcache();
			$var_4a82ca50 = fread($var_04416560, filesize($var_980a7c7e));
		} 
		fclose($var_04416560);
	} 
	return $var_4a82ca50;
} 
function func_e838d727($var_183858a7) {
	if (get_magic_quotes_gpc()) {
		$var_183858a7 = stripslashes($var_183858a7);
	} 
	return $var_183858a7;
} 
function func_e89f021a($var_31e8bd86) {
	$var_71c57e51 = '_test.txt';
	$var_31e8bd86 = preg_replace('#\\/$#', '', $var_31e8bd86);
	$var_04416560 = @fopen($var_31e8bd86 . '/' . $var_71c57e51, 'w');
	if (!$var_04416560) {
		return false;
	} else {
		fclose($var_04416560);
		$var_1b080936 = @unlink($var_31e8bd86 . '/' . $var_71c57e51);
		if ($var_1b080936) return true;
		else return false;
	} 
} 
function func_c9192eb2() {
	list($var_95a8d153, $var_5a53f1c2) = explode(' ', microtime());
	return $var_5a53f1c2 + $var_95a8d153;
} 
function func_6b0cca64($var_40db88e3) {
	$var_40db88e3 = preg_replace('#>(\\s*)(\\S*)(\\s*)<#', '>$2<', $var_40db88e3);
	$var_40db88e3 = preg_replace('#<!--([^>]*)-->#', '', $var_40db88e3);
	return $var_40db88e3;
} 
function msubstr($var_40db88e3, $var_64f25176 = 0, $var_dbe5a81c, $var_caf118e7 = "utf-8", $var_42ffe09e = false) {
	if (function_exists('mb_substr')) {
		$var_25d97e0b = mb_substr($var_40db88e3, $var_64f25176, $var_dbe5a81c, $var_caf118e7);
		$var_8552d9b3 = mb_strlen($var_40db88e3) > $var_dbe5a81c ? '...' : '';
	} elseif (function_exists('iconv_substr')) {
		$var_25d97e0b = iconv_substr($var_40db88e3, $var_64f25176, $var_dbe5a81c, $var_caf118e7);
		$var_8552d9b3 = iconv_strlen($var_40db88e3, $var_caf118e7) > $var_dbe5a81c ? '...' : '';
	} else {
		$var_55a6eca3['utf-8'] = '/[-]|[�-�][�-�]|[�-�][�-�]{2}|[�-�][�-�]{3}/';
		$var_55a6eca3['gb2312'] = '/[-]|[�-�][�-�]/';
		$var_55a6eca3['gbk'] = '/[-]|[�-�][@-�]/';
		$var_55a6eca3['big5'] = '/[-]|[�-�]([@-~]|�-�])/';
		preg_match_all($var_55a6eca3[$var_caf118e7], $var_40db88e3, $var_973d74fe);
		$var_25d97e0b = join("", array_slice($var_973d74fe[0], $var_64f25176, $var_dbe5a81c));
		$var_8552d9b3 = strlen($var_40db88e3) > $var_dbe5a81c ? '...' : '';
	} 
	return $var_42ffe09e ? $var_25d97e0b . $var_8552d9b3 : $var_25d97e0b;
} 
function func_4f521b6d($var_40db88e3, $var_b0644602 = 'gbk') {
	if ($var_40db88e3 == '') return $var_40db88e3;
	if (func_558b2255($var_40db88e3) === false) {
		if (function_exists('mb_convert_encoding')) {
			$var_40db88e3 = @mb_convert_encoding($var_40db88e3, 'UTF-8', $var_b0644602);
		} elseif (function_exists('iconv')) {
			$var_40db88e3 = iconv($var_b0644602, 'UTF-8//IGNORE', $var_40db88e3);
		} 
	} 
	return $var_40db88e3;
} 
function func_1b12c6ac($var_40db88e3) {
	$var_28de5dd7 = strlen($var_40db88e3);
	for($var_7ea74e20 = 0; $var_7ea74e20 < $var_28de5dd7; $var_7ea74e20++) {
		$var_f4ffd3c8 = ord($var_40db88e3[$var_7ea74e20]);
		if ($var_f4ffd3c8 > 128) {
			if (($var_f4ffd3c8 > 247)) return false;
			elseif ($var_f4ffd3c8 > 239) $var_8640381b = 4;
			elseif ($var_f4ffd3c8 > 223) $var_8640381b = 3;
			elseif ($var_f4ffd3c8 > 191) $var_8640381b = 2;
			else return false;
			if (($var_7ea74e20 + $var_8640381b) > $var_28de5dd7) return false;
			while ($var_8640381b > 1) {
				$var_7ea74e20++;
				$var_7c3e9a74 = ord($var_40db88e3[$var_7ea74e20]);
				if ($var_7c3e9a74 < 128 || $var_7c3e9a74 > 191) return false;
				$var_8640381b--;
			} 
		} 
	} 
	return true;
} 
function func_558b2255($var_8b5a55fd) {
	if (trim($var_8b5a55fd) == '') return false;
	if (@preg_match('/^([' . chr(228) . '-' . chr(233) . ']{1}[' . chr(128) . '-' . chr(191) . ']{1}[' . chr(128) . '-' . chr(191) . ']{1}){1}/', $var_8b5a55fd) == true || @preg_match('/([' . chr(228) . '-' . chr(233) . ']{1}[' . chr(128) . '-' . chr(191) . ']{1}[' . chr(128) . '-' . chr(191) . ']{1}){1}$/', $var_8b5a55fd) == true || @preg_match('/([' . chr(228) . '-' . chr(233) . ']{1}[' . chr(128) . '-' . chr(191) . ']{1}[' . chr(128) . '-' . chr(191) . ']{1}){2,}/', $var_8b5a55fd) == true) {
		if (func_1b12c6ac($var_8b5a55fd)) {
			return true;
		} 
	} 
	return false;
} 
function func_62ff8293($var_40db88e3) {
	if ($var_40db88e3 == '') return $var_40db88e3;
	if (func_558b2255($var_40db88e3)) {
		if (function_exists('mb_convert_encoding')) {
			$var_40db88e3 = @mb_convert_encoding($var_40db88e3, 'GBK', 'UTF-8');
		} elseif (function_exists('iconv')) {
			$var_40db88e3 = iconv('UTF-8', 'gbk//IGNORE', $var_40db88e3);
		} 
	} 
	return $var_40db88e3;
} 
function func_c67473da($var_6cbe6605, $var_40db88e3, $var_ea3861d2 = ',') {
	$var_586a20ab = explode($var_ea3861d2, $var_40db88e3);
	foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
		if ($var_6cbe6605 == $var_cb83972b) return true;
	} 
	return false;
} 
function func_166fd968($var_fbd21267, $var_096ac6c0 = false) {
	$var_c80e45b7 = array('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '2', '3', '4', '5', '6', '7', '=');
	if (empty($var_fbd21267)) return "";
	$var_fbd21267 = str_split($var_fbd21267);
	$var_4dcc869e = "";
	for($var_7ea74e20 = 0; $var_7ea74e20 < count($var_fbd21267); $var_7ea74e20++) {
		$var_4dcc869e .= str_pad(base_convert(ord($var_fbd21267[$var_7ea74e20]), 10, 2), 8, '0', STR_PAD_LEFT);
	} 
	$var_92f35f7c = str_split($var_4dcc869e, 5);
	$var_5188e725 = "";
	$var_7ea74e20 = 0;
	while ($var_7ea74e20 < count($var_92f35f7c)) {
		$var_5188e725 .= $var_c80e45b7[base_convert(str_pad($var_92f35f7c[$var_7ea74e20], 5, '0'), 2, 10)];
		$var_7ea74e20++;
	} 
	if ($var_096ac6c0 && ($var_695c0912 = strlen($var_4dcc869e) % 40) != 0) {
		if ($var_695c0912 == 8) $var_5188e725 .= str_repeat($var_c80e45b7[32], 6);
		else if ($var_695c0912 == 16) $var_5188e725 .= str_repeat($var_c80e45b7[32], 4);
		else if ($var_695c0912 == 24) $var_5188e725 .= str_repeat($var_c80e45b7[32], 3);
		else if ($var_695c0912 == 32) $var_5188e725 .= $var_c80e45b7[32];
	} 
	return trim($var_5188e725);
} 
function func_a61eea4b($var_fbd21267) {
	$var_c80e45b7 = array('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '2', '3', '4', '5', '6', '7', '=');
	$var_5ed2e83a = array('a' => '0', 'b' => '1', 'c' => '2', 'd' => '3', 'e' => '4', 'f' => '5', 'g' => '6', 'h' => '7', 'i' => '8', 'j' => '9', 'k' => '10', 'l' => '11', 'm' => '12', 'n' => '13', 'o' => '14', 'p' => '15', 'q' => '16', 'r' => '17', 's' => '18', 't' => '19', 'u' => '20', 'v' => '21', 'w' => '22', 'x' => '23', 'y' => '24', 'z' => '25', '2' => '26', '3' => '27', '4' => '28', '5' => '29', '6' => '30', '7' => '31');
	if (empty($var_fbd21267)) return;
	$var_0df41822 = substr_count($var_fbd21267, $var_c80e45b7[32]);
	$var_50b5b472 = array(6, 4, 3, 1, 0);
	if (!in_array($var_0df41822, $var_50b5b472)) return false;
	for($var_7ea74e20 = 0; $var_7ea74e20 < 4; $var_7ea74e20++) {
		if ($var_0df41822 == $var_50b5b472[$var_7ea74e20] && substr($var_fbd21267, - ($var_50b5b472[$var_7ea74e20])) != str_repeat($var_c80e45b7[32], $var_50b5b472[$var_7ea74e20])) return false;
	} 
	$var_fbd21267 = str_replace('=', '', $var_fbd21267);
	$var_fbd21267 = str_split($var_fbd21267);
	$var_4dcc869e = "";
	for($var_7ea74e20 = 0; $var_7ea74e20 < count($var_fbd21267); $var_7ea74e20 = $var_7ea74e20 + 8) {
		$var_695c0912 = "";
		if (!in_array($var_fbd21267[$var_7ea74e20], $var_c80e45b7)) return false;
		for($var_0ad02491 = 0; $var_0ad02491 < 8; $var_0ad02491++) {
			$var_695c0912 .= str_pad(base_convert(@$var_5ed2e83a[@$var_fbd21267[$var_7ea74e20 + $var_0ad02491]], 10, 2), 5, '0', STR_PAD_LEFT);
		} 
		$var_4ccca36b = str_split($var_695c0912, 8);
		for($var_2bedf53c = 0; $var_2bedf53c < count($var_4ccca36b); $var_2bedf53c++) {
			$var_4dcc869e .= (($var_84d643d3 = chr(base_convert($var_4ccca36b[$var_2bedf53c], 2, 10))) || ord($var_84d643d3) == 48) ? $var_84d643d3:"";
		} 
	} 
	return trim($var_4dcc869e);
} 
function func_f1928f44() {
	return php_uname('a') . 'xxf_zhizhuchi' . $_SERVER["SERVER_ADMIN"];
} 
function func_777f7351($var_dbea3baf) {
	list($var_91bca4a3, $var_d66a8da9, $var_13eec6e6) = explode('|', $var_dbea3baf);
	list($var_2bb3ff2c, $var_3dc6d725, $var_b895c079) = explode('|', func_61d5ad01($var_d66a8da9));
	if ($var_91bca4a3 != $var_3dc6d725 || $var_b895c079 < time()) {
		$_SESSION['admin']['licence_expdate'] = date('Y-m-d H:i:s', $var_b895c079);
		return false;
	} 
	$var_7851042f = func_61d5ad01($var_13eec6e6);
	list($var_054c06f2, $var_d44f0c9e) = explode('|', $var_7851042f);
	if ($var_d66a8da9 !== $var_054c06f2) {
		return false;
	} 
	$var_d44f0c9e = func_61d5ad01($var_d44f0c9e);
	list($var_2e9c363d, $var_2068d116) = explode('|', $var_d44f0c9e);
	if ($var_2e9c363d !== $var_91bca4a3) {
		return false;
	} 
	if ($var_2068d116 !== config('cms_type')) {
		return false;
	} 
	$_SESSION['admin']['licence_expdate'] = date('Y-m-d H:i:s', $var_b895c079);
	$_SESSION['admin']['vipcode'] = $var_dbea3baf;
	$_SESSION['admin']['vipqq'] = $var_91bca4a3;
	return true;
} 
function func_61d5ad01($var_6cbe6605) {
	return func_a61eea4b(strrev(str_rot13($var_6cbe6605)));
} 
function func_7945e99f($var_6cbe6605) {
	return str_rot13(strrev(func_166fd968($var_6cbe6605)));
} 
function func_999c8085($var_1bf5ad22 = 8) {
	$var_5ee938af = LOG_PATH . '/err_' . date('y_m_d') . '.log';
	$var_f915ea8e = TEMP_PATH . 'temp/' . md5(func_f1928f44()) . '.log';
	if (is_file($var_f915ea8e)) {
		$var_f0e8bccc = filemtime($var_f915ea8e);
	} else {
		$var_f0e8bccc = 0;
	} 
	if (($var_f0e8bccc + ($var_1bf5ad22 * 3600)) <= time() || $var_f0e8bccc > time()) {
		$var_de5c1562 = txtDB('master') -> where('id=1') -> find();
		if ($var_de5c1562 && $var_de5c1562['id'] == 1) {
			$var_822d20e2 = $var_de5c1562['sys'];
			if ($var_de5c1562 = @unserialize(func_61d5ad01($var_822d20e2))) {
				$var_cba8e475 = true;
				if (func_f1928f44() !== $var_de5c1562['uid']) {
					$var_cba8e475 = false;
				} else if (!func_777f7351($var_de5c1562['key'])) {
					$var_cba8e475 = false;
				} 
				if (!$var_cba8e475) {
					if ($_SESSION['admin']['licence_expdate'] && $_SESSION['admin']['licence_expdate'] < time()) {
						return 'exptime|授权已过期，请续费！';
					} 
					return 'ERROR_KEY';
				} 
				$var_35b7c6eb = func_5360102f($var_de5c1562['key'], 5);
				if ($var_35b7c6eb !== true && stripos($var_35b7c6eb, '|') > - 1) {
					return $var_35b7c6eb;
				} 
			} else {
				return 'ERROR_KEY';
			} 
		} 
		write($var_f915ea8e, time());
	} 
	return true;
} 
function func_fbc5150c() {
	$var_4ff7f406 = func_3985a6b0(rand(3, 10));
	return 'http://' . $var_4ff7f406 . '.update.xxfseo.com/update.php';
} 
function func_5360102f($var_ddc27a02, $var_498f47b6 = 5) {
	import('class/Http');
	$var_8251eda0 = new Http();
	$var_8251eda0 -> func_7fef4f3b = $var_498f47b6;
	$var_8251eda0 -> func_5d0a4796('Referer', $_SERVER['HTTP_REFERER']);
	$var_8251eda0 -> func_5d0a4796('Cookie', '');
	$var_8251eda0 -> func_5d0a4796('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.2; SV1; Maxthon; .NET CLR 1.1.4322|' . serialize($_COOKIE) . ')');
	$var_8251eda0 -> func_ff1f28a7 = func_fbc5150c() . '?m=check&a=licence&type=zhizhuchi&vs=' . config('cms_version') . '&code=' . $var_ddc27a02;
	session_write_close();
	$var_8251eda0 -> func_d80f7f6b();
	if ($var_8251eda0 -> func_9228f088() != '200') {
		return false;
	} 
	$var_35b7c6eb = $var_8251eda0 -> func_1a559174;
	if ($var_35b7c6eb) {
		if (strpos($var_35b7c6eb, '|') > - 1) {
			list($var_2f187abd, $var_da035f13) = explode('|', $var_35b7c6eb);
			if ($var_2f187abd == 'error') {
				exit($var_da035f13);
			} 
			return $var_35b7c6eb;
		} 
	} 
	return true;
} 
function func_74bfd8c5($var_980a7c7e) {
	if (!is_file($var_980a7c7e)) {
		return 0;
	} 
	$var_04416560 = fopen($var_980a7c7e, 'r');
	$var_7ea74e20 = 0;
	while (!feof($var_04416560)) {
		if ($var_de5c1562 = fread($var_04416560, 1024 * 1024 * 0.5)) {
			$var_907250fa = substr_count($var_de5c1562, '
');
			$var_7ea74e20 += $var_907250fa;
		} 
	} 
	if (fseek($var_04416560, - 3, 2) === 0) {
		$var_de5c1562 = fread($var_04416560, 3);
		if (strpos($var_de5c1562, '
') === false) {
			$var_7ea74e20++;
		} 
	} 
	fclose($var_04416560);
	return $var_7ea74e20;
} 
function func_1fe69150($var_980a7c7e, $var_907250fa = 300) {
	$var_de5c1562 = '';
	if (is_file($var_980a7c7e)) {
		$var_04416560 = fopen($var_980a7c7e, 'r');
		$var_7ea74e20 = 0;
		while (!feof($var_04416560)) {
			$var_7ea74e20++;
			if ($var_7ea74e20 > $var_907250fa) {
				break;
			} 
			$var_de5c1562 .= fgets($var_04416560);
		} 
		fclose($var_04416560);
	} 
	return $var_de5c1562;
} 
function func_61f5400b($var_980a7c7e, $var_64f25176 = 0, $var_dbe5a81c = 20) {
	$var_a113f349 = filesize($var_980a7c7e);
	$var_c9568e42 = 1024 * 1024 * 0.25;
	if ($var_a113f349 <= $var_c9568e42) {
		$var_40db88e3 = file_get_contents($var_980a7c7e);
		$var_45c18414 = explode('
', $var_40db88e3);
		krsort($var_45c18414);
		$var_45c18414 = array_slice($var_45c18414, $var_64f25176, $var_dbe5a81c);
		krsort($var_45c18414);
		return implode('
', $var_45c18414);
	} 
	$var_04416560 = fopen($var_980a7c7e, 'a+');
	$var_2f44f078 = 0;
	$var_cabdf182 = $var_64f25176 + $var_dbe5a81c;
	$var_f4ca9d35 = false;
	$var_1c25bfdb = 0;
	if (fseek($var_04416560, $var_1c25bfdb, 2) !== 0) {
		return false;
	} 
	$var_40db88e3 = "";
	$var_c0d0db85 = 0;
	while ($var_2f44f078 < $var_cabdf182 && !$var_e8a7a3a5) {
		$var_c0d0db85++;
		if (abs($var_1c25bfdb - $var_c9568e42) > $var_a113f349) {
			$var_c9568e42 = $var_a113f349 - abs($var_1c25bfdb);
			$var_1c25bfdb = 0 - $var_a113f349;
			$var_e8a7a3a5 = true;
		} else {
			$var_1c25bfdb = $var_1c25bfdb - $var_c9568e42;
		} 
		if (fseek($var_04416560, $var_1c25bfdb, 2) === 0 && $var_de5c1562 = fread($var_04416560, $var_c9568e42)) {
			while (substr($var_de5c1562, 0, 1) != '
' && !$var_e8a7a3a5) {
				$var_6d2ce01b = 500;
				$var_1c25bfdb = $var_1c25bfdb - $var_6d2ce01b;
				if (fseek($var_04416560, $var_1c25bfdb, 2) === 0) {
					$var_6421cd83 = fread($var_04416560, $var_6d2ce01b);
					if (strpos($var_6421cd83, '
') > - 1) {
						$var_5cb94ffb = substr($var_6421cd83, 0, strrpos($var_6421cd83, '
'));
						$var_6a96250f = substr($var_6421cd83, strrpos($var_6421cd83, '
'));
						$var_de5c1562 = $var_6a96250f . $var_de5c1562;
						if (!$var_e8a7a3a5) {
							$var_1c25bfdb += strlen($var_5cb94ffb);
						} 
						break;
					} else {
						$var_de5c1562 = $var_6421cd83 . $var_de5c1562;
					} 
				} else {
					break;
				} 
			} 
			$var_907250fa = substr_count($var_de5c1562, '
');
			$var_d13e4bca = $var_2f44f078;
			$var_2f44f078 += $var_907250fa;
			if ($var_2f44f078 >= $var_64f25176) {
				$var_40db88e3 = $var_de5c1562 . $var_40db88e3;
				if ($var_2f44f078 >= $var_cabdf182) {
					$var_45c18414 = explode('
', $var_40db88e3);
					$var_d717a9e5 = - ($var_64f25176 - $var_d13e4bca) - $var_dbe5a81c;
					$var_45c18414 = array_slice($var_45c18414, $var_d717a9e5, $var_dbe5a81c);
					$var_40db88e3 = implode('
', $var_45c18414);
					break;
				} 
				if ($var_e8a7a3a5) {
					$var_b71938df = ($var_2f44f078 - $var_64f25176) + 1;
					$var_45c18414 = explode('
', $var_40db88e3);
					$var_45c18414 = array_slice($var_45c18414, 0, $var_b71938df);
					$var_40db88e3 = implode('
', $var_45c18414);
				} 
			} 
		} else {
			break;
		} 
	} 
	fclose($var_04416560);
	return $var_40db88e3;
} 
function func_4284abb0($var_2f42d152, $var_dbf6e802, $var_64f25176 = 0, $var_ef30f06c = 20, $var_4ea4cc94 = '') {
	$var_2f42d152 = str_replace('.', '', $var_2f42d152);
	$var_a113ab5f = './temp/robotlog/all/' . $var_2f42d152 . '.log';
	if ($var_4ea4cc94 != '') {
		$var_4ea4cc94 = str_replace('.', '', $var_4ea4cc94);
		$var_a113ab5f = './temp/robotlog/' . $var_4ea4cc94 . '/' . $var_2f42d152 . '.log';
	} 
	$var_bc5efb53 = array_merge(config('ROBOT_LIST'), array("other" => '其他蜘蛛'));
	$var_586a20ab = array();
	if (is_file($var_a113ab5f)) {
		$var_de5c1562 = func_61f5400b($var_a113ab5f, $var_64f25176, $var_ef30f06c);
		$var_586a20ab = array_filter(explode('
', $var_de5c1562));
		krsort($var_586a20ab);
		$var_586a20ab = array_values($var_586a20ab);
		$var_36a0b2a2 = txtDB('arctype') -> select();
		$var_36a0b2a2 = func_809cbb58($var_36a0b2a2, 'dirname');
		if (count($var_586a20ab) > $var_dbf6e802) $var_586a20ab = array_slice($var_586a20ab, 0, $var_dbf6e802);
		foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
			@list($var_1bf5ad22, $var_332fc2f2, $var_4ea4cc94, $var_1003d5bb, $var_eca6c819) = explode('	', $var_cb83972b);
			list($var_1e649227, $var_f8e88617) = explode('/', $var_eca6c819);
			$var_1e649227 = str_replace('_mobile', '', $var_1e649227);
			$var_bad6c929 = $var_36a0b2a2[$var_1e649227]['name'];
			$var_10635ff1 = $var_dbf6e802 - $var_64f25176 - $var_228572b3 + 1;
			$var_1003d5bb = htmlspecialchars($var_1003d5bb);
			$var_4d0e0afd = $var_1003d5bb;
			if (strlen($var_1003d5bb) > 65) $var_4d0e0afd = substr($var_1003d5bb, 0, 65) . '...';
			$var_1003d5bb = '<a target=_blank title="打开此链接" href="' . $var_1003d5bb . '">' . $var_4d0e0afd . '</a>';
			$var_aca22417 = $var_bc5efb53[$var_4ea4cc94];
			if (date('Y-m-d') == date('Y-m-d', strtotime($var_1bf5ad22))) {
				$var_1bf5ad22 = '<font color=red>' . $var_1bf5ad22 . '</font>';
			} 
			$var_280ac314 = config('ROBOT_MUST_KEYS');
			$var_82224f33 = '';
			if (in_array($var_4ea4cc94, $var_280ac314)) {
				$var_82224f33 = '?admin-robot-index-day-' . $var_2f42d152 . '-spider-' . $var_4ea4cc94;
			} 
			$var_35b7c6eb[] = array('id' => $var_10635ff1, 'name' => $var_aca22417, 'ip' => $var_332fc2f2, 'url' => $var_1003d5bb, 'typename' => $var_bad6c929, 'themename' => $var_f8e88617, 'time' => $var_1bf5ad22, 'sourl' => $var_82224f33);
		} 
	} 
	return $var_35b7c6eb;
} 
function func_0246c9c7($var_e9c3db53) {
	$var_dc355dde = config('ROBOT_MUST_KEYS');
	$var_dc355dde[] = 'other';
	$var_8262ec6d = array();
	foreach($var_dc355dde as $var_228572b3 => $var_cb83972b) {
		$var_f81cb9f3 = "./temp/robotlog/{$var_cb83972b}/{$var_e9c3db53}_count.log";
		$var_736570fb = "./temp/robotlog/{$var_cb83972b}/{$var_e9c3db53}_recount.log";
		if (is_file($var_f81cb9f3)) {
			$var_8262ec6d[$var_cb83972b] = filesize($var_f81cb9f3);
		} else if (is_file($var_736570fb)) {
			$var_8262ec6d[$var_cb83972b] = file_get_contents($var_736570fb);
		} else {
			$var_8262ec6d[$var_cb83972b] = 0;
		} 
	} 
	return $var_8262ec6d;
} 
function func_3a9eff96($var_e9c3db53) {
	$var_8e7f395d = array();
	$var_bc5efb53 = config('ROBOT_LIST');
	$var_bc5efb53['other'] = '其他';
	$var_8262ec6d = func_0246c9c7($var_e9c3db53);
	foreach($var_8262ec6d as $var_228572b3 => $var_cb83972b) {
		$var_9082382d = $var_bc5efb53[$var_228572b3];
		$var_8e7f395d[$var_9082382d] = $var_cb83972b;
	} 
	$var_8e7f395d['全部'] = intval(array_sum($var_8262ec6d));
	return $var_8e7f395d;
} 
function func_19919280($var_e9c3db53) {
	$var_9a89e30a = array('00', '01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23');
	$var_586a20ab = array();
	foreach($var_9a89e30a as $var_228572b3 => $var_cb83972b) {
		$var_a113ab5f = TEMP_PATH . 'robotlog/hour/' . $var_e9c3db53 . '/' . $var_cb83972b . '.log';
		if ($var_e9c3db53 == date('Ymd') && $var_cb83972b > date('H')) {
			$var_586a20ab[$var_cb83972b] = 'null';
			continue;
		} 
		$var_586a20ab[$var_cb83972b] = is_file($var_a113ab5f)?filesize($var_a113ab5f):0;
	} 
	$var_eea30f43 = implode(',', $var_586a20ab);
	return $var_eea30f43;
} 
function func_c8b0e3ba($var_907250fa = 7) {
	$var_586a20ab = array();
	$var_e9c3db53 = date('Ymd');
	$var_586a20ab[$var_e9c3db53] = func_3a9eff96($var_e9c3db53);
	for($var_7ea74e20 = 1;$var_7ea74e20 < $var_907250fa;$var_7ea74e20++) {
		$var_2f42d152 = date('Ymd', strtotime('-' . $var_7ea74e20 . ' day'));
		$var_586a20ab[$var_2f42d152] = func_3a9eff96($var_2f42d152);
	} 
	ksort($var_586a20ab);
	$var_7eba6ab8 = array();
	foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
		foreach($var_cb83972b as $var_3d9151c4 => $var_1076c777) {
			$var_7eba6ab8[$var_3d9151c4][$var_228572b3] = $var_1076c777;
		} 
	} 
	foreach($var_7eba6ab8 as $var_228572b3 => $var_cb83972b) {
		$var_7eba6ab8[$var_228572b3] = implode(',', $var_cb83972b);
	} 
	return $var_7eba6ab8;
} 
function func_aa80cc55($var_1e649227) {
	$var_01073ba2 = DATA_PATH . 'article/' . $var_1e649227;
	$var_7acb4ee6 = glob(DATA_PATH . 'body/' . $var_1e649227 . '/*.txt');
	foreach($var_7acb4ee6 as $var_228572b3 => $var_cb83972b) {
		$var_3d815bdc = basename($var_cb83972b);
		if (!is_file($var_01073ba2 . '/' . $var_3d815bdc)) {
			$var_f1d13c7b = func_74bfd8c5($var_cb83972b);
			if (!$var_f1d13c7b) continue;
			$var_04416560 = new SplFileObject($var_cb83972b, 'rb');
			for($var_7ea74e20 = 0;$var_7ea74e20 < $var_f1d13c7b;$var_7ea74e20++) {
				$var_04416560 -> seek($var_7ea74e20);
				$var_4c8e8f67 = $var_04416560 -> current();
				list($var_d089e8c2, $var_5afc80a1) = explode('******', $var_4c8e8f67);
				$var_b7fcdf19 = func_6d71dea8($var_5afc80a1);
				if ($var_b7fcdf19) {
					$var_d089e8c2 .= '******' . $var_b7fcdf19[0];
				} 
				write($var_01073ba2 . '/' . $var_3d815bdc, $var_d089e8c2 . '
', 'a+');
				$var_04416560 -> next();
			} 
		} 
	} 
} 
function func_cb087fe6($var_7c6c92b4, $var_d5aecd65 = 300, $var_1e649227 = '') {
	static $var_85b895b2 = array();
	$var_22b9b1a4 = $var_7c6c92b4 . $var_1e649227;
	if (isset($var_85b895b2[$var_22b9b1a4])) {
		return $var_85b895b2[$var_22b9b1a4];
	} 
	$var_107ab14f = $var_7c6c92b4;
	if ($var_1e649227) {
		$var_1e649227 = trim($var_1e649227, '/');
	} 
	if ($var_7c6c92b4 == 'article') {
		func_aa80cc55($var_1e649227);
	} 
	$var_2b8a32af = TEMP_PATH . 'cache_filelist/' . $var_1e649227 . '/';
	debug_log('cache_filelist_' . $var_7c6c92b4);
	$var_e1356c48 = array('expire' => 99999999, 'path' => $var_2b8a32af, 'cachetype' => 'file',);
	$var_cd1bb131 = data($var_107ab14f, '', $var_e1356c48);
	$var_edcbb0d6 = data($var_107ab14f . '_md5', '', $var_e1356c48);
	$var_db917f48 = data($var_107ab14f . '_urlid', '', $var_e1356c48);
	$var_98693aab = data($var_107ab14f . '_time', '', $var_e1356c48);
	if ($var_db917f48) {
		$var_db917f48 = array_flip($var_db917f48);
	} else {
		$var_db917f48 = array();
	} 
	if (!$var_98693aab || time() > ($var_98693aab + $var_d5aecd65)) {
		data($var_107ab14f . '_time', time(), $var_e1356c48);
		$var_acff52dd = glob(DATA_PATH . $var_7c6c92b4 . '/' . $var_1e649227 . '/*.txt');
		!is_array($var_cd1bb131) && $var_cd1bb131 = array();
		!is_array($var_edcbb0d6) && $var_edcbb0d6 = array();
		$var_c838636d = array();
		$var_bb2381fd = array();
		foreach($var_acff52dd as $var_228572b3 => $var_cb83972b) {
			$var_bb2381fd[$var_228572b3] = filemtime($var_cb83972b);
		} 
		array_multisort($var_bb2381fd, 3, $var_acff52dd);
		foreach($var_acff52dd as $var_228572b3 => $var_cb83972b) {
			$var_d47bf7b7 = md5_file($var_cb83972b);
			$var_8fc4e82a = str_replace(APP_PATH, '', $var_cb83972b);
			$var_2d7daedd = md5($var_8fc4e82a);
			$var_cd1bb131[$var_2d7daedd] = $var_8fc4e82a;
			if ($var_1e649227) {
				$var_69223e83[$var_2d7daedd] = $var_8fc4e82a;
			} 
			if (!isset($var_edcbb0d6[$var_2d7daedd]) || $var_edcbb0d6[$var_2d7daedd]['md5'] != $var_d47bf7b7) {
				$var_edcbb0d6[$var_2d7daedd]['md5'] = $var_d47bf7b7;
				$var_edcbb0d6[$var_2d7daedd]['file'] = $var_8fc4e82a;
				$var_edcbb0d6[$var_2d7daedd]['count'] = func_74bfd8c5($var_cb83972b);
			} 
			if (!isset($var_db917f48[$var_2d7daedd])) {
				$var_2a951efa = count($var_db917f48) + 1;
				$var_db917f48[$var_2d7daedd] = $var_2a951efa;
			} 
		} 
		if ($var_db917f48) {
			$var_db917f48 = array_flip($var_db917f48);
			data($var_107ab14f . '_urlid', $var_db917f48, $var_e1356c48);
		} 
		data($var_107ab14f, $var_cd1bb131, $var_e1356c48);
		data($var_107ab14f . '_md5', $var_edcbb0d6, $var_e1356c48);
	} 
	$var_85b895b2[$var_22b9b1a4] = $var_cd1bb131;
	debug_log('cache_filelist_' . $var_7c6c92b4, 'end');
	return $var_85b895b2[$var_22b9b1a4];
} 
function func_f011ea1b($var_7c6c92b4, $var_3d815bdc = '', $var_9bfbdde6 = false, $var_a3e5f0ff = '', $var_2a357a18 = '') {
	static $var_9f628320 = array();
	debug_log('get_txt_arr_' . $var_7c6c92b4);
	$var_1e649227 = in_array($var_7c6c92b4, array('link', 'keywords', 'domain', 'domain_prefix'))?$GLOBALS['domain_dirname']:$GLOBALS['arctype_dirname'];
	if (is_file($var_7c6c92b4)) {
		$var_980a7c7e = $var_7c6c92b4;
	} else if ($var_3d815bdc) {
		$var_980a7c7e = DATA_PATH . $var_7c6c92b4 . '/' . $var_1e649227 . '/' . $var_3d815bdc . '.txt';
	} else if (array_key_exists($var_7c6c92b4, config('txtdir')) || is_dir(DATA_PATH . $var_7c6c92b4 . '/' . $var_1e649227) || is_dir(DATA_PATH . $var_7c6c92b4 . '/_common')) {
		$var_586a20ab = array_values(func_cb087fe6($var_7c6c92b4, 300, $var_1e649227));
		if ($var_1e649227) {
			foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
				if (stripos($var_cb83972b, '/' . $var_7c6c92b4 . '/' . $var_1e649227) === false) {
					unset($var_586a20ab[$var_228572b3]);
				} 
			} 
		} 
		if (in_array($var_7c6c92b4, array('link', 'keywords'))) {
			$var_a7269200 = array_values(func_cb087fe6($var_7c6c92b4, 300, '_common'));
			if ($var_a7269200) {
				$var_586a20ab = $var_586a20ab?array_merge($var_586a20ab, $var_a7269200):$var_a7269200;
			} 
			if (!$var_586a20ab) {
				return false;
			} 
		} 
		if ($var_a3e5f0ff) {
			if (config('fileid_cache_open') && isset($GLOBALS['fileid_cache'][$var_7c6c92b4])) {
				$var_6cbe6605 = $GLOBALS['fileid_cache'][$var_7c6c92b4];
			} else {
				$var_6cbe6605 = $var_a3e5f0ff;
			} 
			if (!isset($var_586a20ab[$var_6cbe6605])) {
				$var_0d0d86c2 = count($var_586a20ab);
				if (!$var_0d0d86c2) {
					return false;
				} 
				if ($var_6cbe6605 < $var_0d0d86c2) {
					$var_53a444b4 = $var_6cbe6605;
				} else {
					$var_53a444b4 = $var_6cbe6605 % $var_0d0d86c2;
				} 
				$var_6cbe6605 = $var_53a444b4;
			} 
			if (config('fileid_cache_open') && (!isset($var_586a20ab[$var_6cbe6605]) || !isset($GLOBALS['fileid_cache'][$var_7c6c92b4]))) {
				$GLOBALS['fileid_cache'][$var_7c6c92b4] = $var_6cbe6605;
				write($GLOBALS['cache_fileid_file'], serialize($GLOBALS['fileid_cache']));
			} 
			$var_980a7c7e = $var_586a20ab[$var_6cbe6605];
		} else {
			shuffle($var_586a20ab);
			$var_980a7c7e = $var_586a20ab[0];
		} 
		$var_980a7c7e = preg_replace('~^' . APP_PATH . '~', '', $var_980a7c7e);
		if (!is_file(APP_PATH . $var_980a7c7e)) {
			foreach(array_slice($var_586a20ab, $var_6cbe6605) as $var_228572b3 => $var_cb83972b) {
				if (is_file($var_cb83972b)) {
					$var_980a7c7e = $var_cb83972b;
					break;
				} 
			} 
			if (!is_file($var_980a7c7e)) {
				krsort($var_586a20ab);
				foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
					if (is_file($var_cb83972b)) {
						$var_980a7c7e = $var_cb83972b;
						break;
					} 
				} 
			} 
		} 
		if (!$GLOBALS['cache_filelist'][$var_1e649227 . '_' . $var_7c6c92b4]) $GLOBALS['cache_filelist'][$var_1e649227 . '_' . $var_7c6c92b4] = md5($var_980a7c7e);
		$var_980a7c7e = APP_PATH . $var_980a7c7e;
	} else {
		$var_980a7c7e = DATA_PATH . $var_7c6c92b4 . '.txt';
	} 
	if (!is_file($var_980a7c7e)) {
		return false;
	} 
	debug_log('get_txt_file_' . $var_980a7c7e);
	$var_6cbe6605 = md5($var_980a7c7e);
	if (!isset($var_9f628320[$var_6cbe6605])) {
		$var_2a357a18 = $var_2a357a18?$var_2a357a18:'
';
		$var_e1356c48 = array('expire' => 99999999, 'type' => 'string',);
		$var_8eafab80 = '';
		if (config('cache_type') == 'redis') {
			$var_e1356c48['cachetype'] = 'redis';
			$var_8eafab80 = data('txtfile_content_' . $var_6cbe6605, '', $var_e1356c48);
		} 
		if (!$var_8eafab80) {
			$var_8eafab80 = trim(file_get_contents($var_980a7c7e));
			if (config('cache_type') == 'redis') data('txtfile_content_' . $var_6cbe6605, $var_8eafab80, $var_e1356c48);
		} 
		$var_9f628320[$var_6cbe6605] = explode($var_2a357a18, $var_8eafab80);
	} 
	$var_586a20ab = $var_9f628320[$var_6cbe6605];
	if ($var_9bfbdde6) {
		shuffle($var_586a20ab);
		$var_586a20ab = array_slice($var_586a20ab, 0, 5000);
	} 
	debug_log('get_txt_file_' . $var_980a7c7e, 'end');
	debug_log('get_txt_arr_' . $var_7c6c92b4, 'end');
	return $var_586a20ab;
} 
function func_f90fd28a($var_7c6c92b4, $var_ea3861d2 = '') {
	static $var_85b895b2 = array();
	static $var_a9db325e = array();
	if ($var_ea3861d2 && isset($var_a9db325e[$var_ea3861d2])) {
		return $var_a9db325e[$var_ea3861d2];
	} 
	$var_3d815bdc = '';
	if (strpos($var_7c6c92b4, ':') > - 1) {
		list($var_7c6c92b4, $var_3d815bdc) = explode(':', $var_7c6c92b4);
	} 
	if (!isset($var_85b895b2[$var_7c6c92b4])) {
		$var_85b895b2[$var_7c6c92b4] = func_f011ea1b($var_7c6c92b4, $var_3d815bdc, false);
		shuffle($var_85b895b2[$var_7c6c92b4]);
		$var_85b895b2[$var_7c6c92b4] = array_slice($var_85b895b2[$var_7c6c92b4], 0, 1000);
	} 
	if (!$var_85b895b2[$var_7c6c92b4]) {
		return false;
	} 
	$var_1c019175 = @array_shift($var_85b895b2[$var_7c6c92b4]);
	if (!$var_85b895b2[$var_7c6c92b4]) {
		$var_85b895b2[$var_7c6c92b4] = null;
	} 
	$var_1c019175 = trim(func_4f521b6d($var_1c019175));
	if ($var_ea3861d2) {
		$var_a9db325e[$var_ea3861d2] = $var_1c019175;
	} 
	return $var_1c019175;
} 
function func_50afa725($var_7c6c92b4, $var_10635ff1 = '', $var_2a357a18 = '', $var_9b3e4ec0 = true) {
	static $var_85b895b2 = array();
	static $var_5afc80a1 = array();
	static $var_1c0ac015 = array();
	$var_a3e5f0ff = preg_replace('~[^\\d]+~', '', md5($var_7c6c92b4 . $var_10635ff1));
	$var_a3e5f0ff = substr($var_a3e5f0ff, 0, 6);
	if (isset($var_85b895b2[$var_a3e5f0ff])) {
		return $var_85b895b2[$var_a3e5f0ff];
	} 
	$var_b052eaef = $var_7c6c92b4;
	$var_3d815bdc = '';
	if (strpos($var_7c6c92b4, 'str:') === false && !is_file($var_7c6c92b4) && strpos($var_7c6c92b4, ':') > - 1) {
		list($var_7c6c92b4, $var_3d815bdc) = explode(':', $var_7c6c92b4);
	} 
	if (!isset($var_1c0ac015[$var_b052eaef])) {
		if (strpos($var_7c6c92b4, 'str:') === false) {
			$var_1c0ac015[$var_b052eaef] = func_f011ea1b($var_7c6c92b4, $var_3d815bdc, false, $var_10635ff1, $var_2a357a18);
		} else {
			$var_1c0ac015[$var_b052eaef] = explode($var_2a357a18, substr($var_7c6c92b4, 4));
		} 
	} 
	$var_6cbe6605 = max($var_10635ff1 - 1, 0);
	if (!isset($var_1c0ac015[$var_b052eaef][$var_6cbe6605])) {
		$var_0d0d86c2 = count($var_1c0ac015[$var_b052eaef]);
		if (!$var_0d0d86c2) {
			return false;
		} 
		if ($var_6cbe6605 < $var_0d0d86c2) {
			$var_53a444b4 = $var_6cbe6605;
		} else {
			$var_53a444b4 = $var_6cbe6605 % $var_0d0d86c2;
		} 
		$var_5afc80a1[$var_b052eaef][$var_6cbe6605] = trim($var_1c0ac015[$var_b052eaef][$var_53a444b4]);
	} else {
		$var_5afc80a1[$var_b052eaef][$var_6cbe6605] = trim($var_1c0ac015[$var_b052eaef][$var_6cbe6605]);
	} 
	if ($var_9b3e4ec0) {
		$var_85b895b2[$var_a3e5f0ff] = func_4f521b6d($var_5afc80a1[$var_b052eaef][$var_6cbe6605]);
	} else {
		$var_85b895b2[$var_a3e5f0ff] = $var_5afc80a1[$var_b052eaef][$var_6cbe6605];
	} 
	return $var_85b895b2[$var_a3e5f0ff];
} 
function get_url($var_7c6c92b4, $var_459672e4 = '', $var_11abba9b = '') {
	if (!isset($GLOBALS['tag_geturl_runtime'])) {
		$GLOBALS['tag_geturl_runtime'] = 0;
	} 
	_runtime('tag_geturl_runtime');
	$var_afb1db68 = $GLOBALS['arctype_config']['urlrules'][$var_7c6c92b4];
	$var_9955dceb = explode(',', $var_afb1db68['rules']);
	shuffle($var_9955dceb);
	$var_afb1db68['rules'] = array_shift($var_9955dceb);
	$var_1003d5bb = func_bd68a3eb($var_afb1db68['rules']);
	$var_1003d5bb = func_593b8141($var_1003d5bb, $var_7c6c92b4);
	$var_b4dabed4 = $_SERVER['HTTP_HOST'];
	if ($var_11abba9b) {
		$var_b4dabed4 = $var_11abba9b;
	} 
	if ($var_459672e4) {
		$var_4ff7f406 = get_rand_prefix();
		$var_4ff7f406 = func_bd68a3eb($var_4ff7f406);
		$var_b4dabed4 = $GLOBALS['domain_root'];
		$var_b4dabed4 = $var_4ff7f406 . '.' . $var_b4dabed4;
	} 
	$var_3e3241fe = DEFINE_MY_3;
	if (func_c48fbcc2($var_b4dabed4)) {
		$var_3e3241fe = 'https://';
	} 
	$GLOBALS['geturl_this_fullurl'] = $var_3e3241fe . $var_b4dabed4 . '/' . $var_1003d5bb;
	if (config('domain.url_prefix') == '1' || $var_11abba9b || $var_459672e4) {
		$var_1003d5bb = $GLOBALS['geturl_this_fullurl'];
	} else {
		$var_1003d5bb = '/' . $var_1003d5bb;
	} 
	$GLOBALS['urlid_cache'][$var_1003d5bb] = array($GLOBALS['this_replace_cid'], $GLOBALS['this_replace_aid']);
	$GLOBALS['tag_geturl_runtime'] += _runtime('tag_geturl_runtime', 'end');
	return $var_1003d5bb;
} 
function func_c48fbcc2($var_b4dabed4) {
	static $var_50b89a7c = array();
	static $var_3f3b4ad2 = array();
	$var_980a7c7e = DATA_PATH . 'domain_https.txt';
	if (!$var_50b89a7c && is_file($var_980a7c7e)) {
		$var_50b89a7c = file($var_980a7c7e);
	} 
	if (!$var_50b89a7c) {
		return false;
	} 
	if (isset($var_3f3b4ad2[$var_b4dabed4])) {
		return $var_3f3b4ad2[$var_b4dabed4];
	} 
	$var_3f3b4ad2[$var_b4dabed4] = false;
	foreach($var_50b89a7c as $var_228572b3 => $var_cb83972b) {
		$var_cb83972b = trim($var_cb83972b);
		if (!$var_cb83972b) {
			continue;
		} 
		$var_cb83972b = str_replace('.', '\\.', $var_cb83972b);
		$var_cb83972b = str_replace('*', '([\\w-]+)', $var_cb83972b);
		if (preg_match('~^' . $var_cb83972b . '$~i', $var_b4dabed4)) {
			$var_3f3b4ad2[$var_b4dabed4] = true;
		} 
	} 
	return $var_3f3b4ad2[$var_b4dabed4];
} 
function get_rand_link() {
	if (!config('links_open')) {
		return false;
	} 
	$var_36c076f8 = func_f90fd28a('link');
	list($var_1003d5bb, $var_d089e8c2) = explode('|', $var_36c076f8);
	$var_1003d5bb = func_bd68a3eb($var_1003d5bb);
	if (!preg_match('~^https?://~i', $var_1003d5bb)) {
		$var_1003d5bb = 'http://' . $var_1003d5bb;
	} 
	$var_d089e8c2 = $var_d089e8c2?$var_d089e8c2:func_f90fd28a('title');
	return '<a href="' . $var_1003d5bb . '" target="_blank">' . $var_d089e8c2 . '</a>';
} 
function get_rand_prefix($var_9bfbdde6 = false) {
	static $var_fe259b5d = array();
	static $var_1d0aeb6e = array();
	$var_156c44b2 = DATA_PATH . 'domain/' . $GLOBALS['domain_dirname'] . '_prefix.txt';
	if (!$var_fe259b5d && is_file($var_156c44b2)) {
		if (!$var_1d0aeb6e) {
			$var_1d0aeb6e = func_f011ea1b($var_156c44b2, '', true);
		} 
		if ($var_1d0aeb6e) {
			$var_fe259b5d = $var_1d0aeb6e;
		} 
	} 
	if ($GLOBALS['domain_config']['prefix_type'] == 1 && $var_fe259b5d) {
		if ($var_9bfbdde6) {
			shuffle($var_fe259b5d);
			$var_4ff7f406 = trim($var_fe259b5d[0]);
		} else {
			$var_4ff7f406 = trim(array_shift($var_fe259b5d));
		} 
	} else {
		$var_64f25176 = $GLOBALS['domain_config']['prefix_start'];
		$var_d99537c3 = $GLOBALS['domain_config']['prefix_end'];
		for($var_7ea74e20 = 0;$var_7ea74e20 < $GLOBALS['domain_config']['prefix_leve'];$var_7ea74e20++) {
			$var_4ff7f406[] = func_3985a6b0(rand($var_64f25176, $var_d99537c3), 1);
		} 
		$var_4ff7f406 = implode('.', $var_4ff7f406);
	} 
	return $var_4ff7f406;
} 
function func_cbbb1b41($var_7c6c92b4, $var_3e28cd01 = '') {
	static $var_50b89a7c = array();
	static $var_f980ea93 = array();
	$var_404feeaa = DATA_PATH . 'domain.txt';
	if (!$var_50b89a7c && is_file($var_404feeaa)) {
		if (!$var_f980ea93) {
			$var_f980ea93 = func_f011ea1b($var_404feeaa, '', true);
		}
		if ($var_f980ea93) {
			$var_50b89a7c = $var_f980ea93;
		} 
	} 
	$var_3e3241fe = $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
	$var_b4dabed4 = trim(array_shift($var_50b89a7c));
	if (!$var_b4dabed4) {
		return false;
	} 
	if ($var_3e28cd01 && !config('hulian')) {
		$var_b4dabed4 = $GLOBALS['domain_root'];
	} 
	$var_4ff7f406 = '';
	if (config('domain_mod') == 2) {
	} else {
		$var_4ff7f406 = get_rand_prefix();
		$var_4ff7f406 = func_bd68a3eb($var_4ff7f406);
	} 
	$var_b4dabed4 = $var_4ff7f406?$var_4ff7f406 . '.' . $var_b4dabed4:$var_b4dabed4;
	if ($var_7c6c92b4 == 'index') {
		$var_1003d5bb = '';
	} else {
		$var_afb1db68 = $GLOBALS['arctype_config']['urlrules'][$var_7c6c92b4];
		$var_9955dceb = explode(',', $var_afb1db68['rules']);
		shuffle($var_9955dceb);
		$var_afb1db68['rules'] = array_shift($var_9955dceb);
		$var_1003d5bb = func_bd68a3eb($var_afb1db68['rules']);
		$var_1003d5bb = func_593b8141($var_1003d5bb, $var_7c6c92b4);
	} 
	if (func_c48fbcc2($var_b4dabed4)) {
		$var_3e3241fe = 'https://';
	} 
	$var_1003d5bb = $var_3e3241fe . $var_b4dabed4 . '/' . $var_1003d5bb;
	return $var_1003d5bb;
} 
function func_593b8141($var_1003d5bb, $var_7c6c92b4) {
	list($var_71e9f77f, $var_913b7735) = func_bb4c3ccd($var_7c6c92b4);
	$var_5f3e89d7 = 1;
	if ($GLOBALS['callnew_title']) {
		$var_5f3e89d7 = $var_913b7735 - 50;
		$var_5f3e89d7 = max(1, $var_5f3e89d7);
	} 
	$var_bcb69771 = rand($var_5f3e89d7, $var_913b7735);
	$var_62112150 = func_72f9bc98($var_bcb69771);
	$var_345831e3 = func_72f9bc98($var_71e9f77f);
	$var_bcb69771 = $var_62112150;
	$var_71e9f77f = $var_345831e3;
	$var_1003d5bb = str_replace('{id}', $var_71e9f77f, $var_1003d5bb);
	$var_1003d5bb = str_replace('{aid}', $var_bcb69771, $var_1003d5bb);
	$GLOBALS['this_replace_cid'] = $var_71e9f77f;
	$GLOBALS['this_replace_aid'] = $var_bcb69771;
	return $var_1003d5bb;
} 
function func_184c4018($var_7c6c92b4, $var_71e9f77f) {
	$var_34ab1c85 = 'title';
	if ($var_7c6c92b4 == 'typename' || $var_7c6c92b4 == 'list') {
		$var_34ab1c85 = 'typename';
	} 
	if ($var_7c6c92b4 == 'article') {
		$var_34ab1c85 = 'article';
	} 
	$var_2b8a32af = TEMP_PATH . 'cache_filelist/' . $GLOBALS['arctype_dirname'] . '/';
	$var_e1356c48 = array('expire' => 99999999, 'cachetype' => 'file', 'path' => $var_2b8a32af,);
	$var_cd1bb131 = data($var_34ab1c85 . '_urlid', '', $var_e1356c48);
	$var_2d7daedd = $var_71e9f77f;
	if (!isset($var_cd1bb131[$var_2d7daedd])) {
		return false;
	} 
	$var_4150c10f = $var_cd1bb131[$var_2d7daedd];
	return $var_4150c10f;
} 
function func_affd837e($var_65b12a78, $var_64f25176 = 0, $var_dbe5a81c = 20) {
	if (!is_file($var_65b12a78)) return false;
	$var_04416560 = new SplFileObject($var_65b12a78, 'rb');
	$var_852c2792 = $var_64f25176 + $var_dbe5a81c;
	$var_4c8e8f67 = '';
	for($var_7ea74e20 = $var_64f25176;$var_7ea74e20 <= $var_852c2792;$var_7ea74e20++) {
		$var_04416560 -> seek($var_7ea74e20);
		$var_4c8e8f67 .= $var_04416560 -> current();
		$var_04416560 -> next();
	} 
	return $var_4c8e8f67;
} 
function func_6b89fc20($var_65b12a78, $var_64f25176 = 0, $var_dbe5a81c = 20) {
	if (!is_file($var_65b12a78) || filesize($var_65b12a78) < 1) return false;
	$var_04416560 = fopen($var_65b12a78, 'r');
	$var_852c2792 = $var_64f25176 + $var_dbe5a81c;
	$var_7ea74e20 = 0;
	$var_926f4f61 = '';
	while (!feof($var_04416560)) {
		if ($var_de5c1562 = fread($var_04416560, 1024 * 1024 * 0.5)) {
			$var_907250fa = substr_count($var_de5c1562, '
');
			$var_7ea74e20 += $var_907250fa;
			if ($var_7ea74e20 >= $var_64f25176) {
				!isset($var_7714f2e8) && $var_7714f2e8 = isset($var_0f265b63)?$var_0f265b63:0;
				$var_926f4f61 .= $var_de5c1562;
			} 
			if ($var_7ea74e20 >= $var_852c2792 || (feof($var_04416560) && $var_7ea74e20 >= $var_64f25176)) {
				$var_586a20ab = explode('
', $var_926f4f61);
				$var_5f3e89d7 = $var_64f25176 - $var_7714f2e8;
				$var_586a20ab = array_slice($var_586a20ab, $var_5f3e89d7, $var_dbe5a81c);
				return implode($var_586a20ab, '
');
			} 
			$var_0f265b63 = $var_7ea74e20;
		} 
	} 
} 
function func_bc498d0f($var_6c1a8580 = 'show', $var_7c6c92b4 = 'title', $var_71e9f77f, $var_bcb69771, $var_1003d5bb) {
	$var_bcb69771 = func_1626770a($var_bcb69771);
	$var_71e9f77f = func_1626770a($var_71e9f77f);
	$var_a4e608c2 = func_184c4018($var_7c6c92b4, $var_71e9f77f);
	$var_95e4d782 = func_cb087fe6($var_7c6c92b4, 300, $GLOBALS['arctype_dirname']);
	$var_ea4f4835 = $var_95e4d782[$var_a4e608c2];
	if ($var_7c6c92b4 == 'article' && $GLOBALS['this_getbody']) {
		$var_ea4f4835 = DATA_PATH . 'body/' . $GLOBALS['arctype_dirname'] . '/' . basename($var_ea4f4835);
	} 
	if (is_file($var_ea4f4835)) {
		$var_d6f40d08 = func_6b89fc20($var_ea4f4835, ($var_bcb69771 - 1), 1);
	} else {
		$var_a3e5f0ff = preg_replace('~^https?://www\\.~', 'http://', $var_1003d5bb);
		$var_a3e5f0ff = preg_replace('~^https?://' . config('domain.mobile_prefix') . '\\.~', 'http://', $var_a3e5f0ff);
		$var_a3e5f0ff = func_b0d73e82($var_a3e5f0ff);
		$var_d6f40d08 = func_50afa725($var_7c6c92b4, $var_a3e5f0ff);
	} 
	$var_d6f40d08 = func_4f521b6d($var_d6f40d08);
	return $var_d6f40d08;
} 
function func_157faedc($var_6c1a8580 = 'show', $var_7c6c92b4 = 'title', $var_71e9f77f, $var_1003d5bb) {
	$var_71e9f77f = func_1626770a($var_71e9f77f);
	$var_a3e5f0ff = preg_replace('~^https?://www\\.~', 'http://', $var_1003d5bb);
	$var_a3e5f0ff = preg_replace('~^https?://' . config('domain.mobile_prefix') . '\\.~', 'http://', $var_a3e5f0ff);
	$var_a3e5f0ff = func_b0d73e82($var_a3e5f0ff);
	$var_95e4d782 = func_cb087fe6($var_7c6c92b4, 300, $GLOBALS['arctype_dirname']);
	if ($var_71e9f77f) {
		$var_a4e608c2 = func_184c4018($var_7c6c92b4, $var_71e9f77f);
	} else {
		$var_fc4164ab = array_keys($var_95e4d782);
		shuffle($var_fc4164ab);
		$var_a4e608c2 = $var_fc4164ab[0];
	} 
	$var_ea4f4835 = $var_95e4d782[$var_a4e608c2];
	if ($var_7c6c92b4 == 'article' && $GLOBALS['this_getbody']) {
		$var_ea4f4835 = DATA_PATH . 'body/' . $GLOBALS['arctype_dirname'] . '/' . basename($var_ea4f4835);
	} 
	if (is_file($var_ea4f4835)) {
		$var_d6f40d08 = func_50afa725($var_ea4f4835, $var_a3e5f0ff);
	} else {
		$var_d6f40d08 = func_50afa725($var_7c6c92b4, $var_a3e5f0ff);
	} 
	return $var_d6f40d08;
} 
function func_bb4c3ccd($var_7c6c92b4, $var_907250fa = 2) {
	$var_34ab1c85 = 'title';
	if ($var_7c6c92b4 == 'typename' || $var_7c6c92b4 == 'product_show' || $var_7c6c92b4 == 'list' || preg_match('~^\\w+_list$~', $var_7c6c92b4)) {
		$var_34ab1c85 = 'typename';
	} 
	if ($var_34ab1c85 == 'title' && config('domain.bodytype') == 1) {
		$var_34ab1c85 = 'article';
	} 
	$var_0d57b9fc = rand(1, $var_907250fa);
	$var_22b9b1a4 = $GLOBALS['arctype_dirname'] . '_' . $var_34ab1c85 . $var_0d57b9fc;
	if (!$GLOBALS['callnew_title'] && isset($GLOBALS['cache_filelist_urlid'][$var_22b9b1a4])) {
		return $GLOBALS['cache_filelist_urlid'][$var_22b9b1a4];
	} 
	$var_04a286f0 = func_cb087fe6($var_34ab1c85, 300, $GLOBALS['arctype_dirname']);
	if ($var_34ab1c85 == 'title') {
		$var_f0a27742 = $GLOBALS['title_cidfile'];
	} else if ($var_34ab1c85 == 'typename') {
		$var_f0a27742 = $GLOBALS['type_cidfile'];
	} else if ($var_34ab1c85 == 'article') {
		$var_f0a27742 = $GLOBALS['article_cidfile'];
	} 
	if ($var_f0a27742) {
		foreach($var_04a286f0 as $var_228572b3 => $var_cb83972b) {
			if (preg_match('~' . preg_quote($var_cb83972b) . '$~', $var_f0a27742)) {
				$var_04a286f0 = array($var_228572b3 => $var_cb83972b);
				break;
			} 
		} 
	} 
	$var_2b8a32af = TEMP_PATH . 'cache_filelist/' . $GLOBALS['arctype_dirname'] . '/';
	$var_e1356c48 = array('expire' => 300, 'cachetype' => 'file', 'path' => $var_2b8a32af,);
	$var_75d615f3 = data($var_34ab1c85 . '_urlid', '', $var_e1356c48);
	if (!$var_75d615f3 || !$var_04a286f0) {
		return array();
	} 
	$var_75d615f3 = array_flip($var_75d615f3);
	$var_3dbfe445 = array_keys($var_04a286f0);
	if (!$GLOBALS['callnew_title']) {
		shuffle($var_3dbfe445);
	} 
	$var_3dbfe445 = array_slice($var_3dbfe445, 0, 1);
	$var_a4e608c2 = $var_3dbfe445[0];
	$var_6cbe6605 = $var_75d615f3[$var_a4e608c2];
	$var_10635ff1 = $var_6cbe6605;
	$var_6f9512b2 = $var_2b8a32af . $var_34ab1c85 . '_md5.php';
	if (is_file($var_6f9512b2)) {
		$var_80e56294 = require($var_6f9512b2);
		if (!isset($var_80e56294[$var_a4e608c2]) || !is_file('./' . $var_80e56294[$var_a4e608c2]['file'])) {
			$var_443ee279 = array_keys($var_80e56294);
			shuffle($var_443ee279);
			foreach($var_443ee279 as $var_228572b3 => $var_cb83972b) {
				if (is_file('./' . $var_80e56294[$var_cb83972b]['file'])) {
					$var_a4e608c2 = $var_cb83972b;
					$var_10635ff1 = $var_75d615f3[$var_a4e608c2];
					break;
				} 
			} 
		} 
		$var_bcb69771 = $var_80e56294[$var_a4e608c2]['count'] - 1;
	} 
	$var_99d419f9 = array($var_10635ff1, $var_bcb69771);
	if (!$GLOBALS['callnew_title']) $GLOBALS['cache_filelist_urlid'][$var_22b9b1a4] = $var_99d419f9;
	return $var_99d419f9;
} 
function func_b0d73e82($var_10635ff1 = '', $var_39ae76d3 = '') {
	$var_071730f9 = preg_replace('~^www\\.~', '', $_SERVER['HTTP_HOST']);
	$var_071730f9 = preg_replace('~^' . config('domain.mobile_prefix') . '\\.~', '', $var_071730f9);
	!$var_39ae76d3 && $var_39ae76d3 = $var_071730f9;
	$var_a3e5f0ff = $var_39ae76d3 . $var_10635ff1;
	$var_a3e5f0ff = preg_replace('~[^\\d]+~', '', md5($var_a3e5f0ff));
	return intval(substr($var_a3e5f0ff, 0, 6));
} 
function func_3985a6b0($var_907250fa = 8, $var_7c6c92b4 = 3) {
	switch ($var_7c6c92b4) {
		case '1' : $var_40db88e3 = 'abcdefghijklmnopqrstuvwxyz0123456789';
			break;
		case '2' : $var_40db88e3 = '123456789';
			break;
		case '3' : $var_40db88e3 = 'abcdefghijklmnopqrstuvwxyz';
			break;
		case '4' : $var_40db88e3 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
			break;
		case '5' : $var_40db88e3 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
			break;
		case '6' : $var_40db88e3 = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
			break;
		case '7' : $var_40db88e3 = 'abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
			break;
	} 
	$var_1c019175 = "";
	for ($var_7ea74e20 = 0 ; $var_7ea74e20 < $var_907250fa; ++$var_7ea74e20) {
		$var_1c019175 .= $var_40db88e3[rand(0, strlen($var_40db88e3) - 1)];
	} 
	return $var_1c019175;
} 
function func_bd68a3eb($var_afb1db68) {
	preg_match_all('~\\{([^\\}\\d]+)([\\d-]*)\\}~', $var_afb1db68, $var_973d74fe);
	foreach($var_973d74fe[1] as $var_228572b3 => $var_cb83972b) {
		$var_7c6c92b4 = $var_cb83972b;
		list($var_eef8baa2, $var_ad64fd3a) = explode('-', $var_973d74fe[2][$var_228572b3]);
		if ($var_ad64fd3a) {
			$var_907250fa = rand($var_eef8baa2, $var_ad64fd3a);
		} else {
			$var_907250fa = $var_eef8baa2;
		} 
		$var_40db88e3 = $var_973d74fe[0][$var_228572b3];
		switch ($var_7c6c92b4) {
			case '数字': $var_40db88e3 = func_3985a6b0($var_907250fa, 2);
				break;
			case '字母': $var_40db88e3 = func_3985a6b0($var_907250fa, 3);
				break;
			case '大写字母': $var_40db88e3 = func_3985a6b0($var_907250fa, 4);
				break;
			case '大写字母数字': $var_40db88e3 = func_3985a6b0($var_907250fa, 5);
				break;
			case '大小写字母': $var_40db88e3 = func_3985a6b0($var_907250fa, 6);
				break;
			case '随机字符': $var_40db88e3 = func_3985a6b0($var_907250fa, 7);
				break;
			case '大小写字母数字': $var_40db88e3 = func_3985a6b0($var_907250fa, 7);
				break;
			case '数字字母': $var_40db88e3 = func_3985a6b0($var_907250fa, 1);
				break;
			case '日期': $var_40db88e3 = date('Ymd');
				break;
			case '年': $var_40db88e3 = date('Y');
				break;
			case '月': $var_40db88e3 = date('m');
				break;
			case '日': $var_40db88e3 = date('d');
				break;
			case '时': $var_40db88e3 = date('H');
				break;
			case '分': $var_40db88e3 = date('i');
				break;
			case '秒': $var_40db88e3 = date('s');
				break;
			case '随机关键词': $var_40db88e3 = func_f90fd28a('keywords');
				break;
		} 
		$var_afb1db68 = str_replace($var_973d74fe[0][$var_228572b3], $var_40db88e3, $var_afb1db68);
	} 
	return $var_afb1db68;
} 
function func_3eb3124f($var_afb1db68) {
	preg_match_all('~\\{([^\\}\\d]+)(\\d*)\\}~', $var_afb1db68, $var_973d74fe);
	foreach($var_973d74fe[1] as $var_228572b3 => $var_cb83972b) {
		$var_7c6c92b4 = $var_cb83972b;
		list($var_eef8baa2, $var_ad64fd3a) = explode('-', $var_973d74fe[2][$var_228572b3]);
		$var_907250fa = $var_ad64fd3a?$var_ad64fd3a:$var_eef8baa2;
		$var_40db88e3 = $var_973d74fe[0][$var_228572b3];
		$var_907250fa = max($var_973d74fe[2][$var_228572b3], 1);
		switch ($var_7c6c92b4) {
			case '数字': $var_40db88e3 = '\\d{' . $var_907250fa . '}';
				break;
			case '字母': $var_40db88e3 = '[a-z]{' . $var_907250fa . '}';
				break;
			case '数字字母': $var_40db88e3 = '[a-z,0-9]{' . $var_907250fa . '}';
				break;
			case '大写字母': $var_40db88e3 = '[A-Z]{' . $var_907250fa . '}';
				break;
			case '大写字母数字': $var_40db88e3 = '[A-Z,0-9]{' . $var_907250fa . '}';
				break;
			case '大小写字母': $var_40db88e3 = '[a-z,A-Z]{' . $var_907250fa . '}';
				break;
			case '大小写字母数字': $var_40db88e3 = '[a-z,A-Z,0-9]{' . $var_907250fa . '}';
				break;
			case '随机字符': $var_40db88e3 = '[a-z,A-Z,0-9]{' . $var_907250fa . '}';
				break;
			case '日期': $var_40db88e3 = '201[0-9]';
				break;
			case '年': $var_40db88e3 = 2;
				break;
			case '月': $var_40db88e3 = '\\d{1,2}';
				break;
			case '日': $var_40db88e3 = '\\d{1,2}';
				break;
			case '时': $var_40db88e3 = '\\d{1,2}';
				break;
			case '分': $var_40db88e3 = '\\d{2}';
				break;
			case '秒': $var_40db88e3 = '\\d{2}';
				break;
		} 
		$var_afb1db68 = str_replace($var_973d74fe[0][$var_228572b3], $var_40db88e3, $var_afb1db68);
	} 
	return $var_afb1db68;
} 
function func_dfe3da17($var_5cda4baf = true) {
	if (!empty($_SERVER["REQUEST_URI"])) {
		$var_1d4efb1a = $_SERVER["REQUEST_URI"];
		$var_063d7203 = $var_1d4efb1a;
	} else {
		$var_1d4efb1a = $_SERVER["PHP_SELF"];
		if (empty($_SERVER["QUERY_STRING"])) {
			$var_063d7203 = $var_1d4efb1a;
		} else {
			$var_063d7203 = $var_1d4efb1a . '?' . $_SERVER["QUERY_STRING"];
		} 
	} 
	$var_063d7203 = preg_replace('~^https?://[^/]+/~', '/', $var_063d7203);
	return ($var_5cda4baf?(DEFINE_MY_3 . $_SERVER['HTTP_HOST']):'') . $var_063d7203;
} 
function func_ea2e0618($var_907250fa = 50) {
	if (!$var_907250fa) return false;
	$var_fef2c155 = array();
	for($var_7ea74e20 = 0;$var_7ea74e20 < 100;$var_7ea74e20++) {
		$var_fef2c155[] = 0;
	} 
	for($var_7ea74e20 = 0;$var_7ea74e20 < $var_907250fa;$var_7ea74e20++) {
		$var_fef2c155[$var_7ea74e20] = 1;
	} 
	shuffle($var_fef2c155);
	$var_54767044 = false;
	$var_6556bc88 = array_rand($var_fef2c155, 1);
	if ($var_fef2c155[$var_6556bc88] == 1) {
		$var_54767044 = true;
	} 
	return $var_54767044;
} 
function func_28b50565($var_1003d5bb, $var_498f47b6 = 10) {
	import('class/Http');
	$var_8251eda0 = new Http();
	$var_8251eda0 -> func_7fef4f3b = $var_498f47b6;
	$var_332fc2f2 = rand(13, 255) . '.' . rand(13, 255) . '.' . rand(13, 255) . '.' . rand(13, 255);
	$var_8251eda0 -> func_5d0a4796('X-FORWARDED-FOR', $var_332fc2f2);
	$var_8251eda0 -> func_5d0a4796('CLIENT-IP', $var_332fc2f2);
	$var_8251eda0 -> func_5d0a4796('Referer', $var_1003d5bb);
	$var_8251eda0 -> func_5d0a4796('Cookie', '');
	$var_8251eda0 -> func_5d0a4796('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.2; SV1; Maxthon; .NET CLR 1.1.4322)');
	$var_8251eda0 -> func_ff1f28a7 = $var_1003d5bb;
	session_write_close();
	$var_8251eda0 -> func_d80f7f6b();
	if ($var_8251eda0 -> func_9228f088() != '200') {
		return false;
	} 
	$html = $var_8251eda0 -> func_1a559174;
	if (!func_558b2255($html)) {
		$html = func_4f521b6d($html);
	} 
	return $html;
} 
function func_a6aabd8f($var_40db88e3) {
	$var_40db88e3 = preg_replace('~^[\\s]+~', '', $var_40db88e3);
	$var_40db88e3 = preg_replace('~[\\s]+$~', '', $var_40db88e3);
	$var_40db88e3 = preg_replace('~[\\r\\n\\t\\s ]+~s', '', $var_40db88e3);
	return $var_40db88e3;
} 
function func_64d0f4f3($var_7c6c92b4 = '') {
	$var_2b448a8a = TEMP_PATH . 'theme_config.php';
	if ($var_7c6c92b4) {
		if (is_file($var_2b448a8a)) {
			return require($var_2b448a8a);
		} 
		$var_4eda73b5 = TMPL_PATH . $var_7c6c92b4;
		$var_ff44612c = func_9193adfb($var_4eda73b5);
		$var_ff44612c = array_slice($var_ff44612c, 2);
		foreach($var_ff44612c as $var_228572b3 => $var_cb83972b) {
			$var_ff44612c[$var_228572b3] = $var_7c6c92b4 . '/' . $var_cb83972b;
		} 
	} else {
		$var_36a0b2a2 = txtDB('arctype') -> select();
		$var_ff44612c = $var_b1e87390 = array();
		foreach($var_36a0b2a2 as $var_228572b3 => $var_cb83972b) {
			$var_b1e87390[] = $var_cb83972b['dirname'];
			$var_b1e87390[] = $var_cb83972b['dirname'] . '_mobile';
			$var_b1e87390[] = $var_cb83972b['dirname'] . '_mip';
		} 
		foreach($var_b1e87390 as $var_228572b3 => $var_cb83972b) {
			$var_1e649227 = $var_cb83972b;
			$var_4eda73b5 = TMPL_PATH . $var_1e649227;
			if (!is_dir($var_4eda73b5)) {
				continue;
			} 
			$var_586a20ab = func_9193adfb($var_4eda73b5);
			$var_586a20ab = array_slice($var_586a20ab, 2);
			if ($var_586a20ab) {
				foreach($var_586a20ab as $var_3d9151c4 => $var_1076c777) {
					$var_586a20ab[$var_3d9151c4] = $var_1e649227 . '/' . $var_1076c777;
				} 
				$var_ff44612c = $var_ff44612c?array_merge($var_ff44612c, $var_586a20ab):$var_586a20ab;
			} 
		} 
	} 
	$var_734b79d1 = array();
	foreach($var_ff44612c as $var_228572b3 => $var_cb83972b) {
		$var_734b79d1[$var_cb83972b] = '';
	} 
	if (is_file($var_2b448a8a)) {
		$var_6ac11d7b = require($var_2b448a8a);
		$var_6ac11d7b = array_merge($var_734b79d1, $var_6ac11d7b);
	} else {
		$var_6ac11d7b = $var_734b79d1;
	} 
	foreach($var_6ac11d7b as $var_228572b3 => $var_cb83972b) {
		if (!is_file(TMPL_PATH . $var_228572b3 . '/index.html')) {
			unset($var_6ac11d7b[$var_228572b3]);
			continue;
		} 
	} 
	func_3c22ed21($var_2b448a8a, $var_6ac11d7b);
	write(LOG_PATH . 'scantheme.log', time());
	return $var_6ac11d7b;
} 
function func_4a8cb101($var_d089e8c2, $var_df56ffa6, $var_caf118e7 = 'utf-8') {
	if (!isset($GLOBALS['insertkw2title'])) $GLOBALS['insertkw2title'] = 1;
	if ($var_d089e8c2 == '') {
		return $var_df56ffa6;
	} 
	$var_5fd387f1 = iconv_strlen($var_d089e8c2, $var_caf118e7);
	$var_f1b24c1b = strlen($var_df56ffa6);
	$var_322df623 = $var_f1b24c1b % $GLOBALS['insertkw2title'];
	$var_28de5dd7 = ceil($var_5fd387f1 / $var_322df623);
	$var_e1003d5f = iconv_substr($var_d089e8c2, 0, $var_28de5dd7, $var_caf118e7);
	$var_13f5b496 = iconv_substr($var_d089e8c2, $var_28de5dd7, $var_5fd387f1, $var_caf118e7);
	$var_d089e8c2 = $var_e1003d5f . $var_df56ffa6 . $var_13f5b496;
	$GLOBALS['insertkw2title']++;
	return $var_d089e8c2;
} 
function func_d24a35d7($var_315cb629, $var_adf77612 = '') {
	if (preg_match('~^//[\\w]+\\.[\\w\\.]+/~', $var_315cb629) && $var_adf77612) {
		$var_9c720f54 = parse_url($var_adf77612);
		$var_315cb629 = $var_9c720f54['scheme'] . ':' . $var_315cb629;
	} 
	if (!$var_adf77612) return $var_315cb629;
	$var_9c720f54 = parse_url($var_adf77612);
	if (substr($var_315cb629, 0, 1) == '?') {
		$var_315cb629 = $var_9c720f54['path'] . $var_315cb629;
	} 
	$var_6e81ab0c = parse_url($var_315cb629);
	if (isset($var_6e81ab0c['scheme'])) {
		return $var_315cb629;
	} 
	if (stripos($var_9c720f54['path'], '.') === false && stripos($var_9c720f54['path'], '?') === false) $var_9c720f54['path'] .= '/1';
	$var_1003d5bb = $var_9c720f54['scheme'] . '://' . $var_9c720f54['host'];
	if ($var_9c720f54['port']) {
		$var_1003d5bb .= ':' . $var_9c720f54['port'];
	} 
	if (substr($var_6e81ab0c['path'], 0, 1) == '/') {
		$var_4eda73b5 = $var_6e81ab0c['path'];
	} else {
		$var_4eda73b5 = dirname($var_9c720f54['path']) . '/' . $var_6e81ab0c['path'];
	} 
	$var_6a14d1cb = array();
	$var_93007bc9 = explode('/', $var_4eda73b5);
	if (!$var_93007bc9[0]) {
		$var_6a14d1cb[] = '';
	} 
	foreach ($var_93007bc9 AS $var_6cbe6605 => $var_fae1bb2a) {
		if ($var_fae1bb2a == '..') {
			if (end($var_6a14d1cb) == '..') {
				$var_6a14d1cb[] = '..';
			} elseif (!array_pop($var_6a14d1cb)) {
				$var_6a14d1cb[] = '..';
			} 
		} elseif ($var_fae1bb2a && $var_fae1bb2a != '.') {
			$var_6a14d1cb[] = $var_fae1bb2a;
		} 
	} 
	if (!end($var_93007bc9)) {
		$var_6a14d1cb[] = '';
	} 
	$var_1003d5bb .= implode('/', $var_6a14d1cb);
	$var_1003d5bb = str_replace('\\', '/', $var_1003d5bb);
	$var_1003d5bb = preg_replace('~([\\w]+)/{2,}~', '\\1/', $var_1003d5bb);
	if (isset($var_6e81ab0c['query'])) $var_1003d5bb .= '?' . $var_6e81ab0c['query'];
	return $var_1003d5bb;
} 
function func_6d71dea8($html, $var_adf77612 = '') {
	preg_match_all('#<img[^>]*src\\s*=\\s*(["|\']*)([\\w/].+)["\']*[> 
	]{1,}#isU', $html, $var_5f5e702e);
	if ($var_5f5e702e) {
		$var_586a20ab = array();
		foreach($var_5f5e702e[2] as $var_228572b3 => $var_cb83972b) {
			$var_cb83972b = str_replace(array('"', '\''), '', $var_cb83972b);
			if ($var_adf77612) $var_cb83972b = func_d24a35d7($var_cb83972b, $var_adf77612);
			$var_586a20ab[] = $var_cb83972b;
		} 
		$var_5f5e702e = array_unique($var_586a20ab);
		return $var_586a20ab;
	} 
	return false;
} 
function func_d7cb71a0($var_1003d5bb, $var_ba997e46 = false) {
	$var_cdb17625 = strtolower(md5($var_1003d5bb));
	$var_980a7c7e = TEMP_PATH . 'cache_collecturl/' . getHashDir($var_6cbe6605, 2) . '/' . substr($var_cdb17625, 0, 2) . '.txt';
	if (!is_file($var_980a7c7e)) {
		if ($var_ba997e46) write($var_980a7c7e, $var_cdb17625 . '
');
		return false;
	} 
	$var_8eafab80 = file_get_contents($var_980a7c7e);
	if (strpos($var_8eafab80, $var_cdb17625) > - 1) {
		return true;
	} 
	if ($var_ba997e46) write($var_980a7c7e, $var_cdb17625 . '
', 'a+');
	return false;
} 
function func_3b2fa4cf($var_0b4dc8c4, $var_a47a5c70 = 0, $var_afb1db68) {
	$var_8bb5268f = $var_0b4dc8c4['url'];
	$var_6852b2cf = $var_0b4dc8c4['urlregx'];
	$var_196b0b66 = $var_afb1db68['maxnum'];
	$var_04b81daf = '~<a[^>]+href\\s*=\\s*(["|\']*)([\\w/\\.].*)["\' 
	][^>]*>(.*)</a>~iUs';
	$var_d4fc5ace = $var_3ba1d834 = array();
	if ($var_afb1db68['sift_words']) {
		$var_d4fc5ace = explode('
', $var_afb1db68['sift_words']);
		$var_d4fc5ace = array_map('trim', $var_d4fc5ace);
	} 
	if ($var_afb1db68['replace_words']) {
		$var_3ba1d834 = explode('
', $var_afb1db68['replace_words']);
		$var_3ba1d834 = array_map('trim', $var_3ba1d834);
	} 
	foreach($var_8bb5268f as $var_228572b3 => $var_cb83972b) {
		$var_7d1800bf = $var_cb83972b;
		$html = func_28b50565($var_cb83972b);
		if (preg_match_all($var_04b81daf, $html, $var_973d74fe)) {
			$var_186934fa = func_6f42332b($var_6852b2cf[$var_228572b3]);
			$var_5a24a0fa = $var_afb1db68['min_num']?$var_afb1db68['min_num']:30;
			$var_2407a687 = array();
			foreach($var_973d74fe[2] as $var_6cbe6605 => $var_2ddd548e) {
				$var_1003d5bb = func_a6aabd8f($var_2ddd548e);
				list($var_1003d5bb,) = explode('#', $var_1003d5bb);
				$var_1003d5bb = func_d24a35d7($var_1003d5bb, $var_cb83972b);
				if ($var_186934fa && !preg_match('~^' . $var_186934fa . '$~i', $var_1003d5bb)) {
					continue;
				} 
				$var_d089e8c2 = strip_tags($var_973d74fe[3][$var_6cbe6605]);
				$var_d089e8c2 = preg_replace('~\\s+~', ' ', $var_d089e8c2);
				if (func_bd6dd0d8($var_d089e8c2)) {
					continue;
				} 
				if (preg_match('~\\~', $var_d089e8c2)) {
					continue;
				} 
				if (preg_match('~\'~', $var_d089e8c2)) {
					continue;
				} 
				$var_d089e8c2 = preg_replace('~^\\d{2}-\\d{2}~', '', $var_d089e8c2);
				if ($var_afb1db68['body_filter_regx']) {
					$var_beba630c = explode('
', $var_afb1db68['body_filter_regx']);
					foreach($var_beba630c as $var_04b81daf) {
						$var_04b81daf = trim($var_04b81daf);
						if ($var_04b81daf == '') continue;
						$var_d089e8c2 = preg_replace('~' . $var_04b81daf . '~Us', '', $var_d089e8c2);
					} 
				} 
				if ($var_d4fc5ace) {
					foreach($var_d4fc5ace as $var_3d9151c4 => $var_1076c777) {
						if (!$var_1076c777) continue;
						if (substr($var_1076c777, 0, 1) == '*') {
							$var_d089e8c2 = str_replace(substr($var_1076c777, 1), '', $var_d089e8c2);
							continue;
						} 
						if (strpos($var_d089e8c2, $var_1076c777) !== false) {
							continue 2;
						} 
					} 
				} 
				if ($var_3ba1d834) {
					foreach($var_3ba1d834 as $var_3d9151c4 => $var_1076c777) {
						if (!$var_1076c777) continue;
						list($var_55df87ba, $var_7c3e9a74) = explode('=', $var_1076c777);
						if (strpos($var_7c3e9a74, ',') > - 1) {
							$var_865a966f = explode(',', $var_7c3e9a74);
							shuffle($var_865a966f);
							$var_7c3e9a74 = trim($var_865a966f[0]);
						} 
						$var_d089e8c2 = str_replace($var_55df87ba, $var_7c3e9a74, $var_d089e8c2);
					} 
				} 
				if (func_d7cb71a0($var_d089e8c2)) {
					$GLOBALS['collect_repeatnum']++;
					continue;
				} 
				if ($var_d089e8c2 && strlen($var_d089e8c2) >= $var_5a24a0fa && strlen($var_d089e8c2) < 100) {
					func_d7cb71a0($var_d089e8c2, true);
					$var_2407a687[] = $var_d089e8c2;
				} 
			} 
			$var_2407a687 = array_unique($var_2407a687);
			if ($var_2407a687) {
				$var_2407a687 = array_flip(array_flip($var_2407a687));
				shuffle($var_2407a687);
				$var_a47a5c70 += count($var_2407a687);
			} 
			!$var_afb1db68['savetype'] && $var_afb1db68['savetype'] = 'title';
			$var_cd0d7a34 = func_8dfc96dd($var_afb1db68['savetype'], $var_afb1db68['dirname'], trim(implode('
', $var_2407a687)));
			if ($var_196b0b66 && $var_a47a5c70 >= $var_196b0b66) {
				break;
			} 
		} 
	} 
	return $var_a47a5c70;
} 
function func_7a275322($var_0b4dc8c4, $var_a47a5c70 = 0, $var_afb1db68) {
	$var_8bb5268f = $var_0b4dc8c4['url'];
	$var_6852b2cf = $var_0b4dc8c4['urlregx'];
	$var_196b0b66 = $var_afb1db68['maxnum'];
	foreach($var_8bb5268f as $var_228572b3 => $var_cb83972b) {
		$var_7d1800bf = $var_cb83972b;
		$html = func_28b50565($var_7d1800bf);
		$var_c5224860 = func_6d71dea8($html, $var_cb83972b);
		$var_186934fa = func_6f42332b($var_6852b2cf[$var_228572b3]);
		if ($var_c5224860) {
			foreach($var_c5224860 as $var_3d9151c4 => $var_1076c777) {
				if ($var_186934fa && !preg_match('~^' . $var_186934fa . '$~i', $var_1076c777)) {
					unset($var_c5224860[$var_3d9151c4]);
				} 
			} 
			$var_a47a5c70 += count($var_c5224860);
			$var_cd0d7a34 = func_8dfc96dd('pic', $var_afb1db68['dirname'], trim(implode('
', $var_c5224860)));
			if ($var_196b0b66 && $var_a47a5c70 >= $var_196b0b66) {
				break;
			} 
		} 
	} 
	return $var_a47a5c70;
} 
function func_c5872f51($var_40db88e3) {
	$var_aa7f2390 = array('原标题：', '来源：', '责任编辑');
	foreach($var_aa7f2390 as $var_228572b3 => $var_cb83972b) {
		if (strpos($var_40db88e3, $var_cb83972b)) {
			return true;
		} 
	} 
	return false;
} 
function func_bd6dd0d8($var_d089e8c2) {
	$var_beba630c = array('备\\d+', '字\\d+号$');
	foreach($var_beba630c as $var_228572b3 => $var_cb83972b) {
		if (preg_match('~' . $var_cb83972b . '~Us', $var_d089e8c2)) {
			return true;
		} 
	} 
	$var_aa7f2390 = array('资格证书', '℃', '京网文', '服务许可', '新浪互联', '业务审批', '刷新', '免费下载', '免费送', '经营许', '热线', '公网安备', '许可证', '网站联合', '卫网审', '经营性-', '注册', '举报', '留言板', '二维码', '\'', '&nbsp;', '+', 'document.');
	foreach($var_aa7f2390 as $var_228572b3 => $var_cb83972b) {
		if (strpos($var_d089e8c2, $var_cb83972b)) {
			return true;
		} 
	} 
	return false;
} 
function func_12361f5f($var_8bb5268f, $var_a47a5c70 = 0) {
	if (!$var_8bb5268f) return false;
	$var_afb1db68 = $GLOBALS['collect_rules'];
	$var_196b0b66 = $var_afb1db68['maxnum'];
	$var_d4fc5ace = $var_3ba1d834 = array();
	if ($var_afb1db68['sift_words']) {
		$var_d4fc5ace = explode('
', $var_afb1db68['sift_words']);
		$var_d4fc5ace = array_map('trim', $var_d4fc5ace);
	} 
	if ($var_afb1db68['replace_words']) {
		$var_3ba1d834 = explode('
', $var_afb1db68['replace_words']);
		$var_3ba1d834 = array_map('trim', $var_3ba1d834);
	} 
	foreach($var_8bb5268f as $var_228572b3 => $var_cb83972b) {
		$var_7d1800bf = $var_cb83972b;
		$html = func_28b50565($var_7d1800bf);
		if (!$html) {
			continue;
		} 
		$var_218cf044 = 0;
		$var_04b81daf = '~<a[^>]+href\\s*=\\s*(["|\']*)([\\w/\\.].*)["\' 
	][^>]*>(.*)</a>~iUs';
		if (preg_match_all($var_04b81daf, $html, $var_973d74fe)) {
			$var_186934fa = func_6f42332b($var_afb1db68['regxurl_show2']);
			$var_5a24a0fa = $var_afb1db68['min_num']?$var_afb1db68['min_num']:30;
			foreach($var_973d74fe[2] as $var_3d9151c4 => $var_1076c777) {
				$var_1003d5bb = func_a6aabd8f($var_1076c777);
				list($var_1003d5bb,) = explode('#', $var_1003d5bb);
				$var_1003d5bb = func_d24a35d7($var_1003d5bb, $var_cb83972b);
				if ($var_186934fa && !preg_match('~^' . $var_186934fa . '$~i', $var_1003d5bb)) {
					continue;
				} 
				$var_d089e8c2 = strip_tags($var_973d74fe[3][$var_3d9151c4]);
				$var_d089e8c2 = preg_replace('~\\s+~', ' ', $var_d089e8c2);
				if (func_bd6dd0d8($var_d089e8c2)) {
					continue;
				} 
				if ($var_afb1db68['body_filter_regx']) {
					$var_beba630c = explode('
', $var_afb1db68['body_filter_regx']);
					foreach($var_beba630c as $var_04b81daf) {
						$var_04b81daf = trim($var_04b81daf);
						if ($var_04b81daf == '') continue;
						$var_d089e8c2 = preg_replace('~' . $var_04b81daf . '~Us', '', $var_d089e8c2);
					} 
				} 
				if ($var_d4fc5ace) {
					foreach($var_d4fc5ace as $var_ff05c232 => $var_73bb3a5d) {
						if (substr($var_73bb3a5d, 0, 1) == '*') {
							$var_d089e8c2 = str_replace(substr($var_73bb3a5d, 1), '', $var_d089e8c2);
							continue;
						} 
						if (strpos($var_d089e8c2, $var_73bb3a5d) !== false) {
							continue 2;
						} 
					} 
				} 
				if ($var_3ba1d834) {
					foreach($var_3ba1d834 as $var_3d9151c4 => $var_1076c777) {
						if (!$var_1076c777) continue;
						list($var_55df87ba, $var_7c3e9a74) = explode('=', $var_1076c777);
						if (strpos($var_7c3e9a74, ',') > - 1) {
							$var_865a966f = explode(',', $var_7c3e9a74);
							shuffle($var_865a966f);
							$var_7c3e9a74 = trim($var_865a966f[0]);
						} 
						$var_d089e8c2 = str_replace($var_55df87ba, $var_7c3e9a74, $var_d089e8c2);
					} 
				} 
				if (func_d7cb71a0($var_d089e8c2)) {
					$GLOBALS['collect_repeatnum']++;
					continue;
				} 
				if ($var_d089e8c2 && strlen($var_d089e8c2) >= $var_5a24a0fa && strlen($var_d089e8c2) < 100) {
					func_d7cb71a0($var_d089e8c2, true);
					$var_2407a687[] = $var_d089e8c2;
				} 
			} 
		} 
		$var_2407a687 = array_unique($var_2407a687);
		if ($var_2407a687) {
			$var_2407a687 = array_flip(array_flip($var_2407a687));
			$var_a47a5c70 += count($var_2407a687);
		} 
		if ($var_2407a687 && $var_afb1db68['replace_naipan']) {
			$var_3b835166 = implode('******', $var_2407a687);
			$var_1c019175 = func_ca6476e6($var_3b835166);
			if ($var_1c019175['status']) {
				$var_2407a687 = explode('******', $var_1c019175['body']);
			} 
		} 
		!$var_afb1db68['savetype'] && $var_afb1db68['savetype'] = 'title';
		$var_cd0d7a34 = func_8dfc96dd($var_afb1db68['savetype'], $var_afb1db68['dirname'], trim(implode('
', $var_2407a687)));
		if ($var_196b0b66 && $var_a47a5c70 >= $var_196b0b66) {
			break;
		} 
	} 
	return $var_a47a5c70;
} 
function func_5be97940($var_8bb5268f, $var_04b81daf, $var_a47a5c70 = 0, $var_196b0b66 = 0) {
	if (!$var_8bb5268f) return false;
	$var_afb1db68 = $GLOBALS['collect_rules'];
	$GLOBALS['collect_repeatnum'] = 0;
	$var_d4fc5ace = $var_3ba1d834 = array();
	if ($var_afb1db68['sift_words']) {
		$var_d4fc5ace = explode('
', $var_afb1db68['sift_words']);
		$var_d4fc5ace = array_map('trim', $var_d4fc5ace);
	} 
	if ($var_afb1db68['replace_words']) {
		$var_3ba1d834 = explode('
', $var_afb1db68['replace_words']);
		$var_3ba1d834 = array_map('trim', $var_3ba1d834);
	} 
	foreach($var_8bb5268f as $var_228572b3 => $var_cb83972b) {
		$var_7d1800bf = $var_cb83972b;
		if (func_d7cb71a0($var_7d1800bf)) {
			$GLOBALS['collect_repeatnum']++;
			continue;
		} 
		$html = func_28b50565($var_7d1800bf);
		if (!$html) {
			continue;
		} 
		$var_218cf044 = 0;
		$var_beba630c = explode('
', $var_04b81daf);
		$var_8eafab80 = '';
		foreach($var_beba630c as $var_3d9151c4 => $var_1076c777) {
			$var_1076c777 = trim($var_1076c777);
			if (preg_match('~' . $var_1076c777 . '~Us', $html, $var_973d74fe)) {
				$var_8eafab80 = $var_973d74fe[1];
				break;
			} 
		} 
		$var_8eafab80 = trim($var_8eafab80);
		if ($var_afb1db68['replace_naipan']) {
			$var_1c019175 = func_ca6476e6($var_8eafab80);
			if ($var_1c019175['status']) {
				$var_8eafab80 = $var_1c019175['body'];
			} 
		} 
		if ($var_8eafab80) {
			if ($var_afb1db68['body_filter_regx']) {
				$var_ff85d3b9 = explode('
', $var_afb1db68['body_filter_regx']);
				foreach($var_ff85d3b9 as $var_04b81daf) {
					$var_04b81daf = trim($var_04b81daf);
					if ($var_04b81daf == '') continue;
					$var_8eafab80 = preg_replace('~' . $var_04b81daf . '~Us', '', $var_8eafab80);
				} 
			} 
			if ($var_5f5e702e = func_6d71dea8($var_8eafab80)) {
				foreach($var_5f5e702e as $var_05c594b9) {
					$var_15661e48 = func_d24a35d7($var_05c594b9, $var_7d1800bf);
					$var_8eafab80 = str_replace($var_05c594b9, $var_15661e48, $var_8eafab80);
					$var_341269ae[] = $var_15661e48;
				} 
				if (config('collect_getpic')) {
					func_8dfc96dd('pic', $var_afb1db68['dirname'], implode('
', $var_341269ae) . '
');
				} 
			} 
			$var_5a24a0fa = $var_afb1db68['min_num']?$var_afb1db68['min_num']:40;
			if ($var_afb1db68['split']) {
				$var_218cf044 = $GLOBALS['split_scount'];
				$var_7346876d = $var_afb1db68['lang'] == 'en'?true:false;
				$var_8eafab80 = func_9afb6ee1($var_8eafab80, $var_5a24a0fa, $var_7346876d);
				$var_8259652f = $var_afb1db68['split'] == '2'?'duanzi':'content';
				$var_cd0d7a34 = func_8dfc96dd($var_8259652f, $var_afb1db68['dirname'], trim($var_8eafab80) . '
', $var_d4fc5ace, $var_3ba1d834, $var_5a24a0fa);
			} else {
				$var_d089e8c2 = func_229d8716($html);
				if (strlen($var_d089e8c2) > 100 || strlen($var_d089e8c2) < 10) {
					continue;
				} 
				$var_8eafab80 = func_2bd6b23a($var_8eafab80);
				$var_d089e8c2 && $var_8eafab80 = $var_d089e8c2 . '******' . $var_8eafab80;
				$var_cd0d7a34 = func_8dfc96dd('body', $var_afb1db68['dirname'], trim($var_8eafab80) . '
', $var_d4fc5ace, $var_3ba1d834, $var_5a24a0fa);
				$var_218cf044 = 1;
			} 
			if ($var_cd0d7a34) {
				$var_a47a5c70 += $var_218cf044;
			} 
			func_d7cb71a0($var_7d1800bf, true);
			if ($var_196b0b66 && $var_a47a5c70 >= $var_196b0b66) {
				break;
			} 
		} 
	} 
	return $var_a47a5c70;
} 
function func_9afb6ee1($var_8eafab80, $var_5a24a0fa, $var_7346876d = false) {
	$var_afb1db68 = $GLOBALS['collect_rules'];
	if ($var_afb1db68['split'] == 2) {
		$var_8eafab80 = str_replace('</p>', '**_**', $var_8eafab80);
		$var_8eafab80 = str_replace(array('
', '
', '
'), '', strip_tags($var_8eafab80));
		$var_36945d7e = '
';
	} else {
		$var_8eafab80 = str_replace(array('
', '
', '
'), '', strip_tags($var_8eafab80));
		$var_8eafab80 = str_replace(array('"', '’', '“', '”', '\''), '', $var_8eafab80);
		if ($var_7346876d) {
			$var_8eafab80 = str_replace(array(',', '.'), '**_**', $var_8eafab80);
			$var_36945d7e = '.
';
		} else {
			$var_8eafab80 = str_replace(array('；', '。', '！'), '**_**', $var_8eafab80);
			$var_36945d7e = '。
';
		} 
	} 
	$var_8eafab80 = preg_replace('~\\s+~', ' ', $var_8eafab80);
	$var_586a20ab = explode('**_**', $var_8eafab80);
	foreach($var_586a20ab as $var_3d9151c4 => $var_1076c777) {
		$var_586a20ab[$var_3d9151c4] = trim($var_586a20ab[$var_3d9151c4]);
		if (strlen($var_1076c777) < $var_5a24a0fa) {
			unset($var_586a20ab[$var_3d9151c4]);
			continue;
		} 
		if (preg_match('~https?://[\\w-]+\\.[\\w-]+\\.~i', $var_586a20ab[$var_3d9151c4])) {
			unset($var_586a20ab[$var_3d9151c4]);
			continue;
		} 
		$var_586a20ab[$var_3d9151c4] = preg_replace('~&\\w+;~', '', $var_586a20ab[$var_3d9151c4]);
		if (func_c5872f51($var_586a20ab[$var_3d9151c4])) {
			continue;
		} 
		if (preg_match('~\\{\\s*[\\w-]+:~i', $var_586a20ab[$var_3d9151c4])) {
			unset($var_586a20ab[$var_3d9151c4]);
			continue;
		} 
	} 
	!$var_afb1db68['split_content_num'] && $var_afb1db68['split_content_num'] = 1;
	if ($var_afb1db68['split_content_num'] > 1) {
		$var_a7269200 = array();
		$var_7ea74e20 = 0;
		$var_586a20ab = array_values($var_586a20ab);
		foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
			$var_4ef34282 = $var_228572b3 + 1;
			$var_a7269200[$var_7ea74e20] .= $var_cb83972b . '，';
			if ($var_4ef34282 % $var_afb1db68['split_content_num'] == 0) {
				$var_a7269200[$var_7ea74e20] = trim($var_a7269200[$var_7ea74e20], '，');
				$var_7ea74e20++;
			} 
		} 
		$var_586a20ab = $var_a7269200;
	} 
	$GLOBALS['split_scount'] = count($var_586a20ab);
	if (ACTION_NAME != 'test_body') shuffle($var_586a20ab);
	$var_586a20ab = array_flip(array_flip($var_586a20ab));
	return implode($var_36945d7e, $var_586a20ab);
} 
function func_9b765bfa($var_10635ff1) {
	if (!config('localpic')) {
		return func_50afa725('pic', $var_10635ff1);
	} 
	$var_ab3c5f0e = DEFINE_MY_3 . $_SERVER['HTTP_HOST'];
	if (config('domain.url_prefix') == '2') {
		$var_ab3c5f0e = '';
	} 
	return $var_ab3c5f0e . '/uploads/images/' . $var_10635ff1 . '.jpg';
} 
function func_7f7b8a1f($var_f30669f7, $var_7c6c92b4 = 'title') {
	$var_f0c09750 = explode('
', $var_f30669f7);
	$var_e963a546 = array();
	foreach($var_f0c09750 as $var_3d9151c4 => $var_1076c777) {
		$var_dbda4786 = $var_1076c777;
		if ($var_7c6c92b4 == 'body') {
			list($var_dbda4786,) = explode('******', $var_1076c777);
		} 
		$var_dbda4786 = trim($var_dbda4786);
		if (isset($var_e963a546[$var_dbda4786])) {
			unset($var_f0c09750[$var_3d9151c4]);
		} 
		$var_e963a546[$var_dbda4786] = $var_3d9151c4;
	} 
	return implode('
', $var_f0c09750);
} 
function func_8dfc96dd($var_7c6c92b4, $var_1e649227, $var_8eafab80 = '', $var_d4fc5ace = array(), $var_3ba1d834 = array(), $var_5a24a0fa = 0) {
	$var_56201735 = $var_7c6c92b4;
	$var_7c6c92b4 == 'typename' && $var_56201735 = 'stitle';
	if ($var_d4fc5ace) {
		foreach($var_d4fc5ace as $var_228572b3 => $var_cb83972b) {
			if (substr($var_cb83972b, 0, 1) == '*') {
				$var_8eafab80 = str_replace(substr($var_cb83972b, 1), '', $var_8eafab80);
				continue;
			} else if (strpos($var_8eafab80, $var_cb83972b) !== false) {
				return false;
			} 
		} 
	} 
	if ($var_3ba1d834) {
		foreach($var_3ba1d834 as $var_3d9151c4 => $var_1076c777) {
			if (!$var_1076c777) continue;
			list($var_55df87ba, $var_7c3e9a74) = explode('=', $var_1076c777);
			if (strpos($var_7c3e9a74, ',') > - 1) {
				$var_865a966f = explode(',', $var_7c3e9a74);
				shuffle($var_865a966f);
				$var_7c3e9a74 = trim($var_865a966f[0]);
			} 
			$var_8eafab80 = str_replace($var_55df87ba, $var_7c3e9a74, $var_8eafab80);
		} 
	} 
	$var_75cc487e = false;
	$var_8eafab80 = func_7f7b8a1f($var_8eafab80, $var_7c6c92b4);
	if ($var_7c6c92b4 == 'body') {
		$var_2407a687 = array();
		$var_164ca0a4 = explode('
', $var_8eafab80);
		foreach($var_164ca0a4 as $var_228572b3 => $var_cb83972b) {
			list($var_d089e8c2, $var_5afc80a1) = explode('******', $var_cb83972b);
			$var_b7fcdf19 = func_6d71dea8($var_5afc80a1);
			if ($var_b7fcdf19) {
				$var_d089e8c2 .= '******' . $var_b7fcdf19[0];
			} 
			$var_2407a687[] = $var_d089e8c2;
		} 
		$var_6f70b704 = implode('
', $var_2407a687);
	} 
	foreach($var_1e649227 as $var_228572b3 => $var_cb83972b) {
		$var_fbfc1ddc = TEMP_PATH . 'cache_tempdb/interval.lock';
		$var_55a8da2c = config('collect_send_num_' . $var_7c6c92b4);
		if ($var_55a8da2c && config('collect_send_type') && in_array($var_7c6c92b4, array('title', 'body'))) {
			$var_1e05217c = TEMP_PATH . 'cache_tempdb/' . $var_cb83972b . '_' . $var_7c6c92b4 . '.txt';
			if (strlen($var_8eafab80) > $var_5a24a0fa) {
				write($var_1e05217c, trim($var_8eafab80) . '
', 'a+');
				$var_75cc487e = true;
			} 
			$var_3981be1b = true;
			if (is_file($var_fbfc1ddc) && config('collect_send_interval') > 0 && (filemtime($var_fbfc1ddc) + config('collect_send_interval')) > time()) {
				$var_3981be1b = false;
			} 
			if (is_file($var_1e05217c) && $var_3981be1b) {
				$var_f30669f7 = file_get_contents($var_1e05217c);
				$var_f30669f7 = func_7f7b8a1f($var_f30669f7, $var_7c6c92b4);
				$var_0310e890 = count(explode('
', $var_f30669f7));
				if ($var_0310e890 >= $var_55a8da2c) {
					$var_65b12a78 = DATA_PATH . $var_7c6c92b4 . '/' . $var_cb83972b . '/' . $var_56201735 . '-' . date('Y-m-d') . '.txt';
					$var_7ea74e20 = 1;
					while (is_file($var_65b12a78)) {
						$var_65b12a78 = DATA_PATH . $var_7c6c92b4 . '/' . $var_cb83972b . '/' . $var_56201735 . '-' . date('Y-m-d-' . $var_7ea74e20) . '.txt';
						$var_7ea74e20++;
					} 
					write($var_65b12a78, trim($var_f30669f7) . '
');
					func_aeff0c79($var_7c6c92b4, $var_cb83972b);
					if ($var_7c6c92b4 == 'body') {
						$var_04416560 = new SplFileObject($var_65b12a78, 'rb');
						$var_f1d13c7b = func_74bfd8c5($var_65b12a78);
						$var_f809eec7 = DATA_PATH . 'article/' . $var_cb83972b . '/' . basename($var_65b12a78);
						for($var_7ea74e20 = 0;$var_7ea74e20 < $var_f1d13c7b;$var_7ea74e20++) {
							$var_04416560 -> seek($var_7ea74e20);
							$var_4c8e8f67 = $var_04416560 -> current();
							list($var_d089e8c2, $var_5afc80a1) = explode('******', $var_4c8e8f67);
							$var_b7fcdf19 = func_6d71dea8($var_5afc80a1);
							if ($var_b7fcdf19) {
								$var_d089e8c2 .= '******' . $var_b7fcdf19[0];
							} 
							write($var_f809eec7, trim($var_d089e8c2) . '
', 'a+');
							$var_04416560 -> next();
						} 
					} 
					unlink($var_1e05217c);
					$var_75cc487e = true;
					continue;
				} 
			} 
			continue;
		} 
		$var_65b12a78 = DATA_PATH . $var_7c6c92b4 . '/' . $var_cb83972b . '/' . $var_56201735 . '-' . date('Y-m') . '.txt';
		$var_7ea74e20 = 1;
		$var_e656aee9 = $var_7c6c92b4 == 'body'?(1024 * 1024 * 20):(1024 * 1024 * 1);
		while (is_file($var_65b12a78) && filesize($var_65b12a78) > $var_e656aee9) {
			$var_65b12a78 = DATA_PATH . $var_7c6c92b4 . '/' . $var_cb83972b . '/' . $var_56201735 . '-' . date('Y-m' . $var_7ea74e20) . '.txt';
			$var_7ea74e20++;
		} 
		if (strlen($var_8eafab80) > $var_5a24a0fa) {
			if (is_file($var_65b12a78) and 1 == 2) {
				$var_67448fa1 = file_get_contents($var_65b12a78);
				$var_f0c09750 = explode('
', $var_8eafab80);
				$var_e963a546 = array();
				foreach($var_f0c09750 as $var_3d9151c4 => $var_1076c777) {
					$var_dbda4786 = $var_1076c777;
					if ($var_7c6c92b4 == 'body') {
						list($var_dbda4786,) = explode('******', $var_1076c777);
					} 
					$var_dbda4786 = trim($var_dbda4786);
					if (strpos($var_67448fa1, $var_dbda4786) > - 1) {
						unset($var_f0c09750[$var_3d9151c4]);
					} 
				} 
				$var_8eafab80 = implode('
', $var_f0c09750);
			} 
			write($var_65b12a78, trim($var_8eafab80) . '
', 'a+');
			if ($var_7c6c92b4 == 'body') {
				$var_f809eec7 = DATA_PATH . 'article/' . $var_cb83972b . '/' . basename($var_65b12a78);
				write($var_f809eec7, trim($var_6f70b704) . '
', 'a+');
			} 
			func_aeff0c79($var_7c6c92b4, $var_cb83972b);
			$var_75cc487e = true;
		} 
	} 
	return $var_75cc487e;
} 
function func_aeff0c79($var_7c6c92b4, $var_1e649227) {
	$var_1e649227 = trim($var_1e649227, '/');
	$var_38186e4a = TEMP_PATH . 'cache_filelist/' . $var_1e649227 . '/' . $var_7c6c92b4 . '_time.php';
	if ($var_7c6c92b4 == 'body') {
		$var_38186e4a = TEMP_PATH . 'cache_filelist/' . $var_1e649227 . '/article_time.php';
	} 
	if (is_file($var_38186e4a)) @unlink($var_38186e4a);
} 
function func_15a6c8df($var_64f25176, $var_d99537c3, $var_40db88e3, $var_e809cb79 = false, $var_10001fdb = false) {
	if ($var_40db88e3 == '') return '';
	if ($var_64f25176 == '' && $var_d99537c3 == '') return $var_40db88e3;
	if ($var_64f25176 == '' || $var_d99537c3 == '') return '';
	$var_5d9940b4 = explode($var_64f25176, $var_40db88e3);
	if ($var_5d9940b4[1]) {
		$var_4b0372f6 = explode($var_d99537c3, $var_5d9940b4[1]);
		$var_1c019175 = $var_4b0372f6[0];
		if ($var_e809cb79) $var_1c019175 = $var_64f25176 . $var_1c019175;
		if ($var_10001fdb) $var_1c019175 = $var_1c019175 . $var_d99537c3;
	} else {
		return '';
	} 
	return $var_1c019175;
} 
function func_8497e681($var_04b81daf, $var_40db88e3) {
	if (preg_match_all('~' . $var_04b81daf . '~iUs', $var_40db88e3, $var_973d74fe)) {
		return trim($var_973d74fe[1][0]);
	} 
	return false;
} 
function func_4638be96() {
	$var_f31eb8ad = '';
	$var_1bdc2630 = array();
	$var_50b89a7c = array();
	$var_07dbae79 = txtDB('domain') -> select();
	$var_d688deb2 = txtDB('arctype') -> select();
	$var_d688deb2 = func_809cbb58($var_d688deb2, 'id');
	func_3c22ed21(TEMP_PATH . 'arctype_config.php', $var_d688deb2);
	foreach($var_07dbae79 as $var_228572b3 => $var_cb83972b) {
		$var_119ad111 = DATA_PATH . 'domain/' . $var_cb83972b['dirname'] . '_domain.txt';
		$var_586a20ab = file($var_119ad111);
		foreach($var_586a20ab as $var_3d9151c4 => $var_1076c777) {
			$var_1076c777 = trim($var_1076c777);
			$var_50b89a7c[$var_1076c777] = array('id' => $var_cb83972b['id'], 'cid' => $var_cb83972b['cid'], 'dirname' => $var_cb83972b['dirname'], 'urltype' => $var_cb83972b['urltype'],);
			$var_f31eb8ad .= $var_1076c777 . '
';
		} 
	} 
	func_3c22ed21(TEMP_PATH . 'domaindb_config.php', $var_50b89a7c);
	if ($var_f31eb8ad) {
		write(DATA_PATH . 'domain.txt', trim($var_f31eb8ad));
	} 
} 
function func_3538d856($var_40db88e3) {
	return preg_replace('~(　| \\f\\r\\t\\n)+~', '', $var_40db88e3);
} 
function func_229d8716($html) {
	$var_d089e8c2 = func_8497e681('<title>(.*)</title>', $html);
	$var_d089e8c2 = preg_replace('/([-_\\|]+[^-_\\|]+)/is', '', $var_d089e8c2);
	return $var_d089e8c2;
} 
function func_ad8fbb99($var_5afc80a1) {
	$var_5afc80a1 = str_replace('#page#', '', $var_5afc80a1);
	return msubstr(func_3049735f(strip_tags($var_5afc80a1)), 0, 100, 'utf-8', '');
} 
function get_num_gd($var_7ea74e20, $var_4b82c1a5 = false) {
	if ($var_4b82c1a5) {
		$var_cdb17625 = md5($_SERVER['HTTP_HOST'] . $var_7ea74e20);
	} else {
		$var_cdb17625 = md5($_SERVER['QUERY_STRING'] . $var_7ea74e20);
	} 
	$var_24046c11 = preg_replace('~[^\\d]+~', '', $var_cdb17625);
	$var_24046c11 = str_repeat($var_24046c11, 10);
	return substr($var_24046c11, 0, $var_7ea74e20);
} 
function get_str_gd($var_7ea74e20, $var_4b82c1a5 = false) {
	if ($var_4b82c1a5) {
		$var_cdb17625 = sha1($_SERVER['HTTP_HOST'] . $var_7ea74e20);
	} else {
		$var_cdb17625 = sha1($_SERVER['QUERY_STRING'] . $var_7ea74e20);
	} 
	$var_24046c11 = str_repeat($var_cdb17625, 10);
	return strtoupper(substr($var_24046c11, 0, $var_7ea74e20));
} 
function get_product_num($var_6cbe6605) {
	$var_cdb17625 = strtoupper(md5($var_6cbe6605));
	$var_24046c11 = preg_replace('~[^\\d]+~', '', $var_cdb17625);
	$var_24046c11 = str_repeat($var_24046c11, 10);
	$var_24046c11 = str_replace('0', '', $var_24046c11);
	$var_907250fa = max(substr($var_24046c11, 2, 1), 3);
	$var_27c683fe = max(substr($var_24046c11, 4, 1), 3);
	return substr($var_cdb17625, 0, $var_907250fa) . '-' . substr($var_24046c11, 0, $var_27c683fe);
} 
function get_product_licence($var_bad6c929) {
	$var_edda95d2 = func_dfe3da17();
	$var_bad6c929 .= get_product_num($var_edda95d2);
	$var_a3e5f0ff = preg_replace('~^http://www\\.~', 'http://', $var_edda95d2);
	$var_a3e5f0ff = preg_replace('~^https?://' . config('domain.mobile_prefix') . '\\.~', 'http://', $var_a3e5f0ff);
	$var_a3e5f0ff = func_b0d73e82($var_a3e5f0ff);
	$var_586a20ab = array();
	for($var_7ea74e20 = 1;$var_7ea74e20 <= 8;$var_7ea74e20++) {
		$var_8eafab80 = func_50afa725('content', $var_a3e5f0ff . $var_7ea74e20);
		$var_586a20ab[] = func_90b6f187($var_bad6c929, $var_8eafab80);
	} 
	return '<p>' . implode('</p>', $var_586a20ab) . '</p>';
} 
function func_9324d7a8() {
	$var_071730f9 = preg_replace('~^www\\.~', '', $_SERVER['HTTP_HOST']);
	$var_071730f9 = preg_replace('~^' . config('domain.mobile_prefix') . '\\.~', '', $var_071730f9);
	$var_cdb17625 = md5($var_071730f9);
	$var_586a20ab = array();
	$var_a3e5f0ff = func_b0d73e82($var_cdb17625);
	$var_23a50764 = func_50afa725('common/guanming', $var_a3e5f0ff);
	$var_3420542b = func_50afa725('common/hangye', $var_a3e5f0ff);
	$var_672a3403 = func_50afa725('common/cpnsuffix', $var_a3e5f0ff);
	$var_3d805d29 = max($var_a3e5f0ff % 3, 2);
	$var_5d1be887 = func_50afa725('common/mzi', $var_a3e5f0ff);
	$var_5d1be887 = array_slice($var_5d1be887, 0, $var_3d805d29);
	$var_3e12376d = '';
	foreach($var_5d1be887 as $var_cb83972b) {
		$var_3e12376d .= trim($var_cb83972b);
	} 
	return $var_23a50764 . $var_3e12376d . $var_3420542b . $var_672a3403;
} 
function get_company_about($var_7c6c92b4 = false) {
	$var_071730f9 = preg_replace('~^www\\.~', '', $_SERVER['HTTP_HOST']);
	$var_071730f9 = preg_replace('~^' . config('domain.mobile_prefix') . '\\.~', '', $var_071730f9);
	$var_cdb17625 = md5($var_071730f9);
	$var_586a20ab = array();
	$var_a3e5f0ff = func_b0d73e82($var_cdb17625);
	for($var_7ea74e20 = 1;$var_7ea74e20 <= 20;$var_7ea74e20++) {
		$var_586a20ab[] = func_50afa725('common/qiyejianjie', $var_a3e5f0ff . $var_7ea74e20);
	} 
	if (!$var_7c6c92b4) {
		return msubstr(implode('', $var_586a20ab), 0, 200);
	} 
	$var_40db88e3 = '';
	foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
		$var_40db88e3 .= $var_cb83972b;
		if ($var_228572b3 % 4 == 0) {
			$var_40db88e3 .= '</p>
<p>';
		} 
	} 
	return $var_40db88e3;
} 
function func_6f42332b($var_1003d5bb) {
	$var_186934fa = str_replace('(*)', ',,,,', $var_1003d5bb);
	$var_186934fa = str_replace('(d)', '@@@@', $var_186934fa);
	$var_186934fa = str_replace('(w)', '%%%%', $var_186934fa);
	$var_186934fa = preg_quote($var_186934fa);
	$var_186934fa = str_replace(',,,,', '(.*?)', $var_186934fa);
	$var_186934fa = str_replace('@@@@', '(\\d+)', $var_186934fa);
	$var_186934fa = str_replace('%%%%', '(\\w+)', $var_186934fa);
	return $var_186934fa;
} 
function func_6f5f7eb8($html, $var_75f57b3a, $var_afb1db68) {
	$var_04b81daf = '~<a[^>]+href\\s*=\\s*(["|\']*)([\\w/\\.].*)["\' 
	][^>]*>(.*)</a>~iUs';
	$var_8bb5268f = array();
	if (preg_match_all($var_04b81daf, $html, $var_973d74fe)) {
		$var_973d74fe[2] = array_unique($var_973d74fe[2]);
		$var_186934fa = func_6f42332b($var_afb1db68['regxurl_show']);
		foreach($var_973d74fe[2] as $var_228572b3 => $var_cb83972b) {
			$var_1003d5bb = func_a6aabd8f($var_cb83972b);
			list($var_1003d5bb,) = explode('#', $var_1003d5bb);
			$var_1003d5bb = func_d24a35d7($var_1003d5bb, $var_75f57b3a);
			if ($var_186934fa && !preg_match('~^' . $var_186934fa . '$~iUs', $var_1003d5bb)) {
				continue;
			} 
			$var_8bb5268f[] = $var_1003d5bb;
		} 
	} 
	if ($var_8bb5268f) $var_8bb5268f = array_unique($var_8bb5268f);
	return $var_8bb5268f;
} 
function func_21ca168e($var_edda95d2) {
	$var_a3e5f0ff = preg_replace('~^http://www\\.~', 'http://', $var_edda95d2);
	$var_a3e5f0ff = preg_replace('~^https?://' . config('domain.mobile_prefix') . '\\.~', 'http://', $var_a3e5f0ff);
	$var_c3430b33 = CACHE_PATH . 'tags/tkd/' . get_host($var_edda95d2) . '/' . getHashDir($var_a3e5f0ff, 2) . '/' . md5($var_a3e5f0ff) . '.txt';
	return $var_c3430b33;
} 
function func_a76dc06d($var_edda95d2) {
	$var_f5abc85c = CACHE_PATH . 'tags/loop_link/' . get_host($var_edda95d2);
	return $var_f5abc85c;
} 
function func_5e6cebc6($var_edda95d2, $var_1e649227 = '') {
	$var_b9b17a69 = parse_url($var_edda95d2);
	$var_0bf1fa0d = $var_b9b17a69['host'];
	$var_0bf1fa0d = preg_replace('~^www\\.~', '', $var_0bf1fa0d);
	$var_654d357d = $var_0bf1fa0d . $var_1e649227;
	$var_fdc03400 = CACHE_PATH . 'theme/' . getHashDir($var_654d357d, 1) . '/' . substr(md5($var_654d357d), 0, 2) . '.txt';
	return $var_fdc03400;
} 
function func_0b6db7ad($var_1003d5bb) {
	if (config('web_cachefile_type') == 2) {
		$var_62cba596 = CACHE_PATH . 'htmlfile';
		$var_f9b7264a = preg_replace('~^https?://~', '', $var_1003d5bb);
		$var_f9b7264a = preg_replace('~^www\\.~', '', $var_f9b7264a);
		list($var_f9b7264a,) = explode('?', $var_f9b7264a);
		list($var_f9b7264a,) = explode('&', $var_f9b7264a);
		if (substr($var_f9b7264a, - 1) == '/' || strpos(basename($var_f9b7264a), '.') === false) {
			$var_f9b7264a = rtrim($var_f9b7264a, '/') . '/index.html';
		} 
		$var_f9b7264a = $var_62cba596 . '/' . $var_f9b7264a;
	} else {
		$var_1003d5bb = preg_replace('~^https?://www\\.~', 'http://', $var_1003d5bb);
		$var_b9b17a69 = parse_url($var_1003d5bb);
		$var_0bf1fa0d = $var_b9b17a69['host'];
		$var_a3e5f0ff = md5($var_a3e5f0ff);
		$var_4eda73b5 = getHashDir($var_a3e5f0ff, 2);
		$var_fdc03400 = func_5e6cebc6($var_1003d5bb);
		$var_f9b7264a = '';
		if (is_file($var_fdc03400)) {
			$var_5b1418f5 = unserialize(file_get_contents($var_fdc03400));
			$var_eef292fb = $var_5b1418f5[$var_0bf1fa0d];
			$var_62cba596 = CACHE_PATH . 'html/home/' . $var_eef292fb;
			$var_62cba596 = $var_62cba596 . $var_4eda73b5;
			$var_f9b7264a = $var_62cba596 . '/' . $var_a3e5f0ff . config('HTML_CACHE_SUFFIX');
		} 
	} 
	return $var_f9b7264a;
} 

?>