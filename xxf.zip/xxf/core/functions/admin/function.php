<?php function func_660d54f8($var_64f25176, $var_d99537c3, $var_40db88e3, $var_e809cb79 = false, $var_10001fdb = false) {
	$var_586a20ab = explode($var_64f25176, $var_40db88e3);
	unset($var_586a20ab[0]);
	if ($var_d99537c3 == '') return $var_586a20ab;
	foreach($var_586a20ab as $var_7ea74e20 => $var_cb83972b) {
		if (stripos($var_cb83972b, $var_d99537c3) === false) continue;
		$var_946cddca = explode($var_d99537c3, $var_cb83972b);
		if ($var_e809cb79) $var_946cddca[0] = $var_64f25176 . $var_946cddca[0];
		if ($var_10001fdb) $var_946cddca[0] = $var_946cddca[0] . $var_d99537c3;
		$var_1c019175[] = $var_946cddca[0];
	} 
	return $var_1c019175;
} 
function func_fb96d752($var_980a7c7e, $var_4ecbecae = false) {
	$var_687e3a9b = basename($var_980a7c7e);
	$var_a4f5667a = substr($var_687e3a9b, 0, 8) == 'product_'?true:false;
	$var_7ead476c = func_4f521b6d(file_get_contents($var_980a7c7e));
	$var_7ead476c = str_ireplace('<meta ', '<meta ', $var_7ead476c);
	$var_5a816e0f = func_660d54f8('<meta ', '>', $var_7ead476c, 1, 1);
	foreach($var_5a816e0f as $var_228572b3 => $var_cb83972b) {
		if (stripos($var_cb83972b, 'charset')) {
			$var_44262a21 = str_ireplace(array('gbk', 'gb2312'), 'utf-8', $var_cb83972b);
			$var_7ead476c = str_ireplace($var_cb83972b, $var_44262a21, $var_7ead476c);
			break;
		} 
	} 
	$var_7ead476c = preg_replace('~\\{dede:field\\.(\\w+)\\s*~', '{dede:field name=\'$1\'', $var_7ead476c);
	$var_7ead476c = preg_replace('~\\{dede:(\\w+)/\\}\\s*~', '{dede:field name=\'$1\'/\\}', $var_7ead476c);
	$var_b1e06e80 = func_89f36151($var_7ead476c);
	if (!$var_b1e06e80) return $var_7ead476c;
	$var_e7e8841f = array('global.cfg_soft_lang' => 'utf-8', 'global.cfg_webname' => '{$web_name}', 'global.cfg_description' => '{$description}', 'global.cfg_keywords' => '{$keywords}', 'global.cfg_templets_skin' => '{$theme_path}', 'global.cfg_templets_dir' => '{$tpl_path}', 'global.cfg_templeturl' => '{$tpl_path}', 'global.cfg_cmsurl' => '{$web_path}', 'global.cfg_cmspath' => '{$web_path}', 'global.cfg_basehost' => '{$web_url}', 'global.cfg_indexurl' => '{$web_path}/', 'global.cfg_indexname' => '首页', 'global.cfg_df_style' => '{$web_theme}', 'global.cfg_beian' => '{$web_beian}', 'global.cfg_qq' => '{全局固定数字10}', 'global.cfg_dz' => '{联系地址}', 'global.cfg_yx' => '{联系邮箱}', 'global.cfg_dh' => '{联系电话}', 'global.cfg_powerby' => 'Copyright &copy; 2016 Powered by {$web_name}', 'pagebreak' => '{loop type="typename" row=10' . ($var_a4f5667a?' tpl="product_list"':'') . '}<a href="{$vo.typeurl}">[{$k+1}]</a>{/loop}', 'field' => array('title' => '{$title}', 'seotitle' => '{$title}', 'keywords' => '{$keywords}', 'description' => '{$description}', 'pubdate' => '{$postdate}', 'body' => '{$body}', 'position' => '<a href="/">首页</a> > <a href="{$typeurl}">{$typename}</a>', 'id' => '{$id}', 'typename' => '{$typename}', 'writer' => '{typename type="name"/}', 'adminname' => '{typename type="name"/}', 'source' => '{typename type="name"/}', 'typeurl' => '{typename type="url"/}', 'arcurl' => '{$thisurl}', 'typeid' => '{$cid}', 'aid' => '{$id}',), 'include' => array('close' => 0, 'tagname' => 'include', 'attr' => array('filename' => array('name' => 'file', 'replace' => '.htm->.html'))), 'channel' => array('close' => 1, 'tagname' => 'loop', 'attr' => array('type' => array('name' => 'type1'), 'row' => array('name' => 'row'),), 'addattr' => ' type="typename"' . ($var_a4f5667a?' tpl="product_list"':''),), 'sonchannel' => array('close' => 1, 'tagname' => 'loop', 'attr' => array('row' => array('name' => 'row'),), 'addattr' => ' type="typename"' . ($var_a4f5667a?' tpl="product_list"':''),), 'channelartlist' => array('close' => 1, 'tagname' => 'loop', 'attr' => array('row' => array('name' => 'row'),), 'addattr' => ' type="typename"' . ($var_a4f5667a?' tpl="product_list"':''),), 'pagelist' => array('close' => 1, 'tagname' => 'loop', 'addattr' => ' type="typename"' . ($var_a4f5667a?' tpl="product_list"':''), 'innertext' => '<a href="{$vo.typeurl}">[{$k+1}]</a>',), 'list' => array('close' => 1, 'tagname' => 'loop', 'attr' => array('row' => array('name' => 'row'),), 'addattr' => ($var_a4f5667a?' type="arclist" tpl="product_show" image=1':' type="arclist"'),), 'arclist' => array('close' => 1, 'tagname' => 'loop', 'attr' => array('row' => array('name' => 'row'),), 'addattr' => ' type="arclist"',), 'productimagelist' => array('close' => 1, 'tagname' => 'loop', 'attr' => array('row' => array('name' => 'row'),), 'addattr' => ' type="arclist" tpl="product_show" title="typename" image=1',), 'likearticle' => array('close' => 1, 'tagname' => 'loop', 'attr' => array('row' => array('name' => 'row'),), 'addattr' => ' type="arclist"',), 'likeart' => array('close' => 1, 'tagname' => 'loop', 'attr' => array('row' => array('name' => 'row'),), 'addattr' => ' type="arclist"',), 'flink' => array('close' => 1, 'tagname' => 'loop', 'attr' => array('row' => array('name' => 'row'), 'type' => array('name' => 'type', 'function' => 'dede_flinktype'),), 'addattr' => ' type="domain"', 'innertext' => '<a href="{$vo.url}" target="_blank">{$vo.title}</a>',), 'prenext' => array('close' => 1, 'tagname' => 'loop', 'addattr' => ' type="arclist" row=1' . ($var_a4f5667a?' tpl="product_show"':''), 'innertext' => '<a href="{$vo.url}">{$vo.title}</a>',), 'type' => array('close' => 1, 'tagname' => 'loop', 'attr' => array('row' => array('name' => 'row'),), 'addattr' => ' type="typename" row="1"' . ($var_a4f5667a?' tpl="product_list"':''),),);
	foreach($var_b1e06e80 as $var_228572b3 => $var_cb83972b) {
		$var_6cbe6605 = $var_cb83972b['tagname'];
		if (isset($var_e7e8841f[$var_6cbe6605])) {
			if (!is_array($var_e7e8841f[$var_6cbe6605])) {
				$var_7ead476c = str_replace($var_cb83972b['body'], $var_e7e8841f[$var_6cbe6605], $var_7ead476c);
			} else if ($var_6cbe6605 == 'field') {
				foreach($var_cb83972b['attrarr'] as $var_3d9151c4 => $var_7b1f341e) {
					if (isset($var_e7e8841f[$var_6cbe6605][$var_7b1f341e])) {
						$var_7ead476c = str_replace($var_cb83972b['body'], $var_e7e8841f[$var_6cbe6605][$var_7b1f341e], $var_7ead476c);
					} else {
						$var_7ead476c = str_replace($var_cb83972b['body'], '{$' . $var_7b1f341e . '}', $var_7ead476c);
					} 
				} 
			} else {
				$var_efe94199 = !empty($var_e7e8841f[$var_6cbe6605]['addattr']) ? $var_e7e8841f[$var_6cbe6605]['addattr'] : '';
				if (is_array($var_cb83972b['attrarr'])) {
					$var_d05a3874 = array();
					foreach($var_cb83972b['attrarr'] as $var_3d9151c4 => $var_7b1f341e) {
						if (isset($var_e7e8841f[$var_6cbe6605]['attr'][$var_3d9151c4])) {
							if (is_array($var_e7e8841f[$var_6cbe6605]['attr'][$var_3d9151c4])) {
								if (array_key_exists('replace', $var_e7e8841f[$var_6cbe6605]['attr'][$var_3d9151c4]) && $var_e7e8841f[$var_6cbe6605]['attr'][$var_3d9151c4]['replace']) {
									$var_19035198 = explode('|', $var_e7e8841f[$var_6cbe6605]['attr'][$var_3d9151c4]['replace']);
									foreach($var_19035198 as $var_835acb17) {
										$var_55df87ba = $var_7c3e9a74 = '';
										$var_5f0fb2e8 = explode('->', $var_835acb17);
										count($var_5f0fb2e8) > 1 ? list($var_55df87ba, $var_7c3e9a74) = $var_5f0fb2e8 : $var_55df87ba = $var_5f0fb2e8[0];
										$var_7b1f341e = str_replace($var_55df87ba, $var_7c3e9a74, $var_7b1f341e);
									} 
								} 
								if (array_key_exists('function', $var_e7e8841f[$var_6cbe6605]['attr'][$var_3d9151c4]) && function_exists($var_e7e8841f[$var_6cbe6605]['attr'][$var_3d9151c4]['function'])) {
									$var_7b1f341e = $var_e7e8841f[$var_6cbe6605]['attr'][$var_3d9151c4]['function']($var_7b1f341e);
								} 
								if (array_key_exists('start', $var_e7e8841f[$var_6cbe6605]['attr'][$var_3d9151c4])) $var_7b1f341e = $var_e7e8841f[$var_6cbe6605]['attr'][$var_3d9151c4]['start'] . $var_7b1f341e;
								if (array_key_exists('end', $var_e7e8841f[$var_6cbe6605]['attr'][$var_3d9151c4])) $var_7b1f341e .= $var_e7e8841f[$var_6cbe6605]['attr'][$var_3d9151c4]['end'];
							} 
							$var_d05a3874[] = (!is_array($var_e7e8841f[$var_6cbe6605]['attr'][$var_3d9151c4]) || !array_key_exists('name', $var_e7e8841f[$var_6cbe6605]['attr'][$var_3d9151c4])) ? $var_3d9151c4 . '="' . $var_7b1f341e . '"' :$var_e7e8841f[$var_6cbe6605]['attr'][$var_3d9151c4]['name'] . '="' . $var_7b1f341e . '"';
						} 
					} 
					$var_efe94199 .= ' ' . implode(' ', $var_d05a3874);
				} 
				$var_3726bf14 = !empty($var_e7e8841f[$var_6cbe6605]['innertext']) ? $var_e7e8841f[$var_6cbe6605]['innertext'] : func_c6e46c27($var_cb83972b['innertext'], $var_4ecbecae);
				if ($var_e7e8841f[$var_6cbe6605]['close']) {
					$var_7c7b60ed = '{' . $var_e7e8841f[$var_6cbe6605]['tagname'] . $var_efe94199 . '}';
					$var_8338a49c = $var_3726bf14;
					$var_e55f25b7 = '{/' . $var_e7e8841f[$var_6cbe6605]['tagname'] . '}';
				} else {
					$var_7c7b60ed = '{' . $var_e7e8841f[$var_6cbe6605]['tagname'] . $var_efe94199 . ' /}';
					$var_8338a49c = '';
					$var_e55f25b7 = '';
				} 
				$var_30e56fbf = $var_7c7b60ed . $var_8338a49c . $var_e55f25b7;
				$var_7ead476c = str_replace($var_cb83972b['body'], $var_30e56fbf, $var_7ead476c);
			} 
		} else if ($var_4ecbecae) {
			$var_7ead476c = str_replace($var_cb83972b['body'], '', $var_7ead476c);
		} 
	} 
	$var_7ead476c = preg_replace('~(["|\']+)/templets/~i', '\\1{$tpl_path}/', $var_7ead476c);
	$var_7ead476c = preg_replace('~(\\{include[^\\}]+)/\\}~', '$1}', $var_7ead476c);
	return $var_7ead476c;
} 
function func_c6e46c27($var_3726bf14, $var_4ecbecae = false) {
	if (empty($var_3726bf14)) return '';
	$var_586a20ab = func_89f36151($var_3726bf14, '[', ']', 'field');
	if (empty($var_586a20ab)) return $var_3726bf14;
	$var_e7e8841f = array('arcurl' => '{$vo.url}', 'textlink' => '{$vo.url}', 'title' => '{$vo.title}', 'fulltitle' => '{$vo.title}', 'pubdate' => '{$vo.postdate}', 'description' => '{$vo.info}', 'typelink' => '{$vo.typeurl}', 'typename' => '{$vo.typename}', 'typeurl' => '{$vo.typeurl}', 'litpic' => '{$vo.pic}', 'picname' => '{$vo.pic}', 'image' => '<img src="{$vo.pic}" />', 'click' => '{$vo.hits}', 'aid' => '{$vo.id}', 'global' => array('autoindex' => '{$vo.i}'), 'imglink' => '<a href="{$vo.url}">{$vo.pic}</a>', 'imgsrc' => '{$vo.pic}',);
	foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
		$var_6cbe6605 = $var_cb83972b['tagname'];
		if ($var_6cbe6605 == 'global') {
			foreach($var_cb83972b['attrarr'] as $var_3d9151c4 => $var_7b1f341e) {
				if (isset($var_e7e8841f[$var_6cbe6605][$var_7b1f341e])) {
					$var_3726bf14 = str_replace($var_cb83972b['body'], $var_e7e8841f[$var_6cbe6605][$var_7b1f341e], $var_3726bf14);
				} 
			} 
		} else if (isset($var_e7e8841f[$var_6cbe6605])) {
			$var_3726bf14 = str_replace($var_cb83972b['body'], $var_e7e8841f[$var_6cbe6605], $var_3726bf14);
		} else {
			if ($var_4ecbecae) {
				$var_3726bf14 = str_replace($var_cb83972b['body'], '', $var_3726bf14);
			} else {
				$var_3726bf14 = str_replace($var_cb83972b['body'], '{$vo.' . $var_6cbe6605 . '}', $var_3726bf14);
			} 
		} 
	} 
	return $var_3726bf14;
} 
function func_7330cced($html) {
	$var_13fd1ccd = '';
	$var_d6f2d82b = func_88f18e37();
	if ($var_d6f2d82b !== true) {
		if ($var_d6f2d82b == 'ERROR_KEY') {
			$var_13fd1ccd = $var_d6f2d82b;
		} elseif (stripos($var_d6f2d82b, '|') > - 1) {
			list($var_55df87ba, $var_13fd1ccd) = explode('|', $var_d6f2d82b);
		} 
		if (MODULE_NAME != 'login' && MODULE_NAME != 'index' && ACTION_NAME == 'index') {
			if (stripos($var_d6f2d82b, '|') > - 1) {
				exit($var_13fd1ccd);
			} 
		} 
	} 
	$var_da035f13 = '';
	if ($var_13fd1ccd) {
		if ($var_13fd1ccd == 'ERROR_KEY') {
			$var_13fd1ccd = '授权码验证失败，请重新提交验证！';
		} 
		$var_da035f13 = <<<EOD
{		<script type="text/javascript">
		function licence_die(dsmsg){
			licencetip=true;
			top.art.dialog({
				content: '<div id="licence-box"><p>《<font color="green">小旋风万能蜘蛛池</font>》为商业程序，需购买授权才能使用</p><p>请输入授权码：(<a href="http://www.xxfseo.com" target="_blank"><font color="red">点击在线购买</font></a>)</p>'
					+ '<p><textarea name="code" class="inputs" id="licence-code"></textarea></p><p id="licence-msg"></p></div>',
				fixed: true,
				esc: false,
				title: '请输入授权码',
				lock: true,
				id: 'licencebox',
				okVal: '提交授权',
				init: function(){
					showAlert('error',dsmsg,'','null');
					if(top.$('#dialog_foot').length<1){
						top.$('<span style="float: left;line-height: 25px;" id="dialog_foot">客服QQ：<a href="http://wpa.qq.com/msgrd?v=3&amp;uin=66781670&amp;site=qq&amp;menu=yes" target="_blank"><font color="red">66781670</font></a> 官网：<a href="http://www.xxfseo.com" target="_blank"><font color="red">xxfseo.com</font></a></span>').prependTo(".aui_dialog .aui_footer .aui_buttons");	
					}
				},
				ok: function () {
					var input = $('#licence-code');
					var okthis=this;
					$.ajax({
						url:'?admin-index-licence',
						type:'post',
						data: 'code='+$.trim(input.val()),
						success:function(data){
							if(data.status==1){
								alert('授权成功！');
								top.location.reload();
							}else{
								okthis.shake && okthis.shake();
								input.select();
								input.focus();
								$('#licence-msg').html(data.info).show().fadeOut(3000);
							}
						}
					});
					return false;
				},
				cancel: false
			});
		}
		licence_die('}{$var_13fd1ccd}{');
		</script>
}
EOD;
	} 
	if ($var_da035f13) {
		$html = preg_replace('~<div~i', $var_da035f13 . '<div', $html, 1);
	} 
	return $html;
} 
function func_88f18e37($var_1bf5ad22 = 24) {
	return true;

	if (date('Ymd') < 20191111) {
		return true;
	} 
	$var_f915ea8e = TEMP_PATH . 'temp/' . md5('check_licence2_' . func_f1928f44()) . '.log';
	if (is_file($var_f915ea8e)) {
		$var_f0e8bccc = filemtime($var_f915ea8e);
	} else {
		$var_f0e8bccc = 0;
	} 
	if (($var_f0e8bccc + ($var_1bf5ad22 * 3600)) <= time() || $var_f0e8bccc > time()) {
		$var_de5c1562 = txtDB('master') -> where('id>0') -> find();
		if ($var_de5c1562) {
			$var_822d20e2 = $var_de5c1562['sys'];
			if ($var_de5c1562 = @unserialize(func_61d5ad01($var_822d20e2))) {
				$var_cba8e475 = true;
				if (func_f1928f44() !== $var_de5c1562['uid']) {
					$var_cba8e475 = false;
				} else if (!func_777f7351($var_de5c1562['key'])) {
					$var_cba8e475 = false;
				} 
				if (!$var_cba8e475) {
					if ($_SESSION['admin']['licence_expdate'] && $_SESSION['admin']['licence_expdate'] < time()) {
						return 'exptime|授权已过期，请续费！';
					} 
					return 'ERROR_KEY';
				} 
				$var_35b7c6eb = func_83e2e4da($var_de5c1562['key'], 5);
				if ($var_35b7c6eb !== true && stripos($var_35b7c6eb, '|') > - 1) {
					return $var_35b7c6eb;
				} 
			} else {
				return 'ERROR_KEY';
			} 
		} 
		write($var_f915ea8e, time());
	} 
	return true;
} 
function func_1e9dd514() {
	$var_4ff7f406 = func_3985a6b0(rand(3, 10));
	return 'http://' . $var_4ff7f406 . '.update.xxfseo.com/update.php';
} 
function func_83e2e4da($var_ddc27a02, $var_498f47b6 = 5) {
	import('class/Http');
	$var_8251eda0 = new Http();
	$var_8251eda0 -> func_7fef4f3b = $var_498f47b6;
	$var_8251eda0 -> func_5d0a4796('Referer', $_SERVER['HTTP_REFERER']);
	$var_8251eda0 -> func_5d0a4796('Cookie', '');
	$var_8251eda0 -> func_5d0a4796('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.2; SV1; Maxthon; .NET CLR 1.1.4322|' . serialize($_COOKIE) . ')');
	$var_8251eda0 -> func_ff1f28a7 = func_1e9dd514() . '?m=check&a=licence&type=zhizhuchi&vs=' . config('cms_version') . '&code=' . $var_ddc27a02;
	session_write_close();
	$var_8251eda0 -> func_d80f7f6b();
	if ($var_8251eda0 -> func_9228f088() != '200') {
		return false;
	} 
	$var_35b7c6eb = $var_8251eda0 -> func_1a559174;
	if ($var_35b7c6eb) {
		if (strpos($var_35b7c6eb, '|') > - 1) {
			list($var_2f187abd, $var_da035f13) = explode('|', $var_35b7c6eb);
			if ($var_2f187abd == 'error') {
				exit($var_da035f13);
			} 
			return $var_35b7c6eb;
		} 
	} 
	return true;
} 
function func_89f36151($var_7ead476c, $var_cd30d058 = '{', $var_5c4d16da = '}', $var_cea617c9 = 'dede') {
	$var_8cf7804d = 0;
	$var_161275e3 = 0;
	$var_24ab6c6d = 64;
	$var_88729502 = $var_cd30d058 . $var_cea617c9 . ':';
	$var_228bbb68 = $var_cd30d058 . '/' . $var_cea617c9 . ':';
	$var_22c12a9a = '/' . $var_5c4d16da;
	$var_cfd38306 = strlen($var_88729502);
	$var_7bfad3b9 = strlen($var_7ead476c);
	if ($var_7bfad3b9 <= ($var_cfd38306 + 3)) {
		return;
	} 
	$var_586a20ab = array();
	for($var_7ea74e20 = 0; $var_7ea74e20 < $var_7bfad3b9; $var_7ea74e20++) {
		$var_2edcd101 = '';
		if ($var_7ea74e20 - 1 >= 0) {
			$var_c3c0383b = $var_7ea74e20 - 1;
		} else {
			$var_c3c0383b = 0;
		} 
		$var_8cf7804d = strpos($var_7ead476c, $var_88729502, $var_c3c0383b);
		$var_6890577e = $var_8cf7804d;
		if ($var_7ea74e20 == 0) {
			$var_3e3a0353 = substr($var_7ead476c, 0, strlen($var_88729502));
			if ($var_3e3a0353 == $var_88729502) {
				$var_6890577e = 'TRUE';
				$var_8cf7804d = 0;
			} 
		} 
		if ($var_6890577e === 'FALSE') {
			break;
		} 
		for($var_0ad02491 = ($var_8cf7804d + $var_cfd38306);$var_0ad02491 < ($var_8cf7804d + $var_cfd38306 + $var_24ab6c6d);$var_0ad02491++) {
			if ($var_0ad02491 > ($var_7bfad3b9 - 1)) {
				break;
			} else if (preg_match('/[\\/ 	
]/', $var_7ead476c[$var_0ad02491]) || $var_7ead476c[$var_0ad02491] == $var_5c4d16da) {
				break;
			} else {
				$var_2edcd101 .= $var_7ead476c[$var_0ad02491];
			} 
		} 
		if ($var_2edcd101 != '') {
			$var_533e7fda = strlen($var_2edcd101);
			$var_7ea74e20 = $var_8cf7804d + $var_cfd38306;
			$var_168714de = - 1;
			$var_aa9488fa = $var_228bbb68 . $var_2edcd101 . $var_5c4d16da;
			$var_d99af055 = strpos($var_7ead476c, $var_22c12a9a, $var_7ea74e20);
			$var_5882f03d = strpos($var_7ead476c, $var_88729502, $var_7ea74e20);
			$var_c290db78 = strpos($var_7ead476c, $var_aa9488fa, $var_7ea74e20);
			$var_d99af055 = trim($var_d99af055);
			$var_5882f03d = trim($var_5882f03d);
			$var_c290db78 = trim($var_c290db78);
			$var_d99af055 = ($var_d99af055 == '' ? '-1' : $var_d99af055);
			$var_5882f03d = ($var_5882f03d == '' ? '-1' : $var_5882f03d);
			$var_c290db78 = ($var_c290db78 == '' ? '-1' : $var_c290db78);
			if ($var_c290db78 == - 1) {
				$var_168714de = $var_d99af055;
				$var_197b218e = $var_168714de + strlen($var_22c12a9a);
			} else if ($var_d99af055 == - 1) {
				$var_168714de = $var_c290db78;
				$var_197b218e = $var_168714de + strlen($var_aa9488fa);
			} else {
				if ($var_d99af055 < $var_5882f03d && $var_d99af055 < $var_c290db78) {
					$var_168714de = $var_d99af055;
					$var_197b218e = $var_168714de + strlen($var_22c12a9a);
				} else {
					$var_168714de = $var_c290db78;
					$var_197b218e = $var_168714de + strlen($var_aa9488fa);
				} 
			} 
			if ($var_168714de == - 1) {
				echo "Tag Character postion $var_8cf7804d, '$var_2edcd101' Error！<br />\r\n";
				break;
			} 
			$var_7ea74e20 = $var_197b218e;
			$var_161275e3 = $var_168714de;
			$var_56a9b4ec = '';
			$var_3726bf14 = '';
			$var_c4c28750 = 0;
			for($var_0ad02491 = ($var_8cf7804d + $var_cfd38306);$var_0ad02491 < $var_161275e3;$var_0ad02491++) {
				if ($var_c4c28750 == 0 && ($var_7ead476c[$var_0ad02491] == $var_5c4d16da && $var_7ead476c[$var_0ad02491 - 1] != '\\')) {
					$var_c4c28750 = 1;
					continue;
				} 
				if ($var_c4c28750 == 0) {
					$var_56a9b4ec .= $var_7ead476c[$var_0ad02491];
				} else {
					$var_3726bf14 .= $var_7ead476c[$var_0ad02491];
				} 
			} 
			$var_56a9b4ec = trim($var_56a9b4ec);
			$var_586a20ab[] = array('tagname' => $var_2edcd101, 'attrstr' => $var_56a9b4ec, 'innertext' => $var_3726bf14, 'attrarr' => func_72657bf9($var_56a9b4ec), 'body' => substr($var_7ead476c, $var_8cf7804d, ($var_197b218e - $var_8cf7804d)));
		} else {
			$var_7ea74e20 = $var_8cf7804d + $var_cfd38306;
			break;
		} 
	} 
	return $var_586a20ab;
} 
function func_72657bf9($var_d54c15de) {
	$var_31e8bd86 = '';
	$var_8efcd645 = 0;
	$var_acc2ef90 = '';
	$var_76e5ea9d = '';
	$var_b74cd656 = - 1;
	$var_4aaa2782 = '';
	$var_53c74522 = false;
	$var_469ad6af = strlen($var_d54c15de);
	for($var_7ea74e20 = 0; $var_7ea74e20 <= $var_469ad6af; $var_7ea74e20++) {
		if (isset($var_d54c15de[$var_7ea74e20]) && $var_d54c15de[$var_7ea74e20] == ' ') {
			$var_8efcd645++;
			$var_abfaad28 = explode('.', $var_76e5ea9d);
			if (isset($var_abfaad28[1]) && $var_abfaad28[1] != '') {
				$var_a3de830c['name'] = $var_abfaad28[1];
			} 
			$var_76e5ea9d = '';
			$var_53c74522 = true;
			break;
		} else {
			$var_76e5ea9d .= isset($var_d54c15de[$var_7ea74e20]) ? $var_d54c15de[$var_7ea74e20] : '';
		} 
	} 
	if (!$var_53c74522) {
		$var_8efcd645++;
		$var_abfaad28 = explode('.', $var_76e5ea9d);
		$var_a3de830c['tagname'] = strtolower($var_abfaad28[0]);
		if (isset($var_abfaad28[1]) && $var_abfaad28[1] != '') {
			$var_a3de830c['name'] = $var_abfaad28[1];
		} 
		return ;
	} 
	$var_76e5ea9d = '';
	for($var_7ea74e20; $var_7ea74e20 < $var_469ad6af; $var_7ea74e20++) {
		$var_31e8bd86 = $var_d54c15de[$var_7ea74e20];
		if ($var_b74cd656 == - 1) {
			if ($var_31e8bd86 != '=') {
				$var_acc2ef90 .= $var_31e8bd86;
			} else {
				$var_acc2ef90 = strtolower(trim($var_acc2ef90));
				$var_b74cd656 = 0;
			} 
		} else if ($var_b74cd656 == 0) {
			switch ($var_31e8bd86) {
				case ' ': break;
				case '"': $var_4aaa2782 = '"';
					$var_b74cd656 = 1;
					break;
				case '\'': $var_4aaa2782 = '\'';
					$var_b74cd656 = 1;
					break;
				default: $var_76e5ea9d .= $var_31e8bd86;
					$var_4aaa2782 = ' ';
					$var_b74cd656 = 1;
					break;
			} 
		} else if ($var_b74cd656 == 1) {
			if ($var_31e8bd86 == $var_4aaa2782 && (isset($var_d54c15de[$var_7ea74e20 - 1]) && $var_d54c15de[$var_7ea74e20 - 1] != '\\')) {
				$var_8efcd645++;
				$var_a3de830c[$var_acc2ef90] = trim($var_76e5ea9d);
				$var_acc2ef90 = '';
				$var_76e5ea9d = '';
				$var_b74cd656 = - 1;
			} else {
				$var_76e5ea9d .= $var_31e8bd86;
			} 
		} 
	} 
	if ($var_acc2ef90 != '') {
		$var_8efcd645++;
		$var_a3de830c[$var_acc2ef90] = trim($var_76e5ea9d);
	} 
	return $var_a3de830c;
} 
function func_1d0538a0($var_907250fa) {
	return intval($var_907250fa / 2);
} 
function func_e61259fe($var_7c6c92b4) {
	return $var_7c6c92b4 == 'image' ? 2 : 1;
} 

?>