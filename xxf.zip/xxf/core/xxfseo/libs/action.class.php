<?php abstract class action {
	protected $var_a43e77a0 = null;
	private $var_aca22417 = '';
	protected $var_1b04f3c8 = array();
	protected $var_12ab7d87;
	public function __construct() {
		if (method_exists($this, '_init')) {
			$this -> _init();
		} 
		if (method_exists($this, '_init2')) {
			$this -> _init2();
		} 
	} 
	public function view() {
		if (!isset($this -> func_f24d5c1e)) {
			$this -> func_f24d5c1e = new view;
		} 
		return $this -> func_f24d5c1e;
	} 
	public function tplConf($var_c73949df = '', $var_04144ce3 = null, $var_12ab7d87 = false) {
		if ($var_04144ce3 === null) {
			if ($var_c73949df != '') {
				if ($var_12ab7d87) return $this -> view() -> func_e60bc9d5 -> $var_c73949df;
				return $this -> view() -> func_c1e8b295[$var_c73949df];
			} else {
				if ($var_12ab7d87) return $this -> view() -> func_e60bc9d5;
				return $this -> view() -> func_c1e8b295;
			} 
		} else {
			if ($var_12ab7d87) {
				$this -> view() -> func_e60bc9d5 -> $var_c73949df = $var_04144ce3;
			} else {
				$this -> view() -> func_c1e8b295[$var_c73949df] = $var_04144ce3;
			} 
		} 
	} 
	protected function getActionName() {
		if (empty($this -> func_8f566329)) {
			$this -> func_8f566329 = substr(get_class($this), 0, -6);
		} 
		return $this -> func_8f566329;
	} 
	protected function display($var_8db55ee1 = '', $var_a3e5f0ff = '') {
		$this -> view() -> display($var_8db55ee1, $var_a3e5f0ff);
		if (ACTION_NAME == 'index' && GROUP_NAME == 'admin' && in_array(MODULE_NAME, array('config', 'push', 'domain', 'collect', 'robot', 'ads'))) {
			$html = func_7330cced($html);
		} 
		echo $html;
	} 
	protected function set_replace_compile($var_b0644602, $var_43bf0de7) {
		return $this -> view() -> set_replace_compile($var_b0644602, $var_43bf0de7);
	} 
	protected function fetch($var_8db55ee1 = '') {
		return $this -> view() -> fetch($var_8db55ee1);
	} 
	protected function assign($var_aca22417, $var_2ddd548e = '') {
		$this -> view() -> assign($var_aca22417, $var_2ddd548e);
		return $this;
	} 
	public function __set($var_aca22417, $var_2ddd548e) {
		return $this -> assign($var_aca22417, $var_2ddd548e);
	} 
	protected function isCached() {
		return $this -> view() -> isCached();
	} 
	public function get($var_aca22417 = '') {
		return $this -> view() -> get($var_aca22417);
	} 
	public function __get($var_aca22417) {
		return $this -> get($var_aca22417);
	} 
	public function __isset($var_aca22417) {
		return $this -> get($var_aca22417);
	} 
	protected function error($var_b34403f5 = '', $var_2f532947 = '', $var_a37c9890 = false) {
		$this -> dispatchJump($var_b34403f5, 0, $var_2f532947, $var_a37c9890);
	} 
	protected function success($var_b34403f5 = '', $var_2f532947 = '', $var_a37c9890 = false) {
		$this -> dispatchJump($var_b34403f5, 1, $var_2f532947, $var_a37c9890);
	} 
	protected function ajaxReturn($var_de5c1562, $var_7c6c92b4 = 'JSON') {
		if (func_num_args() > 2) {
			$var_583d62cb = func_get_args();
			array_shift($var_583d62cb);
			$var_35702f41 = array();
			$var_35702f41['data'] = $var_de5c1562;
			$var_35702f41['info'] = array_shift($var_583d62cb);
			$var_35702f41['status'] = array_shift($var_583d62cb);
			$var_de5c1562 = $var_35702f41;
			$var_7c6c92b4 = $var_583d62cb?array_shift($var_583d62cb):'';
		} 
		switch (strtoupper($var_7c6c92b4)) {
			case 'JSON' : header('Content-Type:application/json; charset=utf-8');
				exit(json_encode($var_de5c1562));
			case 'XML' : header('Content-Type:text/xml; charset=utf-8');
				exit(xml_encode($var_de5c1562));
			case 'JSONP': header('Content-Type:application/json; charset=utf-8');
				$var_cfbc89e3 = isset($_GET[C('VAR_JSONP_HANDLER')]) ? $_GET[C('VAR_JSONP_HANDLER')] : C('DEFAULT_JSONP_HANDLER');
				exit($var_cfbc89e3 . '(' . json_encode($var_de5c1562) . ');');
			case 'EVAL' : header('Content-Type:text/html; charset=utf-8');
				exit($var_de5c1562);
		} 
	} 
	public function __call($var_6c1a8580, $var_583d62cb) {
		if (0 === strcasecmp($var_6c1a8580, ACTION_NAME . config('ACTION_SUFFIX'))) {
			if (method_exists($this, '_empty')) {
				$this -> _empty($var_6c1a8580, $var_583d62cb);
			} else {
				_404('非法操作:' . ACTION_NAME);
			} 
		} else {
			switch (strtolower($var_6c1a8580)) {
				case 'ispost' : case 'isget' : case 'ishead' : case 'isdelete' : case 'isput' : return strtolower($_SERVER['REQUEST_METHOD']) == strtolower(substr($var_6c1a8580, 2));
				case '_get' : $var_fbd21267 = &$_GET;
					break;
				case '_post' : $var_fbd21267 = &$_POST;
					break;
				case '_put' : parse_str(file_get_contents('php://input'), $var_fbd21267);
					break;
				case '_param' : switch ($_SERVER['REQUEST_METHOD']) {
						case 'POST': $var_fbd21267 = $_POST;
							break;
						case 'PUT': parse_str(file_get_contents('php://input'), $var_fbd21267);
							break;
						default: $var_fbd21267 = $_GET;
					} 
					break;
				case '_request' : $var_fbd21267 = &$_REQUEST;
					break;
				case '_session' : $var_fbd21267 = &$_SESSION;
					break;
				case '_cookie' : $var_fbd21267 = &$_COOKIE;
					break;
				case '_server' : $var_fbd21267 = &$_SERVER;
					break;
				case '_globals' : $var_fbd21267 = &$GLOBALS;
					break;
				default: throw_exception(__CLASS__ . ':' . $var_6c1a8580 . '请求的方法不存在！');
			} 
			if (!isset($var_583d62cb[0])) {
				$var_de5c1562 = $var_fbd21267;
			} elseif (isset($var_fbd21267[$var_583d62cb[0]])) {
				$var_de5c1562 = $var_fbd21267[$var_583d62cb[0]];
				$var_3cacd0a3 = isset($var_583d62cb[1])?$var_583d62cb[1]:config('DEFAULT_FILTER');
				if ($var_3cacd0a3) {
					$var_3cacd0a3 = explode(',', $var_3cacd0a3);
					foreach($var_3cacd0a3 as $var_69215b26) {
						if (function_exists($var_69215b26)) {
							$var_de5c1562 = is_array($var_de5c1562)?array_map($var_69215b26, $var_de5c1562):$var_69215b26($var_de5c1562);
						} 
					} 
				} 
			} else {
				$var_de5c1562 = isset($var_583d62cb[2])?$var_583d62cb[2]:null;
			} 
			return $var_de5c1562;
		} 
	} 
	private function dispatchJump($var_b34403f5, $var_2f187abd = 1, $var_2f532947 = '', $var_a37c9890 = false) {
		$this -> tplConf('compile_check', true);
		$this -> tplConf('caching', false);
		if (true === $var_a37c9890 || IS_AJAX) {
			$var_de5c1562 = is_array($var_a37c9890)?$var_a37c9890:array();
			$var_de5c1562['info'] = $var_b34403f5;
			$var_de5c1562['status'] = $var_2f187abd;
			$var_de5c1562['url'] = $var_2f532947;
			$this -> ajaxReturn($var_de5c1562);
		} 
		if (is_int($var_a37c9890)) {
			$var_80147430 = $var_a37c9890;
			$this -> assign('waitSecond', $var_a37c9890);
		} 
		if (!empty($var_2f532947)) $this -> assign('jumpUrl', $var_2f532947);

		if ($this -> view() -> get('msgTitle') === null) $this -> assign('msgTitle', $var_2f187abd? '操作成功！' : '操作失败！');
		$this -> assign('status', $var_2f187abd);
		if ($var_2f187abd) {
			$this -> assign('message', $var_b34403f5);

			if (!$this -> get('waitSecond')) $this -> assign('waitSecond', '1');

			if (!$this -> get('jumpUrl')) $this -> assign('jumpUrl', $_SERVER["HTTP_REFERER"]);
			$this -> display(config('TMPL_ACTION_SUCCESS'));
		} else {
			$this -> assign('error', $var_b34403f5);

			if (!$this -> get('waitSecond')) $this -> assign('waitSecond', '3');

			if (!$this -> get('jumpUrl')) $this -> assign('jumpUrl', 'javascript:history.back(-1);');
			$this -> display(config('TMPL_ACTION_ERROR'));
			exit ;
		} 
	} 
} 
