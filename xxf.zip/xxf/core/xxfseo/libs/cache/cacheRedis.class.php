<?php class cacheRedis extends cache {
	public function __construct($var_4c819857 = array()) {
		if (!extension_loaded('redis')) {
			throw_exception('未开启扩展: redis');
		} 
		if (empty($var_4c819857)) {
			$var_4c819857 = array('host' => config('REDIS_HOST') ? config('REDIS_HOST') : '127.0.0.1', 'port' => config('REDIS_PORT') ? config('REDIS_PORT') : 6379, 'timeout' => config('DATA_CACHE_TIMEOUT') ? config('DATA_CACHE_TIMEOUT') : false, 'password' => false, 'persistent' => false,);
		} 
		$this -> func_c1e8b295 = $var_4c819857;
		$this -> func_c1e8b295['expire'] = isset($var_4c819857['expire'])? $var_4c819857['expire'] : config('DATA_CACHE_TIME');
		$this -> func_c1e8b295['prefix'] = isset($var_4c819857['prefix'])? $var_4c819857['prefix'] : config('DATA_CACHE_PREFIX');
		$this -> func_c1e8b295['length'] = isset($var_4c819857['length'])? $var_4c819857['length'] : 0;
		$var_41156c32 = $var_4c819857['persistent'] ? 'pconnect' : 'connect';
		$this -> func_e3269875 = new Redis;
		if ($var_4c819857['timeout'] === false) {
			$this -> func_e3269875 -> $var_41156c32($var_4c819857['host'], $var_4c819857['port']);
		} else {
			$this -> func_e3269875 -> $var_41156c32($var_4c819857['host'], $var_4c819857['port'], $var_4c819857['timeout']);
		} 
		if ($this -> func_c1e8b295['password'] !== false) {
			$this -> func_e3269875 -> auth($this -> func_c1e8b295['password']);
		} 
	} 
	public function get($var_aca22417) {
		$var_8eafab80 = $this -> func_e3269875 -> get($this -> func_c1e8b295['prefix'] . $var_aca22417);
		if ($this -> func_c1e8b295['type'] == 'array') $var_8eafab80 = unserialize($var_8eafab80);
		return $var_8eafab80;
	} 
	public function option($var_aca22417, $var_2ddd548e = '*xxfseo*') {
		if ($var_2ddd548e != '*xxfseo*') {
			$this -> func_c1e8b295[$var_aca22417] = $var_2ddd548e;
		} else {
			return $this -> func_c1e8b295[$var_aca22417];
		} 
	} 
	public function set($var_aca22417, $var_2ddd548e, $var_d5aecd65 = null) {
		if (is_null($var_d5aecd65)) {
			$var_d5aecd65 = $this -> func_c1e8b295['expire'];
		} 
		if ($this -> func_c1e8b295['type'] == 'array') $var_2ddd548e = serialize($var_2ddd548e);
		$var_aca22417 = $this -> func_c1e8b295['prefix'] . $var_aca22417;
		if (is_int($var_d5aecd65)) {
			$var_35b7c6eb = $this -> func_e3269875 -> setex($var_aca22417, $var_d5aecd65, $var_2ddd548e);
		} else {
			$var_35b7c6eb = $this -> func_e3269875 -> set($var_aca22417, $var_2ddd548e);
		} 
		if ($var_35b7c6eb && $this -> func_c1e8b295['length'] > 0) {
			$this -> queue($var_aca22417);
		} 
		return $var_35b7c6eb;
	} 
	public function rm($var_aca22417) {
		return $this -> func_e3269875 -> delete($this -> func_c1e8b295['prefix'] . $var_aca22417);
	} 
	public function clear() {
		return $this -> func_e3269875 -> flushDB();
	} 
} 
