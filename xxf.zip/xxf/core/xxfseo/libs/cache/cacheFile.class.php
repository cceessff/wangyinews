<?php class cacheFile extends cache {
	public function __construct($var_4c819857 = array()) {
		if (!empty($var_4c819857)) {
			$this -> func_c1e8b295 = $var_4c819857;
		} 
		$this -> func_c1e8b295['path'] = !empty($var_4c819857['path'])? $var_4c819857['path'] : config('DATA_CACHE_PATH');
		$this -> func_c1e8b295['prefix'] = isset($var_4c819857['prefix'])? $var_4c819857['prefix'] : config('DATA_CACHE_PREFIX');
		$this -> func_c1e8b295['expire'] = isset($var_4c819857['expire'])? $var_4c819857['expire'] : config('DATA_CACHE_TIME');
		$this -> func_c1e8b295['length'] = isset($var_4c819857['length'])? $var_4c819857['length'] : 0;
		if (substr($this -> func_c1e8b295['path'], - 1) != '/') $this -> func_c1e8b295['path'] .= '/';
		$this -> init();
	} 
	private function init() {
		if (!is_dir($this -> func_c1e8b295['path'])) {
			mkdir($this -> func_c1e8b295['path']);
		} 
	} 
	private function filename($var_aca22417) {
		if (config('DATA_CACHE_SUBDIR')) {
			$var_fae1bb2a = '';
			$var_45e663e3 = md5($var_aca22417);
			for($var_7ea74e20 = 0;$var_7ea74e20 < config('DATA_PATH_LEVEL');$var_7ea74e20++) {
				$var_fae1bb2a .= $var_45e663e3 {
					$var_7ea74e20} 
				. '/';
			} 
			if (!is_dir($this -> func_c1e8b295['path'] . $var_fae1bb2a)) {
				mkdir($this -> func_c1e8b295['path'] . $var_fae1bb2a, 493, true);
			} 
			$var_3d815bdc = $var_fae1bb2a . $this -> func_c1e8b295['prefix'] . $var_aca22417 . '.php';
		} else {
			$var_3d815bdc = $this -> func_c1e8b295['prefix'] . $var_aca22417 . '.php';
		} 
		return $this -> func_c1e8b295['path'] . $var_3d815bdc;
	} 
	public function option($var_aca22417, $var_2ddd548e = '*xxfseo*') {
		if ($var_2ddd548e != '*xxfseo*') {
			$this -> func_c1e8b295[$var_aca22417] = $var_2ddd548e;
		} else {
			return $this -> func_c1e8b295[$var_aca22417];
		} 
	} 
	public function get($var_aca22417) {
		$var_3d815bdc = $this -> filename($var_aca22417);
		if (!is_file($var_3d815bdc)) {
			return null;
		} 
		$var_8eafab80 = file_get_contents($var_3d815bdc);
		if (false !== $var_8eafab80) {
			$var_d5aecd65 = (int)substr($var_8eafab80, 8, 12);
			if ($var_d5aecd65 != 0 && time() > filemtime($var_3d815bdc) + $var_d5aecd65) {
				unlink($var_3d815bdc);
				return false;
			} 
			if (config('DATA_CACHE_CHECK')) {
				$var_f9295710 = substr($var_8eafab80, 20, 32);
				$var_8eafab80 = substr($var_8eafab80, 52, - 3);
				if ($var_f9295710 != md5($var_8eafab80)) {
					return false;
				} 
			} else {
				$var_8eafab80 = substr($var_8eafab80, 20, - 3);
			} 
			if (config('DATA_CACHE_COMPRESS') && function_exists('gzcompress')) {
				$var_8eafab80 = gzuncompress($var_8eafab80);
			} 
			if ($this -> func_c1e8b295['type'] == 'array') $var_8eafab80 = unserialize(trim($var_8eafab80));
			return $var_8eafab80;
		} else {
			return false;
		} 
	} 
	public function set($var_aca22417, $var_de5c1562, $var_d5aecd65 = null) {
		if (is_null($var_d5aecd65)) {
			$var_d5aecd65 = $this -> func_c1e8b295['expire'];
		} 
		$var_3d815bdc = $this -> filename($var_aca22417);
		if ($this -> func_c1e8b295['type'] == 'array') $var_de5c1562 = serialize($var_de5c1562);
		if (config('DATA_CACHE_COMPRESS') && function_exists('gzcompress')) {
			$var_de5c1562 = gzcompress($var_de5c1562, 3);
		} 
		if (config('DATA_CACHE_CHECK')) {
			$var_f9295710 = md5($var_de5c1562);
		} else {
			$var_f9295710 = '';
		} 
		$var_de5c1562 = '<?php
//' . sprintf('%012d', $var_d5aecd65) . $var_f9295710 . '
' . $var_de5c1562 . '
?>';
		$var_35b7c6eb = write($var_3d815bdc, $var_de5c1562);
		if ($var_35b7c6eb) {
			if ($this -> func_c1e8b295['length'] > 0) {
				$this -> queue($var_aca22417);
			} 
			clearstatcache();
			return true;
		} else {
			return false;
		} 
	} 
	public function rm($var_aca22417) {
		return unlink($this -> filename($var_aca22417));
	} 
	public function clear() {
		$var_4eda73b5 = $this -> func_c1e8b295['path'];
		$var_e1a83737 = scandir($var_4eda73b5);
		if ($var_e1a83737) {
			foreach($var_e1a83737 as $var_980a7c7e) {
				if ($var_980a7c7e != '.' && $var_980a7c7e != '..' && is_dir($var_4eda73b5 . $var_980a7c7e)) {
					array_map('unlink', glob($var_4eda73b5 . $var_980a7c7e . '/*.*'));
				} elseif (is_file($var_4eda73b5 . $var_980a7c7e)) {
					unlink($var_4eda73b5 . $var_980a7c7e);
				} 
			} 
			return true;
		} 
		return false;
	} 
} 
