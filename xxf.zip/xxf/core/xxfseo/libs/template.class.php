<?php function temp_func_362($var_1f8c2122) {
	return '.' . str_replace('$', '$', $var_1f8c2122[1]);
} 
function temp_func_399($var_55df87ba, $var_7c3e9a74) {
	return (strLen($var_55df87ba) < strLen($var_7c3e9a74));
} 
class template {
	public $var_fb3843db = '';
	public $var_62cba596 = '';
	public $var_1ce6c4c5 = '';
	public $var_1760c6e3 = 3600;
	public $var_560c515e = false;
	public $var_56de252e = false;
	public $var_17879b45 = false;
	public $var_d979e5d8 = array();
	public $var_ebe83383 = '';
	public $var_09959db8 = 0;
	public $var_62dc5796 = null;
	public $var_b8fe2d43 = array();
	public $var_cf6fbcfe = array();
	public $var_f1c8e4b4 = '';
	public $var_70c9357f = array();
	public function __construct() {
		if (!defined('IN_TXTCMS')) {
			define('IN_TXTCMS', true);
		} 
		$this -> func_99de99af = time();
		$this -> func_459590ca = array();
		$this -> _var = array();
		$this -> func_0ec32c76 = '{';
		$this -> func_1f5252f0 = '}';
	} 
	public function assign($var_4767038b, $var_2ddd548e = '') {
		if (is_array($var_4767038b)) {
			foreach($var_4767038b AS $var_6cbe6605 => $var_04144ce3) {
				if ($var_6cbe6605 != '') {
					$this -> _var[$var_6cbe6605] = $var_04144ce3;
				} 
			} 
		} else {
			if ($var_4767038b != '') {
				$this -> _var[$var_4767038b] = $var_2ddd548e;
			} 
		} 
	} 
	public function display($var_3d815bdc, $var_536d68a3 = '') {
		$var_77704151 = $this -> fetch($var_3d815bdc, $var_536d68a3);
		echo $var_77704151;
	} 
	public function fetch($var_3d815bdc, $var_536d68a3 = '') {
		$this -> func_3e8ec88c = rtrim($this -> func_3e8ec88c, '/');
		if (strncmp($var_3d815bdc, 'str:', 4) == 0) {
			$var_7b5ee9fe = substr($var_3d815bdc, 4);
			if ($this -> func_2df01004) {
				foreach($this -> func_2df01004 as $var_228572b3 => $var_cb83972b) {
					$var_7b5ee9fe = str_replace($var_228572b3, $var_cb83972b, $var_7b5ee9fe);
				} 
			} 
			$var_77704151 = $this -> _eval($this -> fetch_str($var_7b5ee9fe));
		} else {
			if (!is_file($var_3d815bdc)) {
				$var_3d815bdc = $this -> func_3e8ec88c . '/' . $var_3d815bdc;
			} 
			if (!is_file($var_3d815bdc)) {
				return false;
			} 
			if ($var_536d68a3 && $this -> func_4007cba4) {
				$var_77704151 = $this -> func_1b289292;
			} else {
				if (!in_array($var_3d815bdc, $this -> func_459590ca)) {
					$this -> func_459590ca[] = $var_3d815bdc;
				} 
				$var_77704151 = $this -> make_compiled($var_3d815bdc);
				if ($var_536d68a3) {
					$var_20e48016 = basename($var_3d815bdc, strrchr($var_3d815bdc, '.')) . '_' . $var_536d68a3;
					$var_de5c1562 = serialize(array('template' => $this -> func_459590ca, 'expires' => $this -> func_99de99af + $this -> func_f13d7af2, 'maketime' => $this -> func_99de99af));
					$var_5e51dabc = rtrim($this -> func_b16a856d, '/');

					if ($this -> write($var_5e51dabc . '/' . $var_20e48016 . '.php', '<?php exit;?>' . $var_de5c1562 . $var_77704151) === false) {
						trigger_error('can\'t write:' . $var_5e51dabc . '/' . $var_20e48016 . '.php');
					} 
					$this -> func_459590ca = array();
				} 
			} 
		} 
		return $var_77704151;
	} 
	public function set_replace_compile($var_b0644602, $var_43bf0de7) {
		$this -> func_2df01004[$var_b0644602] = $var_43bf0de7;
	} 
	public function make_compiled($var_3d815bdc) {
		$this -> func_c403d9e0 = rtrim($this -> func_c403d9e0, '/');
		$var_aca22417 = $this -> func_c403d9e0 . '/' . md5($var_3d815bdc) . '_' . basename($var_3d815bdc) . '.php';
		if ($this -> func_4944f146) {
			$var_67921722 = $this -> func_4944f146 - $this -> func_f13d7af2;
		} else {
			$var_0dbbb6bf = @stat($var_aca22417);
			$var_67921722 = $var_0dbbb6bf['mtime'];
		} 
		$var_0dbbb6bf = @stat($var_3d815bdc);
		$var_65448e5c = false;
		if ($this -> func_77aca0ae) {
			debug_log('compile_check' . $var_3d815bdc);
			$var_9b2f5337 = md5_file($var_3d815bdc);
			$var_0b16e8e9 = $this -> func_c403d9e0 . '/md5.php';
			$var_fdd0c8e9 = md5($var_3d815bdc) . '/' . intval($this -> func_77aca0ae) . '/' . basename($var_3d815bdc);
			if (!is_file($var_0b16e8e9)) {
				$var_65448e5c = true;
				$this -> write($var_0b16e8e9, serialize(array($var_fdd0c8e9 => $var_9b2f5337)));
			} else {
				$var_f1e8fff4 = unserialize(file_get_contents($var_0b16e8e9));
				if (!isset($var_f1e8fff4[$var_fdd0c8e9]) || $var_f1e8fff4[$var_fdd0c8e9] != $var_9b2f5337) {
					$var_f1e8fff4[$var_fdd0c8e9] = $var_9b2f5337;
					$var_65448e5c = true;
					$this -> write($var_0b16e8e9, serialize($var_f1e8fff4));
				} 
			} 
			debug_log('compile_check' . $var_3d815bdc, 'end');
		} 
		if (!$var_65448e5c && $var_0dbbb6bf['mtime'] <= $var_67921722 && !$this -> func_fee62c9c) {
			if (file_exists($var_aca22417)) {
				$var_59f3caff = $this -> _require($var_aca22417);
				if ($var_59f3caff == '') {
					$var_67921722 = 0;
				} 
			} else {
				$var_59f3caff = '';
				$var_67921722 = 0;
			} 
		} 
		if ($var_65448e5c || $this -> func_fee62c9c || $var_0dbbb6bf['mtime'] > $var_67921722) {
			$this -> func_e46a9b4a = $var_3d815bdc;
			$var_7b5ee9fe = file_get_contents($var_3d815bdc);
			if ($this -> func_2df01004) {
				foreach($this -> func_2df01004 as $var_228572b3 => $var_cb83972b) {
					$var_7b5ee9fe = str_replace($var_228572b3, $var_cb83972b, $var_7b5ee9fe);
				} 
			} 
			$var_59f3caff = $this -> fetch_str($var_7b5ee9fe);
			$var_59f3caff = '<?php if(!defined(\'IN_TXTCMS\')){define(\'IN_TXTCMS\',true);} ?>' . $var_59f3caff;

			if ($this -> write($var_aca22417, $var_59f3caff) === false) {
				trigger_error('can\'t write:' . $var_aca22417);
			} 
			$var_59f3caff = $this -> _eval($var_59f3caff);
		} 
		return $var_59f3caff;
	} 
	public function fetch_str($var_59f3caff) {
		$var_59f3caff = $this -> prefilter_preCompile($var_59f3caff);
		$var_59f3caff = $this -> check_nocache($var_59f3caff);
		debug_log('compile_tags');
		$var_59f3caff = $this -> compile_tags($var_59f3caff);
		debug_log('compile_tags', 'end');
		return $var_59f3caff;
	} 
	public function compile_tags($var_59f3caff) {
		return preg_replace_callback("/" . $this -> func_0ec32c76 . "(\S[^\}\{\n]*)" . $this -> func_1f5252f0 . "/", array($this, 'select'), $var_59f3caff);
	} 
	public function check_nocache($var_59f3caff) {
		if (!preg_match_all('~\{nocache\}(.*)\{/nocache\}~Us', $var_59f3caff, $var_973d74fe)) {
			return $var_59f3caff;
		} 
		foreach($var_973d74fe[1] as $var_228572b3 => $var_cb83972b) {
			$var_8eafab80 = $this -> compile_tags($var_cb83972b);
			$var_3d815bdc = md5($var_8eafab80) . '_nocache.php';
			$var_980a7c7e = $this -> func_c403d9e0 . '/' . $var_3d815bdc;

			if ($this -> write($var_980a7c7e, $var_8eafab80) === false) {
				trigger_error('can\'t write:' . $var_980a7c7e);
			} 
			$var_122296f0 = '<?php echo $this->_require($this->compile_dir.\'/' . $var_3d815bdc . '\'); ?>';
			$var_59f3caff = str_replace($var_973d74fe[0][$var_228572b3], $var_122296f0, $var_59f3caff);
		} 
		return $var_59f3caff;
	} 
	public function is_cached($var_3d815bdc, $var_536d68a3 = '') {
		$var_20e48016 = basename($var_3d815bdc, strrchr($var_3d815bdc, '.'));
		if ($this -> func_4007cba4 == true && $this -> func_fb0a1465 == false) {
			$var_5e51dabc = rtrim($this -> func_b16a856d, '/');
			if ($var_de5c1562 = @file_get_contents($var_5e51dabc . '/' . $var_20e48016 . '.php')) {
				$var_de5c1562 = substr($var_de5c1562, 13);
				$var_c9568e42 = strpos($var_de5c1562, '<');
				$var_fefc7135 = substr($var_de5c1562, 0, $var_c9568e42);
				$var_27dc5229 = @unserialize($var_fefc7135);
				if ($var_27dc5229 === false || $this -> func_99de99af > $var_27dc5229['expires']) {
					$this -> func_4007cba4 = false;
					return false;
				} 
				$this -> func_4944f146 = $var_27dc5229['expires'];
				$this -> func_1b289292 = substr($var_de5c1562, $var_c9568e42);
				foreach($var_27dc5229['template'] AS $var_04144ce3) {
					$var_89fbffb4 = @stat($var_04144ce3);
					if ($var_27dc5229['maketime'] < $var_89fbffb4['mtime']) {
						$this -> func_4007cba4 = false;
						return false;
					} 
				} 
			} else {
				$this -> func_4007cba4 = false;
				return false;
			} 
			return true;
		} else {
			return false;
		} 
	} 
	public function select($var_b1e06e80) {
		is_array($var_b1e06e80) && $var_b1e06e80 = $var_b1e06e80[1];
		if ($GLOBALS['inNocacheTag'] && $var_b1e06e80 != '/nocache' && $GLOBALS['first_compile']) {
			return $this -> func_0ec32c76 . $var_b1e06e80 . $this -> func_1f5252f0;
		} 
		if ($GLOBALS['inlinktag'] && $var_b1e06e80 != '/loop') {
			return $this -> func_0ec32c76 . $var_b1e06e80 . $this -> func_1f5252f0;
		} 
		$var_b1e06e80 = stripslashes(trim($var_b1e06e80));
		if (empty($var_b1e06e80)) {
			return '';
		} else if ($var_b1e06e80 {
				0} == '*' && substr($var_b1e06e80, - 1) == '*') {
			return '';
		} else if (preg_match('~^(\\$[a-zA-Z_\\x7f-\\xff][\\.\\w\\x7f-\\xff]*)([\\+-/\\*]+)(\\d+)$~', $var_b1e06e80, $var_973d74fe)) {
			$var_40db88e3 = $this -> get_val(substr($var_973d74fe[1], 1)) . $var_973d74fe[2] . $var_973d74fe[3];
			return '<?php echo (' . $var_40db88e3 . '); ?>';
		} else if (preg_match('~^(\\$[a-zA-Z_\\x7f-\\xff][\\.\\w\\x7f-\\xff]*)([\\+-/\\*]+)(\\$[a-zA-Z_\\x7f-\\xff][\\.\\w\\x7f-\\xff]*)$~', $var_b1e06e80, $var_973d74fe)) {
			$var_586a20ab = preg_split('~([\\+-/\\*]+)~', $var_b1e06e80, - 1, PREG_SPLIT_DELIM_CAPTURE);
			$var_40db88e3 = '';
			foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
				if ($var_228572b3 % 2 == 0) {
					$var_40db88e3 .= $this -> get_val(substr($var_cb83972b, 1));
					continue;
				} 
				$var_40db88e3 .= $var_cb83972b;
			} 
			return '<?php echo (' . $var_40db88e3 . '); ?>';
		} else if ($var_b1e06e80 {
				0} == '$') {
			return '<?php echo ' . $this -> get_val(substr($var_b1e06e80, 1)) . '; ?>';
		} else if ($var_b1e06e80 {
				0} == '/') {
			switch (substr($var_b1e06e80, 1)) {
				case 'if': return '<?php endif; ?>';
					break;
				case 'foreach': if ($this -> func_b0f7e18d == 'foreachelse') {
						$var_970de168 = '<?php endif; unset($_from); ?>';
					} else {
						array_pop($this -> func_87870b9f);
						$var_970de168 = '<?php endforeach; endif; unset($_from); ?>';
					} 
					$var_970de168 .= '<?php $this->pop_vars(); ?>';
					return $var_970de168;
					break;
				case 'literal': return '';
					break;
				case 'php': return ' ?>';
					break;
				case 'nocache': $GLOBALS['inNocacheTag'] = false;
					return '';
					break;
				default: $var_537a67d9 = $this -> func_7221644a . 'block.' . substr($var_b1e06e80, 1) . '.php';
					if (!$GLOBALS['inlinktag'] && is_file($var_537a67d9)) {
						return '<?php }} ?>';
					} 
					if ($GLOBALS['inlinktag'] && is_file($var_537a67d9)) {
						$GLOBALS['inlinktag'] = false;
					} 
					return $this -> func_0ec32c76 . $var_b1e06e80 . $this -> func_1f5252f0;
					break;
			} 
		} else if (preg_match('~^(\\w+)\\(.*\\)$~', $var_b1e06e80, $var_973d74fe)) {
			if (function_exists($var_973d74fe[1])) {
				return '<?php echo ' . $var_b1e06e80 . '; ?>';
			} 
		} else if (substr($var_b1e06e80, - 1) == '/') {
			$var_9561995a = strpos($var_b1e06e80, ' ') > - 1?@array_shift(explode(' ', $var_b1e06e80)):substr($var_b1e06e80, 0, - 1);
			$var_537a67d9 = $this -> func_7221644a . 'function.' . $var_9561995a . '.php';
			if (is_file($var_537a67d9)) {
				$var_5c3ffaf9 = 'tag_function_' . $var_9561995a;
				$var_3d20800d = $this -> get_params(substr($var_b1e06e80, 0, - 1), 0);
				$var_8647c89d = 'array( ';
				foreach($var_3d20800d as $var_228572b3 => $var_cb83972b) {
					if (substr($var_cb83972b, 0, 1) == '$') {
						$var_cb83972b = '{' . $var_cb83972b . '}';
					} 
					$var_8647c89d .= '\'' . $var_228572b3 . '\'=>"' . $var_cb83972b . '", ';
				} 
				$var_8647c89d .= ')';
				return '<?php echo $this->' . $var_5c3ffaf9 . '(' . $var_8647c89d . '); ?>';
			} 
		} else {
			$var_84c36f7e = explode(' ', $var_b1e06e80);
			$var_9561995a = array_shift($var_84c36f7e);
			switch ($var_9561995a) {
				case 'if': return $this -> _compile_if_tag(substr($var_b1e06e80, 3));
					break;
				case 'else': return '<?php else: ?>';
					break;
				case 'elseif': return $this -> _compile_if_tag(substr($var_b1e06e80, 7), true);
					break;
				case 'foreachelse': $this -> func_b0f7e18d = 'foreachelse';
					return '<?php endforeach; else: ?>';
					break;
				case 'foreach': $this -> func_b0f7e18d = 'foreach';
					if (!isset($this -> func_87870b9f)) {
						$this -> func_87870b9f = array();
					} 
					return $this -> _compile_foreach_start(substr($var_b1e06e80, 8));
					break;
				case 'assign': $var_b4ba575b = $this -> get_params(substr($var_b1e06e80, 7), 0);
					if ($var_b4ba575b['value'] {
							0} == '$') {
						if (strpos($var_b4ba575b['value'], '+') !== false) {
							preg_match('/\\+(\\d)+\'\\]/', $var_b4ba575b['value'], $var_55df87ba);
							$var_2453dbcf = empty($var_55df87ba[1]) ? 0 : $var_55df87ba[1];
							$var_b4ba575b['value'] = preg_replace('/\\+(\\d)+/', '', $var_b4ba575b['value']);
							$var_fe4121aa = '$this->assign(\'' . $var_b4ba575b['var'] . '\',' . $var_b4ba575b['value'] . ' + ' . $var_2453dbcf . ');';
						} else {
							$var_fe4121aa = '$this->assign(\'' . $var_b4ba575b['var'] . '\',' . $var_b4ba575b['value'] . ');';
						} 
					} else {
						$var_fe4121aa = '$this->assign(\'' . $var_b4ba575b['var'] . '\',\'' . addcslashes($var_b4ba575b['value'], '\'') . '\');';
					} 
					return '<?php ' . $var_fe4121aa . ' ?>';
					break;
				case 'math': $var_b4ba575b = $this -> get_math_para(substr($var_b1e06e80, 8));
					return'<?php echo ' . $var_b4ba575b . '; ?>';
					break;
				case 'include': $var_b4ba575b = $this -> get_params(substr($var_b1e06e80, 8), 0);
					return '<?php echo $this->fetch(' . "'$var_b4ba575b[file]'" . '); ?>';
					break;
				case 'literal': return '';
					break;
				case 'php': return '<?php ';
					break;
				case 'nocache': $GLOBALS['inNocacheTag'] = true;
					return '';
					break;
				default: $var_537a67d9 = $this -> func_7221644a . 'block.' . $var_9561995a . '.php';
					if (is_file($var_537a67d9)) {
						$var_5c3ffaf9 = 'tag_block_' . $var_9561995a;
						$var_0ca46759 = md5($var_b1e06e80);
						$var_3d20800d = $this -> get_params($var_b1e06e80, 0);
						$var_20a9da30 = isset($var_3d20800d['as'])?$var_3d20800d['as']:'vo';
						$var_e43d6126 = isset($var_3d20800d['key'])?$var_3d20800d['key']:'k';
						if (!$GLOBALS['linktag_display'] && $var_3d20800d['type'] == 'link') {
							$GLOBALS['inlinktag'] = true;
						} 
						if (!$GLOBALS['inlinktag']) {
							$var_366b15d8 = 'array(';
							foreach($var_3d20800d as $var_228572b3 => $var_cb83972b) {
								$var_4cce7e5a = '\'' . $var_228572b3 . '\'=>' . '\'' . addslashes($var_cb83972b) . '\',';
								if ($var_cb83972b {
										0} == '$') {
									$var_4cce7e5a = '\'' . $var_228572b3 . '\'=>' . $var_cb83972b . ',';
								} 
								$var_366b15d8 .= $var_4cce7e5a;
							} 
							$var_366b15d8 .= ')';
							return '<?php if(!isset($this->_tags_data)){ $this->_tags_data=array(); } if($this->_tags_data["' . $var_0ca46759 . '"]=$this->' . $var_5c3ffaf9 . '(' . $var_366b15d8 . ')){ foreach($this->_tags_data["' . $var_0ca46759 . '"] as $this->_var["' . $var_e43d6126 . '"]=>$this->_var["' . $var_20a9da30 . '"]){ ?>';
						} 
					} 
					return $this -> func_0ec32c76 . $var_b1e06e80 . $this -> func_1f5252f0;
					break;
			} 
		} 
		return $this -> func_0ec32c76 . $var_b1e06e80 . $this -> func_1f5252f0;
	} 
	public function get_val($var_04144ce3) {
		if (strrpos($var_04144ce3, '[') !== false) {
			$var_04144ce3 = preg_replace_callback("/\[([^\[\]]*)\]/is", 'temp_func_362', $var_04144ce3);
		} 
		if (strrpos($var_04144ce3, '|') !== false) {
			$var_a476802c = explode('|', $var_04144ce3);
			$var_04144ce3 = array_shift($var_a476802c);
		} 
		if (empty($var_04144ce3)) {
			return '';
		} 
		if (strpos($var_04144ce3, '.$') !== false) {
			$var_4d715bc1 = explode('.$', $var_04144ce3);
			foreach($var_4d715bc1 as $var_6cbe6605 => $var_04144ce3) {
				$var_4d715bc1[$var_6cbe6605] = $var_6cbe6605 == 0 ? $this -> make_var($var_04144ce3) : '[' . $this -> make_var($var_04144ce3) . ']';
			} 
			$var_3923f601 = implode('', $var_4d715bc1);
		} else {
			$var_3923f601 = $this -> make_var($var_04144ce3);
		} 
		if (!empty($var_a476802c)) {
			foreach($var_a476802c as $var_6cbe6605 => $var_bef9586e) {
				$var_4cce7e5a = explode(':', $var_bef9586e, 2);
				switch ($var_4cce7e5a[0]) {
					case 'default': if ($var_4cce7e5a[1] {
								0} == '$') {
							$var_d8bba397 = $this -> get_val(substr($var_4cce7e5a[1], 1));
						} else if (preg_match('~^"[^\\$]+\\$[a-z,A-Z][\\w]+\\W*[^\\"]*"$~', $var_4cce7e5a[1])) {
							preg_match_all('~(\\$[a-z,A-Z][\\w]+)~', $var_4cce7e5a[1], $var_973d74fe);
							array_shift($var_973d74fe);
							$var_973d74fe = array_shift($var_973d74fe);
							usort($var_973d74fe, 'temp_func_399');
							foreach($var_973d74fe as $var_228572b3 => $var_cb83972b) {
								$var_4cce7e5a[1] = str_replace($var_cb83972b, '{' . $this -> get_val(substr($var_cb83972b, 1)) . '}', $var_4cce7e5a[1]);
							} 
							$var_d8bba397 = $var_4cce7e5a[1];
						} else {
							$var_d8bba397 = $var_4cce7e5a[1];
						} 
						$var_3923f601 = 'empty(' . $var_3923f601 . ') ? ' . $var_d8bba397 . ' : ' . $var_3923f601;
						break;
					default: if (function_exists($var_4cce7e5a[0])) {
							if ($var_4cce7e5a[0] == 'date' && strpos($var_4cce7e5a[1], '###') === false) {
								$var_4cce7e5a[1] .= ',###';
							} 
							if (strpos($var_4cce7e5a[1], '###') !== false) {
								$var_4cce7e5a[1] = str_replace('###', $var_3923f601, $var_4cce7e5a[1]);
							} 
							$var_583d62cb = explode(',', $var_4cce7e5a[1]);
							if ($var_4cce7e5a[1] == '') {
								$var_583d62cb = array($var_3923f601);
							} 
							$var_3923f601 = $var_4cce7e5a[0] . '(' . implode(',', $var_583d62cb) . ')';
						} 
						break;
				} 
			} 
		} 
		return $var_3923f601;
	} 
	public function make_var($var_04144ce3) {
		$var_f89f1924 = array('GLOBALS', '_SERVER', '_GET', '_POST', '_FILES', '_COOKIE', '_SESSION', '_REQUEST', '_ENV');
		if (strrpos($var_04144ce3, '.') === false) {
			if (isset($this -> _var[$var_04144ce3]) && isset($this -> func_87870b9f[$var_04144ce3])) {
				$var_04144ce3 = $this -> func_87870b9f[$var_04144ce3];
			} 
			$var_04144ce3 = trim($var_04144ce3, '"');
			$var_04144ce3 = trim($var_04144ce3, '\'');
			$var_3923f601 = in_array($var_04144ce3, $var_f89f1924)?'$' . $var_04144ce3:'$this->_var[\'' . $var_04144ce3 . '\']';
			preg_match('~^[a-zA-Z_\\x7f-\\xff][\\w\\x7f-\\xff]*~', $var_04144ce3, $var_973d74fe);
			$var_946cddca = str_replace($var_973d74fe[0], '', $var_04144ce3);
			if ($var_946cddca) {
				$var_3923f601 = in_array($var_04144ce3, $var_f89f1924)?'($' . $var_973d74fe[0] . $var_946cddca . ')':'($this->_var[\'' . $var_973d74fe[0] . '\']' . $var_946cddca . ')';
			} 
		} else {
			$var_b4ba575b = explode('.', $var_04144ce3);
			$var_3b1eb635 = array_shift($var_b4ba575b);
			if (isset($this -> _var[$var_3b1eb635]) && isset($this -> func_87870b9f[$var_3b1eb635])) {
				$var_3b1eb635 = $this -> func_87870b9f[$var_3b1eb635];
			} 
			$var_3b1eb635 = trim($var_3b1eb635, '"');
			$var_3b1eb635 = trim($var_3b1eb635, '\'');
			$var_3923f601 = in_array($var_3b1eb635, $var_f89f1924)?'$' . $var_3b1eb635:'$this->_var[\'' . $var_3b1eb635 . '\']';
			foreach($var_b4ba575b as $var_04144ce3) {
				$var_04144ce3 = trim($var_04144ce3, '"');
				$var_04144ce3 = trim($var_04144ce3, '\'');
				$var_3923f601 .= '[\'' . $var_04144ce3 . '\']';
			} 
		} 
		return $var_3923f601;
	} 
	public function &getTemplateVars($var_aca22417 = null) {
		if (empty($var_aca22417)) {
			return $this -> _var;
		} elseif (!empty($this -> _var[$var_aca22417])) {
			return $this -> _var[$var_aca22417];
		} else {
			$var_7766de0b = null;
			return $var_7766de0b;
		} 
	} 
	public function get_params($var_b1e06e80, $var_7c6c92b4 = 1) {
		$var_b1e06e80 = preg_replace('~([\w]+)\s*=\s*([\w\'"]+)~', ' $1=$2', $var_b1e06e80);
		$var_ed252828 = preg_split('~([\\w]+=)~', $var_b1e06e80, 0, PREG_SPLIT_DELIM_CAPTURE);
		array_shift($var_ed252828);
		$var_7bfecb35 = count($var_ed252828);
		$var_0d611593 = array();
		for($var_7ea74e20 = 0;$var_7ea74e20 < $var_7bfecb35;$var_7ea74e20++) {
			if (preg_match('~^(\\w+)=$~', $var_ed252828[$var_7ea74e20])) {
				$var_0d611593[] = trim($var_ed252828[$var_7ea74e20]) . trim($var_ed252828[$var_7ea74e20 + 1]);
				$var_7ea74e20++;
			} 
		} 
		foreach ($var_0d611593 as $var_2ddd548e) {
			if (strrpos($var_2ddd548e, '=')) {
				list($var_55df87ba, $var_7c3e9a74) = explode('=', str_replace(array('"', '\'', '&quot;'), '', $var_2ddd548e));
				if ($var_7c3e9a74 {
						0} == '$') {
					if ($var_7c6c92b4) {
						eval('$para[\'' . $var_55df87ba . '\']=' . $this -> get_val(substr($var_7c3e9a74, 1)) . ';');
					} else {
						$var_27dc5229[$var_55df87ba] = $this -> get_val(substr($var_7c3e9a74, 1));
					} 
				} else {
					$var_27dc5229[$var_55df87ba] = $var_7c3e9a74;
				} 
			} 
		} 
		return $var_27dc5229;
	} 
	public function _compile_if_tag($var_5069cf54, $var_87f2ad21 = false) {
		preg_match_all('/\-?\d+[\.\d]+|\'[^\'|\s]*\'|"[^"|\s]*"|[\$\w\.]+|!==|===|==|!=|<>|<<|>>|<=|>=|&&|\|\||\(|\)|,|\!|\^|=|&|<|>|~|\||\%|\+|\-|\/|\*|\@|\S/', $var_5069cf54, $var_973d74fe);
		$var_ccc3e193 = $var_973d74fe[0];
		$var_31b7c4a3 = array_count_values($var_ccc3e193);
		if (!empty($var_31b7c4a3['(']) && $var_31b7c4a3['('] != $var_31b7c4a3[')']) {
			$this -> _syntax_error('unbalanced parenthesis in if statement', E_USER_ERROR, __FILE__, __LINE__);
		} 
		for($var_7ea74e20 = 0, $var_0d0d86c2 = count($var_ccc3e193); $var_7ea74e20 < $var_0d0d86c2; $var_7ea74e20++) {
			$var_2226d637 = &$var_ccc3e193[$var_7ea74e20];
			switch (strtolower($var_2226d637)) {
				case 'and': $var_2226d637 = '&&';
					break;
				case 'or': $var_2226d637 = '||';
					break;
				default: if ($var_2226d637[0] == '$') {
						$var_2226d637 = $this -> get_val(substr($var_2226d637, 1));
					} 
					break;
			} 
		} 
		if ($var_0d0d86c2 == 6 && $var_ccc3e193[2][0] != '$') {
		} 
		$var_40db88e3 = $var_0d0d86c2 == 6 ?($var_ccc3e193[0] . $var_ccc3e193[1] . $var_ccc3e193[2] . $var_ccc3e193[3] . ' ' . $var_ccc3e193[4] . ' ' . $var_ccc3e193[5]) : implode(' ', $var_ccc3e193);
		if ($var_87f2ad21) {
			return '<?php elseif(' . $var_40db88e3 . '): ?>';
		} else {
			return '<?php if(' . $var_40db88e3 . '): ?>';
		} 
	} 
	public function _compile_foreach_start($var_5069cf54) {
		if (stripos($var_5069cf54, ' as ') !== false) {
			$var_5069cf54 = trim($var_5069cf54);
			$var_5069cf54 = str_ireplace(' as ', ' as ', $var_5069cf54);
			$var_586a20ab = explode(' as ', $var_5069cf54);
			$var_f8f20725 = $this -> get_params('from=' . $var_586a20ab[0], 0);
			if (strpos($var_586a20ab[1], '=>') !== false) {
				list($var_228572b3, $var_cb83972b) = explode('=>', $var_586a20ab[1]);
				$var_f8f20725['item'] = substr(trim($var_cb83972b), 1);
				$var_f8f20725['key'] = substr(trim($var_228572b3), 1);
			} else {
				$var_f8f20725['item'] = substr(trim($var_586a20ab[1]), 1);
			} 
		} else {
			$var_f8f20725 = $this -> get_params($var_5069cf54, 0);
		} 
		$var_10c2a0f7 = array();
		$var_b0644602 = $var_f8f20725['from'];
		if (isset($this -> _var[$var_f8f20725['item']]) && !isset($this -> func_87870b9f[$var_f8f20725['item']]) and 1 == 2) {
			$this -> func_87870b9f[$var_f8f20725['item']] = $var_f8f20725['item'] . '_' . str_replace(array(' ', '.'), '_', microtime());
			$var_f8f20725['item'] = $this -> func_87870b9f[$var_f8f20725['item']];
		} else {
			$this -> func_87870b9f[$var_f8f20725['item']] = $var_f8f20725['item'];
		} 
		$var_c73949df = $this -> get_val($var_f8f20725['item']);
		if (!empty($var_f8f20725['key'])) {
			$var_6cbe6605 = $var_f8f20725['key'];
			$var_d6394f46 = $this -> get_val($var_6cbe6605) . ' => ';
		} else {
			$var_6cbe6605 = null;
			$var_d6394f46 = '';
		} 
		if (!empty($var_f8f20725['name'])) {
			$var_aca22417 = $var_f8f20725['name'];
		} else {
			$var_aca22417 = null;
		} 
		$var_970de168 = '<?php ';
		$var_970de168 .= "\$_from=$var_b0644602; if(!is_array(\$_from) && !is_object(\$_from)){ settype(\$_from, 'array'); }; \$this->push_vars('$var_f8f20725[key]', '$var_f8f20725[item]');";
		if (!empty($var_aca22417)) {
			$var_de46b657 = "\$this->_foreach['$var_aca22417']";
			$var_970de168 .= "{$var_de46b657}=array('total' => count(\$_from), 'iteration' => 0);\n";
			$var_970de168 .= "if({$var_de46b657}['total'] > 0):\n";
			$var_970de168 .= "    foreach(\$_from AS $var_d6394f46$var_c73949df):\n";
			$var_970de168 .= "        {$var_de46b657}['iteration']++;\n";
		} else {
			$var_970de168 .= 'if(count($_from)):
';
			$var_970de168 .= "    foreach(\$_from AS $var_d6394f46$var_c73949df):\n";
		} 
		return $var_970de168 . '?>';
	} 
	public function push_vars($var_6cbe6605, $var_04144ce3) {
		if (!empty($var_6cbe6605)) {
			array_push($this -> func_8f00d9d7, "\$this->_vars['$var_6cbe6605']='" . $this -> func_0e47bf0e[$var_6cbe6605] . "';");
		} 
		if (!empty($var_04144ce3)) {
			array_push($this -> func_990ab60d, "\$this->_vars['$var_04144ce3']='" . $this -> func_0e47bf0e[$var_04144ce3] . '\';');
		} 
	} 
	public function pop_vars() {
		$var_6cbe6605 = array_pop($this -> func_8f00d9d7);
		$var_04144ce3 = array_pop($this -> func_990ab60d);
		if (!empty($var_6cbe6605)) {
			eval($var_6cbe6605);
		} 
	} 
	function prefilter_preCompile($var_59f3caff) {
		$var_64a3d726 = strtolower(strrchr($this -> func_e46a9b4a, '.'));
		$var_ba5b373d = array('/<!--[^>|\\n]*?({.+?})[^<|{|\\n]*?-->/', '/<!--[^\\n]*?-->/',);
		$var_43bf0de7 = array('\\1', '',);
		return preg_replace($var_ba5b373d, $var_43bf0de7, $var_59f3caff);
	} 
	public function parse_params($var_40db88e3) {
		while (strpos($var_40db88e3, '= ') != 0) {
			$var_40db88e3 = str_replace('= ', '=', $var_40db88e3);
		} while (strpos($var_40db88e3, ' =') != 0) {
			$var_40db88e3 = str_replace(' =', '=', $var_40db88e3);
		} 
		return explode(' ', trim($var_40db88e3));
	} 
	public function _eval($var_8eafab80) {
		ob_start();
		eval('?' . '>' . trim($var_8eafab80));
		$var_8eafab80 = ob_get_contents();
		ob_end_clean();
		return $var_8eafab80;
	} 
	public function _require($var_3d815bdc) {
		debug_log('start_require' . $var_3d815bdc);
		debug_log('start_require' . $var_3d815bdc, 'end');
		debug_log('_require' . $var_3d815bdc);
		ob_start();
		include $var_3d815bdc;
		$var_8eafab80 = ob_get_contents();
		ob_end_clean();
		debug_log('_require' . $var_3d815bdc, 'end');
		return $var_8eafab80;
	} 
	public function make_array($var_586a20ab) {
		$var_77704151 = '';
		foreach($var_586a20ab AS $var_6cbe6605 => $var_04144ce3) {
			if ($var_04144ce3 {
					0} == '$') {
				$var_77704151 .= $var_77704151 ? ",'$var_6cbe6605'=>$var_04144ce3" : "array('$var_6cbe6605'=>$var_04144ce3";
			} else {
				$var_77704151 .= $var_77704151 ? ",'$var_6cbe6605'=>'$var_04144ce3'" : "array('$var_6cbe6605'=>'$var_04144ce3'";
			} 
		} 
		return $var_77704151 . ')';
	} 
	function get_math_para($var_04144ce3) {
		$var_088c0158 = $this -> parse_params($var_04144ce3);
		foreach($var_088c0158 AS $var_2ddd548e) {
			if (strrpos($var_2ddd548e, '=')) {
				list($var_55df87ba, $var_7c3e9a74) = explode('=', str_replace(array(' ', '"', '\'', '"'), '', $var_2ddd548e));
				if (strpos($var_7c3e9a74, '$') >= 0) {
					$var_ba5b373d = '/\\$[_a-zA-z]+[a-zA-Z0-9_]*/';
					preg_match($var_ba5b373d, $var_7c3e9a74, $var_586a20ab);
					if ($var_586a20ab) {
						foreach($var_586a20ab as $var_973d74fe) {
							$var_d8bba397 = $this -> get_val(substr($var_973d74fe, 1));
							$var_7c3e9a74 = str_replace($var_973d74fe, $var_d8bba397, $var_7c3e9a74);
						} 
					} 
				} 
			} 
		} 
		return $var_7c3e9a74;
	} 
	private function write($var_980a7c7e, $var_de5c1562, $var_6c1a8580 = "w") {
		$var_fae1bb2a = dirname($var_980a7c7e);
		if (!is_dir($var_fae1bb2a)) {
			mkdir($var_fae1bb2a, 511, true);
		} 
		if (is_file($var_980a7c7e) && !is_writable($var_980a7c7e)) {
			return false;
		} 
		$var_35b7c6eb = false;
		if ($var_04416560 = fopen($var_980a7c7e, $var_6c1a8580)) {
			$var_d33931b9 = microtime();
			do {
				$var_c7179559 = flock($var_04416560, 2 | 4);
				if (!$var_c7179559) {
					usleep(round(rand(0, 100) * 1000));
				} 
			} while ((!$var_c7179559) && ((microtime() - $var_d33931b9) < 1000));
			if ($var_c7179559) {
				$var_35b7c6eb = fwrite($var_04416560, $var_de5c1562);
			} 
			fclose($var_04416560);
		} 
		return $var_35b7c6eb;
	} 
	public function __call($var_6c1a8580, $var_583d62cb) {
		static $var_db03ccf4 = array();
		$var_6d80144c = preg_replace('~^tag_~', '', $var_6c1a8580);
		$var_6d80144c = str_replace('_', '.', $var_6d80144c);
		$var_537a67d9 = $this -> func_7221644a . $var_6d80144c . '.php';
		if (is_file($var_537a67d9)) {
			$var_6cbe6605 = md5($var_537a67d9);
			if (!isset($var_db03ccf4[$var_6cbe6605])) {
				$var_db03ccf4[$var_6cbe6605] = true;
				include_once($var_537a67d9);
			} 
			$var_9774b4cc = preg_replace('~^tag_([a-z]+)_([a-z]+)~', '$2', $var_6c1a8580);
			$var_9c8e42b9 = 'tag_' . $var_9774b4cc . '_runtime';
			if (!isset($GLOBALS[$var_9c8e42b9])) {
				$GLOBALS[$var_9c8e42b9] = 0;
			} 
			_runtime($var_9c8e42b9);
			$var_55df87ba = $var_6c1a8580($var_583d62cb);
			$GLOBALS[$var_9c8e42b9] += _runtime($var_9c8e42b9, 'end');
			return $var_55df87ba;
		} 
	} 
} 

?>