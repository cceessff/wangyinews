<?php class sys {
	static public function run() {
		self :: init();
	} 
	static private function init() {
		header("Content-type: text/html; charset=utf-8");
		define('REQUEST_METHOD', $_SERVER['REQUEST_METHOD']);
		define('DEFINE_MY_3', $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://');
		define('IS_GET', REQUEST_METHOD == 'GET' ? true : false);
		define('IS_POST', REQUEST_METHOD == 'POST' ? true : false);
		define('IS_PUT', REQUEST_METHOD == 'PUT' ? true : false);
		define('IS_DELETE', REQUEST_METHOD == 'DELETE' ? true : false);
		define('IS_AJAX', ((isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')) ? true : false);
		@register_shutdown_function(array('sys', 'fatalError'));
		@set_error_handler(array('sys', 'appError'));
		@set_exception_handler(array('sys', 'appException'));
		spl_autoload_register(array('sys', 'autoload'));
		if (is_file(FUNCTION_PATH . 'function.php')) {
			$var_88a8534a = FUNCTION_PATH . 'function.php';
			if (config('AUTOLOAD_ENCODE')) {
				$var_88a8534a = FUNCTION_PATH . 'xxfseo_' . md5('function.php' . 'xxfseo') . '.php';
			}
			include $var_88a8534a;
		}
		if (is_file(CONFIG_PATH . 'config.php')) {
			config(include CONFIG_PATH . 'config.php');
		} 
		$var_14f3c75e = config('URL_MODEL');
		if ($var_14f3c75e == 2) {
			define('PHP_FILE', _PHP_FILE_);
		} elseif ($var_14f3c75e == 3) {
			$var_1003d5bb = dirname(_PHP_FILE_);
			if ($var_1003d5bb == '/' || $var_1003d5bb == '\\') $var_1003d5bb = '';
			define('PHP_FILE', $var_1003d5bb);
		} else {
			define('PHP_FILE', _PHP_FILE_);
		} 
		define('__APP__', strip_tags(PHP_FILE));
		$var_fc073b09 = new route;

		if (!empty($_SERVER['QUERY_STRING']) && !$var_fc073b09 -> check()) {
			$var_2a6b2574 = config('URL_PATH_DEPR');
			if (isset($_GET[config('GROUP_VAR')])) {
				$var_14f3c75e = 1;
			} else if (preg_match('~^([\\w' . config('URL_PATH_DEPR') . ']+)~', $_SERVER['QUERY_STRING'])) {
				$var_14f3c75e = 2;
			} 
			if ($var_14f3c75e == 1) {
			} 
			if ($var_14f3c75e == 2) {
				$_SERVER['QUERY_STRING'] = str_replace(array('.' . config('URL_PATH_SUFFIX') . '&', '&', '='), config('URL_PATH_DEPR'), $_SERVER['QUERY_STRING']);
				$var_4270dd5a = pathinfo($_SERVER['QUERY_STRING']);
				$var_e6e89a5b = isset($var_4270dd5a['extension'])?strtolower($var_4270dd5a['extension']):'';
				if ($var_e6e89a5b) {
					$_SERVER['QUERY_STRING'] = preg_replace('/\\.(' . trim(config('URL_PATH_SUFFIX'), '.') . ')$/i', '', $_SERVER['QUERY_STRING']);
				} else {
					$_SERVER['QUERY_STRING'] = preg_replace('/\\.' . $var_e6e89a5b . '$/i', '', $_SERVER['QUERY_STRING']);
				} 
				$var_3f177263 = explode($var_2a6b2574, $_SERVER['QUERY_STRING']);
				$var = array();
				if (config('APP_GROUP_LIST') && !isset($_GET[config('GROUP_VAR')])) {
					$var[config('GROUP_VAR')] = in_array(strtolower($var_3f177263[0]), explode(',', strtolower(config('APP_GROUP_LIST'))))? array_shift($var_3f177263) : '';
				} 
				if (!isset($_GET[config('MODULE_VAR')])) {
					$var[config('MODULE_VAR')] = array_shift($var_3f177263);
				} 
				$var[config('ACTION_VAR')] = array_shift($var_3f177263);
				preg_match_all('~(\\w+)\\/([^\\/]+)~', implode('/', $var_3f177263), $var_973d74fe);
				foreach($var_973d74fe[1] as $var_228572b3 => $var_cb83972b) {
					$var[$var_cb83972b] = strip_tags($var_973d74fe[2][$var_228572b3]);
				} 
				$_GET = array_merge($var, $_GET);
			} 
		} 
		if (config('APP_GROUP_LIST')) {
			define('GROUP_NAME', self :: getGroup(config('GROUP_VAR')));
			$var_a4040fe1 = CONFIG_PATH . GROUP_NAME . '/';
			$var_e5e7eeed = FUNCTION_PATH . GROUP_NAME . '/';
			if (is_file($var_a4040fe1 . 'config.php')) config(include $var_a4040fe1 . 'config.php');
			if (is_file($var_e5e7eeed . 'function.php')) include $var_e5e7eeed . 'function.php';
		}
		define('MODULE_NAME', self :: getModule(config('MODULE_VAR')));
		define('ACTION_NAME', self :: getAction(config('ACTION_VAR')));
		$_REQUEST = array_merge($_POST, $_GET);
		$var_a118132d = defined('GROUP_NAME') ? GROUP_NAME . '/' : '';
		$var_7cca9dc1 = action($var_a118132d . MODULE_NAME);
		$var_88fe0209 = ACTION_NAME;
		if (!preg_match('/^[A-Za-z](\\w)*$/', MODULE_NAME)) {
			if (APP_DEBUG || config('web_debug')) {
				throw_exception('非法模块:' . MODULE_NAME);
			} else {
				$var_7cca9dc1 = action($var_a118132d . 'empty');
			} 
		} 
		if (!$var_7cca9dc1) {
			$var_7cca9dc1 = action($var_a118132d . 'empty');
			if (!$var_7cca9dc1) {
				throw_exception('未找到模块:' . MODULE_NAME);
			} 
		}
		try {
			if (!preg_match('/^[A-Za-z](\\w)*$/', $var_88fe0209)) {
				throw new ReflectionException();
			}
			$var_6c1a8580 = new ReflectionMethod($var_7cca9dc1, $var_88fe0209);
			if ($var_6c1a8580 -> isPublic()) {
				$var_36a0b2a2 = new ReflectionClass($var_7cca9dc1);
				if ($var_6c1a8580 -> getNumberOfParameters() > 0) {
					switch ($_SERVER['REQUEST_METHOD']) {
						case 'POST': $var_b1b7cce3 = $_REQUEST;
							break;
						case 'PUT': parse_str(file_get_contents('php://input'), $var_b1b7cce3);
							break;
						default: $var_b1b7cce3 = $_GET;
					} 
					$var_43b9b911 = $var_6c1a8580 -> getParameters();
					foreach ($var_43b9b911 as $var_3d20800d) {
						$var_aca22417 = $var_3d20800d -> getName();
						if (isset($var_b1b7cce3[$var_aca22417])) {
							$var_583d62cb[] = $var_b1b7cce3[$var_aca22417];
						} elseif ($var_3d20800d -> isDefaultValueAvailable()) {
							$var_583d62cb[] = $var_3d20800d -> getDefaultValue();
						} else {
							throw_exception('参数未定义:' . $var_aca22417);
						} 
					} 
					$var_6c1a8580 -> invokeArgs($var_7cca9dc1, $var_583d62cb);
				} else {
					$var_6c1a8580 -> invoke($var_7cca9dc1);
				} 
			} else {
				throw new ReflectionException();
			} 
		} 
		catch (ReflectionException $e) {
			$var_6c1a8580 = new ReflectionMethod($var_7cca9dc1, '__call');
			$var_6c1a8580 -> invokeArgs($var_7cca9dc1, array($var_88fe0209, ''));
		} 
		return ;
	} 
	public static function autoload($var_36a0b2a2) {
		if (require_load($var_36a0b2a2)) return ;
		$var_a118132d = defined('GROUP_NAME') ? GROUP_NAME : '';
		$var_980a7c7e = $var_36a0b2a2 . '.class.php';
		$var_ff2f067b = 'xxfseo_' . md5($var_980a7c7e . 'xxfseo') . 'Action.class.php';
		if (config('AUTOLOAD_ENCODE')) {
			$var_980a7c7e = $var_ff2f067b;
			$var_a118132d = 'xxfseo_' . md5($var_a118132d . 'xxfseo');
		} 
		if (substr($var_36a0b2a2, - 6) == 'Action') {
			require_load(APPLIB_PATH . 'action/' . $var_a118132d . '/' . $var_980a7c7e);
			require_load(APPLIB_PATH . 'action/' . $var_980a7c7e);
		} 
		return ;
	} 
	static private function getGroup($var) {
		$var_a118132d = (!empty($_GET[$var])?$_GET[$var]:config('DEFAULT_GROUP'));
		return strip_tags($var_a118132d);
	} 
	static private function getModule($var) {
		$var_7cca9dc1 = (!empty($_GET[$var])? $_GET[$var]:config('DEFAULT_MODULE'));
		return strip_tags($var_7cca9dc1);
	} 
	static private function getAction($var) {
		$var_88fe0209 = !empty($_POST[$var]) ? $_POST[$var] : (!empty($_GET[$var])?$_GET[$var]:config('DEFAULT_ACTION'));
		return strip_tags(strtolower($var_88fe0209));
	} 
	static public function appException($e) {
		$var_8e75327e = array();
		$var_8e75327e['message'] = $e -> getMessage();
		$var_644871f4 = $e -> getTrace();
		if ('throw_exception' == $var_644871f4[0]['function']) {
			$var_8e75327e['file'] = $var_644871f4[0]['file'];
			$var_8e75327e['line'] = $var_644871f4[0]['line'];
		} else {
			$var_8e75327e['file'] = $e -> getFile();
			$var_8e75327e['line'] = $e -> getLine();
		} 
		if (config('LOG_RECORD')) log :: record($var_8e75327e['message'], 'ERROR');
		exception($var_8e75327e);
	} 
	static public function appError($var_229f34da, $var_96d534c9, $var_9559e6e4, $var_45432727) {
		switch ($var_229f34da) {
			case E_ERROR: case E_PARSE: case E_CORE_ERROR: case E_COMPILE_ERROR: case E_USER_ERROR: ob_end_clean();
				if (config('OUTPUT_ENCODE')) {
					$var_eb9eec05 = ini_get('zlib.output_compression');
					if (empty($var_eb9eec05)) ob_start('ob_gzhandler');
				} 
				$var_ccb7787a = "$var_96d534c9 " . $var_9559e6e4 . " 第 $var_45432727 行.";
				if (config('LOG_RECORD')) log :: write("[$var_229f34da] " . $var_ccb7787a, 'ERROR');
				function_exists('exception')?exception($var_ccb7787a):exit('ERROR:' . $var_ccb7787a);
				break;
			case E_STRICT: case E_USER_WARNING: case E_USER_NOTICE: default: break;
		} 
	} 
	static public function fatalError() {
		if (config('LOG_RECORD')) {
			log :: save();
		} 
		if ($e = error_get_last()) {
			switch ($e['type']) {
				case E_ERROR: case E_PARSE: case E_CORE_ERROR: case E_COMPILE_ERROR: case E_USER_ERROR: ob_end_clean();
					if (config('LOG_RECORD')) {
						$var_da035f13 = $e['message'] . '	 file:' . relative_path($e['file']) . ' [LINE ' . $e['line'] . ']';
						log :: write($var_da035f13, 'ERROR');
					} 
					function_exists('exception')?exception($e):exit('ERROR:' . $e['message']);
					break;
			} 
		} 
	} 
} 
