<?php class db {
	public $var_321df73e = null;
	protected $var_970e3c94 = null;
	public $var_0adfc25e = '';
	public $var_099a9d7e = '';
	private $var_de5c1562 = array();
	private $var_4c819857 = array();
	protected $var_77a6cb90 = null;
	public $var_180cb4bf = false;
	protected $var_6279702c = array();
	private $var_37407cbe = array('eq' => '=', 'neq' => '!=', 'gt' => '>', 'egt' => '>=', 'lt' => '<', 'elt' => '<=', 'notlike' => 'NOT LIKE', 'like' => 'LIKE');
	public function __construct($var_75300211 = '') {
		if (config('db_type') == '') {
			config('db_type', 'mysql');
		} 
		if (config('db_charset') == '') {
			config('db_charset', 'utf8');
		} 
		$this -> func_ebf65a13['db_type'] = isset($var_75300211['db_type'])?$var_75300211['db_type']:config('db_type');
		$this -> func_ebf65a13['db_host'] = isset($var_75300211['db_host'])?$var_75300211['db_host']:config('db_host');
		$this -> func_ebf65a13['db_user'] = isset($var_75300211['db_user'])?$var_75300211['db_user']:config('db_user');
		$this -> func_ebf65a13['db_pwd'] = isset($var_75300211['db_pwd'])?$var_75300211['db_pwd']:config('db_pwd');
		$this -> func_ebf65a13['db_port'] = isset($var_75300211['db_port'])?$var_75300211['db_port']:config('db_port');
		$this -> func_ebf65a13['db_name'] = isset($var_75300211['db_name'])?$var_75300211['db_name']:config('db_name');
		$this -> func_ebf65a13['db_charset'] = isset($var_75300211['db_charset'])?$var_75300211['db_charset']:config('db_charset');
		$this -> func_ebf65a13['db_prefix'] = isset($var_75300211['db_prefix'])?$var_75300211['db_prefix']:config('db_prefix');
		$this -> func_ebf65a13['db_pconnect'] = isset($var_75300211['db_pconnect'])?$var_75300211['db_pconnect']:config('db_pconnect');
		$this -> func_ebf65a13['db_debug'] = isset($var_75300211['db_debug'])?$var_75300211['db_debug']:config('db_debug');
		$this -> func_c1e8b295['_field'] = '*';
		$this -> initConnect();
	} 
	public function initConnect() {
		if ($this -> func_54ccf274) {
			return false;
		} 
		$var_75300211 = $this -> parseConfig($this -> func_ebf65a13);
		$this -> func_dcfd9761 = ucwords(strtolower($var_75300211['dbms']));
		$var_072395ec = LIB_PATH . 'db/dbPdo.class.php';
		require_load($var_072395ec);
		$this -> func_1ae4b444 = new dbPdo();
		$var_35b7c6eb = $this -> func_1ae4b444 -> connect($var_75300211);
		if ($var_35b7c6eb) $this -> func_54ccf274 = true;
	} 
	public function table($var_d69d318b, $var_4b296289 = false) {
		if ($var_4b296289) {
			$this -> func_c1e8b295['_table'] = $this -> addSpecialChar($var_d69d318b);
		} else {
			$var_d69d318b = $this -> func_ebf65a13['db_prefix'] . $var_d69d318b;
			$this -> func_c1e8b295['_table'] = $this -> addSpecialChar($var_d69d318b);
		} 
		return $this;
	} 
	public function cache($var_98693aab = 0, $var_6cbe6605 = '') {
		if ($var_98693aab) {
			$this -> func_c1e8b295['cache'] = array('cachetime' => $var_98693aab, 'key' => $var_6cbe6605);
		} else {
			$this -> func_c1e8b295['cache'] = false;
		} 
		return $this;
	} 
	public function __call($var_6c1a8580, $var_583d62cb) {
		$var_6c1a8580 = strtolower($var_6c1a8580);
		if (in_array($var_6c1a8580, array('field', 'data', 'where', 'group', 'having', 'order', 'limit'))) {
			$this -> func_c1e8b295['_' . $var_6c1a8580] = $var_583d62cb[0];
			return $this;
		} else if (method_exists($this -> func_1ae4b444, $var_6c1a8580)) {
			$this -> func_1ae4b444 -> $var_6c1a8580($var_583d62cb);
		} else {
			$this -> error($var_6c1a8580 . '方法在类中没有定义');
		} 
	} 
	protected function _getDsnType($var_71b05d11) {
		$var_973d74fe = explode(':', $var_71b05d11);
		$var_970e3c94 = strtoupper(trim($var_973d74fe[0]));
		return $var_970e3c94;
	} 
	public function parseDSN($var_2968582b) {
		if (empty($var_2968582b)) {
			return false;
		} 
		$var_35702f41 = parse_url($var_2968582b);
		if ($var_35702f41['scheme']) {
			$var_71b05d11 = array('dbms' => $var_35702f41['scheme'], 'username' => isset($var_35702f41['user']) ? $var_35702f41['user'] : '', 'password' => isset($var_35702f41['pass']) ? $var_35702f41['pass'] : '', 'hostname' => isset($var_35702f41['host']) ? $var_35702f41['host'] : '', 'hostport' => isset($var_35702f41['port']) ? $var_35702f41['port'] : '', 'database' => isset($var_35702f41['path']) ? substr($var_35702f41['path'], 1) : '');
		} else {
			preg_match('/^(.*?)\\:\\/\\/(.*?)\\:(.*?)\\@(.*?)\\:([0-9]{1, 6})\\/(.*?)$/', trim($var_2968582b), $matches);
			$var_71b05d11 = array('dbms' => $matches[1], 'username' => $matches[2], 'password' => $matches[3], 'hostname' => $matches[4], 'hostport' => $matches[5], 'database' => $matches[6]);
		} 
		$var_71b05d11['dsn'] = '';
		return $var_71b05d11;
	} 
	private function parseConfig($var_75300211 = '') {
		if (!empty($var_75300211) && is_string($var_75300211)) {
			$var_75300211 = $this -> parseDSN($var_75300211);
		} elseif (is_array($var_75300211)) {
			$var_75300211 = array_change_key_case($var_75300211);
			$var_75300211 = array('dbms' => $var_75300211['db_type'], 'username' => $var_75300211['db_user'], 'password' => $var_75300211['db_pwd'], 'hostname' => $var_75300211['db_host'], 'hostport' => $var_75300211['db_port'], 'database' => $var_75300211['db_name'], 'dsn' => $var_75300211['db_dsn'], 'params' => $var_75300211['db_params'],);
		} elseif (empty($var_75300211)) {
			$this -> error('数据库信息未配置');
		} 
		if ($var_75300211['dsn'] == '' && 'mysql' == strtolower($var_75300211['dbms'])) {
			$var_75300211['dsn'] = 'mysql:host=' . $var_75300211['hostname'] . ';';
			if ($var_75300211['database']) {
				$var_75300211['dsn'] .= 'dbname=' . $var_75300211['database'] . ';';
			} 
			$var_75300211['dsn'] .= 'charset=utf8';
		} 
		return $var_75300211;
	} 
	public function startTrans() {
		return $this -> func_1ae4b444 -> startTrans();
	} 
	public function commit() {
		return $this -> func_1ae4b444 -> commit();
	} 
	public function rollback() {
		return $this -> func_1ae4b444 -> rollback();
	} 
	public function query($var_0adfc25e) {
		if (empty($var_0adfc25e)) {
			return false;
		} 
		$this -> func_3bfdeefc = $var_0adfc25e;
		return $this -> func_1ae4b444 -> query($this -> func_3bfdeefc);
	} 
	public function count($var_dce42d17 = '') {
		$var_d69d318b = $this -> func_c1e8b295['_table'];
		if ($var_dce42d17 == '') {
			$this -> func_c1e8b295['_field'] = 'count(*) as dtp';
		} else {
			$this -> func_c1e8b295['_field'] = 'count(' . $var_dce42d17 . ') as dtp';
		} 
		if (isset($this -> func_c1e8b295['cache']) && !$this -> func_c1e8b295['cache']['key']) {
			$this -> func_c1e8b295['cache']['key'] = 'count';
		} 
		$var_de5c1562 = $this -> select();
		return $var_de5c1562[0]['dtp'];
	} 
	public function find() {
		return $this -> select(1);
	} 
	public function select($var_076f5a97 = '') {
		$var_d69d318b = $this -> func_c1e8b295['_table'];
		$var_dce42d17 = $this -> func_c1e8b295['_field'];
		$var_dce42d17 = $this -> parseField($var_dce42d17);
		if ($var_076f5a97) {
			$this -> func_c1e8b295['_limit'] = $var_076f5a97;
		} 
		$var_02d59e09 = false;
		if ($var_076f5a97 == 1 || $var_076f5a97 == '0,1') {
			$var_02d59e09 = true;
		} 
		$var_ae21f2d5 = $this -> _parseCondition();
		$this -> func_c1e8b295['_field'] = '*';
		$this -> func_3bfdeefc = "SELECT $var_dce42d17 FROM $var_d69d318b $var_ae21f2d5";
		$var_c1f322eb = isset($this -> func_c1e8b295['cache'])?$this -> func_c1e8b295['cache']:false;
		if ($var_c1f322eb) {
			$var_a3e5f0ff = $var_c1f322eb['key'] . '/' . getHashDir($this -> func_3bfdeefc) . '/' . md5($this -> func_3bfdeefc);
			$var_de5c1562 = data('dbDatas/' . $var_a3e5f0ff, '', $var_c1f322eb['cachetime']);
			if (false !== $var_de5c1562) {
				return $var_de5c1562;
			} 
		} 
		$var_35b7c6eb = $this -> query($this -> func_3bfdeefc);
		if ($var_35b7c6eb === false) {
			return false;
		} 
		$var_de5c1562 = $var_02d59e09?$var_35b7c6eb[0]:$var_35b7c6eb;
		if ($var_c1f322eb && $var_de5c1562) {
			data('dbDatas/' . $var_a3e5f0ff, $var_de5c1562);
		} 
		return $var_de5c1562;
	} 
	public function add($var_de5c1562 = array()) {
		if (!empty($var_de5c1562)) {
			$this -> func_c1e8b295['_data'] = $var_de5c1562;
		} 
		return $this -> insert();
	} 
	public function save($var_de5c1562 = array()) {
		if (!empty($var_de5c1562)) {
			$this -> func_c1e8b295['_data'] = $var_de5c1562;
		} 
		return $this -> update();
	} 
	public function insert() {
		$var_d69d318b = $this -> func_c1e8b295['_table'];
		$var_de5c1562 = $this -> _parseData('add');
		$this -> func_3bfdeefc = "INSERT INTO $var_d69d318b $var_de5c1562" ;
		$var_67989c71 = $this -> func_1ae4b444 -> execute($this -> func_3bfdeefc);

		if ($this -> func_1ae4b444 -> affectedRows()) {
			return $this -> func_1ae4b444 -> getLastInsertId();
		} 
		return false;
	} 
	public function replace() {
		$var_d69d318b = $this -> func_c1e8b295['_table'];
		$var_de5c1562 = $this -> _parseData('add');
		$this -> func_3bfdeefc = "REPLACE INTO $var_d69d318b $var_de5c1562" ;
		$var_67989c71 = $this -> query($this -> func_3bfdeefc);

		if ($this -> func_1ae4b444 -> affectedRows()) {
			return $this -> func_1ae4b444 -> getLastInsertId();
		} 
		return false;
	} 
	public function update() {
		$var_d69d318b = $this -> func_c1e8b295['_table'];
		$var_de5c1562 = $this -> _parseData('save');
		$var_ae21f2d5 = $this -> _parseCondition();
		if (empty($var_de5c1562)) return false;
		if (empty($var_ae21f2d5)) return false;
		$this -> func_3bfdeefc = "UPDATE $var_d69d318b $var_de5c1562 $var_ae21f2d5" ;
		return $this -> func_1ae4b444 -> execute($this -> func_3bfdeefc);
	} 
	public function delete() {
		$var_d69d318b = $this -> func_c1e8b295['_table'];
		$var_ae21f2d5 = $this -> _parseCondition();
		if (empty($var_ae21f2d5)) {
			return false;
		} 
		$this -> func_3bfdeefc = "DELETE FROM $var_d69d318b $var_ae21f2d5";
		return $this -> func_1ae4b444 -> execute($this -> func_3bfdeefc);
	} 
	public function setInc($var_dce42d17, $var_b2f8d2d7 = 1) {
		return $this -> setField($var_dce42d17, array('exp', $var_dce42d17 . '+' . $var_b2f8d2d7));
	} 
	public function setDec($var_dce42d17, $var_b2f8d2d7 = 1) {
		return $this -> setField($var_dce42d17, array('exp', $var_dce42d17 . '-' . $var_b2f8d2d7));
	} 
	public function setField($var_dce42d17, $var_2ddd548e = '') {
		if (is_array($var_dce42d17)) {
			$var_de5c1562 = $var_dce42d17;
		} else {
			$var_de5c1562[$var_dce42d17] = $var_2ddd548e;
		} 
		return $this -> save($var_de5c1562);
	} 
	public function getError() {
		return $this -> func_1ae4b444 -> getError();
	} 
	public function getLastSql() {
		return $this -> func_1ae4b444 -> getLastSql();
	} 
	public function getSql() {
		return $this -> func_3bfdeefc;
	} 
	public function checkField($var_dce42d17) {
		if (empty($this -> func_3c88378a)) {
			$var_d69d318b = str_replace('`', '', $this -> func_c1e8b295['_table']);
			$this -> flushFields($var_d69d318b);
		} 
		if ($this -> func_3c88378a) {
			if (is_numeric($var_dce42d17) || !in_array($var_dce42d17, $this -> func_3c88378a['names'])) {
				return false;
			} 
		} 
		return true;
	} 
	public function flushFields($var_d69d318b) {
		$var_a3e5f0ff = $this -> func_ebf65a13['db_type'] . '_' . $var_d69d318b . '_info';
		$var_de5c1562 = data('dbfields/' . $var_a3e5f0ff, '', 3600);
		if ($var_de5c1562) {
			$this -> func_3c88378a = $var_de5c1562;
			return ;
		} 
		$var_b363a655 = $this -> func_1ae4b444 -> getFields($var_d69d318b);
		if (!$var_b363a655) {
			return false;
		} 
		$this -> func_3c88378a = array();
		$this -> func_3c88378a['names'] = array_keys($var_b363a655);
		$this -> func_3c88378a['_autoinc'] = false;
		$var_7c6c92b4 = $var_036996a3 = $var_5e30735b = array();
		foreach ($var_b363a655 as $var_6cbe6605 => $var_04144ce3) {
			$var_7c6c92b4[$var_6cbe6605] = $var_04144ce3['type'];
			$var_036996a3[$var_6cbe6605] = $var_04144ce3['default'];
			$var_5e30735b[$var_6cbe6605] = $var_04144ce3['notnull'];
			if ($var_04144ce3['primary']) {
				$this -> func_3c88378a['_pk'] = $var_6cbe6605;
				if ($var_04144ce3['autoinc']) $this -> func_3c88378a['_autoinc'] = true;
			} 
		} 
		$this -> func_3c88378a['_default'] = $var_036996a3;
		$this -> func_3c88378a['_type'] = $var_7c6c92b4;
		$this -> func_3c88378a['_notnull'] = $var_5e30735b;
		data('dbfields/' . $var_a3e5f0ff, $this -> func_3c88378a);
	} 
	private function _parseData($var_7c6c92b4) {
		if ((!isset($this -> func_c1e8b295['_data'])) || (empty($this -> func_c1e8b295['_data']))) {
			unset($this -> func_c1e8b295['_data']);
			return false;
		} 
		if (is_string($this -> func_c1e8b295['_data'])) {
			$var_de5c1562 = $this -> func_c1e8b295['_data'];
			unset($this -> func_c1e8b295['_data']);
			return $var_de5c1562;
		} 
		if ($var_7c6c92b4 == 'add') {
			$var_d69d318b = str_replace('`', '', $this -> func_c1e8b295['_table']);
			$this -> flushFields($var_d69d318b);
			$var_916bd36e = array_diff($this -> func_3c88378a['names'], array_keys($this -> func_c1e8b295['_data']));
			if ($var_916bd36e) {
				foreach($var_916bd36e as $var_228572b3 => $var_cb83972b) {
					if ($var_cb83972b <> $this -> func_3c88378a['_pk'] && $this -> func_3c88378a['_notnull'][$var_cb83972b] && $this -> func_3c88378a['_default'][$var_cb83972b] === null) {
						$this -> func_c1e8b295['_data'][$var_cb83972b] = '';
					} 
				} 
			} 
		} 
		foreach($this -> func_c1e8b295['_data'] as $var_6cbe6605 => $var_2ddd548e) {
			if ($var_2ddd548e == '' && preg_match('~int$~', $this -> func_3c88378a['_type'][$var_6cbe6605])) {
				$var_2ddd548e = 0;
			} 
			$var_2ddd548e = $this -> parseValue($var_2ddd548e);
			if ($var_2ddd548e === false || $var_2ddd548e === true) continue;
			if (is_scalar($var_2ddd548e)) {
				if (!$this -> checkField($var_6cbe6605)) {
					continue;
				} 
				$var_bcf17b84 = $this -> addSpecialChar($var_6cbe6605);
				$var_5f841fb5[] = $var_2ddd548e;
				$var_b363a655[] = $var_bcf17b84;
			} 
		} 
		unset($this -> func_c1e8b295['_data']);
		switch ($var_7c6c92b4) {
			case 'add': return ' (' . implode(',', $var_b363a655) . ') VALUES (' . implode(',', $var_5f841fb5) . ')';
				break;
			case 'save': foreach($var_5f841fb5 as $var_228572b3 => $var_cb83972b) {
					$var_ebe8e855[] = $var_b363a655[$var_228572b3] . '=' . $var_cb83972b;
				} 
				return ' SET ' . implode(',', $var_ebe8e855);
				break;
			default: return false;
		} 
	} 
	private function _parseCondition() {
		$var_35cdad30 = "";
		if (!empty($this -> func_c1e8b295['_where'])) {
			$var_ae21f2d5 = $this -> func_c1e8b295['_where'];
			$var_ae21f2d5 = $this -> parseWhere($var_ae21f2d5);
			if ($var_ae21f2d5) {
				$var_35cdad30 .= ' WHERE ' . $var_ae21f2d5;
			} 
			unset($this -> func_c1e8b295['_where']);
		} 
		if (!empty($this -> func_c1e8b295['_group']) && is_string($this -> func_c1e8b295['_group'])) {
			$var_35cdad30 .= ' GROUP BY ' . $this -> func_c1e8b295['_group'];
			unset($this -> func_c1e8b295['_group']);
		} 
		if (!empty($this -> func_c1e8b295['_having']) && is_string($this -> func_c1e8b295['_having'])) {
			$var_35cdad30 .= ' HAVING ' . $this -> func_c1e8b295['_having'];
			unset($this -> func_c1e8b295['_having']);
		} 
		if (!empty($this -> func_c1e8b295['_order']) && is_string($this -> func_c1e8b295['_order'])) {
			if ($this -> func_c1e8b295['_order'] == 'rand') {
				$var_35cdad30 .= ' ORDER BY RAND()';
			} else {
				$var_586a20ab = explode(',', $this -> func_c1e8b295['_order']);
				$var_7eba6ab8 = array();
				foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
					list($var_253990b8, $var_f3c4254e) = explode(' ', $var_cb83972b);
					$var_253990b8 = str_replace('`', '', $var_253990b8);
					$var_7eba6ab8[] = '`' . $var_253990b8 . '` ' . $var_f3c4254e;
				} 
				$var_252e077b = implode(',', $var_7eba6ab8);
				$var_35cdad30 .= ' ORDER BY ' . $var_252e077b;
			} 
			unset($this -> func_c1e8b295['_order']);
		} 
		if (!empty($this -> func_c1e8b295['_limit']) && (is_string($this -> func_c1e8b295['_limit']) || is_numeric($this -> func_c1e8b295['_limit']))) {
			$var_35cdad30 .= ' LIMIT ' . $this -> func_c1e8b295['_limit'];
			unset($this -> func_c1e8b295['_limit']);
		} 
		if (empty($var_35cdad30)) return "";
		return $var_35cdad30;
	} 
	private function parseWhere($var_ae21f2d5) {
		$var_eef6951d = '';
		if (is_string($var_ae21f2d5)) {
			$var_eef6951d = $var_ae21f2d5;
		} else {
			if (array_key_exists('_logic', $var_ae21f2d5)) {
				$var_3044e351 = ' ' . strtoupper($var_ae21f2d5['_logic']) . ' ';
				unset($var_ae21f2d5['_logic']);
			} else {
				$var_3044e351 = ' AND ';
			} 
			foreach ($var_ae21f2d5 as $var_6cbe6605 => $var_04144ce3) {
				if (is_array($var_04144ce3) && empty($var_04144ce3)) continue;
				$var_eef6951d .= '( ';
				if (0 === strpos($var_6cbe6605, '_')) {
					$var_eef6951d .= $this -> parseSpecialWhere($var_6cbe6605, $var_04144ce3);
				} else {
					$var_6cbe6605 = $this -> addSpecialChar($var_6cbe6605);
					if (is_array($var_04144ce3)) {
						if (is_string($var_04144ce3[0])) {
							if (preg_match('/^(EQ|NEQ|GT|EGT|LT|ELT|NOTLIKE|LIKE)$/i', $var_04144ce3[0])) {
								$var_eef6951d .= $var_6cbe6605 . ' ' . $this -> func_24b4fc9e[strtolower($var_04144ce3[0])] . ' ' . $this -> parseValue($var_04144ce3[1]);
							} elseif ('exp' == strtolower($var_04144ce3[0])) {
								$var_eef6951d .= ' (' . $var_6cbe6605 . ' ' . $var_04144ce3[1] . ') ';
							} elseif (preg_match('/IN/i', $var_04144ce3[0])) {
								if (is_string($var_04144ce3[1])) {
									$var_04144ce3[1] = explode(',', $var_04144ce3[1]);
								} 
								$var_df7666ae = implode(',', $this -> parseValue($var_04144ce3[1]));
								$var_eef6951d .= $var_6cbe6605 . ' ' . strtoupper($var_04144ce3[0]) . ' (' . $var_df7666ae . ')';
							} elseif (preg_match('/BETWEEN/i', $var_04144ce3[0])) {
								$var_de5c1562 = is_string($var_04144ce3[1])? explode(',', $var_04144ce3[1]):$var_04144ce3[1];
								$var_eef6951d .= ' (' . $var_6cbe6605 . ' BETWEEN ' . $var_de5c1562[0] . ' AND ' . $var_de5c1562[1] . ' )';
							} else {
								$this -> error($var_04144ce3[0]);
							} 
						} else {
							$var_0d0d86c2 = count($var_04144ce3);
							if (is_string($var_04144ce3[$var_0d0d86c2 - 1]) && in_array(strtoupper(trim($var_04144ce3[$var_0d0d86c2 - 1])), array('AND', 'OR', 'XOR'))) {
								$var_aeaa699e = strtoupper(trim($var_04144ce3[$var_0d0d86c2 - 1]));
								$var_0d0d86c2 = $var_0d0d86c2 - 1;
							} else {
								$var_aeaa699e = 'AND';
							} 
							for($var_7ea74e20 = 0;$var_7ea74e20 < $var_0d0d86c2;$var_7ea74e20++) {
								$var_de5c1562 = is_array($var_04144ce3[$var_7ea74e20])?$var_04144ce3[$var_7ea74e20][1]:$var_04144ce3[$var_7ea74e20];
								if ('exp' == strtolower($var_04144ce3[$var_7ea74e20][0])) {
									$var_eef6951d .= '(' . $var_6cbe6605 . ' ' . $var_de5c1562 . ') ' . $var_aeaa699e . ' ';
								} else {
									$var_2daf62e8 = is_array($var_04144ce3[$var_7ea74e20])?$this -> func_24b4fc9e[strtolower($var_04144ce3[$var_7ea74e20][0])]:'=';
									$var_eef6951d .= '(' . $var_6cbe6605 . ' ' . $var_2daf62e8 . ' ' . $this -> parseValue($var_de5c1562) . ') ' . $var_aeaa699e . ' ';
								} 
							} 
							$var_eef6951d = substr($var_eef6951d, 0, - 4);
						} 
					} else {
						$var_eef6951d .= $var_6cbe6605 . ' = ' . $this -> parseValue($var_04144ce3);
					} 
				} 
				$var_eef6951d .= ' )' . $var_3044e351;
			} 
			$var_eef6951d = substr($var_eef6951d, 0, - strlen($var_3044e351));
		} 
		return empty($var_eef6951d)?'':$var_eef6951d;
	} 
	private function parseSpecialWhere($var_6cbe6605, $var_04144ce3) {
		$var_eef6951d = '';
		switch ($var_6cbe6605) {
			case '_string': $var_eef6951d = $var_04144ce3;
				break;
			case '_complex': $var_eef6951d = $this -> parseWhere($var_04144ce3);
				break;
			case '_query': parse_str($var_04144ce3, $var_ae21f2d5);
				if (array_key_exists('_logic', $var_ae21f2d5)) {
					$var_2daf62e8 = ' ' . strtoupper($var_ae21f2d5['_logic']) . ' ';
					unset($var_ae21f2d5['_logic']);
				} else {
					$var_2daf62e8 = ' AND ';
				} 
				$var_335d704a = array();
				foreach($var_ae21f2d5 as $var_dce42d17 => $var_de5c1562) $var_335d704a[] = $this -> addSpecialChar($var_dce42d17) . ' = ' . $this -> parseValue($var_de5c1562);
				$var_eef6951d = implode($var_2daf62e8, $var_335d704a);
				break;
		} 
		return $var_eef6951d;
	} 
	private function parseField($var_b363a655) {
		if (is_array($var_b363a655)) {
			$var_335d704a = array();
			foreach($var_b363a655 as $var_6cbe6605 => $var_dce42d17) {
				if (!is_numeric($var_6cbe6605)) $var_335d704a[] = $this -> addSpecialChar($var_6cbe6605) . ' AS ' . $this -> addSpecialChar($var_dce42d17);
				else $var_335d704a[] = $this -> addSpecialChar($var_dce42d17);
			} 
			$var_88a33639 = implode(',', $var_335d704a);
		} elseif (is_string($var_b363a655) && !empty($var_b363a655)) {
			$var_88a33639 = $this -> addSpecialChar($var_b363a655);
		} else {
			$var_88a33639 = '*';
		} 
		return $var_88a33639;
	} 
	private function parseValue($var_2ddd548e) {
		if (is_string($var_2ddd548e)) {
			$var_2ddd548e = '\'' . $this -> escape_string($var_2ddd548e) . '\'';
		} elseif (isset($var_2ddd548e[0]) && is_string($var_2ddd548e[0]) && strtolower($var_2ddd548e[0]) == 'exp') {
			$var_2ddd548e = $this -> escape_string($var_2ddd548e[1]);
		} elseif (is_array($var_2ddd548e)) {
			$var_2ddd548e = array_map(array($this, 'parseValue'), $var_2ddd548e);
		} elseif (is_null($var_2ddd548e)) {
			$var_2ddd548e = '\'\'';
		} 
		return $var_2ddd548e;
	} 
	private function addSpecialChar(&$var_2ddd548e) {
		if (0 === stripos($this -> func_ebf65a13['db_type'], 'mysql')) {
			$var_2ddd548e = trim($var_2ddd548e);
			if (false !== strpos($var_2ddd548e, ' ') || false !== strpos($var_2ddd548e, ',') || false !== strpos($var_2ddd548e, '*') || false !== strpos($var_2ddd548e, '(') || false !== strpos($var_2ddd548e, '.') || false !== strpos($var_2ddd548e, '`')) {
			} else {
				$var_2ddd548e = '`' . $var_2ddd548e . '`';
			} 
		} 
		return $var_2ddd548e;
	} 
	public function escape_string($var_40db88e3) {
		return stripslashes($var_40db88e3);
	} 
} 

?>