<?php class cache {
	protected $var_cfbc89e3 ;
	protected $var_4c819857 = array();
	public function connect($var_7c6c92b4 = '', $var_4c819857 = array()) {
		if (empty($var_7c6c92b4)) $var_7c6c92b4 = 'file';
		$var_7c6c92b4 = strtolower(trim($var_7c6c92b4));
		$var_36a0b2a2 = 'cache' . ucwords($var_7c6c92b4);
		$var_072395ec = LIB_PATH . 'cache/' . $var_36a0b2a2 . '.class.php';
		require_load($var_072395ec);
		if (class_exists($var_36a0b2a2)) {
			$this -> func_e3269875 = new $var_36a0b2a2($var_4c819857);
		} else {
			throw_exception('cache type error:' . $var_7c6c92b4);
		} 
		return $this -> func_e3269875;
	} 
	public function __get($var_aca22417) {
		return $this -> get($var_aca22417);
	} 
	public function __set($var_aca22417, $var_2ddd548e) {
		return $this -> set($var_aca22417, $var_2ddd548e);
	} 
	public function __unset($var_aca22417) {
		$this -> rm($var_aca22417);
	} 
	protected function queue($var_6cbe6605) {
		static $var_1f5a15cf = array('file' => array('F', 'F'), 'xcache' => array('xcache_get', 'xcache_set'), 'apc' => array('apc_fetch', 'apc_store'),);
		$var_f8c42076 = isset($this -> func_c1e8b295['queue'])?$this -> func_c1e8b295['queue']:'file';
		$var_e56d9036 = isset($var_1f5a15cf[$var_f8c42076])?$var_1f5a15cf[$var_f8c42076]:$var_1f5a15cf['file'];
		$var_bad6cf10 = isset($this -> func_c1e8b295['queue_name'])?$this -> func_c1e8b295['queue_name']:'think_queue';
		$var_2ddd548e = $var_e56d9036[0]($var_bad6cf10);
		if (!$var_2ddd548e) {
			$var_2ddd548e = array();
		} 
		if (false === array_search($var_6cbe6605, $var_2ddd548e)) array_push($var_2ddd548e, $var_6cbe6605);
		if (count($var_2ddd548e) > $this -> func_c1e8b295['length']) {
			$var_6cbe6605 = array_shift($var_2ddd548e);
			$this -> rm($var_6cbe6605);
		} 
		return $var_e56d9036[1]($var_bad6cf10, $var_2ddd548e);
	} 
	public function __call($var_6c1a8580, $var_583d62cb) {
		if (method_exists($this -> func_e3269875, $var_6c1a8580)) {
			return call_user_func_array(array($this -> func_e3269875, $var_6c1a8580), $var_583d62cb);
		} else {
			throw_exception(__CLASS__ . ':' . $var_6c1a8580 . ' 未定义');
			return;
		} 
	} 
} 
