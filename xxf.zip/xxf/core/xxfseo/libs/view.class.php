<?php class view {
	public $var_12ab7d87;
	private $var_a118132d;
	public $var_4c819857;
	function __construct() {
		$this -> func_e60bc9d5 = new template;
		$this -> func_4a47386d = defined('GROUP_NAME')?GROUP_NAME:config('DEFAULT_GROUP');
		$var_6b406902 = $this -> getTemplateTheme();
		$this -> func_c1e8b295 = array();
		$this -> func_c1e8b295['compile_check'] = config('TMPL_COMPILE_CHECK');
		$this -> func_c1e8b295['caching'] = config('HTML_CACHE');
		$this -> func_c1e8b295['tpl_path'] = config('TMPL_PATH') ? config('TMPL_PATH') : TMPL_PATH;
		$this -> func_c1e8b295['template_dir'] = $this -> func_c1e8b295['tpl_path'] . $this -> func_4a47386d . '/' . $var_6b406902;
		$this -> func_c1e8b295['cache_dir'] = CACHE_PATH . 'html/' . $this -> func_4a47386d . '/' . $var_6b406902;
		$this -> func_c1e8b295['compile_dir'] = TPLCACHE_PATH . $this -> func_4a47386d . '/' . $var_6b406902;
		$this -> func_c1e8b295['cache_id'] = '';
		$this -> func_c1e8b295['cache_html_user_hashdir'] = config('HTML_CACHE_USE_HASHDIR');
		$this -> func_c1e8b295['cache_html_hashdir_level'] = config('HTML_CACHE_HASHDIR_LEVEL');
		$this -> func_c1e8b295['force_compile'] = false;
		$this -> initialize();
	} 
	private function initialize() {
		$this -> func_e60bc9d5 -> func_e52fdcdb = false;
		$this -> func_e60bc9d5 -> func_77aca0ae = $this -> func_c1e8b295['compile_check'];
		$this -> func_e60bc9d5 -> func_7221644a = APPLIB_PATH . 'tpltags/';
		$this -> func_e60bc9d5 -> func_fee62c9c = $this -> func_c1e8b295['force_compile'];
		$this -> func_e60bc9d5 -> func_3e8ec88c = $this -> func_c1e8b295['template_dir'];
		$this -> func_e60bc9d5 -> func_c403d9e0 = $this -> func_c1e8b295['compile_dir'];
		$this -> func_e60bc9d5 -> func_4007cba4 = false;
		$this -> func_e60bc9d5 -> func_b16a856d = $this -> func_c1e8b295['cache_dir'];
		$this -> func_e60bc9d5 -> func_0ec32c76 = '{';
		$this -> func_e60bc9d5 -> func_1f5252f0 = '}';
	} 
	public function assign($var_aca22417, $var_2ddd548e = '') {
		$this -> func_e60bc9d5 -> assign($var_aca22417, $var_2ddd548e);
	} 
	public function fetch($var_8db55ee1 = '') {
		if (strncmp($var_8db55ee1, 'str:', 4) == 0) {
			return $this -> func_e60bc9d5 -> fetch($var_8db55ee1);
		} 
		if (!is_file($var_8db55ee1)) {
			$var_980a7c7e = $this -> getTemplate();
			if ($var_8db55ee1) {
				if (MODULE_NAME != config('DEFAULT_MODULE')) {
					if (ACTION_NAME == config('DEFAULT_ACTION')) {
						$var_8db55ee1 = MODULE_NAME;
					} else {
						$var_8db55ee1 = MODULE_NAME . '_' . $var_8db55ee1;
					} 
				} 
				$var_8db55ee1 = dirname($var_980a7c7e) . '/' . $var_8db55ee1 . config('TMPL_TEMPLATE_SUFFIX');
			} else {
				$var_8db55ee1 = $var_980a7c7e;
			} 
		} 
		if (!is_file($var_8db55ee1)) {
			exception('模板不存在:' . $var_8db55ee1);
		} 
		return $this -> func_e60bc9d5 -> fetch($var_8db55ee1);
	} 
	public function get($var_aca22417 = '') {
		return $this -> func_e60bc9d5 -> getTemplateVars($var_aca22417);
	} 
	public function getTemplate($var_12ab7d87 = '') {
		if (ACTION_NAME == config('DEFAULT_ACTION')) {
			$var_59862b1e = MODULE_NAME;
		} else {
			$var_59862b1e = MODULE_NAME . '_' . ACTION_NAME;
		} 
		define('THEME_PATH', $this -> func_c1e8b295['template_dir']);
		if ($var_12ab7d87) {
			$var_12ab7d87 = $this -> func_c1e8b295['template_dir'] . '/' . $var_12ab7d87 . config('TMPL_TEMPLATE_SUFFIX');
		} else {
			$var_12ab7d87 = THEME_PATH . $var_59862b1e . config('TMPL_TEMPLATE_SUFFIX');
		} 
		return $var_12ab7d87;
	} 
	public function display($var_8db55ee1 = '') {
		$this -> initialize();
		if (!is_file($var_8db55ee1)) {
			$var_8db55ee1 = $this -> getTemplate($var_8db55ee1);
		} 
		$GLOBALS['first_compile'] = true;
		if ($this -> func_c1e8b295['caching']) {
			$var_a3e5f0ff = $this -> func_c1e8b295['cache_id'];
			$var_efa93c7a = $this -> getHtmlPath($var_a3e5f0ff);
			$var_ab1e95e3 = $this -> func_c1e8b295['cache_lifetime'];
			if (!is_file($var_efa93c7a) || (filemtime($var_efa93c7a) + $var_ab1e95e3 * 3600) < time()) {
				$var_6e99cc06 = dirname($var_efa93c7a);
				if (!is_dir($var_6e99cc06)) mkdir($var_6e99cc06, 502, true);
				ob_start();
				$this -> func_e60bc9d5 -> display($var_8db55ee1);
				$var_ff5a8b14 = ob_get_contents();
				ob_end_clean();
				$GLOBALS['linktag_display'] = true;
				$GLOBALS['first_compile'] = false;
				$var_ff5a8b14 = $this -> func_e60bc9d5 -> fetch_str($var_ff5a8b14);
				file_put_contents($var_efa93c7a, $var_ff5a8b14);
			} 
			echo $this -> func_e60bc9d5 -> _require($var_efa93c7a);
		} else {
			$GLOBALS['linktag_display'] = true;
			$GLOBALS['first_compile'] = false;
			$this -> func_e60bc9d5 -> func_77aca0ae = true;
			debug_log('displayfile_' . $var_8db55ee1);
			$this -> func_e60bc9d5 -> display($var_8db55ee1);
			debug_log('displayfile_' . $var_8db55ee1, 'end');
		} 
	} 
	public function __call($var_aca22417, $var_583d62cb) {
		$var_6c1a8580 = new ReflectionMethod($this -> func_e60bc9d5, $var_aca22417);
		$var_6c1a8580 -> invokeArgs($this -> func_e60bc9d5, $var_583d62cb);
	} 
	private function getTemplateTheme() {
		$var_6b406902 = config('DEFAULT_THEME');
		define('THEME_NAME', $var_6b406902);
		return $var_6b406902 ? $var_6b406902 . '/':'';
	} 
	public function getHtmlPath($var_a3e5f0ff, $var_62cba596 = false) {
		if (config('web_cachefile_type') == 2) {
			$var_62cba596 = $var_62cba596 ? $var_62cba596 : CACHE_PATH . 'htmlfile';
			$var_f9b7264a = preg_replace('~^https?://~', '', func_dfe3da17());
			$var_f9b7264a = preg_replace('~^www\\.~', '', $var_f9b7264a);
			list($var_f9b7264a,) = explode('?', $var_f9b7264a);
			list($var_f9b7264a,) = explode('&', $var_f9b7264a);
			if (substr($var_f9b7264a, - 1) == '/' || strpos(basename($var_f9b7264a), '.') === false) {
				$var_f9b7264a = rtrim($var_f9b7264a, '/') . '/index.html';
			} 
			$var_f9b7264a = $var_62cba596 . '/' . $var_f9b7264a;
		} else {
			$var_4eda73b5 = $this -> func_c1e8b295['cache_html_user_hashdir'] ? getHashDir($var_a3e5f0ff, $this -> func_c1e8b295['cache_html_hashdir_level']) : '';
			$var_62cba596 = $var_62cba596 ? $var_62cba596 : $this -> func_c1e8b295['cache_dir'];
			$var_62cba596 = $var_62cba596 . $var_4eda73b5;
			$var_f9b7264a = rtrim($var_62cba596, '/') . '/' . $var_a3e5f0ff . config('HTML_CACHE_SUFFIX');
		} 
		return $var_f9b7264a;
	} 
	public function isCached() {
		if ($this -> func_c1e8b295['caching']) {
			$var_efa93c7a = $this -> getHtmlPath($this -> func_c1e8b295['cache_id']);
			$var_ab1e95e3 = $this -> func_c1e8b295['cache_lifetime'];
			if (is_file($var_efa93c7a) && (filemtime($var_efa93c7a) + $var_ab1e95e3) > time()) {
				return true;
			} 
		} 
		return false;
	} 
} 
