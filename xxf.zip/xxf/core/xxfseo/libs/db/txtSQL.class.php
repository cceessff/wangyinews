<?php
abstract class txtSQL {
	public $_STRICT = true;
	public $_LIBPATH = null;
	public $_USER = null;
	public $_PASS = null;
	public $_CACHE = array();
	public $_SELECTEDDB = null;
	public $_QUERYCOUNT = 0;
	public $hash_db = array();
	function __construct($path = '') {
		$this -> _LIBPATH = $path;
		$hashdb_arr = explode(',', config('DB_HASH_LIST'));
		if ($hashdb_arr) {
			foreach($hashdb_arr as $k => $vo) {
				list($name, $num) = explode('|', $vo);
				$this -> hash_db[] = $name;
			} 
		} 
		return true;
	} 
	function _isselect() {
		if (empty($this -> _SELECTEDDB)) {
			$this -> _error(E_USER_NOTICE, 'No database selected');
			return false;
		} 
	} 
	function _checkdb($db) {
		if (!empty($db)) {
			if (!$this -> selectdb($db)) {
				return false;
			} 
		} 
	} 
	function _isemptytable($table) {
		if (empty($table)) {
			$this -> _error(E_USER_NOTICE, 'No table specified');
			return false;
		} 
	} 
	function _check_table_file($table) {
		if (is_array($table)) {
			foreach($table as $vo) {
				$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$vo";
				$table_frm = preg_replace('#^([A-Za-z_]+)\d+#', '$1', $vo);
				if (in_array($table_frm, $this -> hash_db)) {
					$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$table_frm/$vo";
				} 
				if (!is_file($filename . '.MYD') || !is_file("$this->_LIBPATH/$this->_SELECTEDDB/$table_frm.FRM")) {
					$this -> _error(E_USER_NOTICE, 'Table ' . $vo . ' doesn\'t exist');
					return false;
				} 
			} 
		} else {
			$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$table";
			$table_frm = preg_replace('#^([A-Za-z_]+)\d+#', '$1', $table);
			if (in_array($table_frm, $this -> hash_db)) {
				$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$table_frm/$table";
			} 
			if (!is_file($filename . '.MYD') || !is_file("$this->_LIBPATH/$this->_SELECTEDDB/$table_frm.FRM")) {
				$this -> _error(E_USER_NOTICE, 'Table ' . $table . ' doesn\'t exist');
				return false;
			} 
		} 
	} 
	function _checkdblock() {
		if ($this -> isLocked($this -> _SELECTEDDB)) {
			$this -> _error(E_USER_NOTICE, 'Database ' . $this -> _SELECTEDDB . ' is locked');
			return false;
		} 
	} 
	function connect($user = '', $pass = '') {
		if (!is_dir($this -> _LIBPATH)) {
			$this -> _error(E_USER_ERROR, '数据库路径不存在');
		} 
		return true;
	} 
	function disconnect() {
		return false;
	} 
	function select($arguments) {
		$this -> _validate($arguments);
		$this -> _QUERYCOUNT++;
		return $this -> _select($arguments);
	} 
	function insert($arguments) {
		$this -> _validate($arguments);
		$this -> _QUERYCOUNT++;
		return $this -> _insert($arguments);
	} 
	function update($arguments) {
		$this -> _validate($arguments);
		$this -> _QUERYCOUNT++;
		return $this -> _update($arguments);
	} 
	function delete($arguments) {
		$this -> _validate($arguments);
		$this -> _QUERYCOUNT++;
		return $this -> _delete($arguments);
	} 
	function showdbs() {
		$this -> _validate(array());
		$this -> _QUERYCOUNT++;
		return $this -> _showdatabases();
	} 
	function createdb($arguments) {
		$this -> _validate($arguments);
		$this -> _QUERYCOUNT++;
		return $this -> _createdatabase($arguments);
	} 
	function dropdb($arguments) {
		$this -> _validate($arguments);
		$this -> _QUERYCOUNT++;
		return $this -> _dropdatabase($arguments);
	} 
	function renamedb($arguments) {
		$this -> _validate($arguments);
		$this -> _QUERYCOUNT++;
		return $this -> _renamedatabase($arguments);
	} 
	function showtables($arguments) {
		$this -> _validate($arguments);
		$this -> _QUERYCOUNT++;
		return $this -> _showtables($arguments);
	} 
	function getFields($arguments) {
		$table = $arguments['table'];
		$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$table.FRM";
		$table_frm = preg_replace('#^([A-Za-z_]+)\d+#', '$1', $table);
		if (in_array($table_frm, $this -> hash_db)) {
			$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$table_frm.FRM";
		} 
		$this -> _isemptytable($table_frm);
		$col = $this -> _readFile($filename);
		unset($col['primary']);
		return array_keys($col);
	} 
	function createtable($arguments) {
		$this -> _validate($arguments);
		$this -> _QUERYCOUNT++;
		return $this -> _createtable($arguments);
	} 
	function droptable($arguments) {
		$this -> _validate($arguments);
		$this -> _QUERYCOUNT++;
		return $this -> _droptable($arguments);
	} 
	function altertable($arguments) {
		$this -> _validate($arguments);
		$this -> _QUERYCOUNT++;
		return $this -> _altertable($arguments);
	} 
	function describe($arguments) {
		$this -> _validate($arguments);
		$this -> _QUERYCOUNT++;
		return $this -> _describe($arguments);
	} 
	function _validate($arguments) {
		if (!$this -> _isconnected()) {
			$this -> _error(E_USER_NOTICE, 'Can only perform queries when connected!');
			return false;
		} 
		if (!empty($arguments) && !is_array($arguments)) {
			$this -> _error(E_USER_ERROR, 'can only accept arguments in an array');
		} 
		return true;
	} 
	function execute($action, $arguments = null) {
		if (!$this -> _isconnected()) {
			$this -> _error(E_USER_NOTICE, 'Can only perform queries when connected!');
			return false;
		} 
		if (empty($action)) {
			$this -> _error(E_USER_NOTICE, 'You have an error in your SQL query');
			return false;
		} 
		if (!empty($arguments) && !is_array($arguments)) {
			$this -> _error(E_USER_ERROR, 'SQL Can only accept arguments in an array');
		} 
		switch (strtolower($action)) {
			case 'show databases': $results = $this -> _showdatabases();
				break;
			case 'create database': $results = $this -> _createdatabase($arguments);
				break;
			case 'drop database': $results = $this -> _dropdatabase($arguments);
				break;
			case 'rename database': $results = $this -> _renamedatabase($arguments);
				break;
			case 'show tables': $results = $this -> _showtables($arguments);
				break;
			case 'create table': $results = $this -> _createtable($arguments);
				break;
			case 'drop table': $results = $this -> _droptable($arguments);
				break;
			case 'alter table': $results = $this -> _altertable($arguments);
				break;
			case 'describe': $results = $this -> _describe($arguments);
				break;
			case 'select': $results = $this -> _select($arguments);
				break;
			case 'insert': $results = $this -> _insert($arguments);
				break;
			case 'update': $results = $this -> _update($arguments);
				break;
			case 'delete': $results = $this -> _delete($arguments);
				break;
			default: $this -> _error(E_USER_NOTICE, 'Unknown action: ' . $action);
				return false;
		} 
		$this -> _QUERYCOUNT++;
		return isset($results) ? $results : '';
	} 
	function strict($strict = false) {
		$strict = (bool) $strict;
		$this -> _STRICT = $strict;
		if ($this -> _isconnected()) {
			$this -> _strict($strict);
		} 
		return true;
	} 
	function grant_permissions($action, $user, $pass = null, $pass1 = null) {
		if (!$this -> _isconnected()) {
			$this -> _error(E_USER_NOTICE, 'Not connected');
			return false;
		} 
		if (!is_string($action) || !is_string($user) || (!empty($pass) && !is_string($pass)) || (!empty($pass1) && !is_string($pass1))) {
			$this -> _error(E_USER_NOTICE, 'The arguments must be a string');
			return false;
		} 
		if (($DATA = $this -> _readFile("$this->_LIBPATH/txtsql/user.MYI")) === false) {
			$this -> _error(E_USER_WARNING, 'Database file is corrupted!');
			return false;
		} 
		if (empty($user)) {
			$this -> _error(E_USER_NOTICE, 'Forgot to input username');
			return false;
		} 
		switch (strtolower($action)) {
			case 'add': if (isset($DATA[strtolower($user)])) {
					$this -> _error(E_USER_NOTICE, 'User already exists');
					return false;
				} 
				$DATA[strtolower($user)] = md5($pass);
				break;
			case 'drop': if (strtolower($user) == strtolower($this -> _USER)) {
					$this -> _error(E_USER_NOTICE, 'Can\'t drop yourself');
					return false;
				} elseif (strtolower($user) == 'root') {
					$this -> _error(E_USER_NOTICE, 'Can\'t drop user root');
					return false;
				} elseif (!isset($DATA[strtolower($user)])) {
					$this -> _error(E_USER_NOTICE, 'User doesn\'t exist');
					return false;
				} elseif (md5($pass) != $DATA[strtolower($user)]) {
					$this -> _error(E_USER_NOTICE, 'Incorrect password');
					return false;
				} 
				unset($DATA[strtolower($user)]);
				break;
			case 'edit': if (!isset($DATA[strtolower($user)])) {
					$this -> _error(E_USER_NOTICE, 'User doesn\'t exist');
					return false;
				} 
				if (md5($pass) != $DATA[strtolower($user)]) {
					$this -> _error(E_USER_NOTICE, 'Incorrect password');
					return false;
				} 
				$DATA[strtolower($user)] = md5($pass1);
				break;
			default: $this -> _error(E_USER_NOTICE, 'Invalid action specified');
				return false;
		} 
		$fp = @fopen("$this->_LIBPATH/txtsql/user.MYI", 'w') or $this -> _error(E_USER_FATAL, "Couldn't open $this->_LIBPATH/txtsql/user.MYI for writing");
		@flock($fp, LOCK_EX);
		@fwrite($fp, serialize($DATA)) or $this -> _error(E_USER_FATAL, "Couldn't write to $this->_LIBPATH/txtsql/user.MYI");
		@flock($fp, LOCK_UN);
		@fclose($fp) or $this -> _error(E_USER_NOTICE, "Error closing $this->_LIBPATH/txtsql/user.MYI");
		$this -> _CACHE["$this->_LIBPATH/txtsql/user.MYI"] = $DATA;
		return true;
	} 
	function getUsers() {
		if (!$this -> _isconnected()) {
			$this -> _error(E_USER_NOTICE, 'Not connected');
			return false;
		} 
		if (($DATA = $this -> _readFile("$this->_LIBPATH/txtsql/user.MYI")) === false) {
			$this -> _error(E_USER_WARNING, 'Database file is corrupted!');
			return false;
		} 
		$users = array();
		foreach ($DATA as $key => $value) {
			$users[] = $key;
		} 
		return $users;
	} 
	function isLocked($db) {
		if (!$this -> _dbexist($db)) {
			$this -> _error(E_USER_NOTICE, 'Database ' . $db . ' doesn\'t exist');
			return false;
		} 
		return is_file("$this->_LIBPATH/$db/txtsql.lock") ? true : false;
	} 
	function lockdb($db) {
		if (!$this -> _isConnected()) {
			$this -> _error(E_USER_NOTICE, 'You must be connected');
			return false;
		} elseif ($this -> isLocked($db)) {
			$this -> _error(E_USER_NOTICE, 'Lock for database ' . $db . ' already exists');
			return false;
		} 
		$fp = fopen("$this->_LIBPATH/$db/txtsql.lock", 'a') or $this -> _error(E_USER_ERROR, 'Err1or creating a lock for database ' . $db);
		fclose($fp) or $this -> _error(E_USER_ERROR, 'Error creating a lock for database ' . $db);
		return true;
	} 
	function unlockdb($db) {
		if (!$this -> _isConnected()) {
			$this -> _error(E_USER_NOTICE, 'You must be connected');
			return false;
		} elseif (!$this -> isLocked($db)) {
			$this -> _error(E_USER_NOTICE, 'Lock for database ' . $db . ' doesn\'t exist');
			return false;
		} 
		if (!@unlink("$this->_LIBPATH/$db/txtsql.lock")) {
			$this -> _error(E_USER_ERROR, 'Error removing lock for database ' . $db);
		} 
		return true;
	} 
	function selectdb($db) {
		if (empty($db)) {
			$this -> _error(E_USER_NOTICE, 'Cannot select database ' . $db);
			return false;
		} 
		if (!$this -> _dbexist($db)) {
			$this -> _error(E_USER_NOTICE, 'Database ' . $db . ' doesn\'t exist');
			return false;
		} 
		$this -> _SELECTEDDB = $db;
		return true;
	} 
	function table_exists($table, $db) {
		return $this -> _tableexist($table, $db);
	} 
	function db_exists($db) {
		return $this -> _dbexist($db);
	} 
	function table_count($table, $database = null) {
		if (!empty($database)) {
			if (!$this -> selectdb($database)) {
				return false;
			} 
		} 
		if (empty($this -> _SELECTEDDB) || empty($table)) {
			$this -> _error(E_USER_NOTICE, 'No database selected');
			return false;
		} 
		$this -> _check_table_file($table);
		$count = 0;
		if (is_array($table)) {
			foreach($table as $vo) {
				$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$vo";
				$table_frm = preg_replace('#^([A-Za-z_]+)\d+#', '$1', $vo);
				if (in_array($table_frm, $this -> hash_db)) {
					$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$table_frm/$vo";
				} 
				if (($rows = @file_get_contents($filename . '.MYD')) === false) {
					$this -> _error(E_USER_NOTICE, 'Table ' . $vo . ' doesn\'t exist');
					return false;
				} 
				$count += substr($rows, 2, strpos($rows, '{') - 3);
			} 
		} else {
			$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$table";
			$table_frm = preg_replace('#^([A-Za-z_]+)\d+#', '$1', $table);
			if (in_array($table_frm, $this -> hash_db)) {
				$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$table_frm/$table";
			} 
			if (($rows = @file_get_contents($filename . '.MYD')) === false) {
				$this -> _error(E_USER_NOTICE, 'Table ' . $table . ' doesn\'t exist');
				return false;
			} 
			$count += substr($rows, 2, strpos($rows, '{') - 3);
		} 
		return $count;
	} 
	function last_insert_id($table, $db = '', $column = '') {
		if (!empty($db)) {
			if (!$this -> selectdb($db)) {
				return false;
			} 
		} 
		$this -> _isselect();
		if (is_array($table)) $table = $table[0];
		$table_frm = preg_replace('#^([A-Za-z_]+)\d+#', '$1', $table);
		if (($cols = $this -> _readFile("$this->_LIBPATH/$this->_SELECTEDDB/$table_frm.FRM", false)) === false) {
			$this -> _error(E_USER_NOTICE, 'Table "' . $table . '" doesn\'t exist');
			return false;
		} 
		if (!empty($column)) {
			if ($this -> _getColPos($column, $cols) === false) {
				$this -> _error(E_USER_NOTICE, 'Column ' . $column . ' doesn\'t exist');
				return false;
			} elseif ($cols[$column]['auto_increment'] != 1) {
				$this -> _error(E_USER_NOTICE, 'Column ' . $column . ' is not an auto_increment field');
				return false;
			} 
			$cols['primary'] = $column;
		} elseif (empty($cols['primary']) && empty($column)) {
			$this -> _error(E_USER_NOTICE, 'There is no primary key defined for table "' . $table . '"');
			return false;
		} 
		return $cols[$cols['primary']]['autocount'];
	} 
	function query_count() {
		return $this -> _QUERYCOUNT;
	} 
	function last_error() {
		if (!empty($this -> _ERRORS)) {
			print '<pre>' . $this -> _ERRORSPLAIN[count($this -> _ERRORS)-1] . '</pre>';
		} 
	} 
	function get_last_error() {
		if (!empty($this -> _ERRORS)) {
			return $this -> _ERRORSPLAIN[count($this -> _ERRORS)-1];
		} 
	} 
	function errordump() {
		if (empty($this -> _ERRORS)) {
			echo 'No errors occurred during script execution';
			return true;
		} 
		if (!empty($this -> _ERRORS)) {
			foreach ($this -> _ERRORS as $key => $value) {
				echo 'ERROR #[' . $key . '] ' . $value;
			} 
		} 
		return true;
	} 
	function emptyCache() {
		$this -> _CACHE = array();
		return true;
	} 
	function _error($errno, $errstr, $errtype = null) {
		$backtrace = array_reverse(@debug_backtrace());
		krsort($backtrace);
		$errArr = array();
		foreach($backtrace as $k => $vo) {
			if (!preg_match('~db\.class\.php$~', $vo['file'])) {
				$errArr[] = array('file' => $vo['file'], 'line' => $vo['line']);
				break;
			} 
		} 
		$tkey = count($backtrace)-1;
		$errArr[] = array('file' => $backtrace[$tkey]['file'], 'line' => $backtrace[$tkey]['line']);
		switch ($errno) {
			case E_USER_ERROR: $type = '致命错误';
				break;
			case E_USER_NOTICE: $type = "警告";
				break;
			default: $type = "错误";
				break;
		} 
		$type = isset($errtype) ? $errtype : $type;
		$this -> _ERRORSPLAIN[] = $errstr;
		$errfile = $errfile;
		$errormsg = "<style>.message{font-family: 'Microsoft Yahei', Verdana, arial, sans-serif;font-size:14px;padding:1em;border:solid 1px #000;margin:10px 0;background:#FFD;line-height:150%;background:#FFD;color:#2E2E2E;border:1px solid #E0E0E0;}.red{color:red;font-weight:bold;}</style><p class='message'><strong>$type: </strong>$errstr";
		foreach($errArr as $k => $vo) {
			$errormsg .= "<!-- <br>FILE: <span class='red'>{$vo['file']}</span>	LINE: <span class='red'>{$vo['line']}</span> -->";
		} 
		$errormsg .= '</p>';
		$this -> _ERRORS[] = $errormsg;
		if ($this -> _STRICT === true) {
			echo $errormsg;
		} 
		if ($errno == E_USER_ERROR) {
			exit;
		} 
		return true;
	} 
	function _readFile($filename, $useCache = true, $unserialize = true) {
		if (is_file($filename)) {
			if ($useCache === true) {
				if (isset($this -> _CACHE[$filename])) {
					return $this -> _CACHE[$filename];
				} 
			} 
			if (($contents = @file_get_contents($filename)) !== false) {
				if ($unserialize === true) {
					if (($contents = @unserialize($contents)) === false) {
						return false;
					} 
				} 
				if ($useCache === true) {
					$this -> _CACHE[$filename] = $contents;
				} 
				return $contents;
			} 
		} 
		return false;
	} 
	function _isconnected() {
		return true;
	} 
	function _dbexist($db) {
		return is_dir("$this->_LIBPATH/$db") ? true : false;
	} 
	function _tableexist($table, $db) {
		if (!empty($db)) {
			if (!$this -> selectdb($db)) {
				$this -> _error(E_USER_NOTICE, 'Database, \'' . $db . '\', doesn\'t exist');
				return false;
			} 
		} 
		if (is_array($table)) {
			foreach($table as $vo) {
				$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$vo";
				$table_frm = preg_replace('#^([A-Za-z_]+)\d+#', '$1', $vo);
				if (in_array($table_frm, $this -> hash_db)) {
					$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$table_frm/$vo";
				} 
				if (!is_file($filename . '.MYD') || !is_file("$this->_LIBPATH/$this->_SELECTEDDB/$table_frm.FRM")) {
					return false;
				} 
			} 
		} else {
			$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$table";
			$table_frm = preg_replace('#^([A-Za-z_]+)\d+#', '$1', $table);
			if (in_array($table_frm, $this -> hash_db)) {
				$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$table_frm/$table";
			} 
			if (!is_file($filename . '.MYD') || !is_file("$this->_LIBPATH/$this->_SELECTEDDB/$table_frm.FRM")) {
				return false;
			} 
		} 
		return true;
	} 
	public function _where_query($where, $cols) {
		$query = '';
		foreach ($where as $key => $value) {
			if ($key % 2 == 1) {
				$and = strtolower($value) == 'and';
				$or = strtolower($value) == 'or';
				$xor = strtolower($value) == 'xor';
				if ($and === false && $or === false && $xor === false) {
					$this -> _error(E_USER_NOTICE, 'Only boolean seperators AND, and OR are allowed');
					return false;
				} 
				$query .= ($and === true) ? ' && ' : (($xor === true) ? ' XOR ' : ' || ');
				continue;
			} 
			$f1 = '(';
			$f2 = ') ';
			switch (true) {
				case strpos($value, '!='): $type = 1;
					$op = '!=';
					break;
				case strpos($value, '!~'): $type = 3;
					$op = '!~';
					break;
				case strpos($value, '=~'): $type = 3;
					$op = '=~';
					break;
				case strpos($value, '<='): $type = 2;
					$op = '<=';
					break;
				case strpos($value, '>='): $type = 2;
					$op = '>=';
					break;
				case strpos($value, '='): $type = 1;
					$op = '=';
					break;
				case strpos($value, '<>'): $type = 1;
					$op = '<>';
					break;
				case strpos($value, '<'): $type = 2;
					$op = '<';
					break;
				case strpos($value, '>'): $type = 2;
					$op = '>';
					break;
				case strpos($value, '!?'): $type = 5;
					$op = '!?';
					break;
				case strpos($value, '?'): $type = 5;
					$op = '?';
					break;
				default: $val = 'TRUE';
					if (substr(trim($value), 0, 1) == '!') {
						$val = 'FALSE';
						$value = substr($value, strpos($value, '!') + 1);
					} 
					$function = substr($value, 0, strpos($value, '('));
					$col = substr($value, strlen($function) + 1, strlen($value) - strlen($function) - 2);
					if ($function !== false) {
						$type = 4;
						$op = '===';
						$f1 = $function . '(';
					} 
			} 
			if (!isset($function)) {
				list ($col, $val) = explode($op, $value, 2);
			} 
			$val = trim($val, '"');
			$val = trim($val, '\'');
			if (substr_count($col, '(') == 1 && substr_count($col, ')') == 1) {
				$function = substr($col, 0, strpos($col, '('));
				if ($val != '' && $col{strlen($col)-1} . $val{0} == "  ") {
					$col = substr($col, strlen($function) + 1, strlen($col) - strlen($function) - (($col{strlen($col)-1} != " ") ? 2 : 3)) . " ";
					$val = $val;
				} else {
					$col = substr($col, strlen($function) + 1, strlen($col) - strlen($function) - (($col{strlen($col)-1} != " ") ? 2 : 3));
				} 
				switch (strtolower($function)) {
					case 'strlower': $f1 = 'strtolower(';
						break;
					case 'strupper': $f1 = 'strtoupper(';
						break;
					case 'chop': case 'rtrim': $f1 = 'rtrim(';
						break;
					case 'ltrim': $f1 = 'ltrim(';
						break;
					case 'trim': $f1 = 'trim(';
						break;
					case 'md5': $f1 = 'md5(';
						break;
					case 'stripslash': $f1 = 'stripslashes(';
						break;
					case 'strlength': $f1 = 'strlen(';
						break;
					case 'strreverse': $f1 = 'strrev(';
						break;
					case 'ucfirst': $f1 = 'ucfirst(';
						break;
					case 'ucwords': $f1 = 'ucwords(';
						break;
					case 'bin2hex': $f1 = 'bin2hex(';
						break;
					case 'entdecode': $f1 = 'html_entity_decode(';
						break;
					case 'entencode': $f1 = 'htmlentities(';
						break;
					case 'soundex': $f1 = 'soundex(';
						break;
					case 'ceil': $f1 = 'ceil(';
						break;
					case 'floor': $f1 = 'floor(';
						break;
					case 'round': $f1 = 'round(';
						break;
					case 'isnumeric': case 'isstring': case 'isfile': case 'isdir': $this -> _error(E_USER_NOTICE, 'Function, ' . $function . ', requires that NO operator be present in the clause');
						return false;
					default: $this -> _error(E_USER_NOTICE, 'Function, ' . $function . ', hasn\'t been implemented');
						return false;
				} 
			} 
			if (strtolower(trim($col)) == 'primary') {
				if (empty($cols['primary'])) {
					$this -> _error(E_USER_NOTICE, 'No primary key has been assigned to this table');
					return false;
				} 
				$col = $cols['primary'];
			} 
			if (($position = $this -> _getColPos(rtrim($col), $cols)) === false) {
				continue;
			} 
			$val = str_replace("\'", "'", addslashes($val));
			$val = ($col{strlen($col)-1} . $val{0} == "  ") ? substr($val, 1) : $val;
			if (empty($val) && ($type == '5' || $f1 != '(')) {
				$this -> _error(E_USER_NOTICE, 'Forgot to specify a value to match in your where clause');
				return false;
			} 
			switch ($type) {
				case 1: case 2: $quotes = (!is_numeric($val) || $cols[rtrim($col)]['type'] != 'int') ? '"' : '';
					$query .= ' ( ' . $f1 . '$value[' . $position . ']' . $f2 . ' ' . ($op == '=' ? '==' : $op) . ' ' . $quotes . $val . $quotes . ' ) ';
					break;
				case 3: $val = str_replace(array('(', ')', '{', '}', '.', '$', '/', '\%', '*', '%', '$$PERC$$'), array('\(', '\)', '\{', '\}', '\.', '\$', '\/', '$$PERC$$', '\*', '(.+)?', '%'), $val);
					$query .= ' ( ' . ($op == '!~' ? '!' : '') . 'preg_match("/^' . $val . '$/iU", ' . $f1 . '$value[' . $position . ']' . $f2 . ') ) ';
					break;
				case 4: $query .= ' ( ' . $f1 . '$value[' . $position . ']' . $f2 . ' === ' . $val . ' ) ';
					break;
				case 5: $query .= ' ( $this->_sql_IN(\' \'.$value[' . $position . '], \'' . $val . '\') ' . (($op == '!?') ? '=' : '!') . '== FALSE ) ';
			} 
			unset($function, $f1, $f2, $quotes, $position, $val, $col, $op);
		} 
		return $query;
	} 
	function _sql_IN($instr, $str) {
		$arr = explode(',', $str);
		foreach($arr as $k => $vo) {
			$vo = trim($vo);
			if ($vo == trim($instr)) return true;
		} 
		return false;
	} 
	function _buildIf($where, $cols) {
		if (!is_array($where) || empty($where)) {
			$this -> _error(E_USER_NOTICE, 'Where clause must be an array');
			return false;
		} 
		$_query = '';
		for($k = 0;$k < count($where);$k++) {
			if (is_array($where[$k])) {
				$_op = isset($where[$k-1]) ? $where[$k-1] : ' and ';
				if ($k == 0) $_op = '';
				$_query .= "{$_op}(" . $this -> _where_query($where[$k], $cols) . ")";
				unset($where[$k]);
				if (isset($where[$k-1])) unset($where[$k-1]);
			} 
		} 
		$query = $this -> _where_query($where, $cols) . $_query;
		$andor = substr($query, -3, -1);
		if ($andor == '&&' || $andor == '||' || $andor == 'OR') {
			$this -> _error(E_USER_NOTICE, 'You have an error in your where clause, cannot end statement with an AND, OR, or XOR<br/>query is: ' . $query);
			return false;
		} 
		return $query;
	} 
	function _getColPos($colname, $cols) {
		if (empty($cols) || !is_array($cols) || !array_key_exists($colname, $cols)) {
			return false;
		} 
		unset($cols['primary']);
		if (($position = array_search($colname, array_keys($cols))) === false) {
			return false;
		} 
		return $position;
	} 
	function _qsort($arr, $orderbyKey = 'id', $type = "ASC", $left = 0, $right = -1) {
		if (count($arr) >= 1) {
			if (is_array($orderbyKey) && $type == 'array') {
				if (count($orderbyKey) % 2 != 0) return false;
				$temp1 = $temp = $arg = $key = $sort = array();
				$i = 1;
				foreach($orderbyKey as $k => $vo) {
					if ($i % 2 != 0) {
						$key[] = $orderbyKey[$k];
					} else {
						$sort[] = strtoupper($orderbyKey[$k]) == "ASC" ? 'SORT_ASC' : 'SORT_DESC';
					} 
					$i++;
				} 
				foreach($key as $k => $vo) {
					foreach($arr as $kk => $vvo) {
						$temp[] = $vvo[$key[$k]];
					} 
					$arg[] = $temp;
					unset($temp);
					$arg[] = $sort[$k];
				} 
				foreach($arg as $k => $vo) {
					if ($k % 2 == 0) {
						$temp1[$k] = $vo;
						$arg[$k] = '$temp1[' . $k . ']';
					} 
				} 
				$argstr = implode(',', $arg);
				eval('array_multisort(' . $argstr . ',$arr);');
			} else {
				$column = array();
				foreach($arr as $key => $value) {
					$column[$key] = $value[$orderbyKey];
				} 
				$type = strtoupper($type) == "ASC" ? SORT_ASC : SORT_DESC;
				array_multisort($column, $type, $arr);
			} 
			return $arr;
		} 
		return false;
	} 
	function unique_multi_array($array, $sub_key) {
		$target = array();
		$existing_sub_key_values = array();
		foreach ($array as $key => $sub_array) {
			if (!in_array($sub_array[$sub_key], $existing_sub_key_values)) {
				$existing_sub_key_values[] = $sub_array[$sub_key];
				$target[$key] = $sub_array;
			} 
		} 
		return $target;
	} 
	function version() {
		return '2.2 super';
	} 
	function _select($arg) {
		$this -> _checkdb($arg['db']);
		$this -> _isselect();
		$this -> _isemptytable($arg['table']);
		if (empty($arg['select'])) {
			$arg['select'] = array('*');
		} 
		$table = $arg['table'];
		if (is_array($table)) {
			$table_frm = preg_replace('#^([A-Za-z_]+)\d+#', '$1', $table[0]);
			$cols = $this -> _readFile("$this->_LIBPATH/$this->_SELECTEDDB/{$table_frm}.FRM");
			$temparr = array();
			foreach($table as $vo) {
				$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$vo";
				$table_frm = preg_replace('#^([A-Za-z_]+)\d+#', '$1', $vo);
				if (in_array($table_frm, $this -> hash_db)) {
					$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$table_frm/$vo";
				} 
				$temp1 = $this -> _readFile($filename . '.MYD');
				if (!empty($temp1)) $temparr[] = $temp1;
			} 
			$rows = array();
			foreach($temparr as $k => $vo) {
				$rows = array_merge($rows, $vo);
			} 
		} else {
			$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$table";
			$table_frm = preg_replace('#^([A-Za-z_]+)\d+#', '$1', $table);
			if (in_array($table_frm, $this -> hash_db)) {
				$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$table_frm/$table";
			}
			if (($rows = $this -> _readFile($filename . '.MYD')) === false || ($cols = $this -> _readFile("$this->_LIBPATH/$this->_SELECTEDDB/{$table_frm}.FRM")) === false) {
				$this -> _error(E_USER_NOTICE, 'Table "' . $table . '" doesn\'t exist');
				return false;
			} 
		} 
		if (empty($rows)) {
			return array();
		} 
		$this -> _CACHE[$filename . '.MYD'] = $rows;
		$this -> _CACHE["$this->_LIBPATH/$this->_SELECTEDDB/{$table_frm}.FRM"] = $cols;
		$matches = 'TRUE';
		if (isset($arg['where'])) {
			if (($matches = $this -> _buildIf($arg['where'], $cols)) === false) {
				return false;
			} 
		} 
		if (empty($arg['limit']) || (!empty($arg['limit']) && !is_array($arg['limit']))) {
			$arg['limit'][0] = 0;
			$arg['limit'][1] = count($rows)-1;
		} elseif (isset($arg['limit'][0]) && !isset($arg['limit'][1])) {
			$arg['limit'][1] = $arg['limit'][0];
			$arg['limit'][0] = 0;
		} elseif (!isset($arg['limit'][0]) || !isset($arg['limit'][1]) || $arg['limit'][0] > $arg['limit'][1]) {
			$arg['limit'][0] = 0;
			$arg['limit'][1] = count($rows)-1;
		} 
		$arg['limit'][0] = (int) $arg['limit'][0];
		$arg['limit'][1] = (int) $arg['limit'][1];
		if ($arg['select'][0] == '*') {
			$col = $cols;
			unset($col['primary']);
			$arg['select'] = array_keys($col);
		} 
		foreach ($arg['select'] as $key => $value) {
			if (strtolower($value) == 'primary') {
				if (empty($cols['primary'])) {
					$this -> _error(E_USER_NOTICE, 'No primary key assigned to table ' . $arg['table']);
					return false;
				} 
				$value = $cols['primary'];
			} 
			if (($colPos = $this -> _getColPos($value, $cols)) === false) {
				continue;
			} 
			$temp[$value] = $colPos;
		} 
		$arg['select'] = $temp;
		$found = -1;
		$added = -1;
		$selected = array();
		$function = 'foreach ( $rows as $key => $value ){';
		if ($matches != 'TRUE') {
			$function .= 'if((' . $matches . ')===false){ continue; }';
		} 
		$function .= '$added++;';
		if (empty($arg['orderby'])) {
			$function .= 'if($added>' . $arg['limit'][1] . '){ break; }';
		} 
		foreach ($arg['select'] as $key => $select_value) {
			$function .= "\$selected[\$added]['$key'] = \$value[$select_value];";
		} 
		$function .= '}';
		eval($function);
		if (!empty($arg['orderby']) && !empty($selected) && count($selected) > 0) {
			if (!is_array($arg['orderby']) || count($arg['orderby']) < 2) {
				$this -> _error(E_USER_NOTICE, 'Invalid Order By Clause; Must be array, with two values. array(string "column name", [ASC|DESC])');
				return false;
			} 
			if (!array_key_exists($arg['orderby'][0], $selected[0])) {
				$this -> _error(E_USER_NOTICE, 'Cannot sort results by column \'' . $arg['orderby'][0] . '\'; Column not in result set');
				return false;
			} 
			if (strtolower($arg['orderby'][1]) != 'asc' && strtolower($arg['orderby'][1]) != 'desc') {
				$this -> _error(E_USER_NOTICE, 'Results can only be sorted \'asc\' (ascending) or \'desc\' (descending)');
				return false;
			} 
			if (count($arg['orderby']) > 4) {
			} 
			if (count($arg['orderby']) > 2) {
				$selected = $this -> _qsort($selected, $arg['orderby'], 'array');
			} else {
				$selected = $this -> _qsort($selected, $arg['orderby'][0], $arg['orderby'][1]);
			} 
		} 
		$selected = array_slice($selected, $arg['limit'][0], $arg['limit'][1] + 1);
		if (!empty($arg['distinct'])) {
			if ($this -> _getColPos($arg['distinct'], $cols) === false) {
				$this -> _error(E_USER_NOTICE, 'Column \'' . $arg['distinct'] . '\' doesn\'t exist');
				return false;
			} 
			$selected = $this -> unique_multi_array($selected, $arg['distinct']);
		} 
		return $selected;
	} 
	private function get_insert_value_model($arg, $cols, $model) {
		foreach ($arg['values'] as $key => $value) {
			if (strtolower($key) == 'primary') {
				if (empty($cols['primary'])) {
					$this -> _error(E_USER_NOTICE, 'No primary key assigned to table ' . $arg['table']);
					return false;
				} 
				$key = $cols['primary'];
			} 
			if (($colPos = $this -> _getColPos($key, $cols)) === false) {
				continue;
			} 
			$value = array($colPos, $value);
			if ($cols[$key]['type'] == 'int' && $cols[$key]['max'] > 0 && strlen($value[1]) > $cols[$key]['max']) {
				$this -> _error(E_USER_NOTICE, 'Cannot exceed maximum value for column ' . $key . '<br>value：' . $value[1] . ' <br>max：' . $cols[$key]['max']);
				return false;
			} elseif ($cols[$key]['max'] > 0 && strlen($value[1]) > $cols[$key]['max']) {
				$this -> _error(E_USER_NOTICE, 'Cannot exceed maximum value for column ' . $key . '<br>value：' . $value[1] . ' <br>max：' . $cols[$key]['max']);
				return false;
			} 
			if ($value[1] == '' && !empty($cols[$key]['default'])) {
				$value[1] = $cols[$key]['default'];
			} 
			if ($cols[$key]['auto_increment'] == 1 && !isset($arg['keepid'])) {
				$value[1] = $model[$colPos];
			} 
			switch (strtolower($cols[$key]['type'])) {
				case 'enum': if (empty($cols[$key]['enum_val'])) {
						$cols[$key]['enum_val'] = serialize(array(''));
					} 
					$enum_val = unserialize($cols[$key]['enum_val']);
					foreach ($enum_val as $key => $value1) {
						if (strtolower($value[1]) == strtolower($value1)) {
							break;
						} 
						if ($key == (count($enum_val) - 1)) {
							$value[1] = $enum_val[$key];
							break;
						} 
					} 
				case 'text': case 'string': $model[$value[0]] = (string)$value[1];
					break;
				case 'int': $model[$value[0]] = (int)$value[1];
					break;
				case 'bool': $model[$value[0]] = (boolean)$value[1];
					break;
				case 'date': $model[$value[0]] = time();
					break;
			} 
		} 
		return $model;
	} 
	function _insert($arg) {
		$this -> _checkdb($arg['db']);
		$this -> _isselect();
		$this -> _isemptytable($arg['table']);
		$this -> _checkdblock();
		$filename = "$this->_LIBPATH/$this->_SELECTEDDB/{$arg['table']}";
		$table_frm = preg_replace('#^([A-Za-z_]+)\d+#', '$1', $arg['table']);
		if (in_array($table_frm, $this -> hash_db)) {
			$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$table_frm/{$arg['table']}";
		} 
		if (($rows = $this -> _readFile($filename . '.MYD')) === false || ($cols = $this -> _readFile("$this->_LIBPATH/$this->_SELECTEDDB/{$table_frm}.FRM")) === false) {
			$this -> _error(E_USER_NOTICE, 'Table ' . $arg['table'] . ' doesn\'t exist');
			return false;
		} 
		$max = count($rows);
		if (key(array_slice($arg['values'], 0, 1)) == 0 && is_array($arg['values'][0])) {
			$values = $arg['values'];
			foreach($values as $k => $vo) {
				$arg['values'] = $vo;
				$model = array();
				foreach ($cols as $key => $value) {
					if ($key == 'primary') continue;
					if ($value['auto_increment'] == 1) {
						$model[] = ($cols[$key]['autocount']++) + 1;
					} elseif ($value['type'] == 'date') {
						$arg['values'][$key] = '';
					} else {
						$model[] = $value['default'];
					} 
				} 
				$rows[] = $this -> get_insert_value_model($arg, $cols, $model);
			} 
		} else {
			$model = array();
			foreach ($cols as $key => $value) {
				if ($key == 'primary') continue;
				if ($value['auto_increment'] == 1) {
					$model[] = ($cols[$key]['autocount']++) + 1;
				} elseif ($value['type'] == 'date') {
					$arg['values'][$key] = '';
				} else {
					$model[] = $value['default'];
				} 
			} 
			$rows[] = $this -> get_insert_value_model($arg, $cols, $model);
		} 
		$fp = @fopen($filename . ".MYD", 'w') or $this -> _error(E_USER_ERROR, 'Error opening table ' . $arg['table']);
		@flock($fp, LOCK_EX);
		@fwrite($fp, serialize($rows)) or $this -> _error(E_USER_ERROR, 'Error writing to table ' . $arg['table']);
		@flock($fp, LOCK_UN);
		@fclose($fp);
		$fp = @fopen("$this->_LIBPATH/$this->_SELECTEDDB/{$table_frm}.FRM", 'w') or $this -> _error(E_USER_ERROR, 'Error opening table ' . $arg['table']);
		@flock($fp, LOCK_EX);
		@fwrite($fp, serialize($cols)) or $this -> _error(E_USER_ERROR, 'Error writing to table ' . $arg['table']);
		@flock($fp, LOCK_UN);
		@fclose($fp);
		$this -> _CACHE[$filename . '.MYD'] = $rows;
		$this -> _CACHE["$this->_LIBPATH/$this->_SELECTEDDB/{$table_frm}.FRM"] = $cols;
		return true;
	} 
	function _delete($arg) {
		$this -> _checkdb($arg['db']);
		$this -> _isselect();
		$this -> _isemptytable($arg['table']);
		$this -> _checkdblock();
		$filename = "$this->_LIBPATH/$this->_SELECTEDDB/{$arg['table']}";
		$table_frm = preg_replace('#^([A-Za-z_]+)\d+#', '$1', $arg['table']);
		if (in_array($table_frm, $this -> hash_db)) {
			$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$table_frm/{$arg['table']}";
		} 
		if (($rows = $this -> _readFile($filename . '.MYD')) === false || ($cols = $this -> _readFile("$this->_LIBPATH/$this->_SELECTEDDB/{$table_frm}.FRM")) === false) {
			$this -> _error(E_USER_NOTICE, 'Table ' . $arg['table'] . ' doesn\'t exist');
			return false;
		} 
		if (isset($arg['where'])) {
			if (($matches = $this -> _buildIf($arg['where'], $cols)) === false) {
				return false;
			} 
		} else {
			$rows = array();
		} 
		if (!isset($arg['limit']) || empty($arg['limit']) || !is_numeric($arg['limit'][0])) {
			$arg['limit']['0'] = count($rows);
		} 
		$found = 0;
		$deleted = 0;
		$function = '
		foreach ( $rows as $key => $value )
		{
			if ( ' . (isset($matches) ? $matches : 'TRUE') . ' )
			{
				$found++;
				if ( $found <= $arg[\'limit\'][0] )
				{
					$deleted++;
					unset($rows[$key]);
					if ( $found >= $arg[\'limit\'][0] )
					{
						break;
					}
					continue;
				}
				break;
			}
		}';
		eval($function);
		$fp = @fopen($filename . ".MYD", 'w') or $this -> _error(E_USER_ERROR, 'Error opening table ' . $arg['table']);
		@flock($fp, LOCK_EX);
		@fwrite($fp, serialize($rows)) or $this -> _error(E_USER_ERROR, 'Error writing to table ' . $arg['table']);
		@flock($fp, LOCK_UN);
		@fclose($fp);
		$this -> _CACHE[$filename . '.MYD'] = $rows;
		$this -> _CACHE["$this->_LIBPATH/$this->_SELECTEDDB/{$table_frm}.FRM"] = $cols;
		return $deleted;
	} 
	function _update($arg) {
		$this -> _checkdb($arg['db']);
		$this -> _isselect();
		$this -> _isemptytable($arg['table']);
		$this -> _checkdblock();
		$filename = "$this->_LIBPATH/$this->_SELECTEDDB/{$arg['table']}";
		$table_frm = preg_replace('#^([A-Za-z_]+)\d+#', '$1', $arg['table']);
		if (in_array($table_frm, $this -> hash_db)) {
			$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$table_frm/{$arg['table']}";
		} 
		if (($rows = $this -> _readFile($filename . '.MYD')) === false || ($cols = $this -> _readFile("$this->_LIBPATH/$this->_SELECTEDDB/{$table_frm}.FRM")) === false) {
			$this -> _error(E_USER_NOTICE, 'Table ' . $arg['table'] . ' doesn\'t exist');
			return false;
		} 
		if (!isset($arg['where'])) {
			$this -> _error(E_USER_NOTICE, 'Must specify a where clause');
			return false;
		} elseif (($matches = $this -> _buildIf($arg['where'], $cols)) === false) {
			return false;
		} elseif (!isset($arg['values']) || empty($arg['values'])) {
			$this -> _error(E_USER_NOTICE, 'Must specify values to update');
			return false;
		} 
		if (empty($arg['limit'])) {
			$arg['limit']['0'] = count($rows);
		} elseif (!is_array($arg['limit']) || !is_numeric($arg['limit'][0]) || $arg['limit'][0] <= 0) {
			$arg['limit']['0'] = count($rows);
		} 
		foreach ($arg['values'] as $key => $value) {
			if (strtolower($key) == 'primary') {
				if (empty($cols['primary'])) {
					$this -> _error(E_USER_NOTICE, 'No primary key assigned to table ' . $arg['table']);
					return false;
				} 
				$key = $cols['primary'];
			} 
			if (($colPos = $this -> _getColPos($key, $cols)) === false) {
				unset($arg['values'][$key]);
				continue;
			} 
			if ($cols[$key]['permanent'] == 1) {
				$this -> _error(E_USER_NOTICE, 'Column ' . $key . ' is set to permanent');
				unset($arg['values'][$key]);
				continue;
			} 
			if ($cols[$key]['type'] == 'int' && $cols[$key]['max'] > 0 && strlen($value) > $cols[$key]['max']) {
				$this -> _error(E_USER_NOTICE, 'Cannot exceed maximum value for column ' . $key . ', value：' . $value . ', maxlen：' . $cols[$key]['max']);
				return false;
			} elseif ($cols[$key]['max'] > 0 && strlen($value) > $cols[$key]['max']) {
				$this -> _error(E_USER_NOTICE, 'Cannot exceed maximum value for column ' . $key . ' ,value: ' . $value . ' maxlen：' . $cols[$key]['max']);
				return false;
			} 
			$arg['values'][$key] = array($colPos, $value);
			unset($key, $value);
		} 
		$found = 0;
		$updated = 0;
		$function = '	foreach ( $rows as $key => $value )
				{
					if ( ' . $matches . ' )
					{
						$found++;
						if ( $found <= $arg[\'limit\'][0] )
						{
							$updated++;';
		foreach ($arg['values'] as $key1 => $value1) {
			switch (strtolower($cols[$key1]['type'])) {
				case 'enum': if (empty($cols[$key1]['enum_val'])) {
						$cols[$key1]['enum_val'] = serialize(array(''));
					} 
					$enum_val = unserialize($cols[$key1]['enum_val']);
					foreach ($enum_val as $key2 => $value2) {
						if (strtolower($arg['values'][$key1][1]) == strtolower($value2)) {
							break;
						} 
						if ($key2 == (count($enum_val) - 1)) {
							$arg['values'][$key1][1] = $enum_val[$key2];
							break;
						} 
					} 
				case 'text': case 'string': $type = "string";
					break;
				case 'int': $type = "integer";
					break;
				case 'bool': $type = "boolean";
					break;
				default: $type = "string";
			} 
			$function .= "\$rows[\$key][$value1[0]] = ( $type ) \$arg['values']['$key1'][1];";
		} 
		$function .= '				continue;
						}
						break;
					}
				}
		';
		eval($function);
		@file_put_contents("$this->_LIBPATH/$this->_SELECTEDDB/{$table_frm}.FRM", serialize($cols)) or $this -> _error(E_USER_ERROR, 'Error writing to table ' . $table_frm);
		@file_put_contents($filename . ".MYD", serialize($rows)) or $this -> _error(E_USER_ERROR, 'Error writing to table ' . $arg['table']);
		$this -> _CACHE[$filename . '.MYD'] = $rows;
		$this -> _CACHE["$this->_LIBPATH/$this->_SELECTEDDB/{$table_frm}.FRM"] = $cols;
		return $updated;
	} 
	function _showtables($arg = null) {
		if (!empty($arg['db'])) {
			if (!$this -> selectdb($arg['db'])) {
				return false;
			} 
		} 
		$this -> _isselect();
		if (($fp = @opendir("$this->_LIBPATH/$this->_SELECTEDDB")) === false) {
			$this -> _error(E_USER_ERROR, 'Could not open directory, ' . $this -> _LIBPATH . '/' . $this -> _SELECTEDDB . ', for reading');
		} 
		$table = array();
		while (($file = @readdir($fp)) !== false) {
			if ($file != "." && $file != ".." && $file != 'user.MYI') {
				$extension = substr($file, strrpos($file, '.') + 1);
				if (($extension == 'MYD' || $extension == 'FRM') && is_file("$this->_LIBPATH/$this->_SELECTEDDB/$file")) {
					$table[] = substr($file, 0, strrpos($file, '.'));
				} 
			} 
		} 
		@closedir($fp);
		$tables = array();
		foreach ($table as $key => $value) {
			if (isset($temp[$value])) {
				$tables[] = $value;
			} else {
				$temp[$value] = true;
			} 
		} 
		return !empty($tables) ? $tables : array();
	} 
	function _createtable($arg = null) {
		$this -> _checkdb($arg['db']);
		$this -> _isselect();
		$this -> _checkdblock();
		if (empty($arg['table']) || !preg_match('/^[A-Za-z0-9_]+$/', $arg['table'])) {
			$this -> _error(E_USER_NOTICE, 'Table name can only contain letters, and numbers');
			return false;
		} 
		if (empty($arg['columns']) || !is_array($arg['columns'])) {
			$this -> _error(E_USER_NOTICE, 'Invalid columns for table ' . $arg['table']);
			return false;
		} 
		$cols = array('primary' => '');
		$primaryset = false;
		foreach ($arg['columns'] as $key => $value) {
			$model = array('permanent' => 0, 'auto_increment' => 0, 'max' => 0, 'type' => 'string', 'default' => '', 'autocount' => (int) 0, 'enum_val' => '');
			if ($key == 'primary') {
				$this -> _error(E_USER_NOTICE, 'Use of reserved word [primary]');
				return false;
			} 
			if ((!empty($value) && !is_array($value)) || empty($key)) {
				$this -> _error(E_USER_NOTICE, 'Invalid columns for table ' . $arg['table']);
				return false;
			} 
			foreach ($value as $key1 => $value1) {
				switch (strtolower($key1)) {
					case 'auto_increment': $value1 = (int) $value1;
						if ($value1 < 0 || $value1 > 1) {
							$this -> _error(E_USER_NOTICE, 'Auto_increment must be a boolean 1 or 0');
							return false;
						} 
						if (isset($value['type']) && $value['type'] != 'int' && $value1 == 1) {
							$this -> _error(E_USER_NOTICE, 'auto_increment must be an integer type');
							return false;
						} 
						$model['auto_increment'] = $value1;
						break;
					case 'permanent': $value1 = (int) $value1;
						if ($value1 < 0 || $value1 > 1) {
							$this -> _error(E_USER_NOTICE, 'Permanent must be a boolean 1 or 0');
							return false;
						} 
						$model['permanent'] = $value1;
						break;
					case 'max': $value1 = (int) $value1;
						if ($value1 < 0 || $value1 > 1000000) {
							$this -> _error(E_USER_NOTICE, 'Max must be less than 1,000,000 and greater than -1');
							return false;
						} 
						$model['max'] = $value1;
						break;
					case 'type': switch (strtolower($value1)) {
							case 'text': $model['type'] = 'text';
								break;
							case 'string': $model['type'] = 'string';
								break;
							case 'int': $model['type'] = 'int';
								break;
							case 'bool': $model['type'] = 'bool';
								break;
							case 'enum': if (!isset($value['enum_val']) || !is_array($value['enum_val']) || empty($value['enum_val'])) {
									$this -> _error(E_USER_NOTICE, 'Missing enum\'s list of values or invalid list inputted');
									return false;
								} 
								$model['type'] = 'enum';
								$model['enum_val'] = serialize($value['enum_val']);
								break;
							case 'date': $model['type'] = 'date';
								break;
							default: $this -> _error(E_USER_NOTICE, 'Invalid column type, can only accept integers, strings, and booleans');
								return false;
						} 
						break;
					case 'default': $model['default'] = $value1;
						break;
					case 'primary': $value1 = (int) $value1;
						if ($value1 < 0 || $value1 > 1) {
							$this -> _error(E_USER_NOTICE, 'Primary must be a boolean 1 or 0');
							return false;
						} 
						if ($primaryset === true && $value1 == 1) {
							$this -> _error(E_USER_NOTICE, 'Only one primary column can be set');
							return false;
						} 
						if ($value1 == 1) {
							$value['auto_increment'] = isset($value['auto_increment']) ? $value['auto_increment'] : 0;
							$value['type'] = isset($value['type']) ? $value['type'] : 0;
							if ($value['auto_increment'] != 1 || $value['type'] != 'int') {
								$this -> _error(E_USER_NOTICE, 'Primary keys must be of type \'integer\' and auto_increment');
								return false;
							} 
							$cols['primary'] = $key;
						} 
						break;
					case 'enum_val': break;
					default: $this -> _error(E_USER_NOTICE, 'Invalid column definition, ["' . $key1 . '"], specified');
						return false;
						break;
				} 
			} 
			$cols[$key] = $model;
		} 
		$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$arg[table]";
		$table_frm = preg_replace('#^([A-Za-z_]+)\d+#', '$1', $arg['table']);
		if (in_array($table_frm, $this -> hash_db)) {
			$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$table_frm/{$arg['table']}";
		} 
		if (is_file($filename . ".MYD") || is_file("$this->_LIBPATH/$this->_SELECTEDDB/$table_frm.FRM")) {
			$this -> _error(E_USER_NOTICE, 'Table ' . $arg['table'] . ' already exists');
			return false;
		} 
		$fp = @fopen($filename . ".MYD", 'w') or $this -> _error(E_USER_ERROR, 'Error creating table ' . $arg['table']);
		@flock($fp, LOCK_EX);
		@fwrite($fp, 'a:0:{}') or $this -> _error(E_USER_ERROR, 'Error writing to table ' . $arg['table'] . ' while creating it');
		@flock($fp, LOCK_UN);
		@fclose($fp);
		@chmod($filename . ".MYD", 0766);
		$fp = @fopen("$this->_LIBPATH/$this->_SELECTEDDB/$table_frm.FRM", 'w') or $this -> _error(E_USER_ERROR, 'Error creating table ' . $arg['table']);
		@flock($fp, LOCK_EX);
		@fwrite($fp, serialize($cols)) or $this -> _error(E_USER_ERROR, 'Error creating table ' . $arg['table']);
		@flock($fp, LOCK_UN);
		@chmod("$this->_LIBPATH/$this->_SELECTEDDB/$table_frm.FRM", 0766);
		@fclose($fp);
		$this -> _CACHE["$this->_LIBPATH/$this->_SELECTEDDB/$table_frm.FRM"] = $cols;
		return true;
	} 
	function _droptable($arg = null) {
		if (empty($arg['table']) || !preg_match('/^[A-Za-z0-9_]+$/', $arg['table'])) {
			$this -> _error(E_USER_NOTICE, 'Database name can only contain letters, and numbers');
			return false;
		} 
		$this -> _checkdb($arg['db']);
		$this -> _isselect();
		$this -> _checkdblock();
		$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$arg[table]";
		$table_frm = preg_replace('#^([A-Za-z_]+)\d+#', '$1', $arg['table']);
		if (in_array($table_frm, $this -> hash_db)) {
			$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$table_frm/{$arg['table']}";
		} 
		if (!is_file($filename . '.MYD') || !is_file("$this->_LIBPATH/$this->_SELECTEDDB/$table_frm.FRM")) {
			$this -> _error(E_USER_NOTICE, 'Table ' . $arg['table'] . ' doesn\'t exist');
			return false;
		} 
		if (!@unlink($filename . '.MYD') || !@unlink("$this->_LIBPATH/$this->_SELECTEDDB/$table_frm.FRM")) {
			$this -> _error(E_USER_ERROR, 'Could not delete table ' . $arg['table']);
		} 
		return true;
	} 
	function _altertable($arg = null) {
		$this -> _checkdb($arg['db']);
		$this -> _isselect();
		$this -> _checkdblock();
		if (!empty($arg['name']) && !preg_match('/^[A-Za-z0-9_]+$/', $arg['name'])) {
			$this -> _error(E_USER_NOTICE, 'Names can only contain letters, numbers, and underscored');
			return false;
		} elseif (empty($arg['action'])) {
			$this -> _error(E_USER_NOTICE, 'No action specified in alter table query');
			return false;
		} 
		$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$arg[table]";
		$table_frm = preg_replace('#^([A-Za-z_]+)\d+#', '$1', $arg['table']);
		if (in_array($table_frm, $this -> hash_db)) {
			$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$table_frm/{$arg['table']}";
		} 
		if (!is_file($filename . '.MYD') || !is_file("$this->_LIBPATH/$this->_SELECTEDDB/$table_frm.FRM")) {
			$this -> _error(E_USER_NOTICE, 'Table ' . $arg['table'] . ' doesn\'t exist');
			return false;
		} 
		if (($rows = $this -> _readFile($filename . '.MYD')) === false || ($cols = $this -> _readFile("$this->_LIBPATH/$this->_SELECTEDDB/$table_frm.FRM")) === false) {
			$this -> _error(E_USER_NOTICE, 'Table "' . $arg['table'] . '" doesn\'t exist');
			return false;
		} 
		$primaryset = !empty($cols['primary']) ? true : false;
		$action = strtolower($arg['action']);
		switch (strtolower($arg['action'])) {
			case 'insert': if (empty($arg['name'])) {
					$this -> _error(E_USER_NOTICE, 'Forgot to input new column\'s name');
					return false;
				} 
				if ($arg['name'] == 'primary') {
					$this -> _error(E_USER_NOTICE, 'Cannot name column primary (use of reserved words)');
					return false;
				} elseif (isset($cols[$arg['name']])) {
					$this -> _error(E_USER_NOTICE, 'Column ' . $arg['name'] . ' already exists');
					return false;
				} 
				if (empty($arg['after'])) {
					$colNames = array_keys($cols);
					$arg['after'] = $colNames[count($cols)-1];
				} 
				$model = array('permanent' => 0, 'auto_increment' => 0, 'max' => 0, 'type' => 'int', 'default' => '', 'autocount' => 0, 'enum_val' => '');
				foreach ($arg['values'] as $key => $value) {
					switch (strtolower($key)) {
						case 'auto_increment': $value = (int) $value;
							if ($value < 0 || $value > 1) {
								$this -> _error(E_USER_NOTICE, 'Auto_increment must be a boolean 1 or 0');
								return false;
							} 
							if (isset($arg['values']['type']) && $arg['values']['type'] != 'int' && $value == 1) {
								$this -> _error(E_USER_NOTICE, 'auto_increment must be an integer type');
								return false;
							} 
							$model['auto_increment'] = $value;
							break;
						case 'permanent': $value = (int) $value;
							if ($value < 0 || $value > 1) {
								$this -> _error(E_USER_NOTICE, 'Permanent must be a boolean 1 or 0');
								return false;
							} 
							$model['permanent'] = $value;
							break;
						case 'max': $value = (int) $value;
							if ($value < 0 || $value > 1000000) {
								$this -> _error(E_USER_NOTICE, 'Max must be less than 1,000,000 and greater than -1');
								return false;
							} 
							$model['max'] = $value;
							break;
						case 'type': switch (strtolower($value)) {
								case 'text': $model['type'] = 'text';
									break;
								case 'string': $model['type'] = 'string';
									break;
								case 'int': $model['type'] = 'int';
									break;
								case 'bool': $model['type'] = 'bool';
									break;
								case 'enum': if (!isset($arg['values']['enum_val']) || !is_array($arg['values']['enum_val']) || empty($arg['values']['enum_val'])) {
										$this -> _error(E_USER_NOTICE, 'Missing enum\'s list of values or invalid list inputted');
										return false;
									} 
									$model['type'] = 'enum';
									$model['enum_val'] = serialize($arg['values']['enum_val']);
									break;
								case 'date': $model['type'] = 'date';
									break;
								default: $this -> _error(E_USER_NOTICE, 'Invalid column type, can only accept integers, strings, and booleans');
									return false;
							} 
							break;
						case 'default': $model['default'] = $value;
							break;
						case 'primary': $value = (int) $value;
							if ($value < 0 || $value > 1) {
								$this -> _error(E_USER_NOTICE, 'Primary must be a boolean 1 or 0');
								return false;
							} 
							if ($primaryset === true && $value == 1) {
								$this -> _error(E_USER_NOTICE, 'Only one primary column can be set');
								return false;
							} 
							if ($value == 1) {
								$cols['primary'] = $arg['name'];
							} 
							break;
						case 'enum_val': break;
						default: $this -> _error(E_USER_NOTICE, 'Invalid column definition, ["' . $key . '"], specified');
							return false;
					} 
				} 
				if ($arg['after'] == 'primary') {
					$afterColPos = 1;
				} else {
					if (($afterColPos = $this -> _getColPos($arg['after'], $cols) + 2) === false) {
						$this -> _error(E_USER_NOTICE, 'Column \'' . $arg['after'] . '\' doesn\'t exist');
						return false;
					} 
				} 
				$i = 0;
				foreach ($cols as $key => $value) {
					$temp[$key] = $value;
					$i++;
					if ($i == $afterColPos) {
						$temp[$arg['name']] = $model;
					} 
				} 
				$cols = $temp;
				if (!empty($rows)) {
					foreach ($rows as $key => $value) {
						$i = 0;
						foreach ($value as $key1 => $value1) {
							if ($i < $afterColPos-1) {
								$temp1[$key][$key1] = $value1;
							} 
							if ($i == $afterColPos - 1 || ($i == count($value) - 1 && $i == $afterColPos - 2)) {
								$temp1[$key][ (($i == count($value) - 1 && $i == $afterColPos - 2) ? $key1 + 1 : $key1) ] = '';
								$i++;
							} 
							if ($i > $afterColPos-1) {
								$temp1[$key][$key1 + 1] = $value1;
							} 
							$i++;
						} 
					} 
					$rows = $temp1;
				} 
				$fp = @fopen("$this->_LIBPATH/$this->_SELECTEDDB/$table_frm.FRM", 'w') or $this -> _error(E_USER_ERROR, 'Could not open ' . $table_frm . '.FRM for writing');
				@flock($fp, LOCK_EX);
				@fwrite($fp, serialize($cols)) or $this -> _error(E_USER_ERROR, 'Could not write to file ' . $filename . '.FRM');
				@flock($fp, LOCK_UN);
				@fclose($fp) or $this -> _error(E_USER_ERROR, 'Could not close ' . $filename . '.FRM');
				$fp = @fopen($filename . '.MYD', 'w') or $this -> _error(E_USER_ERROR, 'Could not open ' . $filename . '.MYD for writing');
				@flock($fp, LOCK_EX);
				@fwrite($fp, serialize($rows)) or $this -> _error(E_USER_ERROR, 'Could not write to file ' . $filename . '.MYD');
				@flock($fp, LOCK_UN);
				@fclose($fp) or $this -> _error(E_USER_ERROR, 'Could not close ' . $filename . '.MYD');
				$this -> _CACHE[$filename . '.MYD'] = $rows;
				$this -> _CACHE["$this->_LIBPATH/$this->_SELECTEDDB/{$table_frm}.FRM"] = $cols;
				return true;
				break;
			case 'modify': if ($arg['name'] == 'primary') {
					$this -> _error(E_USER_NOTICE, 'Column primary doesn\'t exist');
					return false;
				} elseif (!isset($cols[$arg['name']])) {
					$this -> _error(E_USER_NOTICE, 'Column ' . $arg['name'] . ' doesn\'t exist');
					return false;
				} elseif (empty($arg['values'])) {
					$this -> _error(E_USER_NOTICE, 'Empty column set given');
					return false;
				} 
				$model = array('permanent' => $cols[$arg['name']]['permanent'], 'auto_increment' => $cols[$arg['name']]['auto_increment'], 'max' => $cols[$arg['name']]['max'], 'type' => $cols[$arg['name']]['type'], 'default' => $cols[$arg['name']]['default'], 'autocount' => $cols[$arg['name']]['autocount'], 'enum_val' => $cols[$arg['name']]['enum_val']);
				foreach ($arg['values'] as $key => $value) {
					switch (strtolower($key)) {
						case 'auto_increment': $value = (int) $value;
							if ($value < 0 || $value > 1) {
								$this -> _error(E_USER_NOTICE, 'Auto_increment must be a boolean 1 or 0');
								return false;
							} 
							if (isset($arg['values']['type']) && $arg['values']['type'] != 'int' && $value == 1) {
								$this -> _error(E_USER_NOTICE, 'auto_increment must be an integer type');
								return false;
							} 
							$model['auto_increment'] = $value;
							break;
						case 'permanent': $value = (int) $value;
							if ($value < 0 || $value > 1) {
								$this -> _error(E_USER_NOTICE, 'Permanent must be a boolean 1 or 0');
								return false;
							} 
							$model['permanent'] = $value;
							break;
						case 'max': $value = (int) $value;
							if ($value < 0 || $value > 1000000) {
								$this -> _error(E_USER_NOTICE, 'Max must be less than 1,000,000 and greater than -1');
								return false;
							} 
							$model['max'] = $value;
							break;
						case 'type': switch (strtolower($value)) {
								case 'text': $model['type'] = 'text';
									break;
								case 'string': $model['type'] = 'string';
									break;
								case 'int': $model['type'] = 'int';
									break;
								case 'bool': $model['type'] = 'bool';
									break;
								case 'enum': if (!isset($arg['values']['enum_val']) || !is_array($arg['values']['enum_val']) || empty($arg['values']['enum_val'])) {
										$this -> _error(E_USER_NOTICE, 'Missing enum\'s list of values or invalid list inputted');
										return false;
									} 
									$model['type'] = 'enum';
									$model['enum_val'] = serialize($arg['values']['enum_val']);
									break;
								case 'date': $model['type'] = 'date';
									break;
								default: $this -> _error(E_USER_NOTICE, 'Invalid column type, can only accept integers, strings, and booleans');
									return false;
							} 
							break;
						case 'default': $model['default'] = $value;
							break;
						case 'primary': $value = (int) $value;
							if ($value < 0 || $value > 1) {
								$this -> _error(E_USER_NOTICE, 'Primary must be a boolean 1 or 0');
								return false;
							} 
							if ($primaryset === true && $value == 1) {
								$this -> _error(E_USER_NOTICE, 'Only one primary column can be set');
								return false;
							} 
							if ($value == 1) {
								$cols['primary'] = $arg['name'];
							} 
							break;
						case 'enum_val': break;
						default: $this -> _error(E_USER_NOTICE, 'Invalid column definition, ["' . $key . '"], specified');
							return false;
					} 
				} 
				if (($model['type'] != 'int' || $model['auto_increment'] != 1) && strtolower($cols['primary']) == strtolower($arg['name'])) {
					$cols['primary'] = '';
					$this -> _error(E_USER_NOTICE, 'The primary key has been dropped, column must be auto_increment, and integer');
				} 
				$cols[$arg['name']] = $model;
				$fp = @fopen("$this->_LIBPATH/$this->_SELECTEDDB/$table_frm.FRM", 'w') or $this -> _error(E_USER_ERROR, 'Could not open ' . $filename . '.FRM for writing');
				@flock($fp, LOCK_EX);
				@fwrite($fp, serialize($cols)) or $this -> _error(E_USER_ERROR, 'Could not write to file ' . $filename . '.FRM');
				@flock($fp, LOCK_UN);
				@fclose($fp) or $this -> _error(E_USER_ERROR, 'Could not close ' . $filename . '.FRM');
				$this -> _CACHE["$this->_LIBPATH/$this->_SELECTEDDB/$table_frm.FRM"] = $cols;
				return true;
				break;
			case 'drop': if (empty($arg['name']) or !preg_match('/^[A-Za-z0-9_]+$/', $arg['name'])) {
					$this -> _error(E_USER_NOTICE, 'Column name can only contain letters, numbers, and underscores');
					return false;
				} 
				if (!isset($cols[$arg['name']]) || $arg['name'] == 'primary') {
					$this -> _error(E_USER_NOTICE, 'Column ' . $arg['name'] . ' doesn\'t exist');
					return false;
				} 
				if (count($cols) - 2 <= 0) {
					$this -> _error(E_USER_NOTICE, 'Cannot drop column; There has to be at-least ONE column present');
					return false;
				} 
				$i = -1;
				foreach ($cols as $key => $value) {
					if ($key == $arg['name'] && $i > -1) {
						$position = $i;
						break;
					} 
					$i++;
				} 
				if ($cols['primary'] == $arg['name']) {
					$cols['primary'] = '';
				} 
				unset($cols[$arg['name']]);
				if (is_array($rows) && count($rows) > 0) {
					foreach ($rows as $key => $value) {
						unset($rows[$key][$position]);
						$rows[$key] = array_splice($rows[$key], 0);
					} 
				} 
				$fp = @fopen("$this->_LIBPATH/$this->_SELECTEDDB/$table_frm.FRM", 'w') or $this -> _error(E_USER_ERROR, 'Could not open ' . $filename . '.FRM for writing');
				@flock($fp, LOCK_EX);
				@fwrite($fp, serialize($cols)) or $this -> _error(E_USER_ERROR, 'Could not write to file ' . $filename . '.FRM');
				@flock($fp, LOCK_UN);
				@fclose($fp) or $this -> _error(E_USER_ERROR, 'Could not close ' . $filename . '.FRM');
				$fp = @fopen($filename . '.MYD', 'w') or $this -> _error(E_USER_ERROR, 'Could not open ' . $filename . '.MYD for writing');
				@flock($fp, LOCK_EX);
				@fwrite($fp, serialize($rows)) or $this -> _error(E_USER_ERROR, 'Could not write to file ' . $filename . '.MYD');
				@flock($fp, LOCK_UN);
				@fclose($fp) or $this -> _error(E_USER_ERROR, 'Could not close ' . $filename . '.MYD');
				$this -> _CACHE[$filename . '.MYD'] = $rows;
				$this -> _CACHE["$this->_LIBPATH/$this->_SELECTEDDB/{$table_frm}.FRM"] = $cols;
				return true;
				break;
			case 'rename col': if (empty($arg['name']) || empty($arg['values']['name']) || !preg_match('/^[A-Za-z0-9_]+$/', $arg['values']['name'])) {
					$this -> _error(E_USER_NOTICE, 'Column names can only contain letters, numbers, and underscores');
					return false;
				} 
				if (!isset($cols[$arg['name']])) {
					$this -> _error(E_USER_NOTICE, 'Column ' . $arg['name'] . ' doesn\'t exist');
					return false;
				} 
				if (isset($cols[$arg['values']['name']]) && $arg['values']['name'] != $arg['name']) {
					$this -> _error(E_USER_NOTICE, 'Column ' . $arg['name'] . ' already exists');
					return false;
				} 
				if ($cols['primary'] == $arg['name']) {
					$cols['primary'] = $arg['values']['name'];
				} 
				$tmp = $cols;
				$cols = array();
				foreach ($tmp as $key => $value) {
					if ($key == $arg['name']) {
						$key = $arg['values']['name'];
					} 
					$cols[$key] = $value;
				} 
				$fp = @fopen("$this->_LIBPATH/$this->_SELECTEDDB/$table_frm.FRM", 'w') or $this -> _error(E_USER_ERROR, 'Could not open ' . $filename . '.FRM for writing');
				@flock($fp, LOCK_EX);
				@fwrite($fp, serialize($cols)) or $this -> _error(E_USER_ERROR, 'Could not write to file ' . $filename . '.FRM');
				@flock($fp, LOCK_UN);
				@fclose($fp) or $this -> _error(E_USER_ERROR, 'Could not close ' . $filename . '.FRM');
				$this -> _CACHE["$this->_LIBPATH/$this->_SELECTEDDB/$table_frm.FRM"] = $cols;
				return true;
				break;
			case 'rename table': if (!preg_match('/^[A-Za-z0-9_]+$/', $arg['name'])) {
					$this -> _error(E_USER_NOTICE, 'Table name can only contain letters, numbers, and underscores');
					return false;
				} 
				$fp1 = "$this->_LIBPATH/$this->_SELECTEDDB/{$arg['name']}";
				if ((is_file($fp1 . '.FRM') || is_file($fp1 . '.MYD')) && strtolower($arg['name']) != strtolower($arg['table'])) {
					$this -> _error(E_USER_NOTICE, 'Table ' . $arg['name'] . ' already exists');
					return false;
				} 
				@rename("$this->_LIBPATH/$this->_SELECTEDDB/$table_frm.FRM", $fp1 . '.FRM') or $this -> _error(E_USER_ERROR, 'Error renaming file ' . $filename . '.FRM');
				@rename($filename . '.MYD', $fp1 . '.MYD') or $this -> _error(E_USER_ERROR, 'Error renaming file ' . $filename . '.MYD');
				return true;
				break;
			case 'addkey': if (empty($arg['values']['name'])) {
					$this -> _error(E_USER_NOTICE, 'Invalid Column Name');
					return false;
				} 
				if ($this -> _getColPos($arg['values']['name'], $cols) === false) {
					$this -> _error(E_USER_NOTICE, 'Column ' . $arg['values']['name'] . ' doesn\'t exist');
					return false;
				} 
				if (!empty($cols['primary'])) {
					$this -> _error(E_USER_NOTICE, 'Primary key already set to \'' . $cols['primary'] . '\'');
					return false;
				} 
				if (($cols[$arg['values']['name']]['type'] != 'int') || ($cols[$arg['values']['name']]['auto_increment'] === false)) {
					$this -> _error(E_USER_NOTICE, 'Primary key must be integer type, and auto increment');
					return false;
				} 
				$cols['primary'] = $arg['values']['name'];
				$fp = @fopen("$this->_LIBPATH/$this->_SELECTEDDB/$table_frm.FRM", 'w') or $this -> _error(E_USER_ERROR, 'Could not open ' . $filename . '.FRM for writing');
				@flock($fp, LOCK_EX);
				@fwrite($fp, serialize($cols)) or $this -> _error(E_USER_ERROR, 'Could not write to file ' . $filename . '.FRM');
				@flock($fp, LOCK_UN);
				@fclose($fp) or $this -> _error(E_USER_ERROR, 'Could not close ' . $filename . '.FRM');
				$this -> _CACHE["$this->_LIBPATH/$this->_SELECTEDDB/$table_frm.FRM"] = $cols;
				return true;
				break;
			case 'dropkey': if (empty($cols['primary'])) {
					$this -> _error(E_USER_NOTICE, 'No Primary key exists for table ' . $arg['table']);
					return false;
				} 
				$cols['primary'] = '';
				$fp = @fopen("$this->_LIBPATH/$this->_SELECTEDDB/$table_frm.FRM", 'w') or $this -> _error(E_USER_ERROR, 'Could not open ' . $filename . '.FRM for writing');
				@flock($fp, LOCK_EX);
				@fwrite($fp, serialize($cols)) or $this -> _error(E_USER_ERROR, 'Could not write to file ' . $filename . '.FRM');
				@flock($fp, LOCK_UN);
				@fclose($fp) or $this -> _error(E_USER_ERROR, 'Could not close ' . $filename . '.FRM');
				$this -> _CACHE["$this->_LIBPATH/$this->_SELECTEDDB/$table_frm.FRM"] = $cols;
				return true;
				break;
			default: $this -> _error(E_USER_NOTICE, 'Invalid action specified for alter table query');
				return false;
		} 
		return false;
	} 
	function _describe($arg = null) {
		$this -> _checkdb($arg['db']);
		$this -> _isselect();
		$filename = "$this->_LIBPATH/$this->_SELECTEDDB/{$arg['table']}";
		$table_frm = preg_replace('#^([A-Za-z_]+)\d+#', '$1', $arg['table']);
		if (in_array($table_frm, $this -> hash_db)) {
			$filename = "$this->_LIBPATH/$this->_SELECTEDDB/$table_frm/{$arg['table']}";
		} 
		if (!(is_file($filename . '.MYD') && is_file("$this->_LIBPATH/$this->_SELECTEDDB/{$table_frm}.FRM"))) {
			$this -> _error(E_USER_NOTICE, 'Table ' . $arg['table'] . ' doesn\'t exist');
			return false;
		} 
		if (($cols = $this -> _readFile("$this->_LIBPATH/$this->_SELECTEDDB/{$table_frm}.FRM")) === false) {
			$this -> _error(E_USER_ERROR, 'Couldn\'t open file ' . $filename . '.FRM for reading');
		} 
		$errorLevel = error_reporting(0);
		foreach ($cols as $key => $col) {
			if ($cols[$key]['type'] == 'enum') {
				$cols[$key]['enum_val'] = unserialize($cols[$key]['enum_val']);
			} 
		} 
		error_reporting($errorLevel);
		return $cols;
	} 
	function _showdatabases() {
		if (($fp = @opendir("$this->_LIBPATH")) === false) {
			$this -> _error(E_USER_ERROR, 'Could not open directory, ' . $this -> _LIBPATH . ', for reading');
		} while (($file = @readdir($fp)) !== false) {
			if ($file != "." && $file != ".." && strtolower($file) != 'txtsql' && is_dir("$this->_LIBPATH/$file")) {
				$db[] = $file;
			} 
		} 
		@closedir($fp);
		return isset($db) ? $db : array();
	} 
	function _createdatabase($arg = null) {
		if (empty($arg['db']) || !preg_match('/^[A-Za-z0-9_]+$/', $arg['db'])) {
			$this -> _error(E_USER_NOTICE, 'Database name can only contain letters, and numbers');
			return false;
		} 
		if ($this -> _dbexist($arg['db'])) {
			$this -> _error(E_USER_NOTICE, 'Database ' . $arg['db'] . ' already exists');
			return false;
		} 
		if (! (mkdir("$this->_LIBPATH/$arg[db]", 0755) && chmod("$this->_LIBPATH/$arg[db]", 0755))) {
			$this -> _error(E_USER_NOTICE, 'Error creating database ' . $arg['db']);
			return false;
		} 
		return true;
	} 
	function _dropdatabase($arg = null) {
		if (empty($arg['db']) || !preg_match('/^[A-Za-z0-9_]+$/', $arg['db'])) {
			$this -> _error(E_USER_NOTICE, 'Database name can only contain letters, and numbers');
			return false;
		} elseif (strtolower($arg['db']) == 'txtsql') {
			$this -> _error(E_USER_NOTICE, 'Cannot delete database txtsql');
			return false;
		} 
		if (!$this -> _dbexist($arg['db'])) {
			$this -> _error(E_USER_NOTICE, 'Database ' . $arg['db'] . ' doesn\'t exist');
			return false;
		} 
		if ($this -> isLocked($arg['db'])) {
			$this -> _error(E_USER_NOTICE, 'Database \'' . $arg['db'] . '\' is locked');
			return false;
		} 
		if (($fp = @opendir("$this->_LIBPATH/$arg[db]")) === false) {
			$this -> _error(E_USER_ERROR, 'Could not delete database ' . $arg['db']);
		} while (($file = @readdir($fp)) !== false) {
			if ($file != "." && $file != "..") {
				if (is_dir("$this->_LIBPATH/$arg[db]/$file") || !@unlink("$this->_LIBPATH/$arg[db]/$file")) {
					$this -> _error(E_USER_ERROR, 'Could not delete database ' . $arg['db']);
				} 
			} 
		} 
		@closedir($fp);
		if (!@rmdir("$this->_LIBPATH/$arg[db]")) {
			$this -> _error(E_USER_ERROR, 'Could not delete database ' . $arg['db']);
		} 
		return true;
	} 
	function _renamedatabase($arg = null) {
		if (empty($arg[0]) || empty($arg[1]) || !preg_match('/^[A-Za-z0-9_]+$/', $arg[0]) || !preg_match('/^[A-Za-z0-9_]+$/', $arg[1])) {
			$this -> _error(E_USER_NOTICE, 'Database name can only contain letters, and numbers');
			return false;
		} elseif (strtolower($arg[0]) == 'txtsql') {
			$this -> _error(E_USER_NOTICE, 'Cannot rename database txtsql');
			return false;
		} 
		if (!$this -> _dbexist($arg[0])) {
			$this -> _error(E_USER_NOTICE, 'Database ' . $arg[0] . ' doesn\'t exist');
			return false;
		} elseif ($this -> _dbexist($arg[1]) && strtolower($arg[0]) != strtolower($arg[1])) {
			$this -> _error(E_USER_NOTICE, 'Database ' . $arg[1] . ' already exists');
			return false;
		} 
		$this -> _checkdblock();
		if (!@rename("$this->_LIBPATH/$arg[0]", "$this->_LIBPATH/$arg[1]")) {
			$this -> _error(E_USER_ERROR, 'Could not rename database ' . $arg[0] . ', to ' . $arg[1]);
		} 
		return true;
	} 
} 
