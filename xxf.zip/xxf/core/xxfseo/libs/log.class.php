<?php class log {
	static $var_7c6c92b4 = 3;
	static $var_095106dd = array();
	static $var_09852b22 = '[ Y-m-d H:i:s ]';
	static function record($var_b34403f5, $var_ea3861d2 = 'ERROR') {
		self :: $var_095106dd[] = "{$var_ea3861d2}: {$var_b34403f5}" . PHP_EOL;
	} 
	static function save($var_67364b0a = '', $var_ebce1a8d = '') {
		if (empty(self :: $var_095106dd)) return ;
		if (3 == self :: $var_7c6c92b4) {
			if (empty($var_67364b0a)) $var_67364b0a = LOG_PATH . date('y_m_d') . '.log';
			if (is_file($var_67364b0a) && 2097152 <= filesize($var_67364b0a)) rename($var_67364b0a, dirname($var_67364b0a) . '/' . time() . '-' . basename($var_67364b0a));
		} 
		$var_e42d1625 = date(self :: $var_09852b22);
		error_log($var_e42d1625 . ' ' . get_client_ip() . ' ' . $_SERVER['REQUEST_URI'] . PHP_EOL . implode('', self :: $var_095106dd) . '
', self :: $var_7c6c92b4, $var_67364b0a , $var_ebce1a8d);
		self :: $var_095106dd = array();
	} 
	static function write($var_b34403f5, $var_ea3861d2 = 'ERROR', $var_67364b0a = '', $var_ebce1a8d = '') {
		$var_e42d1625 = date(self :: $var_09852b22);
		if (3 == self :: $var_7c6c92b4) {
			if (empty($var_67364b0a)) $var_67364b0a = LOG_PATH . date('y_m_d') . '.log';
			if (is_file($var_67364b0a) && 2097152 <= filesize($var_67364b0a)) rename($var_67364b0a, dirname($var_67364b0a) . '/' . time() . '-' . basename($var_67364b0a));
		} 
		error_log("{$var_e42d1625} {$var_ea3861d2}: {$var_b34403f5}" . PHP_EOL, self :: $var_7c6c92b4, $var_67364b0a, $var_ebce1a8d);
	} 
} 
