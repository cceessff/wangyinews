<?php class route {
	protected $var_4c819857 = array('URL_ROUTER_ON' => false, 'URL_ROUTE_RULES' => array(),);
	public function check() {
		$var_04b81daf = ltrim($_SERVER['QUERY_STRING'], '/');
		if (empty($var_04b81daf)) return false;
		if (!config('URL_ROUTER_ON')) return false;
		if (substr(strtolower($var_04b81daf), 0, 5) == 'admin' || $_REQUEST['g'] == 'admin') {
			return false;
		} 
		$var_c6a7b982 = config('URL_ROUTE_RULES');
		if (!empty($var_c6a7b982)) {
			$var_2a6b2574 = config('URL_PATH_DEPR');
			if (strpos($var_04b81daf, '&') !== false) {
				$var_04b81daf = substr($var_04b81daf, 0, strpos($var_04b81daf, '&'));
			} 
			foreach ($var_c6a7b982 as $var_aeaa699e => $var_fc073b09) {
				if (0 === strpos($var_aeaa699e, '/') && preg_match($var_aeaa699e, $var_04b81daf, $matches)) {
					return $this -> parseRegex($matches, $var_fc073b09, $var_04b81daf);
				} 
			} 
		} 
		return false;
	} 
	private function parseRegex($matches, $var_fc073b09, $var_04b81daf) {
		$var_1003d5bb = is_array($var_fc073b09)?$var_fc073b09[0]:$var_fc073b09;
		$var_1003d5bb = preg_replace('/:(\\d+)/', '[match\\1]', $var_1003d5bb);
		foreach($matches as $var_228572b3 => $var_cb83972b) {
			$var_1003d5bb = str_replace('[match' . $var_228572b3 . ']', $matches[$var_228572b3], $var_1003d5bb);
		} 
		if (0 === strpos($var_1003d5bb, '/') || 0 === strpos($var_1003d5bb, 'http')) {
			header("Location: $var_1003d5bb", true, (is_array($var_fc073b09) && isset($var_fc073b09[1]))?$var_fc073b09[1]:301);
			exit;
		} else {
			$var = $this -> parseUrl($var_1003d5bb);
			$var_04b81daf = substr_replace($var_04b81daf, '', 0, strlen($matches[0]));
			if ($var_04b81daf) {
				preg_match_all('~(\\w+)\\/([^,\\/]+)~', $var_04b81daf, $var_973d74fe);
				foreach($var_973d74fe[1] as $var_228572b3 => $var_cb83972b) {
					$var[strtolower($var_cb83972b)] = strip_tags($var_973d74fe[2][$var_228572b3]);
				} 
			} 
			if (is_array($var_fc073b09) && isset($var_fc073b09[1])) {
				parse_str($var_fc073b09[1], $var_43b9b911);
				$var = array_merge($var, $var_43b9b911);
			} 
			$_GET = array_merge($var, $_GET);
		} 
		return true;
	} 
	private function parseUrl($var_1003d5bb) {
		$var = array();
		if (false !== strpos($var_1003d5bb, '?')) {
			$var_35702f41 = parse_url($var_1003d5bb);
			$var_4eda73b5 = explode('/', $var_35702f41['path']);
			parse_str($var_35702f41['query'], $var);
		} elseif (strpos($var_1003d5bb, '/')) {
			$var_4eda73b5 = explode('/', $var_1003d5bb);
		} else {
			parse_str($var_1003d5bb, $var);
		} 
		if (isset($var_4eda73b5)) {
			$var[config('ACTION_VAR')] = array_pop($var_4eda73b5);
			if (!empty($var_4eda73b5)) {
				$var[config('MODULE_VAR')] = array_pop($var_4eda73b5);
			} 
			if (!empty($var_4eda73b5)) {
				$var[config('GROUP_VAR')] = array_pop($var_4eda73b5);
			} 
		} 
		return $var;
	} 
} 
