<?php
defined('INI_TXTCMS') or exit();
if (version_compare(PHP_VERSION, '5.2.0', '<')) exit('本系统运行环境要求PHP版本5.2.0及以上！');
define('IS_CGI', substr(PHP_SAPI, 0, 3) == 'cgi' ? 1 : 0);
define('IS_WIN', strstr(PHP_OS, 'WIN') ? 1 : 0);
define('IS_CLI', PHP_SAPI == 'cli'? 1 : 0);
define('MEMORY_LIMIT_ON', function_exists('memory_get_usage'));
if (MEMORY_LIMIT_ON) $GLOBALS['_start_memory'] = memory_get_usage();
$GLOBALS['_start_time'] = time();
defined('APP_NAME') or define('APP_NAME', basename(dirname($_SERVER['SCRIPT_FILENAME'])));
if (!IS_CLI) {
	if (!defined('_PHP_FILE_')) {
		if (IS_CGI) {
			$var_395355ff = explode('.php', $_SERVER['PHP_SELF']);
			define('_PHP_FILE_', rtrim(str_replace($_SERVER['HTTP_HOST'], '', $var_395355ff[0] . '.php'), '/'));
		} else {
			define('_PHP_FILE_', rtrim($_SERVER['SCRIPT_NAME'], '/'));
		} 
	} 
	if (!defined('__ROOT__')) {
		$var_00036df1 = dirname(_PHP_FILE_);
		define('__ROOT__', (($var_00036df1 == '/' || $var_00036df1 == '\\')?'':$var_00036df1));
	} 
} 
defined('APP_DEBUG') or define('APP_DEBUG', false);
defined('LIB_PATH') or define('LIB_PATH', TXTCMS_PATH . 'libs/');
defined('TEMPLATE_PATH') or define('TEMPLATE_PATH', LIB_PATH . 'template/');
defined('APPLIB_PATH') or define('APPLIB_PATH', APP_PATH . 'core/');
defined('FUNCTION_PATH') or define('FUNCTION_PATH', APPLIB_PATH . 'functions/');
defined('CONFIG_PATH') or define('CONFIG_PATH', APPLIB_PATH . 'configs/');
defined('CLASS_PATH') or define('CLASS_PATH', APPLIB_PATH . 'class/');
defined('TMPL_PATH') or define('TMPL_PATH', APP_PATH . 'template/');
defined('TEMP_PATH') or define('TEMP_PATH', APP_PATH . 'temp/');
defined('LOG_PATH') or define('LOG_PATH', TEMP_PATH . 'logs/');
defined('CACHE_PATH') or define('CACHE_PATH', TEMP_PATH . 'cache/');
defined('DATA_PATH') or define('DATA_PATH', TEMP_PATH . 'data/');
defined('DB_PATH') or define('DB_PATH', TEMP_PATH . 'db/');
defined('SESSION_PATH') or define('SESSION_PATH', TEMP_PATH . 'session/');
defined('TPLCACHE_PATH') or define('TPLCACHE_PATH', CACHE_PATH . 'tplcache/');
session_save_path(SESSION_PATH);
session_set_cookie_params(24 * 3600 * 2);
if (isset($_SERVER['HTTP_X_ORIGINAL_URL'])) {
	$_SERVER['REQUEST_URI'] = $_SERVER['HTTP_X_ORIGINAL_URL'];
} else if (isset($_SERVER['HTTP_X_REWRITE_URL'])) {
	$_SERVER['REQUEST_URI'] = $_SERVER['HTTP_X_REWRITE_URL'];
} 
require TXTCMS_PATH . 'common/function.php';

if (APP_DEBUG || config('web_debug')) {
	@ini_set('display_errors', 'On');
	error_reporting(30719 &~8);
} 
debug_log('loadcms');
config(include TXTCMS_PATH . 'configs/config.php');
function_exists('date_default_timezone_set') && date_default_timezone_set(config('DEFAULT_TIMEZONE'));
if (!is_dir(APP_PATH)) mkdir(APP_PATH, 502, true);
if (!is_dir(SESSION_PATH)) mkdir(SESSION_PATH, 502, true);
if (!is_dir(APPLIB_PATH) && is_writeable(APP_PATH)) {
	$var_aecec765 = array(FUNCTION_PATH, APPLIB_PATH, CONFIG_PATH, TMPL_PATH, TEMP_PATH, LOG_PATH, CACHE_PATH, DATA_PATH, TPLCACHE_PATH, SESSION_PATH, DB_PATH);
	foreach ($var_aecec765 as $var_fae1bb2a) {
		if (!is_dir($var_fae1bb2a)) mkdir($var_fae1bb2a, 502, true);
	} 
} 
$var_370ebc88 = array(LIB_PATH . 'sys.class.php', LIB_PATH . 'route.class.php', LIB_PATH . 'action.class.php', LIB_PATH . 'template.class.php', LIB_PATH . 'view.class.php', LIB_PATH . 'log.class.php', LIB_PATH . 'cache.class.php',);
foreach ($var_370ebc88 as $var_6cbe6605 => $var_980a7c7e) {
	require_load($var_980a7c7e);
} 
_runtime('loadTime');
Sys :: run();
