<?php function _runtime($var_6cbe6605, $var_bd960a5a = '', $var_b7368ff3 = 4) {
	static $var_83300cca = array();
	if (is_float($var_bd960a5a)) {
		$var_83300cca[$var_6cbe6605] = $var_bd960a5a;
	} elseif (!empty($var_bd960a5a)) {
		$var_83300cca[$var_6cbe6605 . '____' . $var_bd960a5a] = microtime('TRUE');
		return round(($var_83300cca[$var_6cbe6605 . '____' . $var_bd960a5a] - $var_83300cca[$var_6cbe6605]), $var_b7368ff3);
	} else {
		$var_83300cca[$var_6cbe6605] = microtime('TRUE');
	} 
} 
function _run_mem($var_6cbe6605, $var_bd960a5a = '', $var_b7368ff3 = 4) {
	static $var_83300cca = array();
	if (is_float($var_bd960a5a)) {
		$var_83300cca[$var_6cbe6605] = $var_bd960a5a;
	} elseif (!empty($var_bd960a5a)) {
		return round((memory_get_usage() - $var_83300cca[$var_6cbe6605]) / 1024, $var_b7368ff3);
	} else {
		$var_83300cca[$var_6cbe6605] = memory_get_usage();
	} 
} 
function num($var_6cbe6605, $var_b2f8d2d7 = 0) {
	$var_6cbe6605 = md5($var_6cbe6605 . '_num');
	if (!_static($var_6cbe6605)) {
		_static($var_6cbe6605, 0);
	} 
	if (empty($var_b2f8d2d7)) {
		return _static($var_6cbe6605);
	} else {
		_static($var_6cbe6605, intval(_static($var_6cbe6605)) + intval($var_b2f8d2d7));
	} 
} 
function _static($var_6cbe6605, $var_2ddd548e = null) {
	static $var_5256d72a = array();
	if (empty($var_6cbe6605)) return $var_5256d72a;
	if (is_null($var_2ddd548e)) {
		return isset($var_5256d72a[$var_6cbe6605]) ? $var_5256d72a[$var_6cbe6605] : null;
	} 
	$var_5256d72a[$var_6cbe6605] = $var_2ddd548e;
	return null;
} 
function get_client_ip($var_7c6c92b4 = 0) {
	$var_7c6c92b4 = $var_7c6c92b4 ? 1 : 0;
	static $var_332fc2f2 = null;
	if ($var_332fc2f2 !== null) return $var_332fc2f2[$var_7c6c92b4];
	if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) {
		$var_332fc2f2 = $_SERVER['HTTP_CF_CONNECTING_IP'];
	} elseif (isset($_SERVER['HTTP_INCAP_CLIENT_IP'])) {
		$var_332fc2f2 = $_SERVER['HTTP_INCAP_CLIENT_IP'];
	} elseif (isset($_SERVER['REMOTE_ADDR'])) {
		$var_332fc2f2 = $_SERVER['REMOTE_ADDR'];
	} elseif (isset($_SERVER['HTTP_CLIENT_IP'])) {
		$var_332fc2f2 = $_SERVER['HTTP_CLIENT_IP'];
	} elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
		$var_586a20ab = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
		$var_c9568e42 = array_search('unknown', $var_586a20ab);
		if (false !== $var_c9568e42) unset($var_586a20ab[$var_c9568e42]);
		$var_332fc2f2 = trim($var_586a20ab[0]);
	} 
	$var_71b80620 = sprintf('%u', ip2long($var_332fc2f2));
	$var_332fc2f2 = $var_71b80620 ? array($var_332fc2f2, $var_71b80620) : array('0.0.0.0', 0);
	return $var_332fc2f2[$var_7c6c92b4];
} 
function url($var_1003d5bb = '', $var_b1b7cce3 = '', $var_42ffe09e = true) {
	$var_35702f41 = parse_url($var_1003d5bb);
	$var_1003d5bb = !empty($var_35702f41['path'])?$var_35702f41['path']:ACTION_NAME;
	if (is_string($var_b1b7cce3)) {
		parse_str($var_b1b7cce3, $var_b1b7cce3);
	} elseif (!is_array($var_b1b7cce3)) {
		$var_b1b7cce3 = array();
	} 
	if (isset($var_35702f41['query'])) {
		parse_str($var_35702f41['query'], $var_43b9b911);
		$var_b1b7cce3 = array_merge($var_43b9b911, $var_b1b7cce3);
	} 
	$var_2a6b2574 = config('URL_PATH_DEPR');
	if ($var_1003d5bb) {
		if ('/' != $var_2a6b2574) {
			$var_1003d5bb = str_replace('/', $var_2a6b2574, $var_1003d5bb);
		} 
		$var_1003d5bb = trim($var_1003d5bb, $var_2a6b2574);
		$var_4eda73b5 = explode($var_2a6b2574, $var_1003d5bb);
		$var = array();
		$var[config('ACTION_VAR')] = !empty($var_4eda73b5)?array_pop($var_4eda73b5):ACTION_NAME;
		$var[config('MODULE_VAR')] = !empty($var_4eda73b5)?array_pop($var_4eda73b5):MODULE_NAME;
		if (config('APP_GROUP_LIST')) {
			if (!empty($var_4eda73b5)) {
				$var_a118132d = array_pop($var_4eda73b5);
				$var[config('GROUP_VAR')] = $var_a118132d;
			} else {
				if (GROUP_NAME != config('DEFAULT_GROUP')) {
					$var[config('GROUP_VAR')] = GROUP_NAME;
				} 
			} 
		} 
	} 
	if (config('URL_MODEL') == 1) {
		$var_1003d5bb = __APP__ . '?' . http_build_query(array_reverse($var));
		if (!empty($var_b1b7cce3)) {
			$var_b1b7cce3 = urldecode(http_build_query($var_b1b7cce3));
			$var_1003d5bb .= '&' . $var_b1b7cce3;
		} 
	} else {
		if (config('URL_MODEL') == 2) {
			$var_62448e83 = __APP__ . '?';
		} else {
			$var_62448e83 = __ROOT__ . '/';
		} 
		$var_1003d5bb = $var_62448e83 . implode($var_2a6b2574, array_reverse($var));
		if (!empty($var_b1b7cce3)) {
			foreach ($var_b1b7cce3 as $var => $var_04144ce3) {
				if ('' !== trim($var_04144ce3)) {
					$var_04144ce3 = urlencode($var_04144ce3);
					$var_04144ce3 = str_replace(array('%21', '%40', '%2C'), array('!', '@', ','), $var_04144ce3);
					$var_1003d5bb .= $var_2a6b2574 . $var . $var_2a6b2574 . $var_04144ce3;
				} 
			} 
		} 
		if ($var_42ffe09e) {
			$var_42ffe09e = $var_42ffe09e === true?config('URL_PATH_SUFFIX'):$var_42ffe09e;
			if ($var_c9568e42 = strpos($var_42ffe09e, '|')) {
				$var_42ffe09e = substr($var_42ffe09e, 0, $var_c9568e42);
			} 
			if ($var_42ffe09e && '/' != substr($var_1003d5bb, - 1)) {
				$var_1003d5bb .= '.' . ltrim($var_42ffe09e, '.');
			} 
		} 
	} 
	return $var_1003d5bb;
} 
function dump($var_40db88e3, $var_2516225d = false, $var_29d86cd1 = false) {
	ob_start();
	if ($var_2516225d) {
		print_r($var_40db88e3);
	} else {
		var_dump($var_40db88e3);
	} 
	$var_970de168 = ob_get_clean();
	echo '<pre>' . $var_970de168 . '</pre>';
	if ($var_29d86cd1) exit;
	return;
} 
function txtDB($var_aca22417 = '', $var_6cbe6605 = '', $var_f6545c26 = false) {
	static $var_f54331ec = array();
	require_load(LIB_PATH . 'db/txtSQL.class.php');
	require_load(LIB_PATH . 'db/dbTxt.class.php');
	$var_20e48016 = $var_aca22417 . $var_6cbe6605;
	if (!isset($var_f54331ec[$var_20e48016])) {
		$var_f54331ec[$var_20e48016] = new dbTxt(rtrim(TEMP_PATH, '/'), 'db', $var_aca22417);
		if (APP_DEBUG or config('web_debug')) {
			$var_f54331ec[$var_20e48016] -> _STRICT = true;
		} else {
			$var_f54331ec[$var_20e48016] -> _STRICT = false;
		} 
		$var_6e2781bb = explode(',', config('DB_HASH_LIST'));
		if ($var_6e2781bb) {
			foreach($var_6e2781bb as $var_228572b3 => $var_cb83972b) {
				list($var_a6c7b72a, $var_907250fa) = explode('|', $var_cb83972b);
				if ($var_aca22417 == $var_a6c7b72a) {
					$var_f54331ec[$var_20e48016] -> setHashNum($var_907250fa);
					if ($var_6cbe6605 != '') $var_f54331ec[$var_20e48016] -> getHash($var_6cbe6605, $var_f6545c26);
				} 
			} 
		} 
	} 
	return $var_f54331ec[$var_20e48016];
} 
function DB($var_aca22417 = '', $var_5f37c40a = false) {
	static $var_f54331ec = array();
	require_load(LIB_PATH . 'db.class.php');
	$var_20e48016 = md5($var_aca22417);
	if (!isset($var_f54331ec[$var_20e48016]) || $var_5f37c40a) {
		if (APP_DEBUG or config('web_debug')) {
			$var_75300211['db_debug'] = true;
		} 
		$var_f54331ec[$var_20e48016] = new db();
		if ($var_aca22417) {
			$var_f54331ec[$var_20e48016] -> table($var_aca22417);
		} 
	} 
	return $var_f54331ec[$var_20e48016];
} 
function import($var_36a0b2a2, $var_8f3f98e5 = '.class.php') {
	static $var_2db97218 = array();
	$var_36a0b2a2 = str_replace(array('.', '#'), array('/', '.'), $var_36a0b2a2);
	$var_072395ec = APPLIB_PATH . $var_36a0b2a2 . $var_8f3f98e5;
	if (isset($var_2db97218[$var_072395ec])) return true;
	$var_2db97218[$var_36a0b2a2] = true;
	$var_817e313c = explode('/', $var_36a0b2a2);
	if (!class_exists(basename($var_36a0b2a2), false)) {
		return require_load($var_072395ec);
	} 
} 
function raction($var_1003d5bb, $var_b1b7cce3 = array()) {
	$GLOBALS['RACTION'] = true;
	$var_35702f41 = pathinfo($var_1003d5bb);
	$var_88fe0209 = $var_35702f41['basename'];
	$var_7cca9dc1 = $var_35702f41['dirname'];
	$var_36a0b2a2 = action($var_7cca9dc1);
	if ($var_36a0b2a2) {
		if (is_string($var_b1b7cce3)) {
			parse_str($var_b1b7cce3, $var_b1b7cce3);
		} 
		return call_user_func_array(array(&$var_36a0b2a2, $var_88fe0209), $var_b1b7cce3);
	} else {
		return false;
	} 
} 
function action($var_aca22417) {
	static $var_d26c5acf = array();
	$var_42ffe09e = config('DEFAULT_C_SUFFIX');
	$var_aca22417 = $var_aca22417 . ucfirst($var_42ffe09e);
	$var_3d815bdc = $var_42ffe09e . '/' . $var_aca22417;
	if (isset($var_d26c5acf[$var_3d815bdc])) return $var_d26c5acf[$var_3d815bdc];
	list($var_1e649227, $var_687e3a9b) = explode('/', $var_aca22417);
	if (config('AUTOLOAD_ENCODE')) {
		$var_b26cf4e7 = $var_42ffe09e . '/xxfseo_' . md5($var_1e649227 . 'xxfseo');
		$var_072395ec = APPLIB_PATH . $var_b26cf4e7 . '/xxfseo_' . md5($var_687e3a9b . '.class.php' . 'xxfseo') . 'Action.class.php';
		require_load($var_072395ec);
	} else {
		import($var_3d815bdc);
	} 
	$var_36a0b2a2 = basename($var_3d815bdc);
	if (class_exists($var_36a0b2a2, false)) {
		$var_88fe0209 = new $var_36a0b2a2();
		$var_d26c5acf[$var_3d815bdc] = $var_88fe0209;
		return $var_88fe0209;
	} else {
		return false;
	} 
} 
function config($var_aca22417 = null, $var_2ddd548e = null) {
	static $var_a1036c9c = array();
	if (empty($var_aca22417)) return $var_a1036c9c;
	if (is_string($var_aca22417)) {
		if (!strpos($var_aca22417, '.')) {
			$var_aca22417 = strtolower($var_aca22417);
			if (is_null($var_2ddd548e)) return isset($var_a1036c9c[$var_aca22417]) ? $var_a1036c9c[$var_aca22417] : null;
			$var_a1036c9c[$var_aca22417] = $var_2ddd548e;
			return;
		} 
		$var_aca22417 = explode('.', $var_aca22417);
		$var_aca22417[0] = strtolower($var_aca22417[0]);
		if (is_null($var_2ddd548e)) return isset($var_a1036c9c[$var_aca22417[0]][$var_aca22417[1]]) ? $var_a1036c9c[$var_aca22417[0]][$var_aca22417[1]] : null;
		$var_a1036c9c[$var_aca22417[0]][$var_aca22417[1]] = $var_2ddd548e;
		return;
	} 
	if (is_array($var_aca22417)) return $var_a1036c9c = array_merge($var_a1036c9c, array_change_key_case($var_aca22417));
	return null;
} 
function require_load($var_980a7c7e) {
	static $var_36c11a69 = array();
	if (!isset($var_36c11a69[$var_980a7c7e])) {
		debug_log('require_file_' . $var_980a7c7e);
		$var_fd4b7d98 = dirname($var_980a7c7e) . '/' . basename($var_980a7c7e);
		$var_fd4b7d98 = str_replace('\\', '/', $var_fd4b7d98);
		if (is_file($var_fd4b7d98)) {
			$var_36c11a69[$var_980a7c7e] = true;
			require $var_fd4b7d98;
		} else {
			$var_36c11a69[$var_980a7c7e] = false;
		} 
		debug_log('require_file_' . $var_980a7c7e, 'end');
	} 
	return $var_36c11a69[$var_980a7c7e];
} 
function load($var_aca22417, $var_b2ae5e6f = '', $var_8f3f98e5 = '.php') {
	$var_aca22417 = str_replace(array('.', '#'), array('/', '.'), $var_aca22417);
	if (empty($var_b2ae5e6f)) {
		$var_b2ae5e6f = FUNCTION_PATH;
	} 
	if (substr($var_b2ae5e6f, - 1) != '/') $var_b2ae5e6f .= '/';
	require_load($var_b2ae5e6f . $var_aca22417 . $var_8f3f98e5);
} 
function xml_encode($var_de5c1562, $var_62448e83 = 'txtcms', $var_c73949df = 'item', $var_7b1f341e = '', $var_10635ff1 = 'id', $var_0be95d47 = 'utf-8') {
	if (is_array($var_7b1f341e)) {
		$var_ceb47952 = array();
		foreach ($var_7b1f341e as $var_6cbe6605 => $var_2ddd548e) {
			$var_ceb47952[] = "{$var_6cbe6605}=\"{$var_2ddd548e}\"";
		} 
		$var_7b1f341e = implode(' ', $var_ceb47952);
	} 
	$var_7b1f341e = trim($var_7b1f341e);
	$var_7b1f341e = empty($var_7b1f341e) ? '' : " {$var_7b1f341e}";
	$var_ae9cdea0 = "<?xml version=\"1.0\" encoding=\"{$var_0be95d47}\"?>";
	$var_ae9cdea0 .= "<{$var_62448e83}{$var_7b1f341e}>";
	$var_ae9cdea0 .= data_to_xml($var_de5c1562, $var_c73949df, $var_10635ff1);
	$var_ae9cdea0 .= "</{$var_62448e83}>";
	return $var_ae9cdea0;
} 
function data_to_xml($var_de5c1562, $var_c73949df = 'item', $var_10635ff1 = 'id') {
	$var_ae9cdea0 = $var_7b1f341e = '';
	foreach ($var_de5c1562 as $var_6cbe6605 => $var_04144ce3) {
		if (is_numeric($var_6cbe6605)) {
			$var_10635ff1 && $var_7b1f341e = " {$var_10635ff1}=\"{$var_6cbe6605}\"";
			$var_6cbe6605 = $var_c73949df;
		} 
		$var_ae9cdea0 .= "<{$var_6cbe6605}{$var_7b1f341e}>";
		$var_ae9cdea0 .= (is_array($var_04144ce3) || is_object($var_04144ce3)) ? data_to_xml($var_04144ce3, $var_c73949df, $var_10635ff1) : $var_04144ce3;
		$var_ae9cdea0 .= "</{$var_6cbe6605}>";
	} 
	return $var_ae9cdea0;
} 
function _404($var_da035f13 = '', $var_1003d5bb = '') {
	(APP_DEBUG || config('web_debug')) && throw_exception($var_da035f13);
	if (empty($var_1003d5bb) && config('URL_404_REDIRECT')) {
		$var_1003d5bb = config('URL_404_REDIRECT');
	} 
	if ($var_1003d5bb) {
		redirect($var_1003d5bb);
	} else {
		send_http_status(404);
		exit;
	} 
} 
function send_http_status($var_dbea3baf) {
	static $var_41e88b56 = array(100 => 'Continue', 101 => 'Switching Protocols', 200 => 'OK', 201 => 'Created', 202 => 'Accepted', 203 => 'Non-Authoritative Information', 204 => 'No Content', 205 => 'Reset Content', 206 => 'Partial Content', 300 => 'Multiple Choices', 301 => 'Moved Permanently', 302 => 'Moved Temporarily ', 303 => 'See Other', 304 => 'Not Modified', 305 => 'Use Proxy', 307 => 'Temporary Redirect', 400 => 'Bad Request', 401 => 'Unauthorized', 402 => 'Payment Required', 403 => 'Forbidden', 404 => 'Not Found', 405 => 'Method Not Allowed', 406 => 'Not Acceptable', 407 => 'Proxy Authentication Required', 408 => 'Request Timeout', 409 => 'Conflict', 410 => 'Gone', 411 => 'Length Required', 412 => 'Precondition Failed', 413 => 'Request Entity Too Large', 414 => 'Request-URI Too Long', 415 => 'Unsupported Media Type', 416 => 'Requested Range Not Satisfiable', 417 => 'Expectation Failed', 500 => 'Internal Server Error', 501 => 'Not Implemented', 502 => 'Bad Gateway', 503 => 'Service Unavailable', 504 => 'Gateway Timeout', 505 => 'HTTP Version Not Supported', 509 => 'Bandwidth Limit Exceeded');
	if (isset($var_41e88b56[$var_dbea3baf])) {
		header('HTTP/1.1 ' . $var_dbea3baf . ' ' . $var_41e88b56[$var_dbea3baf]);
		header('Status:' . $var_dbea3baf . ' ' . $var_41e88b56[$var_dbea3baf]);
	} 
} 
function redirect($var_1003d5bb, $var_1bf5ad22 = 0, $var_da035f13 = '') {
	$var_1003d5bb = str_replace(array('
', '
'), '', $var_1003d5bb);
	if (empty($var_da035f13)) $var_da035f13 = "系统将在{$var_1bf5ad22}秒之后自动跳转到{$var_1003d5bb}！";
	if (!headers_sent()) {
		if (0 === $var_1bf5ad22) {
			header('Location: ' . $var_1003d5bb);
		} else {
			header("refresh:{$var_1bf5ad22};url={$var_1003d5bb}");
			echo($var_da035f13);
		} 
		exit();
	} else {
		$var_40db88e3 = "<meta http-equiv='Refresh' content='{$var_1bf5ad22};URL={$var_1003d5bb}'>";
		if ($var_1bf5ad22 != 0) $var_40db88e3 .= $var_da035f13;
		exit($var_40db88e3);
	} 
} 
function relative_path($var_4eda73b5) {
	$var_4eda73b5 = str_replace('\\', '/', $var_4eda73b5);
	return str_replace(APP_PATH, '/', $var_4eda73b5);
} 
function runTime($var_64f25176, $var_d99537c3 = '', $var_b7368ff3 = 4) {
	static $var_83300cca = array();
	static $var_c8b2d650 = array();
	if (is_float($var_d99537c3)) {
		$var_83300cca[$var_64f25176] = $var_d99537c3;
	} elseif (!empty($var_d99537c3)) {
		if (!isset($var_83300cca[$var_d99537c3])) $var_83300cca[$var_d99537c3] = microtime('TRUE');
		if (MEMORY_LIMIT_ON && $var_b7368ff3 == 'm') {
			if (!isset($var_c8b2d650[$var_d99537c3])) $var_c8b2d650[$var_d99537c3] = memory_get_usage();
			return number_format(($var_c8b2d650[$var_d99537c3] - $var_c8b2d650[$var_64f25176]) / 1024);
		} else {
			return number_format(($var_83300cca[$var_d99537c3] - $var_83300cca[$var_64f25176]), $var_b7368ff3);
		} 
	} else {
		$var_83300cca[$var_64f25176] = microtime('TRUE');
		if (MEMORY_LIMIT_ON) $var_c8b2d650[$var_64f25176] = memory_get_usage();
	} 
} 
function exception($var_8e75327e) {
	$e = array();
	if (APP_DEBUG || config('web_debug')) {
		if (!is_array($var_8e75327e)) {
			$var_644871f4 = debug_backtrace();
			$e['message'] = $var_8e75327e;
			$e['file'] = relative_path($var_644871f4[0]['file']);
			$e['line'] = $var_644871f4[0]['line'];
			ob_start();
			debug_print_backtrace();
			$e['trace'] = ob_get_clean();
		} else {
			$e = $var_8e75327e;
		} 
	} else {
		$var_64e1d919 = config('ERROR_PAGE');
		if (!empty($var_64e1d919) && ($var_64e1d919 != '/' || ($var_64e1d919 == '/' && !empty($_SERVER["QUERY_STRING"])))) {
			redirect($var_64e1d919);
		} else {
			if (config('SHOW_ERROR_MSG')) $e['message'] = is_array($var_8e75327e) ? $var_8e75327e['message'] : $var_8e75327e;
			else $e['message'] = config('ERROR_MESSAGE');
		} 
	} 
	include config('TMPL_EXCEPTION_FILE');
	exit;
} 
function throw_exception($var_da035f13, $var_7c6c92b4 = 'txtcmsException', $var_dbea3baf = 0) {
	if (class_exists($var_7c6c92b4, false)) {
		throw new $var_7c6c92b4($var_da035f13, $var_dbea3baf);
	} else {
		exception($var_da035f13);
	} 
} 
function data($var_aca22417, $var_2ddd548e = '', $var_4c819857 = array()) {
	if (isset($var_4c819857['cachetype'])) {
		$var_0902754e = $var_4c819857['cachetype'];
	} else {
		$var_0902754e = config('cache_type');
	} 
	!$var_0902754e && $var_0902754e = 'file';
	if ($var_0902754e == 'file') {
		return data_file($var_aca22417, $var_2ddd548e, $var_4c819857);
	} 
	if ($var_0902754e == 'redis') {
		return data_redis($var_aca22417, $var_2ddd548e, $var_4c819857);
	} 
} 
function data_file($var_aca22417, $var_2ddd548e = '', $var_4c819857 = array()) {
	static $var_2e98f4b6 = array();
	$var_4eda73b5 = DATA_PATH;
	$var_d5aecd65 = 0;
	if (isset($var_4c819857['expire'])) {
		$var_d5aecd65 = $var_4c819857['expire'];
	} 
	if (isset($var_4c819857['path'])) {
		$var_4eda73b5 = $var_4c819857['path'];
	} 
	$var_3d815bdc = $var_4eda73b5 . $var_aca22417 . '.php';
	$var_22b9b1a4 = md5($var_3d815bdc);
	if ('' !== $var_2ddd548e) {
		if (is_null($var_2ddd548e)) {
			return false !== strpos($var_aca22417, '*')?array_map('unlink', glob($var_3d815bdc)):unlink($var_3d815bdc);
		} else {
			$var_fae1bb2a = dirname($var_3d815bdc);
			if (!is_dir($var_fae1bb2a)) {
				mkdir($var_fae1bb2a, 502, true);
			} 
			$var_2e98f4b6[$var_22b9b1a4] = $var_2ddd548e;
			return file_put_contents($var_3d815bdc, '<?php	return ' . var_export($var_2ddd548e, true) . ';?>');
		} 
	} 
	if (isset($var_2e98f4b6[$var_22b9b1a4])) return $var_2e98f4b6[$var_22b9b1a4];
	if (is_file($var_3d815bdc)) {
		if ($var_d5aecd65 != 0) {
			if (time() < filemtime($var_3d815bdc) + $var_d5aecd65) {
				$var_2ddd548e = include $var_3d815bdc;
				$var_2e98f4b6[$var_22b9b1a4] = $var_2ddd548e;
			} else {
				$var_2ddd548e = false;
			} 
		} else {
			$var_2ddd548e = include $var_3d815bdc;
			$var_2e98f4b6[$var_22b9b1a4] = $var_2ddd548e;
		} 
	} else {
		$var_2ddd548e = null;
	} 
	return $var_2ddd548e;
} 
function data_redis($var_aca22417, $var_2ddd548e = '', $var_4c819857 = array()) {
	static $var_08d9017d = array();
	static $var_c1f322eb = '';
	$var_aca22417 .= '_' . md5($var_4c819857['path']);
	!isset($var_4c819857['type']) && $var_4c819857['type'] = 'array';
	if (empty($var_c1f322eb)) {
		$var_c1f322eb = new cache();
		$var_c1f322eb -> connect('redis', $var_4c819857);
	} 
	$var_c1f322eb -> option('path', $var_4c819857['path']);
	$var_c1f322eb -> option('expire', $var_4c819857['expire']);
	$var_c1f322eb -> option('type', $var_4c819857['type']);
	if ('' === $var_2ddd548e) {
		$var_2ddd548e = $var_c1f322eb -> get($var_aca22417);
		return $var_2ddd548e;
	} elseif (is_null($var_2ddd548e)) {
		return $var_c1f322eb -> rm($var_aca22417);
	} else {
		if (is_array($var_4c819857)) {
			$var_d5aecd65 = isset($var_4c819857['expire'])?$var_4c819857['expire']:null;
		} else {
			$var_d5aecd65 = is_numeric($var_4c819857)?$var_4c819857:null;
		} 
		return $var_c1f322eb -> set($var_aca22417, $var_2ddd548e, $var_d5aecd65);
	} 
} 
function cache($var_6cbe6605, $var_2ddd548e = '', $var_d5aecd65 = 0, $var_4eda73b5 = '') {
	$var_4eda73b5 = $var_4eda73b5 == '' ? 'temp' : $var_4eda73b5;
	$var_dde775d0 = CACHE_PATH . $var_4eda73b5 . '/' . getHashDir($var_6cbe6605, 2) . '/';
	return data($var_6cbe6605, $var_2ddd548e, $var_d5aecd65 , $var_dde775d0);
} 
function getHashDir($var_6cbe6605, $var_80db6f8c = 2) {
	$var_5e51dabc = array();
	$var_de25f840 = str_split(sha1($var_6cbe6605), 2);
	for($var_7ea74e20 = 0; $var_7ea74e20 < $var_80db6f8c; $var_7ea74e20++) {
		$var_5e51dabc[] = $var_de25f840[$var_7ea74e20];
	} 
	$var_fae1bb2a = str_replace('\\', '/', implode(DIRECTORY_SEPARATOR, $var_5e51dabc));
	return $var_fae1bb2a;
} 
function writefile($var_980a7c7e, $var_de5c1562, $var_6c1a8580 = "w") {
	$var_fae1bb2a = dirname($var_980a7c7e);
	if (!is_dir($var_fae1bb2a)) {
		mkdir($var_fae1bb2a, 511, true);
	} 
	if (is_file($var_980a7c7e) && !is_writable($var_980a7c7e)) {
		return false;
	} 
	$var_35b7c6eb = false;
	if ($var_04416560 = fopen($var_980a7c7e, $var_6c1a8580)) {
		$var_d33931b9 = microtime(true) * 1000;
		do {
			$var_c7179559 = flock($var_04416560, 2 | 4);
			if (!$var_c7179559) {
				usleep(round(rand(0, 100) * 1000));
			} 
		} while ((!$var_c7179559) && ((microtime(true) * 1000 - $var_d33931b9) < 1000));
		if ($var_c7179559) {
			$var_35b7c6eb = fwrite($var_04416560, $var_de5c1562);
			flock($var_04416560, 3);
		} 
		fclose($var_04416560);
	} 
	return $var_35b7c6eb;
} 
function debug_log($var_6cbe6605 = null, $var_bd960a5a = '') {
	static $var_39d051b9 = array();
	if ($var_6cbe6605 === null && $var_39d051b9) {
		$var_40328955 = $var_dee8cd16 = 0;
		foreach($var_39d051b9 as $var_6cbe6605 => $var_ef30f06c) {
			$var_40328955 += $var_ef30f06c['usetime'];
			$var_dee8cd16 += $var_ef30f06c['memory'];
			$var_d04070a1[$var_6cbe6605] = $var_ef30f06c['usetime'];
			$var_6e3a8577[$var_6cbe6605] = $var_ef30f06c['memory'];
		} 
		$var_39d051b9[] = array('key' => 'alluse', 'usetime' => $var_40328955, 'memory' => $var_dee8cd16, 'slow' => true,);
		return $var_39d051b9;
	} 
	if ($var_bd960a5a == '') {
		_runtime($var_6cbe6605);
		_run_mem($var_6cbe6605);
	} else {
		$var_ee4a24d7 = _runtime($var_6cbe6605, $var_bd960a5a);
		$var_ef28a461 = _run_mem($var_6cbe6605, $var_bd960a5a);
		$var_39d051b9[] = array('key' => $var_6cbe6605, 'usetime' => $var_ee4a24d7, 'memory' => $var_ef28a461, 'slow' => ($var_ee4a24d7 > 0.05),);
		return 'usetime: ' . $var_ee4a24d7 . 's , memory: ' . $var_ef28a461 . 'kb';
	} 
} 
function get_tags_runtime() {
	$var_a51596c0 = array('loop', 'getone', 'menu', 'geturl', 'function');
	$var_586a20ab = array();
	foreach($var_a51596c0 as $var_228572b3 => $var_cb83972b) {
		$var_586a20ab[$var_cb83972b] = isset($GLOBALS['tag_' . $var_cb83972b . '_runtime'])?$GLOBALS['tag_' . $var_cb83972b . '_runtime']:0;
	} 
	return $var_586a20ab;
} 
function show_debug_page() {
	include('./static/tips/page_debug.html');
} 
