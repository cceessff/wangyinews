<?php define('INI_TXTCMS', true);
defined('TXTCMS_PATH') or define('TXTCMS_PATH', str_replace('\\', '/', dirname(__FILE__)) . '/');
defined('APP_PATH') or define('APP_PATH', str_replace('\\', '/', dirname($_SERVER['SCRIPT_FILENAME']) . '/'));
define('_START_TIME', microtime());
error_reporting(30719 &~8);
require TXTCMS_PATH . 'common/run.php';
