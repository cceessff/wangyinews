<?php class Http {
	public $var_2f5d64f2 = '';
	public $var_b454fa6a = 'GET';
	public $var_f17e1d76 = 'http';
	public $var_5d15c3f4 = '';
	public $var_9161fd67 = '80';
	public $var_4efdac71 = '/';
	public $var_1d15a55d = '';
	public $var_20215fca = '';
	public $var_998dd949 = '';
	public $var_99e72d10 = array();
	public $var_b18b800c = '';
	public $var_a311a2c2 = '';
	public $var_be718343 = array();
	public $var_fcda760e = '';
	public $var_cbafa007 = 20;
	public $var_27e74181 = false;
	public $var_3d8185dd = '';
	public $var_a7eeed3b = '';
	public $var_9e6fd747 = '';
	public $var_55153761 = '';
	public $var_01376bee = '';
	public $var_c86d4f59 = false;
	public function init() {
		if ($this -> func_ff1f28a7 == '') {
			return ;
		} 
		$var_9c56b70f = @parse_url($this -> func_ff1f28a7);
		if (is_array($var_9c56b70f)) {
			$this -> func_756652d9 = $var_9c56b70f["host"];
			if (!empty($var_9c56b70f["scheme"])) {
				$this -> func_86b673ef = $var_9c56b70f["scheme"];
			} 
			if (!empty($var_9c56b70f["user"])) {
				$this -> func_b344bed7 = $var_9c56b70f["user"];
			} 
			if (!empty($var_9c56b70f["pass"])) {
				$this -> func_a81efe05 = $var_9c56b70f["pass"];
			} 
			if (!empty($var_9c56b70f["port"])) {
				$this -> func_9fb29970 = $var_9c56b70f["port"];
			} 
			if (!empty($var_9c56b70f["path"])) {
				$this -> func_23a20c61 = $var_9c56b70f["path"];
			} 
			if (!empty($var_9c56b70f["query"])) {
				$this -> func_b05cb578 = $var_9c56b70f["query"];
				$this -> func_23a20c61 .= '?' . $this -> func_b05cb578;
			} 
			$this -> func_7db8ba75 = $this -> func_756652d9 . $var_9c56b70f["path"];
			$this -> func_7db8ba75 = preg_replace('/\\/([^\\/]*)\\.(.*)$/', '/', $this -> func_7db8ba75);
			$this -> func_7db8ba75 = preg_replace('/\\/$/', "", $this -> func_7db8ba75);
		} 
	} 
	public function reset() {
		$this -> func_23a20c61 = "";
		$this -> func_86b673ef = 'http';
		$this -> func_756652d9 = "";
		$this -> func_9fb29970 = '80';
		$this -> func_23a20c61 = '/';
		$this -> func_b05cb578 = "";
		$this -> func_d15a48c8 = "";
		$this -> func_1a559174 = '';
		$this -> func_0b3f8dae = array();
	} 
	public function func_d80f7f6b() {
		$this -> reset();
		$this -> init();
		$this -> func_de63247e();
		$var_41156c32 = $this -> func_ad778b91 ? 'getHtmlFor' . ucfirst($this -> func_ad778b91):'';
		if (!method_exists($this, $var_41156c32)) {
			if (function_exists('curl_init') && function_exists('curl_exec')) {
				$this -> func_ad778b91 = 'curl';
				$this -> func_789fffef();
			} else if (function_exists('fsockopen') or function_exists('pfsockopen') or function_exists('stream_socket_client')) {
				$this -> func_ad778b91 = 'sock';
				$this -> func_e143fd45();
			} else if (ini_get('allow_url_fopen')) {
				$this -> func_ad778b91 = 'file';
				$this -> func_b174d616();
			} else {
				$this -> func_d15a48c8 = 'No correlation function is enabled';
				return false;
			} 
		} else {
			$this -> $var_41156c32();
		} 
	} 
	public function func_5d0a4796($var_6cbe6605, $var_2ddd548e) {
		$this -> func_dec40491[$var_6cbe6605] = $var_2ddd548e;
	} 
	public function func_1419e5d9($var_6cbe6605 = '') {
		if ($var_6cbe6605 == '') return $this -> func_0b3f8dae;
		$var_6cbe6605 = strtolower($var_6cbe6605);
		return isset($this -> func_0b3f8dae[$var_6cbe6605]) ? $this -> func_0b3f8dae[$var_6cbe6605] : '';
	} 
	public function func_de63247e() {
		$this -> func_dec40491["Host"] = $this -> func_756652d9;
		if (is_array($this -> func_27d15989)) {
			$this -> func_27d15989 = http_build_query($this -> func_27d15989);
		} 
		if (!isset($this -> func_dec40491["Accept"])) {
			$this -> func_dec40491["Accept"] = '*/*';
		} 
		if (!isset($this -> func_dec40491["User-Agent"])) {
			$this -> func_dec40491["User-Agent"] = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36';
		} 
		if (!isset($this -> func_dec40491["Referer"])) {
			$this -> func_dec40491["Referer"] = 'http://' . $this -> func_dec40491["Host"];
		} 
		if (!empty($this -> func_b344bed7)) {
			$this -> func_dec40491["Authorization"] = 'Basic ' . base64_encode($this -> func_b344bed7 . ':' . $this -> func_a81efe05);
		} 
		if ($this -> func_358358fd && !empty($this -> func_d2277eb7)) {
			$this -> func_dec40491["Proxy-Authorization"] = 'Basic ' . base64_encode($this -> func_d2277eb7 . ':' . $this -> func_3737314f);
		} 
		$this -> func_3e049f93 = array();
		foreach($this -> func_dec40491 as $var_228572b3 => $var_cb83972b) {
			$var_228572b3 = trim($var_228572b3);
			$var_cb83972b = trim($var_cb83972b);
			$this -> func_3e049f93[] = ucwords($var_228572b3) . ": {$var_cb83972b}";
		} 
	} 
	public function func_e143fd45() {
		$var_229f34da = "";
		$var_96d534c9 = "";
		$var_7c6c92b4 = 'tcp://';
		if ($this -> func_86b673ef == 'https') {
			$var_7c6c92b4 = 'ssl://';
			$this -> func_9fb29970 = '443';
		} 
		$var_39ae76d3 = $this -> func_756652d9;
		$var_228be5f8 = $this -> func_9fb29970;
		if ($this -> func_358358fd) {
			$this -> func_23a20c61 = $this -> func_86b673ef . '://' . $this -> func_756652d9 . ':' . $this -> func_9fb29970 . $this -> func_23a20c61;
			$var_39ae76d3 = $this -> func_3feeb7da;
			$var_228be5f8 = $this -> func_2fa80686;
		} 
		if (function_exists('fsockopen')) {
			$this -> func_9534aa82 = fsockopen($var_7c6c92b4 . $var_39ae76d3, $var_228be5f8, $var_229f34da, $var_96d534c9, $this -> func_7fef4f3b);
		} else if (function_exists('pfsockopen')) {
			$this -> func_9534aa82 = pfsockopen($var_7c6c92b4 . $var_39ae76d3, $var_228be5f8, $var_229f34da, $var_96d534c9, $this -> func_7fef4f3b);
		} else if (function_exists('stream_socket_client')) {
			$this -> func_9534aa82 = stream_socket_client($var_7c6c92b4 . $var_39ae76d3 . ':' . $var_228be5f8, $var_229f34da, $var_96d534c9, $this -> func_7fef4f3b);
		} else {
			$this -> func_d15a48c8 = 'Failed to enable fsockopen and stream_socket_client';
			return false;
		} 
		if (!$this -> func_9534aa82) {
			$this -> func_d15a48c8 = $var_96d534c9;
			return false;
		} 
		if (function_exists('socket_set_timeout')) {
			socket_set_timeout($this -> func_9534aa82, $this -> func_7fef4f3b);
		} elseif (function_exists('stream_set_timeout')) {
			stream_set_timeout($this -> func_9534aa82, $this -> func_7fef4f3b);
		} 
		$var_77704151 = $this -> func_a2b0a95b . ' ' . $this -> func_23a20c61 . ' HTTP/1.0
';
		if ($this -> func_a2b0a95b == 'POST') {
			if (!isset($this -> func_dec40491["Content-type"])) $var_77704151 .= 'Content-type: application/x-www-form-urlencoded
';
			$var_77704151 .= 'Content-length: ' . strlen($this -> func_27d15989) . '
';
		} 
		$var_77704151 .= implode('
', $this -> func_3e049f93) . '
';
		$var_77704151 .= 'Connection: Close

';
		if ($this -> func_a2b0a95b == 'POST') $var_77704151 .= $this -> func_27d15989 . '

';
		fputs($this -> func_9534aa82, $var_77704151);
		$var_de5c1562 = '';
		while (!feof($this -> func_9534aa82)) {
			$var_de5c1562 .= fgets($this -> func_9534aa82, 256);
			if ($this -> func_7514b98a && strpos($var_de5c1562, '
') > - 1) {
				break;
			} 
		} 
		if (is_resource($this -> func_9534aa82)) fclose($this -> func_9534aa82);
		list($var_0c0e92d3, $this -> func_1a559174) = preg_split('~
~', $var_de5c1562, 2);
		$this -> func_1a559174 = @$this -> func_525d44f4(trim($this -> func_525d44f4($this -> func_1a559174)));
		$var_586a20ab = explode('
', $var_0c0e92d3);
		$this -> func_83f08a46($var_586a20ab);
	} 
	public function func_789fffef() {
		if (!function_exists('curl_init') || !function_exists('curl_exec')) {
			$this -> func_d15a48c8 = 'Failed to enable curl';
			return false;
		} 
		$var_297ad4f1 = curl_init();
		curl_setopt($var_297ad4f1, CURLOPT_URL, $this -> func_ff1f28a7);
		if (!ini_get('safe_mode') && !ini_get('open_basedir')) {
			curl_setopt($var_297ad4f1, CURLOPT_FOLLOWLOCATION, 1);
		} 
		curl_setopt($var_297ad4f1, CURLOPT_AUTOREFERER, 1);
		curl_setopt($var_297ad4f1, CURLOPT_HEADER, 1);
		curl_setopt($var_297ad4f1, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($var_297ad4f1, CURLOPT_HTTPHEADER, $this -> func_3e049f93);
		curl_setopt($var_297ad4f1, CURLOPT_NOBODY, $this -> func_7514b98a);
		curl_setopt($var_297ad4f1, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($var_297ad4f1, CURLOPT_SSL_VERIFYHOST, false);
		$var_691ec736 = curl_version();
		if (substr($var_691ec736['ssl_version'], 0, 3) != 'NSS') {
			curl_setopt($var_297ad4f1, CURLOPT_SSL_CIPHER_LIST, 'TLSv1');
		} 
		if ($this -> func_a2b0a95b == 'POST') {
			curl_setopt($var_297ad4f1, CURLOPT_POST, true);
			curl_setopt($var_297ad4f1, CURLOPT_POSTFIELDS, $this -> func_27d15989);
		} 
		if ($this -> func_358358fd) {
			curl_setopt($var_297ad4f1, CURLOPT_PROXY, $this -> func_3feeb7da);
			curl_setopt($var_297ad4f1, CURLOPT_PROXYPORT, $this -> func_2fa80686);
			if ($this -> func_d2277eb7) {
				curl_setopt($var_297ad4f1, CURLOPT_PROXYUSERPWD, $this -> func_d2277eb7 . ':' . $this -> func_3737314f);
			} 
		} 
		curl_setopt($var_297ad4f1, CURLOPT_TIMEOUT, $this -> func_7fef4f3b);
		$this -> func_1a559174 = curl_exec($var_297ad4f1);
		$var_35702f41 = curl_getinfo($var_297ad4f1);
		$var_8e75327e = curl_error($var_297ad4f1);
		curl_close($var_297ad4f1);
		if ($var_8e75327e) {
			$this -> func_d15a48c8 = $var_8e75327e;
		} 
		if (empty($this -> func_1a559174)) {
			$var_586a20ab = array('HTTP/1.x ' . $var_35702f41['http_code']);
		} else {
			$var_0c0e92d3 = substr($this -> func_1a559174, 0, $var_35702f41['header_size']);
			$this -> func_1a559174 = @$this -> func_525d44f4(substr($this -> func_1a559174, - $var_35702f41['size_download']));
			$var_586a20ab = explode('
', $var_0c0e92d3);
		} 
		$this -> func_83f08a46($var_586a20ab);
	} 
	public function func_b174d616() {
		if (!ini_get('allow_url_fopen')) {
			$this -> func_d15a48c8 = 'Failed to enable allow_url_fopen';
			return false;
		} 
		if (!function_exists('stream_context_create')) {
			$this -> func_d15a48c8 = 'Failed to enable stream_context_create';
			return false;
		} 
		$var_5b367116 = array('http' => array('method' => $this -> func_a2b0a95b, 'timeout' => $this -> func_7fef4f3b, 'header' => implode('
', $this -> func_3e049f93)));
		if ($this -> func_a2b0a95b == 'POST') {
			$var_5b367116['http'] = array_merge($var_5b367116['http'], array('content' => $this -> func_27d15989,));
		} 
		if ($this -> func_358358fd) {
			$var_5b367116['http'] = array_merge($var_5b367116['http'], array('request_fulluri' => true, 'proxy' => 'tcp://' . $this -> func_3feeb7da . ':' . $this -> func_2fa80686,));
		} 
		if ($this -> func_7514b98a) {
			stream_context_get_default($var_5b367116);
			@get_headers($this -> func_ff1f28a7);
		} else {
			$var_7a307bbc = stream_context_create($var_5b367116);
			$this -> func_1a559174 = @$this -> func_525d44f4(@file_get_contents($this -> func_ff1f28a7, false, $var_7a307bbc));
		} 
		$this -> func_83f08a46($http_response_header);
	} 
	private function func_83f08a46($var_3a8670b1) {
		foreach($var_3a8670b1 as $var_228572b3 => $var_cb83972b) {
			if ($var_cb83972b == '') continue;
			if ($var_228572b3 == 0) {
				$this -> func_0b3f8dae['http-code'] = substr($var_cb83972b, 9, 3);
				continue;
			} 
			@list($var_03beda56, $var_5f841fb5) = @explode(': ', $var_cb83972b);
			$var_03beda56 = strtolower(trim($var_03beda56));
			$var_5f841fb5 = trim($var_5f841fb5);
			if ($var_03beda56 == 'set-cookie') {
				$var_5f841fb5 = substr($var_5f841fb5, 0, (strpos($var_5f841fb5, ';')));
				$var_b83001de = substr($var_5f841fb5, 0, strpos($var_5f841fb5, '='));
				$var_01d3ebef = substr($var_5f841fb5, strpos($var_5f841fb5, '=') + 1);
				$this -> func_0b3f8dae['set-cookie'][$var_b83001de] = $var_01d3ebef;
				$this -> func_0b3f8dae['set-cookie2'][$var_b83001de] = $var_01d3ebef;
			} else if (isset($this -> func_0b3f8dae[$var_03beda56])) {
				if (!is_array($this -> func_0b3f8dae[$var_03beda56])) $this -> func_0b3f8dae[$var_03beda56] = array($this -> func_0b3f8dae[$var_03beda56]);
				$var_5f841fb5 = is_array($var_5f841fb5) ? $var_5f841fb5 : array($var_5f841fb5);
				$this -> func_0b3f8dae[$var_03beda56] = array_merge($this -> func_0b3f8dae[$var_03beda56], $var_5f841fb5);
				$this -> func_0b3f8dae[$var_03beda56] = array_unique($this -> func_0b3f8dae[$var_03beda56]);
				if (count($this -> func_0b3f8dae[$var_03beda56]) == 1) $this -> func_0b3f8dae[$var_03beda56] = $this -> func_0b3f8dae[$var_03beda56][0];
			} else {
				$this -> func_0b3f8dae[$var_03beda56] = $var_5f841fb5;
			} 
		} 
		if (isset($this -> func_0b3f8dae['set-cookie']) && is_array($this -> func_0b3f8dae['set-cookie'])) {
			$var_77c75311 = '';
			foreach($this -> func_0b3f8dae['set-cookie'] as $var_228572b3 => $var_cb83972b) {
				$var_77c75311 .= $var_228572b3 . '=' . $var_cb83972b . '; ';
			} 
			$this -> func_0b3f8dae['set-cookie'] = substr(trim($var_77c75311), 0, - 1);
		} 
		if ($this -> func_d15a48c8) {
			$this -> func_0b3f8dae['_error'] = $this -> func_d15a48c8;
		} 
	} 
	public function func_9228f088() {
		return $this -> func_0b3f8dae['http-code'];
	} 
	public function func_525d44f4($var_de5c1562) {
		if (function_exists('gzdecode')) {
			$var_003f508c = gzdecode($var_de5c1562);
		} else {
			$var_453e4d64 = ord(substr($var_de5c1562, 3, 1));
			$var_3f02655b = 10;
			$var_ae9e7fbb = 0;
			$var_2793c19a = 0;
			if ($var_453e4d64 &4) {
				$var_ae9e7fbb = unpack('v' , substr($var_de5c1562, 10, 2));
				$var_ae9e7fbb = $var_ae9e7fbb[1];
				$var_3f02655b += 2 + $var_ae9e7fbb;
			} 
			if ($var_453e4d64 &8) $var_3f02655b = @strpos($var_de5c1562, chr(0), $var_3f02655b) + 1;
			if ($var_453e4d64 &16) $var_3f02655b = @strpos($var_de5c1562, chr(0), $var_3f02655b) + 1;
			if ($var_453e4d64 &2) $var_3f02655b += 2;
			$var_003f508c = @gzinflate(substr($var_de5c1562, $var_3f02655b));
		} 
		if (!$var_003f508c) $var_003f508c = $var_de5c1562;
		return $var_003f508c;
	} 
} 
