<?php class Robot {
	function __construct($var_37e4f1f4 = array()) {
		$this -> func_8653f0fe = $var_37e4f1f4 ? $var_37e4f1f4 : config('ROBOT_LIST');
		$this -> func_b330726e = get_client_ip();
		$this -> func_5a1e87b5 = func_dfe3da17();
		$this -> func_4a5c79b1 = $_SERVER ["HTTP_USER_AGENT"];
		$this -> func_902f7cb2 = $this -> get();
		$this -> func_8deba27e = date('Ymd');
		$this -> func_8ac6c4df = date('H');
		$this -> func_67c8756f = './temp/robotlog/count.log';
	} 
	public function get() {
		foreach($this -> func_8653f0fe as $var_228572b3 => $var_d8bba397) {
			if (stripos(strtolower($this -> func_4a5c79b1), strtolower($var_228572b3)) > -1) {
				if ($var_228572b3 == 'HaoSouSpider') {
					$var_228572b3 = '360Spider';
				} 
				return $var_228572b3;
			} 
		} 
		if ($this -> func_0a3c77ef()) return 'other';
		return false;
	} 
	public function func_0a3c77ef() {
		static $var_44eec0d9 = null;
		static $var_3a1568a4 = array('bot', 'crawl', 'spider' , 'slurp', 'sohu-search', 'lycos', 'robozilla');
		static $var_83a7bf44 = array('msie', 'netscape', 'opera', 'konqueror', 'mozilla');
		if (null == $var_44eec0d9) {
			$var_44eec0d9 = false;
			if (preg_match('#bot|spider|crawl|nutch|lycos|robozilla|slurp|search|seek|archive|scrapy|ltx71.com#i', $this -> func_4a5c79b1)) $var_44eec0d9 = true;
		} 
		return $var_44eec0d9;
	} 
	public function ban($var_370ebc88) {
		$var_280ac314 = explode(',', $var_370ebc88);
		if ($this -> func_902f7cb2 && in_array($this -> func_902f7cb2, $var_280ac314)) {
			header('HTTP/1.1 403 Forbidden');
			exit;
		} 
	} 
	public function func_068accd6() {
		$var_b5ae185e = './temp/robotlog/lock.log';
		if (!is_file($var_b5ae185e)) {
			$this -> write($var_b5ae185e, '0');
		} 
		$var_cce32cf7 = array();
		if ($this -> func_0a3c77ef() && $var_dac00219 = fopen($var_b5ae185e, 'r+')) {
			$var_d33931b9 = microtime(true) * 1000;
			do {
				$var_c7d5af57 = flock($var_dac00219, 2 | 4);
				if (!$var_c7d5af57) {
					usleep(round(rand(0, 100) * 1000));
				} 
			} while (!$var_c7d5af57 && (microtime(true) * 1000 - $var_d33931b9) < 1000);
			if (!$var_c7d5af57) {
				return false;
			} 
			$var_de5c1562 = implode('	', array(date('Y-m-d H:i:s'), $this -> func_b330726e, $this -> func_902f7cb2, $this -> func_5a1e87b5, config('web_theme'))) . '
';
			if ($this -> func_902f7cb2 == 'Baiduspider-render') {
				$this -> func_902f7cb2 = 'Baiduspider';
			} 
			$this -> write("./temp/robotlog/all/{$this->func_8deba27e}.log", $var_de5c1562, 'a+');
			$var_1e649227 = in_array($this -> func_902f7cb2, config('ROBOT_MUST_KEYS'))?$this -> func_902f7cb2:'other';
			$this -> write("./temp/robotlog/{$var_1e649227}/{$this->func_8deba27e}.log", $var_de5c1562, 'a+');
			$this -> write("./temp/robotlog/{$var_1e649227}/{$this->func_8deba27e}_count.log", 1, 'a+');
			$this -> write("./temp/robotlog/hour/{$this->func_8deba27e}/{$this->func_8ac6c4df}.log", 1, 'a+');
			flock($var_dac00219, 3);
			fclose($var_dac00219);
		} 
	} 
	public function write($var_980a7c7e, $var_de5c1562, $var_6c1a8580 = "w") {
		$var_fae1bb2a = dirname($var_980a7c7e);
		if (!is_dir($var_fae1bb2a)) {
			mkdir($var_fae1bb2a, 511, true);
		} 
		if (is_file($var_980a7c7e) && !is_writable($var_980a7c7e) && (filemtime($var_980a7c7e) + 20 > time())) {
			return false;
		} 
		$var_35b7c6eb = false;
		if ($var_04416560 = fopen($var_980a7c7e, $var_6c1a8580)) {
			$var_d33931b9 = microtime(true) * 1000;
			do {
				$var_c7179559 = flock($var_04416560, 2 | 4);
				if (!$var_c7179559) {
					usleep(round(rand(0, 100) * 1000));
				} 
			} while (!$var_c7179559 && ((microtime(true) * 1000 - $var_d33931b9) < 1000));
			if ($var_c7179559) {
				$var_35b7c6eb = fwrite($var_04416560, $var_de5c1562);
				flock($var_04416560, 3);
			} 
			fclose($var_04416560);
		} 
		return $var_35b7c6eb;
	} 
	public function recount() {
		session_write_close();
		@set_time_limit(3600);
		@unlink($this -> func_67c8756f);
		$var_fae1bb2a = './temp/robotlog/all/';
		$var_586a20ab = glob($var_fae1bb2a . '20*.log');
		$var_7eba6ab8 = array();
		sort($var_586a20ab);
		foreach($var_586a20ab as $var_228572b3 => $var_cb83972b) {
			if (!preg_match('~/20\\d{6}\\.log$~', $var_cb83972b)) {
				continue;
			} 
			$var_2f42d152 = preg_replace('~[^\\d]+~i', '', basename($var_cb83972b));
			if (is_file($var_cb83972b)) {
				$var_04416560 = fopen($var_cb83972b, 'r');
				$var_7ea74e20 = 0;
				while (!feof($var_04416560)) {
					$var_de5c1562 = fread($var_04416560, 1024 * 20);
					if (!$var_de5c1562) break;
					while (substr($var_de5c1562, - 1) != '
' && !feof($var_04416560)) {
						$var_de5c1562 .= fread($var_04416560, 1);
					} 
					$var_45c18414 = explode('
', $var_de5c1562);
					foreach($var_45c18414 as $var_3d9151c4 => $var_1076c777) {
						list($var_1bf5ad22, $var_332fc2f2, $var_4ea4cc94, $var_1003d5bb) = explode('	', trim($var_1076c777));
						if (!$var_4ea4cc94) {
							continue;
						} 
						if ($var_4ea4cc94 == 'Baiduspider-render') {
							$var_4ea4cc94 = 'Baiduspider';
						} 
						$var_1e649227 = in_array($var_4ea4cc94, config('ROBOT_MUST_KEYS'))?$var_4ea4cc94:'other';
						@$var_7eba6ab8[$var_2f42d152][$var_1e649227] += 1;
					} 
				} 
				fclose($var_04416560);
			} 
		} 
		foreach($var_7eba6ab8 as $var_228572b3 => $var_cb83972b) {
			foreach($var_cb83972b as $var_3d9151c4 => $var_1076c777) {
				$this -> write("./temp/robotlog/{$var_3d9151c4}/{$var_228572b3}_recount.log", $var_1076c777);
			} 
		} 
		return true;
	} 
} 
