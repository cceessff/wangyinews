<?php class Image {
	public $var_06c4adbe = 9;
	public $var_18e28e23 = 80;
	public function getImageInfo($var_41956ce8) {
		$var_f1e111dd = getimagesize($var_41956ce8);
		if ($var_f1e111dd !== false) {
			$var_edc28ca7 = strtolower(substr(image_type_to_extension($var_f1e111dd[2]), 1));
			$var_b12cde4a = filesize($var_41956ce8);
			$var_35702f41 = array("width" => $var_f1e111dd[0], "height" => $var_f1e111dd[1], "type" => $var_edc28ca7, "size" => $var_b12cde4a, "mime" => $var_f1e111dd['mime']);
			return $var_35702f41;
		} else {
			return false;
		} 
	} 
	public function func_7657a398($var_59f3caff, $var_2f600c36, $var_70115b15 = null) {
		if (!file_exists($var_59f3caff) || !file_exists($var_2f600c36)) return false;
		$var_6c2c4ed2 = self :: getImageInfo($var_59f3caff);
		$var_71c80abe = self :: getImageInfo($var_2f600c36);
		$this -> func_cf2c34f1 = $var_6c2c4ed2['width'];
		$this -> func_7b38d5e6 = $var_6c2c4ed2['height'];
		$this -> func_4c813971 = $var_71c80abe['width'];
		$this -> func_20f92829 = $var_71c80abe['height'];
		if ($var_6c2c4ed2["width"] < $var_71c80abe["width"] || $var_6c2c4ed2['height'] < $var_71c80abe['height']) return false;
		$var_7b53f7e5 = 'imagecreatefrom' . $var_6c2c4ed2['type'];
		$var_942e7210 = $var_7b53f7e5($var_59f3caff);
		$var_fc0c7ec7 = 'imagecreatefrom' . $var_71c80abe['type'];
		$var_6328a24f = $var_fc0c7ec7($var_2f600c36);
		list($var_eb063a75, $var_551d3502) = self :: func_ad0c6590($this -> func_23991785);
		if ($var_71c80abe['type'] == 'png') {
			imagecopy($var_942e7210, $var_6328a24f, $var_eb063a75, $var_551d3502, 0, 0, $var_71c80abe['width'], $var_71c80abe['height']);
		} else {
			imagealphablending($var_6328a24f, true);
			imagecopymerge($var_942e7210, $var_6328a24f, $var_eb063a75, $var_551d3502, 0, 0, $var_71c80abe['width'], $var_71c80abe['height'], $this -> func_f515401d);
		} 
		$var_ebcbd265 = 'Image' . $var_6c2c4ed2['type'];
		if (!$var_70115b15) {
			$var_70115b15 = $var_59f3caff;
			@unlink($var_59f3caff);
		} 
		$var_ebcbd265($var_942e7210, $var_70115b15);
		imagedestroy($var_942e7210);
	} 
	private function func_ad0c6590($var_7c6c92b4 = 0) {
		if (!$var_7c6c92b4) $var_7c6c92b4 = rand(1, 9);
		switch ($var_7c6c92b4) {
			case 1: $var_695c0912 = 5;
				$var_84d643d3 = 5;
				break;
			case 2: $var_695c0912 = ($this -> func_cf2c34f1 - $this -> func_4c813971) / 2;
				$var_84d643d3 = 5;
				break;
			case 3: $var_695c0912 = $this -> func_cf2c34f1 - $this -> func_4c813971 - 5;
				$var_84d643d3 = 5;
				break;
			case 4: $var_695c0912 = 5;
				$var_84d643d3 = ($this -> func_7b38d5e6 - $this -> func_20f92829) / 2;
				break;
			case 5: $var_695c0912 = ($this -> func_cf2c34f1 - $this -> func_4c813971) / 2;
				$var_84d643d3 = ($this -> func_7b38d5e6 - $this -> func_20f92829) / 2;
				break;
			case 6: $var_695c0912 = $this -> func_cf2c34f1 - $this -> func_4c813971 - 5;
				$var_84d643d3 = ($this -> func_7b38d5e6 - $this -> func_20f92829) / 2;
				break;
			case 7: $var_695c0912 = 5;
				$var_84d643d3 = $this -> func_7b38d5e6 - $this -> func_20f92829 - 5;
				break;
			case 8: $var_695c0912 = ($this -> func_cf2c34f1 - $this -> func_4c813971) / 2;
				$var_84d643d3 = $this -> func_7b38d5e6 - $this -> func_20f92829 - 5;
				break;
			case 9: $var_695c0912 = $this -> func_cf2c34f1 - $this -> func_4c813971 - 5;
				$var_84d643d3 = $this -> func_7b38d5e6 - $this -> func_20f92829 - 5;
				break;
		} 
		return array($var_695c0912, $var_84d643d3);
	} 
	static function func_97f6c476($var_e01be967, $var_2f619d23, $var_adb796a7 = 200, $var_df50723c = '', $var_82d707c7 = true) {
		$var_35702f41 = Image :: getImageInfo($var_e01be967);
		if ($var_35702f41 !== false) {
			$var_05937f87 = $var_35702f41['width'];
			$var_eafafe16 = $var_35702f41['height'];
			$var_7c6c92b4 = strtolower($var_35702f41['type']);
			$var_82d707c7 = $var_82d707c7 ? 1 : 0;
			unset($var_35702f41);
			$var_95002caf = $var_df50723c ? $var_df50723c / $var_eafafe16 : 99999;
			$var_69950bc2 = min($var_adb796a7 / $var_05937f87, $var_95002caf);
			if ($var_69950bc2 >= 1) {
				return false;
				$var_7d9fc077 = $var_05937f87;
				$var_c5a3f7bb = $var_eafafe16;
			} else {
				$var_7d9fc077 = (int) ($var_05937f87 * $var_69950bc2);
				$var_c5a3f7bb = (int) ($var_eafafe16 * $var_69950bc2);
			} 
			$var_ebcdbcc7 = 'imagecreatefrom' . ($var_7c6c92b4 == 'jpg' ? 'jpeg' : $var_7c6c92b4);
			$var_1f028d07 = $var_ebcdbcc7($var_e01be967);
			if ($var_7c6c92b4 != 'gif' && function_exists('imagecreatetruecolor')) {
				$var_7cb2cb84 = imagecreatetruecolor($var_7d9fc077, $var_c5a3f7bb);
			} else {
				$var_7cb2cb84 = imagecreate($var_7d9fc077, $var_c5a3f7bb);
			} 
			if ('gif' == $var_7c6c92b4 || 'png' == $var_7c6c92b4) {
				$var_d02e6dbf = imagecolortransparent($var_1f028d07);
				if ($var_d02e6dbf >= 0) {
					$var_2a3eee20 = imagecolorsforindex($var_1f028d07, $var_d02e6dbf);
					$var_d02e6dbf = imagecolorallocate($var_7cb2cb84, $var_2a3eee20['red'], $var_2a3eee20['green'], $var_2a3eee20['blue']);
					imagefill($var_7cb2cb84, 0, 0, $var_d02e6dbf);
					imagecolortransparent($var_7cb2cb84, $var_d02e6dbf);
				} elseif ('png' == $var_7c6c92b4) {
					imagealphablending($var_7cb2cb84, false);
					$var_82483e23 = imagecolorallocatealpha($var_7cb2cb84, 0, 0, 0, 127);
					imagefill($var_7cb2cb84, 0, 0, $var_82483e23);
					imagesavealpha($var_7cb2cb84, true);
				} 
			} 
			if (function_exists('imagecopyresampled')) {
				imagecopyresampled($var_7cb2cb84, $var_1f028d07, 0, 0, 0, 0, $var_7d9fc077, $var_c5a3f7bb, $var_05937f87, $var_eafafe16);
			} else {
				imagecopyresized($var_7cb2cb84, $var_1f028d07, 0, 0, 0, 0, $var_7d9fc077, $var_c5a3f7bb, $var_05937f87, $var_eafafe16);
			} 
			if ('jpg' == $var_7c6c92b4 || 'jpeg' == $var_7c6c92b4) imageinterlace($var_7cb2cb84, $var_82d707c7);
			$var_92fd4972 = 'image' . ($var_7c6c92b4 == 'jpg' ? 'jpeg' : $var_7c6c92b4);
			if ('imagejpeg' == $var_92fd4972) {
				$var_92fd4972($var_7cb2cb84, $var_2f619d23, 100);
			} else {
				$var_92fd4972($var_7cb2cb84, $var_2f619d23);
			} 
			imagedestroy($var_7cb2cb84);
			imagedestroy($var_1f028d07);
			return $var_2f619d23;
		} 
		return false;
	} 
	public function func_471916f5($var_59f3caff, $var_2c53ffcc, $var_e280c56b = '', $var_a95f78d1 = '' , $var_23883804 = '', $var_02853e08 = '', $var_82d707c7 = true) {
		$var_35702f41 = Image :: getImageInfo($var_59f3caff);
		if ($var_35702f41 !== false) {
			$var_05937f87 = $var_35702f41['width'];
			$var_eafafe16 = $var_35702f41['height'];
			$var_7c6c92b4 = strtolower($var_35702f41['type']);
			$var_ebcdbcc7 = 'imagecreatefrom' . ($var_7c6c92b4 == 'jpg' ? 'jpeg' : $var_7c6c92b4);
			$var_1743fa58 = $var_ebcdbcc7($var_59f3caff);
			$var_937523f0 = imagecreatetruecolor($var_e280c56b, $var_a95f78d1);
			if (function_exists('imagecopyresampled')) {
				imagecopyresampled($var_937523f0, $var_1743fa58, 0, 0, $var_23883804, $var_02853e08, $var_e280c56b, $var_a95f78d1, $var_e280c56b, $var_a95f78d1);
			} else {
				imagecopyresized($var_937523f0, $var_1743fa58, 0, 0, $var_23883804, $var_02853e08, $var_e280c56b, $var_a95f78d1, $var_e280c56b, $var_a95f78d1);
			} 
			if ('jpg' == $var_7c6c92b4 || 'jpeg' == $var_7c6c92b4) imageinterlace($var_937523f0, $var_82d707c7);
			$var_92fd4972 = 'image' . ($var_7c6c92b4 == 'jpg' ? 'jpeg' : $var_7c6c92b4);
			$var_92fd4972($var_937523f0, $var_2c53ffcc);
			imagedestroy($var_937523f0);
			imagedestroy($var_1743fa58);
			return $var_2c53ffcc;
		} 
		return false;
	} 
	static function func_2311e802($var_bca829df, $var_4656cf7b = array(), $var_3d815bdc = '', $var_7c6c92b4 = 'png', $var_e2521109 = 1, $var_6afa4c94 = true) {
		if (is_string($var_f6a0d07b)) $var_f6a0d07b = explode(',', $var_f6a0d07b);
		$var_7d9fc077 = $var_f6a0d07b[0];
		$var_c5a3f7bb = $var_f6a0d07b[1];
		if (is_string($var_c8b60ae0)) $var_c8b60ae0 = explode(',', $var_c8b60ae0);
		$var_d1399d5f = $var_c8b60ae0[0];
		$var_dfdaa6c7 = $var_c8b60ae0[1];
		$var_dbe5a81c = strlen($var_bca829df);
		$var_7d9fc077 = ($var_dbe5a81c * 9 + 10) > $var_7d9fc077 ? $var_dbe5a81c * 9 + 10 : $var_7d9fc077;
		$var_c5a3f7bb = 22;
		if ($var_7c6c92b4 != 'gif' && function_exists('imagecreatetruecolor')) {
			$var_ee8d7c4a = @imagecreatetruecolor($var_7d9fc077, $var_c5a3f7bb);
		} else {
			$var_ee8d7c4a = @imagecreate($var_7d9fc077, $var_c5a3f7bb);
		} 
		if (empty($var_4656cf7b)) {
			$var_82483e23 = imagecolorallocate($var_ee8d7c4a, 102, 104, 104);
		} else {
			$var_82483e23 = imagecolorallocate($var_ee8d7c4a, $var_4656cf7b[0], $var_4656cf7b[1], $var_4656cf7b[2]);
		} 
		$var_8d8e8aa8 = imagecolorallocate($var_ee8d7c4a, 255, 255, 255);
		$var_c9896e6f = imagecolorallocate($var_ee8d7c4a, 100, 100, 100);
		$var_e963916f = imagecolorallocate($var_ee8d7c4a, mt_rand(0, 255), mt_rand(0, 255), mt_rand(0, 255));
		@imagefilledrectangle($var_ee8d7c4a, 0, 0, $var_7d9fc077 - 1, $var_c5a3f7bb - 1, $var_8d8e8aa8);
		@imagerectangle($var_ee8d7c4a, 0, 0, $var_7d9fc077 - 1, $var_c5a3f7bb - 1, $var_c9896e6f);
		@imagestring($var_ee8d7c4a, 5, 5, 3, $var_bca829df, $var_82483e23);
		if (!empty($var_e2521109)) {
			if ($var_e2521109 = 1 || $var_e2521109 = 3) {
				for ($var_7ea74e20 = 0; $var_7ea74e20 < 25; $var_7ea74e20++) {
					imagesetpixel($var_ee8d7c4a, mt_rand(0, $var_7d9fc077), mt_rand(0, $var_c5a3f7bb), $var_e963916f);
				} 
			} elseif ($var_e2521109 = 2 || $var_e2521109 = 3) {
				for ($var_7ea74e20 = 0; $var_7ea74e20 < 10; $var_7ea74e20++) {
					imagearc($var_ee8d7c4a, mt_rand(- 10, $var_7d9fc077), mt_rand(- 10, $var_c5a3f7bb), mt_rand(30, 300), mt_rand(20, 200), 55, 44, $var_e963916f);
				} 
			} 
		} 
		Image :: func_9bca0fe7($var_ee8d7c4a, $var_7c6c92b4, $var_3d815bdc);
	} 
	static function func_5601f597($var_dbe5a81c = 4, $var_cebcf803 = 1, $var_7c6c92b4 = 'png', $var_7d9fc077 = 48, $var_c5a3f7bb = 22, $var_82483e23 = '#2850b9', $var_dc792bd8 = 'verifycode') {
		import('@.ORG.String');
		$var_247080d8 = $var_cebcf803 == 4 ? 'zh.ttf' : 'en.ttf';
		$var_9c1ab248 = STATIC_PATH . 'fonts/vcode/' . $var_247080d8;
		$var_475c86b7 = strtoupper(String :: randString($var_dbe5a81c, $var_cebcf803));
		$_SESSION[$var_dc792bd8] = md5(strtolower($var_475c86b7));
		$var_7d9fc077 = ($var_dbe5a81c * 10 + 10) > $var_7d9fc077 ? $var_dbe5a81c * 10 + 10 : $var_7d9fc077;
		$var_82483e23 = hex2rgb($var_82483e23);
		if ($var_7c6c92b4 != 'gif' && function_exists('imagecreatetruecolor')) {
			$var_ee8d7c4a = imagecreatetruecolor($var_7d9fc077, $var_c5a3f7bb);
		} else {
			$var_ee8d7c4a = imagecreate($var_7d9fc077, $var_c5a3f7bb);
		} 
		$var_8d8e8aa8 = imagecolorallocate($var_ee8d7c4a, 255, 255, 255);
		imagefilledrectangle($var_ee8d7c4a, 0, 0, $var_7d9fc077 - 1, $var_c5a3f7bb - 1, $var_8d8e8aa8);
		$var_3a731084 = imagecolorallocate($var_ee8d7c4a, $var_82483e23['r'], $var_82483e23['g'], $var_82483e23['b']);
		$var_6f6be565 = $var_c5a3f7bb - 5;
		$var_0eee1953 = mt_rand(1, ($var_6f6be565 / 4));
		for($var_7ea74e20 = 0;$var_7ea74e20 < ($var_7d9fc077 - 10);$var_7ea74e20 += 0.1) {
			$var_84d643d3 = ($var_6f6be565 / 2) + ($var_0eee1953 * sin($var_7ea74e20 / ($var_6f6be565 / 5)));
			$var_ca52a8de = $var_7ea74e20 + 5;
			imagesetpixel($var_ee8d7c4a, $var_ca52a8de, $var_84d643d3, $var_3a731084);
			imagesetpixel($var_ee8d7c4a, $var_ca52a8de, $var_84d643d3 + 1, $var_3a731084);
		} 
		$var_33200efd = $var_3a731084;
		for ($var_7ea74e20 = 0; $var_7ea74e20 < $var_dbe5a81c; $var_7ea74e20++) {
			$var_40db88e3 = String :: msubstr($var_475c86b7, $var_7ea74e20, 1, 'utf-8', '');
			$var_695c0912 = $var_7ea74e20 == 0 ? 10 : ($var_7d9fc077 / $var_dbe5a81c) * $var_7ea74e20 + 10;
			if ($var_695c0912 > ($var_7d9fc077 - 10)) $var_695c0912 = ($var_7d9fc077 - 10);
			$var_84d643d3 = round($var_c5a3f7bb * 30 / 40);
			imagettftext($var_ee8d7c4a, ($var_c5a3f7bb / 2), mt_rand(- 20, 40), $var_695c0912, $var_84d643d3, $var_33200efd, $var_9c1ab248, $var_40db88e3);
		} 
		Image :: func_9bca0fe7($var_ee8d7c4a, $var_7c6c92b4);
	} 
	static function func_a959c37c($var_dbe5a81c = 4, $var_7c6c92b4 = 'png', $var_7d9fc077 = 180, $var_c5a3f7bb = 50, $var_d1399d5f = 'simhei.ttf', $var_dc792bd8 = 'verify') {
		import('ORG.Util.String');
		$var_dbea3baf = String :: randString($var_dbe5a81c, 4);
		$var_7d9fc077 = ($var_dbe5a81c * 45) > $var_7d9fc077 ? $var_dbe5a81c * 45 : $var_7d9fc077;
		$_SESSION[$var_dc792bd8] = md5($var_dbea3baf);
		$var_ee8d7c4a = imagecreatetruecolor($var_7d9fc077, $var_c5a3f7bb);
		$var_c9896e6f = imagecolorallocate($var_ee8d7c4a, 100, 100, 100);
		$var_e52653b3 = imagecolorallocate($var_ee8d7c4a, 250, 250, 250);
		imagefill($var_ee8d7c4a, 0, 0, $var_e52653b3);
		@imagerectangle($var_ee8d7c4a, 0, 0, $var_7d9fc077 - 1, $var_c5a3f7bb - 1, $var_c9896e6f);
		for ($var_7ea74e20 = 0; $var_7ea74e20 < 15; $var_7ea74e20++) {
			$var_3360097b = imagecolorallocate($var_ee8d7c4a, mt_rand(0, 255), mt_rand(0, 255), mt_rand(0, 255));
			imagearc($var_ee8d7c4a, mt_rand(- 10, $var_7d9fc077), mt_rand(- 10, $var_c5a3f7bb), mt_rand(30, 300), mt_rand(20, 200), 55, 44, $var_3360097b);
		} 
		for ($var_7ea74e20 = 0; $var_7ea74e20 < 255; $var_7ea74e20++) {
			$var_3360097b = imagecolorallocate($var_ee8d7c4a, mt_rand(0, 255), mt_rand(0, 255), mt_rand(0, 255));
			imagesetpixel($var_ee8d7c4a, mt_rand(0, $var_7d9fc077), mt_rand(0, $var_c5a3f7bb), $var_3360097b);
		} 
		if (!is_file($var_d1399d5f)) {
			$var_d1399d5f = dirname(__FILE__) . '/' . $var_d1399d5f;
		} 
		for ($var_7ea74e20 = 0; $var_7ea74e20 < $var_dbe5a81c; $var_7ea74e20++) {
			$var_3360097b = imagecolorallocate($var_ee8d7c4a, mt_rand(0, 120), mt_rand(0, 120), mt_rand(0, 120));
			$var_82d004b1 = String :: msubstr($var_dbea3baf, $var_7ea74e20, 1);
			imagettftext($var_ee8d7c4a, mt_rand(16, 20), mt_rand(- 60, 60), 40 * $var_7ea74e20 + 20, mt_rand(30, 35), $var_3360097b, $var_d1399d5f, $var_82d004b1);
		} 
		Image :: func_9bca0fe7($var_ee8d7c4a, $var_7c6c92b4);
	} 
	static function func_53caf456($var_e01be967, $var_bca829df = '', $var_7c6c92b4 = '') {
		$var_35702f41 = Image :: getImageInfo($var_e01be967);
		if ($var_35702f41 !== false) {
			$var_7c6c92b4 = empty($var_7c6c92b4) ? $var_35702f41['type'] : $var_7c6c92b4;
			unset($var_35702f41);
			$var_ebcdbcc7 = 'ImageCreateFrom' . ($var_7c6c92b4 == 'jpg' ? 'jpeg' : $var_7c6c92b4);
			$var_ee8d7c4a = $var_ebcdbcc7($var_e01be967);
			$var_a7c03955 = imagesx($var_ee8d7c4a);
			$var_3a52c234 = imagesy($var_ee8d7c4a);
			$var_7ea74e20 = 0;
			$var_77704151 = '<span style="padding:0px;margin:0;line-height:100%;font-size:1px;">';
			set_time_limit(0);
			for ($var_84d643d3 = 0; $var_84d643d3 < $var_3a52c234; $var_84d643d3++) {
				for ($var_695c0912 = 0; $var_695c0912 < $var_a7c03955; $var_695c0912++) {
					$var_af03d95f = imagecolorat($var_ee8d7c4a, $var_695c0912, $var_84d643d3);
					$var_4656cf7b = imagecolorsforindex($var_ee8d7c4a, $var_af03d95f);
					$var_40db88e3 = empty($var_bca829df) ? '*' : $var_bca829df[$var_7ea74e20++];
					$var_77704151 .= sprintf('<span style="margin:0px;color:#%02x%02x%02x">' . $var_40db88e3 . '</span>', $var_4656cf7b['red'], $var_4656cf7b['green'], $var_4656cf7b['blue']);
				} 
				$var_77704151 .= '<br>
';
			} 
			$var_77704151 .= '</span>';
			imagedestroy($var_ee8d7c4a);
			return $var_77704151;
		} 
		return false;
	} 
	static function func_97457ba2($var_dbea3baf, $var_7c6c92b4 = 'png', $var_87ab3f7f = 2, $var_cb17b69e = 100) {
		static $var_254914cc = array('0001101', '0011001', '0010011', '0111101', '0100011', '0110001', '0101111', '0111011', '0110111', '0001011');
		static $var_a6daa62b = array('1110010', '1100110', '1101100', '1000010', '1011100', '1001110', '1010000', '1000100', '1001000', '1110100');
		$var_6190eadb = '101';
		$var_4fe0c37d = '01010';
		if (strlen($var_dbea3baf) != 11) {
			die('UPC-A Must be 11 digits.');
		} 
		$var_07ec6b2d = '0' . $var_dbea3baf;
		$var_7ade498c = 0;
		$var_4149735d = 0;
		for ($var_695c0912 = 0; $var_695c0912 < 12; $var_695c0912++) {
			if ($var_695c0912 % 2) {
				$var_4149735d += $var_07ec6b2d[$var_695c0912];
			} else {
				$var_7ade498c += $var_07ec6b2d[$var_695c0912];
			} 
		} 
		$var_dbea3baf .= (10 - (($var_4149735d * 3 + $var_7ade498c) % 10)) % 10;
		$var_5809fdc3 = $var_6190eadb;
		$var_5809fdc3 .= $var_254914cc[$var_dbea3baf[0]];
		for ($var_695c0912 = 1; $var_695c0912 < 6; $var_695c0912++) {
			$var_5809fdc3 .= $var_254914cc[$var_dbea3baf[$var_695c0912]];
		} 
		$var_5809fdc3 .= $var_4fe0c37d;
		for ($var_695c0912 = 6; $var_695c0912 < 12; $var_695c0912++) {
			$var_5809fdc3 .= $var_a6daa62b[$var_dbea3baf[$var_695c0912]];
		} 
		$var_5809fdc3 .= $var_6190eadb;
		if ($var_7c6c92b4 != 'gif' && function_exists('imagecreatetruecolor')) {
			$var_ee8d7c4a = imagecreatetruecolor($var_87ab3f7f * 95 + 30, $var_cb17b69e + 30);
		} else {
			$var_ee8d7c4a = imagecreate($var_87ab3f7f * 95 + 30, $var_cb17b69e + 30);
		} 
		$var_e358b7b8 = ImageColorAllocate($var_ee8d7c4a, 0, 0, 0);
		$var_b51f6a91 = ImageColorAllocate($var_ee8d7c4a, 255, 255, 255);
		ImageFilledRectangle($var_ee8d7c4a, 0, 0, $var_87ab3f7f * 95 + 30, $var_cb17b69e + 30, $var_b51f6a91);
		$var_69047dbc = 10;
		for ($var_695c0912 = 0; $var_695c0912 < strlen($var_5809fdc3); $var_695c0912++) {
			if (($var_695c0912 < 10) || ($var_695c0912 >= 45 && $var_695c0912 < 50) || ($var_695c0912 >= 85)) {
				$var_bdaf0d9d = 10;
			} else {
				$var_bdaf0d9d = 0;
			} 
			if ($var_5809fdc3[$var_695c0912] == '1') {
				$var_82483e23 = $var_e358b7b8;
			} else {
				$var_82483e23 = $var_b51f6a91;
			} 
			ImageFilledRectangle($var_ee8d7c4a, ($var_695c0912 * $var_87ab3f7f) + 15, 5, ($var_695c0912 + 1) * $var_87ab3f7f + 14, $var_cb17b69e + 5 + $var_bdaf0d9d, $var_82483e23);
		} 
		ImageString($var_ee8d7c4a, 4, 5, $var_cb17b69e - 5, $var_dbea3baf[0], $var_e358b7b8);
		for ($var_695c0912 = 0; $var_695c0912 < 5; $var_695c0912++) {
			ImageString($var_ee8d7c4a, 5, $var_87ab3f7f * (13 + $var_695c0912 * 6) + 15, $var_cb17b69e + 5, $var_dbea3baf[$var_695c0912 + 1], $var_e358b7b8);
			ImageString($var_ee8d7c4a, 5, $var_87ab3f7f * (53 + $var_695c0912 * 6) + 15, $var_cb17b69e + 5, $var_dbea3baf[$var_695c0912 + 6], $var_e358b7b8);
		} 
		ImageString($var_ee8d7c4a, 4, $var_87ab3f7f * 95 + 17, $var_cb17b69e - 5, $var_dbea3baf[11], $var_e358b7b8);
		Image :: func_9bca0fe7($var_ee8d7c4a, $var_7c6c92b4);
	} 
	static function func_9bca0fe7($var_ee8d7c4a, $var_7c6c92b4 = 'png', $var_3d815bdc = '') {
		header("Content-type: image/" . $var_7c6c92b4);
		$var_ebcbd265 = 'image' . $var_7c6c92b4;
		if (empty($var_3d815bdc)) {
			$var_ebcbd265($var_ee8d7c4a);
		} else {
			$var_ebcbd265($var_ee8d7c4a, $var_3d815bdc);
		} 
		imagedestroy($var_ee8d7c4a);
	} 
} 
