<?php function tag_function_getone($var_583d62cb) {
	$var_43b9b911 = $var_583d62cb[0];
	if (empty($var_43b9b911)) {
		return false;
	} 
	if (!isset($var_43b9b911['name'])) {
		echo '未指定文件类型';
		return;
	} 
	$var_a3e5f0ff = $var_43b9b911['cacheid'];
	if ($var_a3e5f0ff == 'rand' || !$var_a3e5f0ff) {
		$var_a3e5f0ff = func_3985a6b0(rand(100, 999), 1);
	} else if ($var_a3e5f0ff) {
		$var_a3e5f0ff = func_dfe3da17() . $var_a3e5f0ff;
	} 
	if (!isset($GLOBALS['tag_getone'])) {
		$GLOBALS['tag_getone'] = 1000;
	} 
	$GLOBALS['tag_getone']--;
	if ($var_43b9b911['isloop'] || ($var_43b9b911['global'] && !preg_match('~^http~', $var_a3e5f0ff))) {
		$var_a3e5f0ff .= $GLOBALS['tag_getone'];
	} 
	$var_a3e5f0ff = func_b0d73e82($var_a3e5f0ff);
	$var_136fc366 = md5(serialize($var_43b9b911) . $var_a3e5f0ff);
	$var_1c019175 = func_50afa725($var_43b9b911['name'], $var_a3e5f0ff);
	if (config('tobig5')) {
		import('class/Trans');
		$var_fa6bf187 = new Trans;
		list($var_f9df6cf6,) = explode('/', $var_43b9b911['name']);
		list($var_f9df6cf6,) = explode(':', $var_f9df6cf6);
		if (array_key_exists($var_f9df6cf6, config('txtdir'))) {
			$var_1c019175 = $var_fa6bf187 -> c2t($var_1c019175);
		} 
	} 
	return $var_1c019175;
} 

?>