<?php function tag_function_typename($var_583d62cb) {
	$var_43b9b911 = $var_583d62cb[0];
	if (empty($var_43b9b911)) {
		return false;
	} 
	if (!isset($var_43b9b911['type'])) {
		echo '未指定类型';
		return;
	} 
	$var_d089e8c2 = $var_43b9b911['title']?$var_43b9b911['title']:$var_43b9b911['name'];
	$var_3d815bdc = $var_d089e8c2 ? (strpos($var_d089e8c2, ':')?$var_d089e8c2:'typename:' . $var_d089e8c2) :'typename';
	!$var_43b9b911['tpl'] && $var_43b9b911['tpl'] = 'list';
	switch ($var_43b9b911['type']) {
		case 'name': $var_136fc366 = md5(serialize($var_43b9b911));
			_runtime($var_136fc366);
			$var_1c019175 = func_f90fd28a($var_3d815bdc);
			if ($GLOBALS['DEBUG']) {
				echo 'USETTIME_typename:' . $var_3d815bdc . '----' . _runtime($var_136fc366, 'end');
			} 
			if (config('tobig5')) {
				import('class/Trans');
				$var_fa6bf187 = new Trans;
				$var_1c019175 = $var_fa6bf187 -> c2t($var_1c019175);
			} 
			return $var_1c019175;
			break;
		case 'url': return get_url($var_43b9b911['tpl'], $var_43b9b911['fan']);
			break;
	} 
} 

?>