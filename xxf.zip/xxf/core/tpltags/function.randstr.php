<?php function tag_function_randstr($var_583d62cb) {
	$var_43b9b911 = $var_583d62cb[0];
	if (empty($var_43b9b911)) {
		return false;
	} 
	if (strpos($var_43b9b911['num'], ',') > - 1) {
		list($var_eef8baa2, $var_ad64fd3a) = explode(',', $var_43b9b911['num']);
		$var_43b9b911['num'] = rand($var_eef8baa2, $var_ad64fd3a);
	} 
	return func_3985a6b0($var_43b9b911['num'], $var_43b9b911['type']);
} 

?>