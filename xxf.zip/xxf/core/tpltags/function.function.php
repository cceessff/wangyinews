<?php function tag_function_function($var_583d62cb) {
	$var_43b9b911 = $var_583d62cb[0];
	if (empty($var_43b9b911)) {
		return false;
	} 
	$var_1c019175 = '';
	$var_583d62cb = explode(',', $var_43b9b911['args']);
	if (!isset($GLOBALS['tag_function_runtime'])) {
		$GLOBALS['tag_function_runtime'] = 0;
	} 
	$var_5c3b14d4 = array('get_host', 'get_rand_prefix', 'get_url', 'randstr', 'get_rand_link', 'get_num_gd', 'get_product_num', 'get_product_licence', 'get_company_about', 'get_str_gd');
	$var_136fc366 = md5(serialize($var_43b9b911));
	$var_1c019175 = call_user_func_array($var_43b9b911['name'], $var_583d62cb);
	return $var_1c019175;
} 

?>