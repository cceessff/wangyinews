<?php function tag_block_menu($var_583d62cb) {
	$var_43b9b911 = $var_583d62cb[0];
	if (empty($var_43b9b911)) {
		return false;
	} 
	!$var_43b9b911['row'] && $var_43b9b911['row'] = 10;
	!$var_43b9b911['tpl'] && $var_43b9b911['tpl'] = 'list';
	!$var_43b9b911['title'] && $var_43b9b911['title'] = 'typename';
	$var_a3e5f0ff = md5($_SERVER['HTTP_HOST'] . $var_43b9b911['tpl'] . $var_43b9b911['tpl'] . config('domain.typefile') . config('domain.urltype') . config('domain.cid'));
	if ($var_43b9b911['cacheid']) {
		$var_a3e5f0ff .= $var_43b9b911['cacheid'];
	} 
	$var_98693aab = $var_43b9b911['cachetime']?$var_43b9b911['cachetime']:999999999999;
	if (!config('domain.menu_cache')) {
		$var_98693aab = 0;
	} 
	if ($var_98693aab) {
		$var_f5abc85c = CACHE_PATH . 'tags/menu/' . getHashDir(get_host(), 2) . '/' . get_host() . '/' . $var_a3e5f0ff . '.txt';
		if (is_file($var_f5abc85c) && ($var_98693aab * 3600 + filemtime($var_f5abc85c)) >= time()) {
			$var_de5c1562 = unserialize(file_get_contents($var_f5abc85c));
			$var_de5c1562 = array_slice($var_de5c1562, 0, $var_43b9b911['row']);
			return $var_de5c1562;
		} 
	} 
	$var_a26ce86e = config('domain.typefile');
	if ($var_a26ce86e != '' && is_file('.' . $var_a26ce86e)) {
		$GLOBALS['type_cidfile'] = ltrim($var_a26ce86e, '.');
		$GLOBALS['type_cidfile'] = ltrim($GLOBALS['type_cidfile'], '/');
	} 
	if ($var_43b9b911['name']) {
		$var_938ce18d = DATA_PATH . $var_43b9b911['title'] . '/' . $GLOBALS['arctype_dirname'] . '/' . $var_43b9b911['name'] . '.txt';
		if (is_file($var_938ce18d)) $GLOBALS['type_cidfile'] = $var_938ce18d;
	} 
	$var_47bd04a7 = $var_43b9b911['row'] > 20?$var_43b9b911['row']:20;
	for($var_7ea74e20 = 0;$var_7ea74e20 < $var_47bd04a7;$var_7ea74e20++) {
		$var_1003d5bb = get_url($var_43b9b911['tpl'], $var_43b9b911['fan']);
		list($var_a4319a30, $var_9f94e05a) = $GLOBALS['urlid_cache'][$var_1003d5bb];
		if ($var_9f94e05a && config('domain.urltype') == 2) {
			$var_d089e8c2 = func_bc498d0f($var_43b9b911['tpl'], $var_43b9b911['title'], $var_a4319a30, $var_9f94e05a, $GLOBALS['geturl_this_fullurl']);
		} else {
			$var_d089e8c2 = func_157faedc($var_43b9b911['tpl'], $var_43b9b911['title'], $var_a4319a30, $GLOBALS['geturl_this_fullurl']);
		} 
		if ($var_43b9b911['tpl'] == 'product_show') $var_d089e8c2 .= get_product_num($var_1003d5bb);
		$var_a3e5f0ff = preg_replace('~^https?://www\\.~', 'http://', $var_1003d5bb);
		$var_a3e5f0ff = preg_replace('~^https?://' . config('domain.mobile_prefix') . '\\.~', 'http://', $var_a3e5f0ff);
		$var_a3e5f0ff = func_b0d73e82($var_a3e5f0ff);
		if (config('tobig5')) {
			import('class/Trans');
			$var_fa6bf187 = new Trans;
			$var_d089e8c2 = $var_fa6bf187 -> c2t($var_d089e8c2);
		} 
		$var_de5c1562[] = array('url' => $var_1003d5bb, 'typeurl' => $var_1003d5bb, 'title' => $var_d089e8c2, 'typename' => $var_d089e8c2, 'cacheid' => $var_a3e5f0ff, 'i' => ($var_7ea74e20 + 1),);
	} 
	$GLOBALS['type_cidfile'] = null;
	if ($var_98693aab) {
		write($var_f5abc85c, serialize($var_de5c1562));
	} 
	$var_de5c1562 = array_slice($var_de5c1562, 0, $var_43b9b911['row']);
	return $var_de5c1562;
} 

?>