<?php function tag_function_geturl($var_583d62cb) {
	$var_43b9b911 = $var_583d62cb[0];
	if (empty($var_43b9b911)) {
		return false;
	} 
	if (!isset($var_43b9b911['tpl'])) {
		echo '未指定模板';
		return;
	} 
	!$var_43b9b911['tpl'] && $var_43b9b911['tpl'] = 'list';
	return get_url($var_43b9b911['tpl'], $var_43b9b911['fan']);
} 

?>