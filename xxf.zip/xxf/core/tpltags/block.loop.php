<?php function tag_block_loop($var_583d62cb) {
	$var_43b9b911 = $var_583d62cb[0];
	if (empty($var_43b9b911)) {
		return false;
	} 
	$var_6af3ba37 = $var_43b9b911['type'] . rand(111, 999);
	debug_log('loop_' . $var_6af3ba37);
	if ($var_43b9b911['type'] == 'link') {
		$var_43b9b911['row'] = $var_43b9b911['row']?$var_43b9b911['row']:config('links_default_num');
	} else if ($var_43b9b911['type'] == 'domain') {
		$var_43b9b911['row'] = $var_43b9b911['row']?$var_43b9b911['row']:config('domain_default_num');
	} 
	!$var_43b9b911['row'] && $var_43b9b911['row'] = 10;
	if (stripos($var_43b9b911['row'], ',') > - 1) {
		list($var_55df87ba, $var_7c3e9a74) = explode(',', $var_43b9b911['row']);
		$var_43b9b911['row'] = rand($var_55df87ba, $var_7c3e9a74);
	} 
	$var_a3e5f0ff = $var_43b9b911['cacheid'];
	if ($var_43b9b911['type'] == 'link' && !config('links_open')) {
		return false;
	} 
	if (config('domain_mod') == 2) {
		$var_43b9b911['fan'] = '';
	} 
	if (!$var_a3e5f0ff) {
		if (!isset($GLOBALS['tag_' . $var_43b9b911['type']])) {
			$GLOBALS['tag_' . $var_43b9b911['type']] = 1;
		} 
		$GLOBALS['tag_' . $var_43b9b911['type']]++;
		$var_a3e5f0ff = md5(func_dfe3da17() . $var_43b9b911['row'] . $GLOBALS['tag_' . $var_43b9b911['type']]);
	} 
	if (!$GLOBALS['callnum_tag_' . $var_43b9b911['type']]) {
		$GLOBALS['callnum_tag_' . $var_43b9b911['type']] = 0;
	} 
	$GLOBALS['callnum_tag_' . $var_43b9b911['type']]++;
	$var_98693aab = $var_43b9b911['cachetime']?$var_43b9b911['cachetime']:config('cache_lifetime_' . $var_43b9b911['type']);
	if ($var_98693aab) {
		$var_f5abc85c = CACHE_PATH . 'tags/loop_' . $var_43b9b911['type'] . '/' . get_host() . '/' . getHashDir($var_a3e5f0ff, 2) . '/' . $var_a3e5f0ff . '.txt';
		if (is_file($var_f5abc85c) && ($var_98693aab * 3600 + filemtime($var_f5abc85c)) >= time()) {
			$var_de5c1562 = unserialize(file_get_contents($var_f5abc85c));
			$var_de5c1562 = array_slice($var_de5c1562, 0, $var_43b9b911['row']);
			return $var_de5c1562;
		} 
	} 
	switch ($var_43b9b911['type']) {
		case 'arclist': $var_de5c1562 = array();
			!$var_43b9b911['tpl'] && $var_43b9b911['tpl'] = 'show';
			!$var_43b9b911['title'] && $var_43b9b911['title'] = 'title';
			$var_78af1c09 = array();
			for($var_7ea74e20 = 0;$var_7ea74e20 < $var_43b9b911['row'];$var_7ea74e20++) {
				$var_78af1c09[$var_7ea74e20] = time() - rand(0, 9999);
			} 
			sort($var_78af1c09);
			rsort($var_78af1c09);
			if ($var_43b9b911['tpl'] == 'product_show') {
				$var_43b9b911['title'] = 'typename';
			} 
			!$GLOBALS['callnew_title_num'] && $GLOBALS['callnew_title_num'] = 0;
			for($var_7ea74e20 = 0;$var_7ea74e20 < $var_43b9b911['row'];$var_7ea74e20++) {
				$GLOBALS['callnew_title'] = false;
				if ($GLOBALS['callnum_tag_' . $var_43b9b911['type']] > 1 && $GLOBALS['callnew_title_num'] < 20 && $GLOBALS['callnum_tag_' . $var_43b9b911['type']] % 2 == 0 && $var_7ea74e20 % 2 == 0) {
					$GLOBALS['callnew_title'] = true;
					$GLOBALS['callnew_title_num']++;
				} 
				if ($var_43b9b911['title'] == 'title' && config('domain.bodytype') == 1) {
					$var_43b9b911['title'] = 'article';
					$var_7a44f1af = config('domain.titlefile');
				} 
				if (config('domain.articlefile')) $var_7a44f1af = config('domain.articlefile');
				if ($var_7a44f1af != '' && is_file('.' . $var_7a44f1af)) {
					$GLOBALS[$var_43b9b911['title'] . '_cidfile'] = '.' . $var_7a44f1af;
					$GLOBALS['callnew_title'] = false;
				} 
				$var_1003d5bb = get_url($var_43b9b911['tpl'], $var_43b9b911['fan']);
				$var_a3e5f0ff = preg_replace('~^https?://www\\.~', 'http://', $GLOBALS['geturl_this_fullurl']);
				$var_a3e5f0ff = func_b0d73e82($var_a3e5f0ff);
				list($var_a4319a30, $var_9f94e05a) = $GLOBALS['urlid_cache'][$var_1003d5bb];
				if (config('domain.urltype') == 2) {
					$var_d089e8c2 = func_bc498d0f($var_43b9b911['tpl'], $var_43b9b911['title'], $var_a4319a30, $var_9f94e05a, $GLOBALS['geturl_this_fullurl']);
				} else {
					$var_d089e8c2 = func_157faedc($var_43b9b911['tpl'], $var_43b9b911['title'], $var_a4319a30, $GLOBALS['geturl_this_fullurl']);
				} 
				$var_dbf47a74 = '';
				if ($var_43b9b911['title'] == 'article' && config('domain.bodytype') == 1) {
					list($var_d089e8c2, $var_dbf47a74) = explode('******', $var_d089e8c2);
				} 
				if ($var_43b9b911['tpl'] == 'product_show') $var_d089e8c2 .= get_product_num($var_1003d5bb);
				list($var_d089e8c2,) = explode('******', $var_d089e8c2);
				if (config('insert_titleascii')) {
					$var_d089e8c2 = func_09a64523($var_d089e8c2);
				} 
				$var_35702f41 = $var_43b9b911['info'] ? msubstr(func_f90fd28a('content'), 0, 100):'';
				if (config('tobig5')) {
					import('class/Trans');
					$var_fa6bf187 = new Trans;
					$var_d089e8c2 = $var_fa6bf187 -> c2t($var_d089e8c2);
					$var_35702f41 && $var_35702f41 = $var_fa6bf187 -> c2t($var_35702f41);
				} 
				if ($var_43b9b911['image'] && !$var_dbf47a74) {
					$var_dbf47a74 = func_9b765bfa($var_a3e5f0ff);
				} 
				$var_d089e8c2 = str_replace('"', '', $var_d089e8c2);
				$var_de5c1562[] = array('url' => $var_1003d5bb, 'title' => $var_d089e8c2, 'info' => $var_35702f41, 'pic' => $var_dbf47a74, 'hits' => rand(50, 3000), 'postdate' => date('Y-m-d H:i', $var_78af1c09[$var_7ea74e20]), 'cacheid' => $var_a3e5f0ff, 'i' => ($var_7ea74e20 + 1),);
			} 
			break;
		case 'typename': !$var_43b9b911['tpl'] && $var_43b9b911['tpl'] = 'list';
			!$var_43b9b911['title'] && $var_43b9b911['title'] = 'typename';
			if ($var_43b9b911['name']) {
				$var_938ce18d = DATA_PATH . $var_43b9b911['title'] . '/' . $GLOBALS['arctype_dirname'] . '/' . $var_43b9b911['name'] . '.txt';
				if (is_file($var_938ce18d)) $GLOBALS['type_cidfile'] = $var_938ce18d;
			} 
			for($var_7ea74e20 = 0;$var_7ea74e20 < $var_43b9b911['row'];$var_7ea74e20++) {
				$var_1003d5bb = get_url($var_43b9b911['tpl'], $var_43b9b911['fan']);
				list($var_a4319a30, $var_9f94e05a) = $GLOBALS['urlid_cache'][$var_1003d5bb];
				if ($var_9f94e05a && config('domain.urltype') == 2) {
					$var_d089e8c2 = func_bc498d0f($var_43b9b911['tpl'], $var_43b9b911['title'], $var_a4319a30, $var_9f94e05a, $GLOBALS['geturl_this_fullurl']);
				} else {
					$var_d089e8c2 = func_157faedc($var_43b9b911['tpl'], $var_43b9b911['title'], $var_a4319a30, $GLOBALS['geturl_this_fullurl']);
				} 
				if ($var_43b9b911['tpl'] == 'product_show') $var_d089e8c2 .= get_product_num($var_1003d5bb);
				$var_a3e5f0ff = preg_replace('~^https?://www\\.~', 'http://', $var_1003d5bb);
				$var_a3e5f0ff = func_b0d73e82($var_a3e5f0ff);
				if (config('tobig5')) {
					import('class/Trans');
					$var_fa6bf187 = new Trans;
					$var_d089e8c2 = $var_fa6bf187 -> c2t($var_d089e8c2);
				} 
				$var_d089e8c2 = str_replace('"', '', $var_d089e8c2);
				$var_de5c1562[] = array('url' => $var_1003d5bb, 'typeurl' => $var_1003d5bb, 'title' => $var_d089e8c2, 'typename' => $var_d089e8c2, 'cacheid' => $var_a3e5f0ff, 'i' => ($var_7ea74e20 + 1),);
			} 
			break;
		case 'link': if (!config('links_open')) {
				return false;
			} 
			$var_de5c1562 = $var_8bb5268f = array();
			$var_3d815bdc = $var_43b9b911['name'] ? 'link:' . $var_43b9b911['name'] :'link';
			!$var_43b9b911['tpl'] && $var_43b9b911['tpl'] = 'list';
			$var_ef30f06c = $var_43b9b911['row']?$var_43b9b911['row']:config('links_default_num');
			$var_ef30f06c = min($var_ef30f06c, 999);
			for($var_7ea74e20 = 0;$var_7ea74e20 < $var_ef30f06c;$var_7ea74e20++) {
				$var_36c076f8 = func_f90fd28a($var_3d815bdc);
				list($var_1003d5bb, $var_d089e8c2) = explode('|', $var_36c076f8);
				if (!$var_1003d5bb) {
					continue;
				} 
				$var_1003d5bb = trim($var_1003d5bb);
				if (!preg_match('~https?://~i', $var_1003d5bb)) {
					$var_1003d5bb = 'http://' . $var_1003d5bb;
				} 
				$var_1003d5bb = func_bd68a3eb($var_1003d5bb);
				if (!$var_d089e8c2) {
					if (config('links_title') == 'keywords') {
						$var_d089e8c2 = func_f90fd28a('keywords');
					} else if (config('links_title') == 'txt' && config('links_title_txt')) {
						$var_980a7c7e = config('links_title_txt');
						if (!is_file($var_980a7c7e)) {
							$var_980a7c7e = substr($var_980a7c7e, 0, 1) == '/' ? '.' . $var_980a7c7e:$var_980a7c7e;
						} 
						$var_d089e8c2 = func_f90fd28a($var_980a7c7e);
					} else if (config('links_title') == 'url') {
						$var_d089e8c2 = $var_1003d5bb;
					} else {
						$var_d089e8c2 = func_f90fd28a('title');
						if (config('tobig5')) {
							import('class/Trans');
							$var_fa6bf187 = new Trans;
							$var_d089e8c2 = $var_fa6bf187 -> c2t($var_d089e8c2);
						} 
					} 
				} 
				$var_d089e8c2 = str_replace('"', '', $var_d089e8c2);
				$var_8bb5268f[$var_1003d5bb] = $var_d089e8c2;
			} 
			$var_7ea74e20 = 1;
			foreach($var_8bb5268f as $var_228572b3 => $var_cb83972b) {
				$var_de5c1562[] = array('url' => $var_228572b3, 'title' => $var_cb83972b, 'pic' => $var_43b9b911['image'] ? func_f90fd28a('pic'):'', 'i' => ($var_7ea74e20),);
				$var_7ea74e20++;
			} 
			break;
		case 'domain': if (!config('hulian')) {
				return false;
			} 
			$var_de5c1562 = $var_8bb5268f = array();
			if (!$var_43b9b911['tpl']) {
				if (config('flink_mod') == '2') {
					$var_43b9b911['tpl'] = 'show';
				} else {
					$var_43b9b911['tpl'] = 'index';
				} 
			} 
			if (config('domain_mod') == 2) {
				config('islochost', true);
			} 
			$var_3e28cd01 = isset($var_43b9b911['lochost'])?$var_43b9b911['lochost']:config('islochost');
			for($var_7ea74e20 = 0;$var_7ea74e20 < $var_43b9b911['row'];$var_7ea74e20++) {
				$var_1003d5bb = func_cbbb1b41($var_43b9b911['tpl'], $var_3e28cd01);
				if ($var_1003d5bb) {
					$var_8bb5268f[] = $var_1003d5bb;
				} else {
					$var_43b9b911['row']++;
				} 
			} 
			$var_8bb5268f = array_unique($var_8bb5268f);
			if (config('domain_mod') == 2 && !$var_8bb5268f) {
				return false;
			} 
			$var_d089e8c2 = $var_43b9b911['name']?$var_43b9b911['name']:'';
			foreach($var_8bb5268f as $var_228572b3 => $var_cb83972b) {
				$var_b9b17a69 = parse_url($var_cb83972b);
				if (!$var_d089e8c2) {
					if (config('domain_title') == 'keywords') {
						$var_d089e8c2 = 'keywords';
					} else if (config('domain_title') == 'txt' && config('domain_title_txt')) {
						$var_980a7c7e = config('domain_title_txt');
						if (!is_file($var_980a7c7e)) {
							$var_980a7c7e = substr($var_980a7c7e, 0, 1) == '/' ? '.' . $var_980a7c7e:$var_980a7c7e;
						} 
						$var_d089e8c2 = $var_980a7c7e;
					} else {
						$var_d089e8c2 = 'title';
					} 
				} 
				$var_d089e8c2 = func_50afa725($var_d089e8c2, func_b0d73e82($var_cb83972b, $var_b9b17a69['host']));
				$var_d089e8c2 = str_replace('"', '', $var_d089e8c2);
				$var_de5c1562[] = array('url' => $var_cb83972b, 'title' => $var_d089e8c2, 'i' => ($var_228572b3 + 1),);
			} 
			break;
		case 'keywords': $var_de5c1562 = $var_8bb5268f = array();
			$var_3d815bdc = $var_43b9b911['name'] ? 'keywords:' . $var_43b9b911['name'] :'keywords';
			!$var_43b9b911['tpl'] && $var_43b9b911['tpl'] = 'show';
			for($var_7ea74e20 = 0;$var_7ea74e20 < $var_43b9b911['row'];$var_7ea74e20++) {
				$var_8bb5268f[] = get_url($var_43b9b911['tpl']);
			} 
			$var_8bb5268f = array_unique($var_8bb5268f);
			foreach($var_8bb5268f as $var_228572b3 => $var_cb83972b) {
				$var_a3e5f0ff = func_b0d73e82($var_cb83972b);
				$var_de5c1562[] = array('url' => $var_cb83972b, 'title' => func_50afa725($var_3d815bdc, $var_a3e5f0ff), 'i' => ($var_228572b3 + 1),);
			} 
			break;
		default: $var_de5c1562 = array();
			for($var_7ea74e20 = 0;$var_7ea74e20 < $var_43b9b911['row'];$var_7ea74e20++) {
				$var_de5c1562[] = array('i' => ($var_7ea74e20 + 1),);
			} 
	} 
	if ($var_43b9b911['orderby']) {
		if (stripos($var_43b9b911['orderby'], ' ') > - 1) {
			list($var_6cbe6605, $var_253990b8) = explode(' ', $var_43b9b911['orderby']);
			if (isset($var_de5c1562[0][$var_6cbe6605])) {
				$var_de5c1562 = func_809cbb58($var_de5c1562, $var_6cbe6605);
				if ($var_253990b8 == 'desc' || !$var_253990b8) {
					krsort($var_de5c1562);
				} else {
					ksort($var_de5c1562);
				} 
			} 
		} 
		if ($var_43b9b911['orderby'] == 'asc') {
			sort($var_de5c1562);
		} 
		if ($var_43b9b911['orderby'] == 'desc') {
			rsort($var_de5c1562);
		} 
		if ($var_43b9b911['orderby'] == 'daoxu') {
			$var_de5c1562 = array_reverse($var_de5c1562);
		} 
	} 
	if ($var_98693aab) {
		write($var_f5abc85c, serialize($var_de5c1562));
	} 
	debug_log('loop_' . $var_6af3ba37, 'end');
	$GLOBALS['title_cidfile'] = null;
	$GLOBALS['article_cidfile'] = null;
	$GLOBALS['type_cidfile'] = null;
	return $var_de5c1562;
} 

?>