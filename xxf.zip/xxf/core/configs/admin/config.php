<?php
defined('INI_TXTCMS') or exit();
return array('URL_MODEL' => 2, 'URL_PATH_DEPR' => '-', 'TMPL_COMPILE_CHECK' => true, 'HTML_CACHE' => false, 'DEFAULT_THEME' => '',);
