<?php	return array (
  '18aa6a826462becf4f52c5afb2a529dc' => 'temp/data/typename/news/mingxing.txt',
  'd114fc5177e1a7bb0e9fc1b796b4a44c' => 'temp/data/typename/news/diqu.txt',
);?>