<?php	return array (
  'cba559d1afd233e4e85ecfed52509fea' => 
  array (
    'md5' => 'e6e78e8c7bd7ed0c576640d54d1f898f',
    'file' => 'temp/data/pic/news/picurl-2019.txt',
    'count' => 12902,
  ),
);?>