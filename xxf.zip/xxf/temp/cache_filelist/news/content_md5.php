<?php	return array (
  'b5d49bb6e88bfd0032a3d85b5d412338' => 
  array (
    'md5' => 'b5afcb95481cd9eeb150f4644f4a372b',
    'file' => 'temp/data/content/news/content-2019.txt',
    'count' => 1398,
  ),
  '4c239dfe36577d11bcd5563c852c6f90' => 
  array (
    'md5' => '49682c2eb62d6eebda64079ffa847efb',
    'file' => 'temp/data/content/news/content-2019-04-29.txt',
    'count' => 2984,
  ),
  'ee47be9d6dfbd96b496bef9d171d17b3' => 
  array (
    'md5' => '1dfe1c1741758820cf596427e6080ace',
    'file' => 'temp/data/content/news/content-2017-09-22.txt',
    'count' => 82,
  ),
  '1374280582bcfa39f538c5a0750353c5' => 
  array (
    'md5' => '56570e20c601251c7bf699b8ca55fab0',
    'file' => 'temp/data/content/news/2017-04-01-5.txt',
    'count' => 2193,
  ),
  '8c0aa9ab25a38bd0850b991470b59acb' => 
  array (
    'md5' => '63e8811c0b964d1a5b5c262473000452',
    'file' => 'temp/data/content/news/2017-04-01-4.txt',
    'count' => 6407,
  ),
  '4b88eaf94739d0ec680d7f52789c6044' => 
  array (
    'md5' => '031528ace1c5d7943747d33b9a6ff018',
    'file' => 'temp/data/content/news/2017-04-01-3.txt',
    'count' => 5977,
  ),
  'bb93c54f02d2c4727c31ca011aaf565a' => 
  array (
    'md5' => '06070f38729890324f2fd13e0f12b13a',
    'file' => 'temp/data/content/news/2017-04-01-2.txt',
    'count' => 6346,
  ),
  '5d2a5982910240bbe34aff455f3baabe' => 
  array (
    'md5' => 'c2b80442884a7e86df3e2888e38a8363',
    'file' => 'temp/data/content/news/2017-04-01-1.txt',
    'count' => 5991,
  ),
  '351d66ee8e8b9d071139cd5e1df0426b' => 
  array (
    'md5' => '341072ec34e6b116233bde3b176bc6bb',
    'file' => 'temp/data/content/news/2017-04-01.txt',
    'count' => 6151,
  ),
  '0dac1314e179f968dbed8016939a7990' => 
  array (
    'md5' => '8418e1ec7f5f00ee568baf29fb380f99',
    'file' => 'temp/data/content/news/2017-02-09-15.txt',
    'count' => 1649,
  ),
  '53979876ded35fda504c5eab088dfb27' => 
  array (
    'md5' => '39bcd04403eaa0da427a111aa3aea7f1',
    'file' => 'temp/data/content/news/2017-02-09.txt',
    'count' => 3544,
  ),
  'a7a25b8dd030130fff355246cb5a354d' => 
  array (
    'md5' => '367e9a22d676655fda5e34562a03c9a0',
    'file' => 'temp/data/content/news/2016-10-06.txt',
    'count' => 1508,
  ),
  '082ed5a422254a5ee75883f3bc699931' => 
  array (
    'md5' => 'b765b1b00b6d6bb6164a67b92f925242',
    'file' => 'temp/data/content/news/2016-09-01.txt',
    'count' => 1975,
  ),
  'b1539085618c01bc2fbb9c140b34fe8f' => 
  array (
    'md5' => 'a193d88d2e9ea83ac3166f70f186ec61',
    'file' => 'temp/data/content/news/body.txt',
    'count' => 1253,
  ),
);?>