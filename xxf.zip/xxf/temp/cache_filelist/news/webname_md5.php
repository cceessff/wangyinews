<?php	return array (
  'd307c779b81f1779033b741598bf0ca1' => 
  array (
    'md5' => '8d0279854be3a6fc3348bd75017ce227',
    'file' => 'temp/data/webname/news/44.txt',
    'count' => 17089,
  ),
  '9e5a45eb6e98bdbea4ef41b37bcbc4d2' => 
  array (
    'md5' => '8f9a4ffb20485d850c147900171e677b',
    'file' => 'temp/data/webname/news/webname.txt',
    'count' => 3925,
  ),
);?>