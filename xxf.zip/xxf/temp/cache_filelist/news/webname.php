<?php	return array (
  'd307c779b81f1779033b741598bf0ca1' => 'temp/data/webname/news/44.txt',
  '9e5a45eb6e98bdbea4ef41b37bcbc4d2' => 'temp/data/webname/news/webname.txt',
);?>