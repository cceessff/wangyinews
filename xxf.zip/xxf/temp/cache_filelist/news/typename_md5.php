<?php	return array (
  '18aa6a826462becf4f52c5afb2a529dc' => 
  array (
    'md5' => 'd092eb70c428a15f10be6d976714bef1',
    'file' => 'temp/data/typename/news/mingxing.txt',
    'count' => 3815,
  ),
  'd114fc5177e1a7bb0e9fc1b796b4a44c' => 
  array (
    'md5' => '8df62da17788621176a61cd2d069b84a',
    'file' => 'temp/data/typename/news/diqu.txt',
    'count' => 537,
  ),
);?>