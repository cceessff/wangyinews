<?php	return array (
  '721204ee34e30feb2e189a2b53085b47' => 
  array (
    'md5' => '89541f5dbf00beaaddead91c12ec6068',
    'file' => 'temp/data/title/news/title-2019-05-01-7.txt',
    'count' => 924,
  ),
  '1e3c3c559a6c23c1c415979f91344481' => 
  array (
    'md5' => 'ee612de28317f7a5cb2d1f4eb00cfb78',
    'file' => 'temp/data/title/news/title-2019-05-01-6.txt',
    'count' => 256,
  ),
  '6ce43a981ba080b7ccaf94a8cb21860e' => 
  array (
    'md5' => '48342511179ff9625879a2bbdcd05cc7',
    'file' => 'temp/data/title/news/title-2019-05-01-5.txt',
    'count' => 741,
  ),
  '8c2cfc738d2b6e5aa502210d2ca7701a' => 
  array (
    'md5' => '5064008349ef809582d8a7fb94cd865c',
    'file' => 'temp/data/title/news/title-2019-05-01-4.txt',
    'count' => 671,
  ),
  '5f407d62b0b14aa14ce1acd3c0981396' => 
  array (
    'md5' => '326204f89c81dff19ea3e8638385934f',
    'file' => 'temp/data/title/news/title-2019-05-01-3.txt',
    'count' => 200,
  ),
  'fe0407861d05bb2630b8b2a00197d0d1' => 
  array (
    'md5' => 'f1ad97dd0d5936b844973a675b4c62f4',
    'file' => 'temp/data/title/news/title-2019-05-01-2.txt',
    'count' => 200,
  ),
  'b3d30fa1fd4564d94dd2a42283d3d38c' => 
  array (
    'md5' => '5b02ccc7220fd78b4ab248360276a84f',
    'file' => 'temp/data/title/news/title-2019-05-01-1.txt',
    'count' => 200,
  ),
  'e608973488226a151fc327d1e6c65994' => 
  array (
    'md5' => 'ee8bef0472fdbd333422e2a3d87f8a2f',
    'file' => 'temp/data/title/news/title-2019-05-01.txt',
    'count' => 200,
  ),
  'd79915b4a82448a00be9fe6fe152a099' => 
  array (
    'md5' => '8d6ea373295c6a431ef7edb2c7e6efc6',
    'file' => 'temp/data/title/news/title-2019.txt',
    'count' => 2885,
  ),
);?>