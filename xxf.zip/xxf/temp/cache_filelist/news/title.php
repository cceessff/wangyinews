<?php	return array (
  '721204ee34e30feb2e189a2b53085b47' => 'temp/data/title/news/title-2019-05-01-7.txt',
  '1e3c3c559a6c23c1c415979f91344481' => 'temp/data/title/news/title-2019-05-01-6.txt',
  '6ce43a981ba080b7ccaf94a8cb21860e' => 'temp/data/title/news/title-2019-05-01-5.txt',
  '8c2cfc738d2b6e5aa502210d2ca7701a' => 'temp/data/title/news/title-2019-05-01-4.txt',
  '5f407d62b0b14aa14ce1acd3c0981396' => 'temp/data/title/news/title-2019-05-01-3.txt',
  'fe0407861d05bb2630b8b2a00197d0d1' => 'temp/data/title/news/title-2019-05-01-2.txt',
  'b3d30fa1fd4564d94dd2a42283d3d38c' => 'temp/data/title/news/title-2019-05-01-1.txt',
  'e608973488226a151fc327d1e6c65994' => 'temp/data/title/news/title-2019-05-01.txt',
  'd79915b4a82448a00be9fe6fe152a099' => 'temp/data/title/news/title-2019.txt',
);?>