<?php	return array (
  'cba559d1afd233e4e85ecfed52509fea' => 'temp/data/pic/news/picurl-2019.txt',
);?>