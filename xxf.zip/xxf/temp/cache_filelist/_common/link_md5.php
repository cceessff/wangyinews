<?php	return array (
  'ff666fbe477a84ef17c185ba4672877d' => 
  array (
    'md5' => '60ddc51d66cb74a4e463ad6d2cd8a222',
    'file' => 'temp/data/link/_common/ydurls.txt',
    'count' => 9,
  ),
);?>