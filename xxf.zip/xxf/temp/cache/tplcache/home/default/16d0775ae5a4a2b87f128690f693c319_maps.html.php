<?php if(!defined('IN_TXTCMS')){define('IN_TXTCMS',true);} ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>HTML SiteMap</title>
<style type="text/css">
body{background-color:#fff;margin:20px;font-family:Verdana,Arial,Helvetica,sans-serif;font-size:12px}h1{color:#189115}#intro{background-color:#cef9e4;border:1px #49a92e solid;padding:15px 10px 15px 10px;margin:10px 0 10px 0;line-height:20px;min-width:900px}#myTable{font-size:11px;list-style:none;margin:10px 0 10px 0;padding:0;width:100%;min-width:804px}#myTable li{list-style-type:none;width:100%;min-width:404px;height:20px;line-height:20px}#myTable li .T1-h{float:left;font-weight:700;min-width:300px}#myTable li .T2-h{width:200px;float:right;font-weight:700}#myTable li .T3-h{width:200px;float:right;font-weight:700}#myTable li .T4-h{width:100px;float:right;font-weight:700}#myTable li .T1{float:left;min-width:300px}#myTable li .T2{width:200px;float:right}#myTable li .T3{width:200px;float:right}#myTable li .T4{width:100px;float:right}#footer{padding:2px;margin:0;font-size:8pt;color:gray;min-width:900px}#footer a{color:gray}.myClear{clear:both}
</style>
</head>
<body>
<h1>HTML Sitemap</h1>
<div id="intro">This is an HTML Sitemap</div>
<ul id="myTable">
	<li>
	<div class="T1-h">
		URL
	</div>
	<div class="T2-h">
		Last Change
	</div>
	<div class="T3-h">
		Change Frequency
	</div>
	<div class="T4-h">
		Priority
	</div>
	</li>
	<div class="myClear">
	</div>
	<?php if(!isset($this->_tags_data)){ $this->_tags_data=array(); } if($this->_tags_data["66862f155f4e45ed575eaf9f83c6b22e"]=$this->tag_block_loop(array('type'=>'domain','row'=>'500',))){ foreach($this->_tags_data["66862f155f4e45ed575eaf9f83c6b22e"] as $this->_var["k"]=>$this->_var["vo"]){ ?>
	<li>
		<div class="T1"><a href="<?php echo $this->_var['vo']['url']; ?>"><?php echo $this->_var['vo']['url']; ?></a></div>
		<div class="T2"><?php echo date('Y-m-d H:i:s'); ?></div>
		<div class="T3">Always</div>
		<div class="T4">1.0</div>
	</li>
	<?php }} ?>
	<div class="myClear">
	</div>
</ul>
<div id="footer"></div>
</body>
</html>