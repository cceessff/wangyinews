<?php if(!defined('IN_TXTCMS')){define('IN_TXTCMS',true);} ?><div class="link w960" style="margin:0 auto;">
	<h3 >友情链接</h3>
    <p >
    <?php if(!isset($this->_tags_data)){ $this->_tags_data=array(); } if($this->_tags_data["976aaf4546ee96e17a6fa10824e3d0c5"]=$this->tag_block_loop(array('type'=>'domain',))){ foreach($this->_tags_data["976aaf4546ee96e17a6fa10824e3d0c5"] as $this->_var["k"]=>$this->_var["vo"]){ ?><a href="<?php echo $this->_var['vo']['url']; ?>" target="_blank"><?php echo $this->_var['vo']['title']; ?></a><?php }} ?>
	<?php if($this->_var['links_open']): ?>
   <?php if(!isset($this->_tags_data)){ $this->_tags_data=array(); } if($this->_tags_data["65b2a1fa104e5a94754905a6ce126c2e"]=$this->tag_block_loop(array('type'=>'link',))){ foreach($this->_tags_data["65b2a1fa104e5a94754905a6ce126c2e"] as $this->_var["k"]=>$this->_var["vo"]){ ?>
   <a href="<?php echo $this->_var['vo']['url']; ?>" target="_blank"><?php echo $this->_var['vo']['title']; ?></a>
   <?php }} ?>
   <?php endif; ?>
    </p> 
</div>    </div>
    <div class="footer">
   <div class="copyright"><p >Copyright &copy; 2016 Powered by <a href="<?php echo $this->_var['thisurl']; ?>"><?php echo $this->_var['title']; ?></a>,<a href="<?php echo $this->_var['web_url']; ?>"><?php echo $this->_var['web_name']; ?></a>&nbsp;&nbsp;<?php echo $this->_var['web_tongji']; ?> <a href="http://<?php echo $this->_var['host']; ?>/sitemap.xml">sitemap</a></p></div>
    </div>
	<?php echo $this->_var['web_share']; ?>
<?php echo $this->_var['web_bdpush']; ?>