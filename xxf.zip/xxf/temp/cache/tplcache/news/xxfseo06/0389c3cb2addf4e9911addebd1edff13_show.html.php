<?php if(!defined('IN_TXTCMS')){define('IN_TXTCMS',true);} ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $this->_var['toptitle']; ?></title>
<meta name="keywords" content="<?php echo $this->_var['keywords']; ?>" />
<meta name="description" content="<?php echo $this->_var['description']; ?>" />
<link href="<?php echo $this->_var['theme_path']; ?>/style/dedecms.css" rel="stylesheet" media="screen" type="text/css" />
</head>
<body class="articleview">
<?php echo $this->fetch('head.html'); ?>

<div class="w960 center clear mt1">
<div class="pleft">
 <div class="place"> <strong>当前位置:</strong><a href="/">首页</a> > <a href="<?php echo $this->_var['typeurl']; ?>"><?php echo $this->_var['typename']; ?></a> > <a href="<?php echo $this->_var['thisurl']; ?>"><?php echo $this->_var['title']; ?></a> </div>
 
 <div class="viewbox">
  <div class="title"><h2 ><?php echo $this->_var['title']; ?></h2></div>
  
  <div class="info"><small>时间:</small><?php echo $this->_var['postdate']; ?>来源：<a href="<?php echo $this->_var['web_url']; ?>"><?php echo $this->_var['web_name']; ?></a> <small>作者:</small><?php echo $this->tag_function_typename(array( 'type'=>"name", )); ?></div>
  
	  <div class="content">
	   <table width='100%'>
		<tr>
		 <td>
		 <?php echo $this->_var['body']; ?>
	   </td>
		</tr>
	   </table>
	  </div>

  
  
  <div class="handle">
   <div class="context">
    <ul>
     <li >上一篇：<?php if(!isset($this->_tags_data)){ $this->_tags_data=array(); } if($this->_tags_data["3b5bf96764b6dc98f5d7b5ccda66f15e"]=$this->tag_block_loop(array('type'=>'arclist','row'=>'1',))){ foreach($this->_tags_data["3b5bf96764b6dc98f5d7b5ccda66f15e"] as $this->_var["k"]=>$this->_var["vo"]){ ?><a href="<?php echo $this->_var['vo']['url']; ?>"><?php echo $this->_var['vo']['title']; ?></a><?php }} ?></li>
     <li >下一篇：<?php if(!isset($this->_tags_data)){ $this->_tags_data=array(); } if($this->_tags_data["3b5bf96764b6dc98f5d7b5ccda66f15e"]=$this->tag_block_loop(array('type'=>'arclist','row'=>'1',))){ foreach($this->_tags_data["3b5bf96764b6dc98f5d7b5ccda66f15e"] as $this->_var["k"]=>$this->_var["vo"]){ ?><a href="<?php echo $this->_var['vo']['url']; ?>"><?php echo $this->_var['vo']['title']; ?></a><?php }} ?></li>
    </ul>
   </div>
   
   
  </div>
  
 </div>
 
</div>



<div class="pright">
  <div>
   <dl class="tbox">
    <dt><strong>相关内容</strong></dt>
    <dd>
     <ul class="c1 ico2">
      <?php if(!isset($this->_tags_data)){ $this->_tags_data=array(); } if($this->_tags_data["c03cc48d34b6c4a22bf60cecdc2b4653"]=$this->tag_block_loop(array('type'=>'arclist','row'=>'15','fan'=>'1',))){ foreach($this->_tags_data["c03cc48d34b6c4a22bf60cecdc2b4653"] as $this->_var["k"]=>$this->_var["vo"]){ ?>
      <li ><a href="<?php echo $this->_var['vo']['url']; ?>"><?php echo $this->_var['vo']['title']; ?></a>
      </li><?php }} ?>
     </ul>
    </dd>
   </dl>
  </div>
  <div class="commend mt1">
   <dl class="tbox light">
    <dt class='light'><strong>推荐内容</strong></dt>
    <dd class='light'>
     <ul class="d4">
      <?php if(!isset($this->_tags_data)){ $this->_tags_data=array(); } if($this->_tags_data["28ff61ea4d67f8a108cd941e43cd6088"]=$this->tag_block_loop(array('type'=>'link','row'=>'6','info'=>'1',))){ foreach($this->_tags_data["28ff61ea4d67f8a108cd941e43cd6088"] as $this->_var["k"]=>$this->_var["vo"]){ ?>
      <li ><a href="<?php echo $this->_var['vo']['url']; ?>"><?php echo $this->_var['vo']['title']; ?></a>
      </li>
      <?php }} ?>
     </ul>
    </dd>
   </dl>
  </div>
  
  <div class="hot mt1">
   <dl class="tbox light">
    <dt class='light'><strong>热点内容</strong></dt>
    <dd class='light'>
     <ul class="c1 ico2">
      <?php if(!isset($this->_tags_data)){ $this->_tags_data=array(); } if($this->_tags_data["63603858e4394ea2109f14e27d3d373f"]=$this->tag_block_loop(array('type'=>'arclist','row'=>'15',))){ foreach($this->_tags_data["63603858e4394ea2109f14e27d3d373f"] as $this->_var["k"]=>$this->_var["vo"]){ ?>
      <li ><a href="<?php echo $this->_var['vo']['url']; ?>"><?php echo $this->_var['vo']['title']; ?></a></li>
      <?php }} ?>
     </ul>
    </dd>
   </dl>
  </div>
</div>
</div>

<?php echo $this->fetch('footer.html'); ?>
</body>
</html>
