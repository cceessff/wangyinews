<?php if(!defined('IN_TXTCMS')){define('IN_TXTCMS',true);} ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $this->_var['toptitle']; ?></title>
<meta name="description" content="<?php echo $this->_var['description']; ?>" />
<meta name="keywords" content="<?php echo $this->_var['keywords']; ?>" />
<link href="<?php echo $this->_var['theme_path']; ?>/style/dedecms.css" rel="stylesheet" media="screen" type="text/css" />
</head>
<body class="index">
<?php echo $this->fetch('head.html'); ?>

<div class="w960 center clear mt1">
 <div class="pleft">
  <div class="bignews">
   
   <div class="onenews"> <?php if(!isset($this->_tags_data)){ $this->_tags_data=array(); } if($this->_tags_data["02fb131b5bf05c8d2b3efa955bd6e5cd"]=$this->tag_block_loop(array('type'=>'arclist','row'=>'1','info'=>'1',))){ foreach($this->_tags_data["02fb131b5bf05c8d2b3efa955bd6e5cd"] as $this->_var["k"]=>$this->_var["vo"]){ ?>
    <h2 ><a href="<?php echo $this->_var['vo']['url']; ?>"><?php echo $this->_var['vo']['title']; ?></a></h2>
    <p ><?php echo $this->_var['vo']['info']; ?>...<a href="<?php echo $this->_var['vo']['url']; ?>">[查看全文]</a></p>
    <?php }} ?> </div>
   
   <div class="d1"> <?php if(!isset($this->_tags_data)){ $this->_tags_data=array(); } if($this->_tags_data["1bedd329580713b6158cec922faeb3e8"]=$this->tag_block_loop(array('type'=>'arclist','row'=>'4',))){ foreach($this->_tags_data["1bedd329580713b6158cec922faeb3e8"] as $this->_var["k"]=>$this->_var["vo"]){ ?>
    <div class='d1arc'><a href="<?php echo $this->_var['vo']['url']; ?>"><?php echo $this->_var['vo']['title']; ?></a></div>
    <?php }} ?> </div>
   
   <div class='newarticle'>最新文章</div>
   <ul class="c2 ico1">
    
    <?php if(!isset($this->_tags_data)){ $this->_tags_data=array(); } if($this->_tags_data["e5600196b6e8b5baf2d90c27d15609d2"]=$this->tag_block_loop(array('type'=>'arclist','row'=>'20',))){ foreach($this->_tags_data["e5600196b6e8b5baf2d90c27d15609d2"] as $this->_var["k"]=>$this->_var["vo"]){ ?>
    <li ><a href="<?php echo $this->_var['vo']['url']; ?>"><?php echo $this->_var['vo']['title']; ?></a></li>
    <?php }} ?>
    
   </ul>
  </div>
<div class="flashnews">
<?php if(!isset($this->_tags_data)){ $this->_tags_data=array(); } if($this->_tags_data["3bb616deb6c79c719c8246eff1ad960d"]=$this->tag_block_loop(array('type'=>'arclist','row'=>'1','image'=>'1',))){ foreach($this->_tags_data["3bb616deb6c79c719c8246eff1ad960d"] as $this->_var["k"]=>$this->_var["vo"]){ ?><img src="<?php echo $this->_var['vo']['pic']; ?>" width="296" height="259"><?php }} ?>
</div>
  <div class="latestnews">
   <dl class="tbox light">
    <dt class="light"><strong>本月热门文章</strong></dt>
    <dd class="light">
     <ul class="d2 ico2">
      <?php if(!isset($this->_tags_data)){ $this->_tags_data=array(); } if($this->_tags_data["7169e65830041a5ecbf7c4f7e117aa8e"]=$this->tag_block_loop(array('type'=>'arclist','row'=>'6',))){ foreach($this->_tags_data["7169e65830041a5ecbf7c4f7e117aa8e"] as $this->_var["k"]=>$this->_var["vo"]){ ?>
      <li class='dotline'><a href="<?php echo $this->_var['vo']['url']; ?>"><?php echo $this->_var['vo']['title']; ?></a></li>
      <?php }} ?>
     </ul>
    </dd>
   </dl>
  </div>
  <div class="listbox"> <?php if(!isset($this->_tags_data)){ $this->_tags_data=array(); } if($this->_tags_data["b5e47c5a5068009fc42634853229bc38"]=$this->tag_block_loop(array('type'=>'typename','row'=>'8',))){ foreach($this->_tags_data["b5e47c5a5068009fc42634853229bc38"] as $this->_var["k"]=>$this->_var["vo"]){ ?>

   <dl class="tbox">
    <dt><strong><a href="<?php echo $this->_var['vo']['typeurl']; ?>"><?php echo $this->_var['vo']['typename']; ?></a></strong><span class="more"><a href="<?php echo $this->_var['vo']['typeurl']; ?>">更多...</a></span></dt>
    <dd>
     <ul class="d1 ico3">
      <?php if(!isset($this->_tags_data)){ $this->_tags_data=array(); } if($this->_tags_data["50b4df1f8b39044757ab9851a81c53f1"]=$this->tag_block_loop(array('type'=>'arclist','row'=>'8',))){ foreach($this->_tags_data["50b4df1f8b39044757ab9851a81c53f1"] as $this->_var["k"]=>$this->_var["vo"]){ ?>
      <li ><span ><?php echo $this->_var['vo']['postdate']; ?></span><a href="<?php echo $this->_var['vo']['url']; ?>"><?php echo $this->_var['vo']['title']; ?></a></li>
      <?php }} ?>
     </ul>
    </dd>
   </dl>
  <?php }} ?>
</div>
  
 </div>
 
 <div class="pright">


  <div class="hot mt1">
   <dl class="tbox light">
    <dt class='light'><strong><?php echo $this->tag_function_typename(array( 'type'=>"name", )); ?></strong></dt>
    <dd class='light'>
     <ul class="c1 ico2">
      <?php if(!isset($this->_tags_data)){ $this->_tags_data=array(); } if($this->_tags_data["4a8e6e986ce82f73718ded01b856df51"]=$this->tag_block_loop(array('type'=>'arclist','row'=>'16',))){ foreach($this->_tags_data["4a8e6e986ce82f73718ded01b856df51"] as $this->_var["k"]=>$this->_var["vo"]){ ?>
      <li ><a href="<?php echo $this->_var['vo']['url']; ?>"><?php echo $this->_var['vo']['title']; ?></a></li>
      <?php }} ?>
     </ul>
    </dd>
   </dl>
  </div>

  <div class="hot mt1">
   <dl class="tbox light">
    <dt class='light'><strong><?php echo $this->tag_function_typename(array( 'type'=>"name", )); ?></strong></dt>
    <dd class='light'>
     <ul class="c1 ico2">
      <?php if(!isset($this->_tags_data)){ $this->_tags_data=array(); } if($this->_tags_data["dcf93399581a94f79ecbcc2177273230"]=$this->tag_block_loop(array('type'=>'link','row'=>'11',))){ foreach($this->_tags_data["dcf93399581a94f79ecbcc2177273230"] as $this->_var["k"]=>$this->_var["vo"]){ ?>
      <li ><a href="<?php echo $this->_var['vo']['url']; ?>"><?php echo $this->_var['vo']['title']; ?></a></li>
      <?php }} ?>
     </ul>
    </dd>
   </dl>
  </div>

  <div class="commend mt1">
   <dl class="tbox light">
    <dt class='light'><strong>推荐文章</strong></dt>
    <dd class='light'>
     <ul class="c1 ico2">
      <?php if(!isset($this->_tags_data)){ $this->_tags_data=array(); } if($this->_tags_data["5d37222614561fd99ab348e80ffa9163"]=$this->tag_block_loop(array('type'=>'arclist','row'=>'12','fan'=>'1',))){ foreach($this->_tags_data["5d37222614561fd99ab348e80ffa9163"] as $this->_var["k"]=>$this->_var["vo"]){ ?>
      <li class='dotline'><a href="<?php echo $this->_var['vo']['url']; ?>"><?php echo $this->_var['vo']['title']; ?></a></li>
      <?php }} ?>
     </ul>
    </dd>
   </dl>
  </div>
  

  <div class="hot mt1">
   <dl class="tbox light">
    <dt class='light'><strong>热门文章</strong></dt>
    <dd class='light'>
     <ul class="c1 ico2">
      <?php if(!isset($this->_tags_data)){ $this->_tags_data=array(); } if($this->_tags_data["1dfbfbf2e201e9964dee439c0ed8ced6"]=$this->tag_block_loop(array('type'=>'arclist','row'=>'12',))){ foreach($this->_tags_data["1dfbfbf2e201e9964dee439c0ed8ced6"] as $this->_var["k"]=>$this->_var["vo"]){ ?>
      <li class='dotline'><a href="<?php echo $this->_var['vo']['url']; ?>"><?php echo $this->_var['vo']['title']; ?></a></li>
      <?php }} ?>
     </ul>
    </dd>
   </dl>
  </div>

  <div style="margin:10 auto"></div>
 </div>
 
</div>
<?php echo $this->fetch('footer.html'); ?>
</body>
</html>
