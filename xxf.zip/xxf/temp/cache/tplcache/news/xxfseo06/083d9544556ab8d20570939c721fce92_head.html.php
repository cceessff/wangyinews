<?php if(!defined('IN_TXTCMS')){define('IN_TXTCMS',true);} ?><div class="header_top">  
    <div class="w960 center">  
     <span id="time" class="time"></span>
     <div class="toplinks"></div>
    </div> 
</div>
<div class="header">
    <h1 >
  <a href="<?php echo $this->_var['web_url']; ?>"><img src="/uploads/images/logo.png?n=<?php echo $this->_var['encode_name']; ?>&w=230"></a> </h1>
    <div class="search">
	  <form name="formsearch" action="">
           <input type="hidden" name="kwtype" value="0">
           <input name="q" type="text" class="search-keyword" id="search-keyword" value="在这里搜索..." onfocus="if(this.value=='在这里搜索...'){this.value='';}" onblur="if(this.value==''){this.value='在这里搜索...';}">
          <button type="submit" class="search-submit">搜一下</button>
      </form>
      
	</div>
</div>
<div class="nav_bg">
  <ul class="nav">
      	<a href='/' class="hvoer">首页</a>
      	<?php if(!isset($this->_tags_data)){ $this->_tags_data=array(); } if($this->_tags_data["70569b2f1232e041990b784bcf39683e"]=$this->tag_block_menu(array('row'=>'8',))){ foreach($this->_tags_data["70569b2f1232e041990b784bcf39683e"] as $this->_var["k"]=>$this->_var["vo"]){ ?>
      	<a href='<?php echo $this->_var['vo']['typeurl']; ?>' ><?php echo $this->_var['vo']['typename']; ?></a>
      	<?php }} ?>
  </ul>
</div>

