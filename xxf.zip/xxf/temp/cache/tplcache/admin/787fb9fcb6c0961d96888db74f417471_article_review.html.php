<?php if(!defined('IN_TXTCMS')){define('IN_TXTCMS',true);} ?><?php echo $this->fetch('header.html'); ?>
<div class="divtips">
	<p>提示：仅预览前20条</p>
</div>
<div style="max-height:400px;overflow:auto;background:#eee;">
		<table border="0" align="center" cellpadding="3" cellspacing="1" class="table_b">
		<tr>
		  <td class="title_bg">标题</td>
		  <td width="80" align='center' class="title_bg">缩略图</td>
		</tr>
	<?php $_from=$this->_var['list']; if(!is_array($_from) && !is_object($_from)){ settype($_from, 'array'); }; $this->push_vars('k', 'vo');if(count($_from)):
    foreach($_from AS $this->_var['k'] => $this->_var['vo']):
?>
		<tr onmouseover=this.bgColor='#EDF8FE'; onmouseout=this.bgColor='#ffffff'; bgcolor='#ffffff'>
		  <td>&nbsp;&nbsp;<?php echo $this->_var['vo']['title']; ?></td>
		  <td align='center'><?php if($this->_var['vo']['litpic']): ?><font color="green">有</font><?php else: ?><font color="red">无</font><?php endif; ?></td>
		</tr>
	<?php endforeach; else: ?>
		<tr bgcolor='#ffffff'>
			<td colspan='2' height="25" align="center">暂无文档！</td>
		</tr>
	<?php endif; unset($_from); ?><?php $this->pop_vars(); ?>
		</table>
</div>