<?php if(!defined('IN_TXTCMS')){define('IN_TXTCMS',true);} ?><?php echo $this->fetch('header.html'); ?>
<body class="body-main">
<ul id="admin_sub_title">
	<li class="sub"><a href="javascript:void(0)">蜘蛛防火墙设置</a></li>
</ul>
<div id="admin_right_b">

<form action="?admin-robot-Update" method="post">
<table border="0" cellpadding="8" cellspacing="1" class="tableConfig">
<tr>
	<td align="right" width="120">蜘蛛防火墙开关：</td>
	<td class="icheck_radios"><label><input type="radio" name="con[web_robot_ban]" value="1" <?php if($this->_var['web_robot_ban']): ?> checked<?php endif; ?>>开启</label>
	<label><input type="radio" name="con[web_robot_ban]" value="0" <?php if(! $this->_var['web_robot_ban']): ?> checked<?php endif; ?>>关闭</label>
	</td>
</tr>
<tr>
	<td colspan="2">
		<table border="0" align="center" cellpadding="8" cellspacing="1">
		<tr align="center">
		  <td width="110" align='center' class="title_bg">蜘蛛名称</td>
		  <td align='center' class="title_bg">屏蔽</td>
		  <td width="110" align='center' class="title_bg">蜘蛛名称</td>
		  <td align='center' class="title_bg">屏蔽</td>
		</tr>
		<?php $i=1; ?>
		<?php $_from=$this->_var['robot_list']; if(!is_array($_from) && !is_object($_from)){ settype($_from, 'array'); }; $this->push_vars('key', 'vo');if(count($_from)):
    foreach($_from AS $this->_var['key'] => $this->_var['vo']):
?>
		<?php if($i==1):?><tr><?php endif; ?>
			<td align="right"><label for="in_<?php echo $this->_var['key']; ?>"><?php echo $this->_var['vo']; ?></label></td>
			<td align='center'><input type="checkbox" name="con[web_robot_ban_list][]" id="in_<?php echo $this->_var['key']; ?>" value="<?php echo $this->_var['key']; ?>" <?php if($this->_var['web_robot_ban_list'] && in_array ( $this->_var['key'] , $this->_var['web_robot_ban_list'] )): ?> checked<?php endif; ?> /></td>
				<?php if($i!=$this->_var['list_last'] and ($i%2==0)):?>
					</tr><tr>
				<?php endif; ?>
			<?php $i++; ?>
		<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars(); ?>
		<tr bgcolor='#ffffff'>
			<td colspan="8"><label><input name="chkall" type="checkbox" id="chkall" onclick=checkall(this.form) value="checkbox"> 全选/反选</label></td>
		</tr>
		</table>
		<tr class="tdbg">
		  <td colspan="2"><button type="submit" id="dosave" class="button button_submit">保存设置</button></td>
		</tr>
	</td>
</tr>
</table>
</form>
<div class="runtime"></div>  
</div>
<?php echo $this->fetch('footer.html'); ?>
</body>
</html>