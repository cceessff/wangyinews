<?php if(!defined('IN_TXTCMS')){define('IN_TXTCMS',true);} ?><?php echo $this->fetch('header.html'); ?>
<div style="padding:0 10px 10px 10px;">
	<table border="0" align="center" cellpadding="8" cellspacing="0" class="tableConfig">
		<tbody>
			<tr class="tdbg item_title">
				<td align="right"><i class="typcn typcn-cog"></i> 上传<font class="title"></font></td>
				<td></td>
			</tr>
			<tr>
				<td align="right">所属分组：</td> 
				<td align="left"><select name="arctype" id="arctype" onchange="change_type(this.value);">
				<?php $_from=$this->_var['class_list']; if(!is_array($_from) && !is_object($_from)){ settype($_from, 'array'); }; $this->push_vars('k', 'vo');if(count($_from)):
    foreach($_from AS $this->_var['k'] => $this->_var['vo']):
?>
					<option value="<?php echo $this->_var['vo']['dirname']; ?>"><?php echo $this->_var['vo']['name']; ?></option>
				<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars(); ?>
					</select>
				</td>
			</tr>
			<tr>
			  <td align="right" width="150" class="config_td_first">上传文件：</td>
			  <td id="updiv">
				<div id="up<?php echo $this->_var['input_name']; ?>" class="uploader">
					<div class="uploader-list"></div>
					<div class="uploader-btns">
						<div class="picker">选择文件</div>
						<button type="button" class="uploadbtn button button_grey">开始上传</button>
					</div>
				</div>
				<div style="padding-top:10px;color:green">上传<font class="title"></font>txt，支持多选，不建议使用中文文件名</div>
			  </td>
			</tr>
			<?php if($this->_var['input_name'] == 'article'): ?>
				<tr><td>&nbsp;</td><td><font color="red">文章库每行一篇文章，格式：标题******内容</font></td></tr>
			<?php endif; ?>
		</tbody>
	</table>
</div>
<style type="text/css">
.webuploader-container .webuploader-pick .webuploader-pick{ padding:0;}
</style>
<script type="text/javascript">
var type=top.art.dialog.data('type');
$("#arctype").find("option[value='"+type+"']").attr("selected",true);
upload('#up<?php echo $this->_var['input_name']; ?>','txt',null,'<?php echo $this->_var['input_name']; ?>/'+$('#arctype').val());
$('.title').html(top.art.dialog.data('title'));
var html=$('#updiv').html();
var i=1;

function change_type(value){
	$('#updiv').html('');
	var newhtml=html.replace('up<?php echo $this->_var['input_name']; ?>','up<?php echo $this->_var['input_name']; ?>'+i);
	$('#updiv').html(newhtml);
	upload('#up<?php echo $this->_var['input_name']; ?>'+i,'txt',null,'<?php echo $this->_var['input_name']; ?>/'+value);
	i++;
}
</script>