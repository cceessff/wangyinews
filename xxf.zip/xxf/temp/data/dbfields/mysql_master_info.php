<?php	return array (
  'names' => 
  array (
    0 => 'id',
    1 => 'logip',
    2 => 'logtime',
    3 => 'name',
    4 => 'nick',
    5 => 'pass',
    6 => 'sys',
  ),
  '_autoinc' => true,
  '_pk' => 'id',
  '_default' => 
  array (
    'id' => NULL,
    'logip' => NULL,
    'logtime' => NULL,
    'name' => NULL,
    'nick' => NULL,
    'pass' => NULL,
    'sys' => NULL,
  ),
  '_type' => 
  array (
    'id' => 'int',
    'logip' => 'varchar',
    'logtime' => 'int',
    'name' => 'varchar',
    'nick' => 'varchar',
    'pass' => 'varchar',
    'sys' => 'varchar',
  ),
  '_notnull' => 
  array (
    'id' => true,
    'logip' => false,
    'logtime' => false,
    'name' => false,
    'nick' => false,
    'pass' => false,
    'sys' => false,
  ),
);?>