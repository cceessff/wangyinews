<?php 

if (@$_SERVER ["HTTP_USER_AGENT"] == '') {
	exit('.');
} 
$var_5eb48332 = array('ltx71.com', 'scrapy', 'semrush', 'Bytespider', 'baidu.sogo.uc.UCBrowser');
foreach($var_5eb48332 as $var_228572b3 => $var_cb83972b) {
	if (stripos($_SERVER ["HTTP_USER_AGENT"], $var_cb83972b) > - 1) {
		exit;
	} 
} 
define('APP_DEBUG', true);
define('APP_ROOT', str_replace('\\', '/', dirname(__FILE__)) . '/');
require APP_ROOT . 'core/xxfseo/xxfseo.php';
